import JSONAPIAdapter from 'ember-data/adapters/json-api';

export default JSONAPIAdapter.extend({
  buildURL: function() {
    return this._super(...arguments) + '?include=buttons';
  }
});
