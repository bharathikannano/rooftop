export default {
  mobile: '(max-width: 767px)' /* Mobile Specific */,
  tablet: '(min-width: 768px)' /* Tablet and Above */,
  tabletOnly: '(min-width: 768px) and (max-width: 991px)' /* Tablet Specific */,
  desktop: '(min-width: 992px)' /* Desktop and Above */,
  desktopOnly: '(min-width: 992px) and (max-width: 1200px)' /* Desktop Specific */,
  jumbo: '(min-width: 1201px)' /* Jumbo */
};
