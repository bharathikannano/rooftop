import Component from '@ember/component';
import layout from '../templates/components/account-disclaimer';

export default Component.extend({
  layout,
  tagName: '',
  actions: {
    goToAccountOpening() {
      this.sendAction('goToAccountOpening');
    }
  }
});
