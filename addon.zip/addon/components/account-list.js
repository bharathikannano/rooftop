import Component from '@ember/component';
import layout from '../templates/components/account-list';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';
export default Component.extend(quickEvent, {
  layout
});
