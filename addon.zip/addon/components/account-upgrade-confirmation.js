import Component from '@ember/component';
import layout from '../templates/components/account-upgrade-confirmation';
import { inject as service } from '@ember/service';
import fetch from 'fetch';

export default Component.extend({
  layout,
  classNames: ['rdc-component-base account-upgrade-confirmation'],
  rdcLoadingIndicator: service(),
  init() {
    this._super(...arguments);
    this.getNgData();
  },
  // To get account data from JSON.
  getNgData() {
    this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
    let path = 'https://av.sc.com/configuration/ng-start-application',
      host = window.location.host.indexOf('sit') != -1 || window.location.host.indexOf('uat') != -1 ? '-test' : '';
    let response = fetch(path + host + '.json');
    response
      .then(response => response.json())
      .then(response => {
        let ngData = response;
        // Getting only the Instant Plus account data for showing here.
        let instantPlusData = ngData.ngStartApplication.accountInformation.category.filter(
          account => account.title === 'Instant Plus Account'
        );
        this.set('instantPlusData', instantPlusData[0]);
        // Getting only the required docs out of all required docs.
        this.set('docs', instantPlusData[0].required.document.slice(2));
        this.get('rdcLoadingIndicator').hideLoadingIndicator(' ');
      })
      .catch(() => {
        this.get('rdcLoadingIndicator').hideLoadingIndicator(' ');
        return;
      });
  },
  actions: {
    upgradeAccount(upgradeFlag) {
      this.sendAction('upgradeNgAccount', upgradeFlag);
    }
  }
});
