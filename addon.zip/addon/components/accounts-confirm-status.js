import { inject as service } from '@ember/service';
import Component from '@ember/component';

export default Component.extend({
  queries: service('customer-info'),

  init() {
    this.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    let accData = this.get('pageData.accData') != undefined ? this.get('pageData.accData') : [];
    accData.forEach(data => {
      if (data.get('isSelected') == 'true') {
        if (data.get('isAccType') == 'Primary' && data.get('blockListCat').toLowerCase() == 'primary') {
          this.set('primaryAcc', data);
        } else if (
          data.get('isAccType') == 'other-account-active OtherAccount1' &&
          data.get('blockListCat').toLowerCase() == 'supplementary'
        ) {
          this.set('otherAcccounts1', data);
          this.set('otherAcccountsEnable', true);
        } else if (
          data.get('isAccType') == 'other-account-active OtherAccount2' &&
          data.get('blockListCat').toLowerCase() == 'supplementary'
        ) {
          this.set('otherAcccounts2', data);
          this.set('otherAcccountsEnable', true);
        }
      }
    });
    this.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    this._super(...arguments);
  },

  actions: {
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    }
  }
});
