import { inject as service } from '@ember/service';
import Component from '@ember/component';
import layout from '../templates/components/accountselect-action-modal';
export default Component.extend({
  layout,
  store: service(),
  rdcModalManager: service(),
  init() {
    let accData = this.get('model.accountList') != undefined ? this.get('model.accountList') : [];
    let accountTypeFilter = this.get('model.accountTypeFilter');
    if (this.get('model.debitFrom')) {
      this.set('accList', accData);
    } else {
      let newPeople = [];
      accData.forEach(function(item) {
        if (
          item.get('blockListCat').toLowerCase() == accountTypeFilter &&
          (item.get('isSelected') == undefined || item.get('isSelected') == 'false')
        ) {
          newPeople.push(item);
        }
      });
      this.set('accList', newPeople);
    }
    this._super(...arguments);
  },

  actions: {
    actionSelectedAccount(item) {
      this.get('rdcModalManager').closeModalResolve(item);
    }
  }
});
