import Component from '@ember/component';
import layout from '../templates/components/add-country-search';
import { A, makeArray } from '@ember/array';
import { inject as service } from '@ember/service';
import { isNone } from '@ember/utils';
import { later } from '@ember/runloop';

export default Component.extend({
  layout,
  i18n: service(),
  filteredArray: null,
  selectedItems: null,
  selectedCountries: null,

  init() {
    this._super(...arguments);

    this.set('countries', [
      { countryId: 'ALB', countryId2: 'AL', countryName: 'Albania' },
      { countryId: 'DZA', countryId2: 'DZ', countryName: 'Algeria' },
      { countryId: 'ASM', countryId2: 'AS', countryName: 'American Samoa' },
      { countryId: 'AND', countryId2: 'AD', countryName: 'Andorra' },
      { countryId: 'AGO', countryId2: 'AO', countryName: 'Angola' },
      { countryId: 'AIA', countryId2: 'AI', countryName: 'Anguilla' },
      { countryId: 'ATA', countryId2: 'AQ', countryName: 'Antarctica' },
      { countryId: 'ATG', countryId2: 'AG', countryName: 'Antigua and Barbuda' },
      { countryId: 'ARG', countryId2: 'AR', countryName: 'Argentina' },
      { countryId: 'ARM', countryId2: 'AM', countryName: 'Armenia' },
      { countryId: 'ABW', countryId2: 'AW', countryName: 'Aruba' },
      { countryId: 'AUS', countryId2: 'AU', countryName: 'Australia' },
      { countryId: 'AUT', countryId2: 'AT', countryName: 'Austria' },
      { countryId: 'AZE', countryId2: 'AZ', countryName: 'Azerbaijan' },
      { countryId: 'BHS', countryId2: 'BS', countryName: 'Bahamas' },
      { countryId: 'BHR', countryId2: 'BH', countryName: 'Bahrain' },
      { countryId: 'BGD', countryId2: 'BD', countryName: 'Bangladesh' },
      { countryId: 'BRB', countryId2: 'BB', countryName: 'Barbados' },
      { countryId: 'BLR', countryId2: 'BY', countryName: 'Belarus' },
      { countryId: 'BEL', countryId2: 'BE', countryName: 'Belgium' },
      { countryId: 'BLZ', countryId2: 'BZ', countryName: 'Belize' },
      { countryId: 'BEN', countryId2: 'BJ', countryName: 'Benin' },
      { countryId: 'BMU', countryId2: 'BM', countryName: 'Bermuda' },
      { countryId: 'BTN', countryId2: 'BT', countryName: 'Bhutan' },
      { countryId: 'BOL', countryId2: 'BO', countryName: 'Bolivia' },
      { countryId: 'BIH', countryId2: 'BA', countryName: 'Bosnia and Herzegovina' },
      { countryId: 'BWA', countryId2: 'BW', countryName: 'Botswana' },
      { countryId: 'BVT', countryId2: 'BV', countryName: 'Bouvet Island' },
      { countryId: 'BRA', countryId2: 'BR', countryName: 'Brazil' },
      { countryId: 'IOT', countryId2: 'IO', countryName: 'British Indian Ocean Territory' },
      { countryId: 'VGB', countryId2: 'VG', countryName: 'British Virgin Islands' },
      { countryId: 'BRN', countryId2: 'BN', countryName: 'Brunei Darussalam' },
      { countryId: 'BGR', countryId2: 'BG', countryName: 'Bulgaria' },
      { countryId: 'BFA', countryId2: 'BF', countryName: 'Burkina Faso' },
      { countryId: 'BDI', countryId2: 'BI', countryName: 'Burundi' },
      { countryId: 'KHM', countryId2: 'KH', countryName: 'Cambodia' },
      { countryId: 'CMR', countryId2: 'CM', countryName: 'Cameroon, United Republic of' },
      { countryId: 'CAN', countryId2: 'CA', countryName: 'Canada' },
      { countryId: 'CPV', countryId2: 'CV', countryName: 'Cape Verde Island' },
      { countryId: 'CYM', countryId2: 'KY', countryName: 'Cayman Islands' },
      { countryId: 'CAF', countryId2: 'CF', countryName: 'Central African Republic' },
      { countryId: 'TCD', countryId2: 'TD', countryName: 'Chad' },
      { countryId: 'CHL', countryId2: 'CL', countryName: 'Chile' },
      { countryId: 'CHN', countryId2: 'CN', countryName: 'China' },
      { countryId: 'CXR', countryId2: 'CX', countryName: 'Christmas Island' },
      { countryId: 'CCK', countryId2: 'CC', countryName: 'Cocos (Keeling) Islands' },
      { countryId: 'COL', countryId2: 'CO', countryName: 'Colombia' },
      { countryId: 'COM', countryId2: 'KM', countryName: 'Comoros' },
      { countryId: 'COG', countryId2: 'CG', countryName: 'Congo' },
      { countryId: 'COK', countryId2: 'CK', countryName: 'Cook Islands' },
      { countryId: 'CRI', countryId2: 'CR', countryName: 'Costa Rica' },
      { countryId: 'CIV', countryId2: 'CI', countryName: "Côte d'Ivoire (Ivory Coast)" },
      { countryId: 'HRV', countryId2: 'HR', countryName: 'Croatia' },
      { countryId: 'CUB', countryId2: 'CU', countryName: 'Cuba' },
      { countryId: 'CYP', countryId2: 'CY', countryName: 'Cyprus' },
      { countryId: 'CZE', countryId2: 'CZ', countryName: 'Czech Republic' },
      { countryId: 'COD', countryId2: 'CD', countryName: 'Democratic Republic of the Congo' },
      { countryId: 'DNK', countryId2: 'DK', countryName: 'Denmark' },
      { countryId: 'DJI', countryId2: 'DJ', countryName: 'Djibouti' },
      { countryId: 'DMA', countryId2: 'DM', countryName: 'Dominica' },
      { countryId: 'DOM', countryId2: 'DO', countryName: 'Dominican Republic' },
      { countryId: 'ECU', countryId2: 'EC', countryName: 'Ecuador' },
      { countryId: 'EGY', countryId2: 'EG', countryName: 'Egypt' },
      { countryId: 'SLV', countryId2: 'SV', countryName: 'El Salvador' },
      { countryId: 'GNQ', countryId2: 'GQ', countryName: 'Equatorial Guinea' },
      { countryId: 'ERI', countryId2: 'ER', countryName: 'Eritrea' },
      { countryId: 'EST', countryId2: 'EE', countryName: 'Estonia' },
      { countryId: 'ETH', countryId2: 'ET', countryName: 'Ethiopia' },
      { countryId: 'FLK', countryId2: 'FK', countryName: 'Falkland Islands (Malvinas)' },
      { countryId: 'FRO', countryId2: 'FO', countryName: 'Faroe Islands' },
      { countryId: 'FJI', countryId2: 'FJ', countryName: 'Fiji' },
      { countryId: 'FIN', countryId2: 'FI', countryName: 'Finland' },
      { countryId: 'FRA', countryId2: 'FR', countryName: 'France' },
      { countryId: 'GUF', countryId2: 'GF', countryName: 'French Guiana' },
      { countryId: 'PYF', countryId2: 'PF', countryName: 'French Polynesia' },
      { countryId: 'ATF', countryId2: 'TF', countryName: 'French Southern Territories' },
      { countryId: 'GAB', countryId2: 'GA', countryName: 'Gabon' },
      { countryId: 'GMB', countryId2: 'GM', countryName: 'Gambia' },
      { countryId: 'GEO', countryId2: 'GE', countryName: 'Georgia' },
      { countryId: 'DEU', countryId2: 'DE', countryName: 'Germany' },
      { countryId: 'GHA', countryId2: 'GH', countryName: 'Ghana' },
      { countryId: 'GIB', countryId2: 'GI', countryName: 'Gibralter' },
      { countryId: 'GRC', countryId2: 'GR', countryName: 'Greece' },
      { countryId: 'GRL', countryId2: 'GL', countryName: 'Greenland' },
      { countryId: 'GRD', countryId2: 'GD', countryName: 'Grenada' },
      { countryId: 'GLP', countryId2: 'GP', countryName: 'Guadeloupe' },
      { countryId: 'GUM', countryId2: 'GU', countryName: 'Guam' },
      { countryId: 'GTM', countryId2: 'GT', countryName: 'Guatamala' },
      { countryId: 'GIN', countryId2: 'GN', countryName: 'Guinea' },
      { countryId: 'GNB', countryId2: 'GW', countryName: 'Guinea-Bissau' },
      { countryId: 'GUY', countryId2: 'GY', countryName: 'Guyana' },
      { countryId: 'HTI', countryId2: 'HT', countryName: 'Haiti' },
      { countryId: 'HMD', countryId2: 'HM', countryName: 'Heard and McDonald Islands' },
      { countryId: 'VAT', countryId2: 'VA', countryName: 'Holy See (Vatican City State)' },
      { countryId: 'HND', countryId2: 'HN', countryName: 'Honduras' },
      { countryId: 'HKG', countryId2: 'HK', countryName: 'Hong Kong' },
      { countryId: 'HUN', countryId2: 'HU', countryName: 'Hungary' },
      { countryId: 'ISL', countryId2: 'IS', countryName: 'Iceland' },
      { countryId: 'IND', countryId2: 'IN', countryName: 'India' },
      { countryId: 'IDN', countryId2: 'ID', countryName: 'Indonesia' },
      { countryId: 'IRN', countryId2: 'IR', countryName: 'Iran, Islamic Republic of' },
      { countryId: 'IRQ', countryId2: 'IQ', countryName: 'Iraq' },
      { countryId: 'IRL', countryId2: 'IE', countryName: 'Ireland, Republic of' },
      { countryId: 'ISR', countryId2: 'IL', countryName: 'Israel' },
      { countryId: 'ITA', countryId2: 'IT', countryName: 'Italy' },
      { countryId: 'JAM', countryId2: 'JM', countryName: 'Jamaica' },
      { countryId: 'JPN', countryId2: 'JP', countryName: 'Japan' },
      { countryId: 'JOR', countryId2: 'JO', countryName: 'Jordan' },
      { countryId: 'KAZ', countryId2: 'KZ', countryName: 'Kazakhstan' },
      { countryId: 'KEN', countryId2: 'KE', countryName: 'Kenya' },
      { countryId: 'KIR', countryId2: 'KI', countryName: 'Kiribati' },
      { countryId: 'KOR', countryId2: 'KR', countryName: 'Korea, Republic of' },
      { countryId: 'PRK', countryId2: 'KP', countryName: "Korea, Democratic People's Republic of" },
      { countryId: 'KWT', countryId2: 'KW', countryName: 'Kuwait' },
      { countryId: 'KGZ', countryId2: 'KG', countryName: 'Kyrgyzstan' },
      { countryId: 'LAO', countryId2: 'LA', countryName: 'Laos' },
      { countryId: 'LVA', countryId2: 'LV', countryName: 'Latvia' },
      { countryId: 'LBN', countryId2: 'LB', countryName: 'Lebanon' },
      { countryId: 'LSO', countryId2: 'LS', countryName: 'Lesotho' },
      { countryId: 'LBR', countryId2: 'LR', countryName: 'Liberia' },
      { countryId: 'LBY', countryId2: 'LY', countryName: 'Libyan Arab Jamahiriya' },
      { countryId: 'LIE', countryId2: 'LI', countryName: 'Liechtenstein' },
      { countryId: 'LTU', countryId2: 'LT', countryName: 'Lithuania' },
      { countryId: 'LUX', countryId2: 'LU', countryName: 'Luxembourg' },
      { countryId: 'MAC', countryId2: 'MO', countryName: 'Macau, China' },
      { countryId: 'MKD', countryId2: 'MK', countryName: 'Macedonia' },
      { countryId: 'MDG', countryId2: 'MG', countryName: 'Madagascar' },
      { countryId: 'MWI', countryId2: 'MW', countryName: 'Malawi' },
      { countryId: 'MYS', countryId2: 'MY', countryName: 'Malaysia' },
      { countryId: 'MDV', countryId2: 'MV', countryName: 'Maldives' },
      { countryId: 'MLI', countryId2: 'ML', countryName: 'Mali' },
      { countryId: 'MLT', countryId2: 'MT', countryName: 'Malta' },
      { countryId: 'MHL', countryId2: 'MH', countryName: 'Marshall Islands' },
      { countryId: 'MTQ', countryId2: 'MQ', countryName: 'Martinique' },
      { countryId: 'MRT', countryId2: 'MR', countryName: 'Mauritania' },
      { countryId: 'MUS', countryId2: 'MU', countryName: 'Mauritius' },
      { countryId: 'MYT', countryId2: 'YT', countryName: 'Mayotte' },
      { countryId: 'MEX', countryId2: 'MX', countryName: 'Mexico' },
      { countryId: 'FSM', countryId2: 'FM', countryName: 'Micronesia' },
      { countryId: 'MDA', countryId2: 'MD', countryName: 'Moldova, Republic of' },
      { countryId: 'MCO', countryId2: 'MC', countryName: 'Monaco' },
      { countryId: 'MNG', countryId2: 'MN', countryName: 'Mongolia' },
      { countryId: 'MSR', countryId2: 'MS', countryName: 'Montserrat' },
      { countryId: 'MNE', countryId2: 'ME', countryName: 'Montenegro' },
      { countryId: 'MAR', countryId2: 'MA', countryName: 'Morocco' },
      { countryId: 'MOZ', countryId2: 'MZ', countryName: 'Mozambique' },
      { countryId: 'MMR', countryId2: 'MM', countryName: 'Myanmar' },
      { countryId: 'NAM', countryId2: 'NA', countryName: 'Namibia' },
      { countryId: 'NRU', countryId2: 'NR', countryName: 'Nauru' },
      { countryId: 'NPL', countryId2: 'NP', countryName: 'Nepal' },
      { countryId: 'NLD', countryId2: 'NL', countryName: 'Netherlands' },
      { countryId: 'ANT', countryId2: 'AN', countryName: 'Netherlands Antilles' },
      { countryId: 'NCL', countryId2: 'NC', countryName: 'New Caledonia' },
      { countryId: 'NZL', countryId2: 'NZ', countryName: 'New Zealand' },
      { countryId: 'NIC', countryId2: 'NI', countryName: 'Nicaragua' },
      { countryId: 'NER', countryId2: 'NE', countryName: 'Niger' },
      { countryId: 'NGA', countryId2: 'NG', countryName: 'Nigeria' },
      { countryId: 'NIU', countryId2: 'NU', countryName: 'Niue' },
      { countryId: 'NFK', countryId2: 'NF', countryName: 'Norfolk Island' },
      { countryId: 'MNP', countryId2: 'MP', countryName: 'Northern Mariana Islands' },
      { countryId: 'NOR', countryId2: 'NO', countryName: 'Norway' },
      { countryId: 'OMN', countryId2: 'OM', countryName: 'Oman' },
      { countryId: 'PAK', countryId2: 'PK', countryName: 'Pakistan' },
      { countryId: 'PLW', countryId2: 'PW', countryName: 'Palau' },
      { countryId: 'PSE', countryId2: 'PS', countryName: 'Palestine, State of' },
      { countryId: 'PAN', countryId2: 'PA', countryName: 'Panama' },
      { countryId: 'PNG', countryId2: 'PG', countryName: 'Papua New Guinea' },
      { countryId: 'PRY', countryId2: 'PY', countryName: 'Paraguay' },
      { countryId: 'PER', countryId2: 'PE', countryName: 'Peru' },
      { countryId: 'PHL', countryId2: 'PH', countryName: 'Philippines' },
      { countryId: 'PCN', countryId2: 'PN', countryName: 'Pitcairn' },
      { countryId: 'POL', countryId2: 'PL', countryName: 'Poland' },
      { countryId: 'PRT', countryId2: 'PT', countryName: 'Portugal' },
      { countryId: 'PRI', countryId2: 'PR', countryName: 'Puerto Rico' },
      { countryId: 'QAT', countryId2: 'QA', countryName: 'Qatar' },
      { countryId: 'REU', countryId2: 'RE', countryName: 'Réunion' },
      { countryId: 'ROM', countryId2: 'RO', countryName: 'Romania' },
      { countryId: 'RUS', countryId2: 'RU', countryName: 'Russian Federation' },
      { countryId: 'RWA', countryId2: 'RW', countryName: 'Rwanda' },
      { countryId: 'WSM', countryId2: 'WS', countryName: 'Samoa' },
      { countryId: 'SMR', countryId2: 'SM', countryName: 'San Marino' },
      { countryId: 'STP', countryId2: 'ST', countryName: 'Sao Tome and Principe' },
      { countryId: 'SAU', countryId2: 'SA', countryName: 'Saudi Arabia' },
      { countryId: 'SEN', countryId2: 'SN', countryName: 'Senegal' },
      { countryId: 'SRB', countryId2: 'RS', countryName: 'Serbia, Republic of' },
      { countryId: 'SYC', countryId2: 'SC', countryName: 'Seychelles' },
      { countryId: 'SLE', countryId2: 'SL', countryName: 'Sierra Leone' },
      { countryId: 'SGP', countryId2: 'SG', countryName: 'Singapore' },
      { countryId: 'SVK', countryId2: 'SK', countryName: 'Slovakia' },
      { countryId: 'SVN', countryId2: 'SI', countryName: 'Slovenia' },
      { countryId: 'SLB', countryId2: 'SB', countryName: 'Solomon Islands' },
      { countryId: 'SOM', countryId2: 'SO', countryName: 'Somalia' },
      { countryId: 'ZAF', countryId2: 'ZA', countryName: 'South Africa' },
      { countryId: 'SGS', countryId2: 'GS', countryName: 'South Georgia and the South Sandwich Islands' },
      { countryId: 'ESP', countryId2: 'ES', countryName: 'Spain' },
      { countryId: 'LKA', countryId2: 'LK', countryName: 'Sri Lanka' },
      { countryId: 'SHN', countryId2: 'SH', countryName: 'St. Helena' },
      { countryId: 'KNA', countryId2: 'KN', countryName: 'St. Kitts and Nevis' },
      { countryId: 'LCA', countryId2: 'LC', countryName: 'St. Lucia' },
      { countryId: 'SPM', countryId2: 'PM', countryName: 'St. Pierre and Miquelon' },
      { countryId: 'VCT', countryId2: 'VC', countryName: 'St. Vincent and the Grenadines' },
      { countryId: 'SDN', countryId2: 'SD', countryName: 'Sudan' },
      { countryId: 'SUR', countryId2: 'SR', countryName: 'Suriname' },
      { countryId: 'SJM', countryId2: 'SJ', countryName: 'Svalbard and Jan Mayen Islands' },
      { countryId: 'SWZ', countryId2: 'SZ', countryName: 'Swaziland' },
      { countryId: 'SWE', countryId2: 'SE', countryName: 'Sweden' },
      { countryId: 'CHE', countryId2: 'CH', countryName: 'Switzerland' },
      { countryId: 'SYR', countryId2: 'SY', countryName: 'Syrian Arab Republic' },
      { countryId: 'TWN', countryId2: 'TW', countryName: 'Taiwan' },
      { countryId: 'TJK', countryId2: 'TJ', countryName: 'Tajikistan' },
      { countryId: 'TZA', countryId2: 'TZ', countryName: 'Tanzania, United Republic of' },
      { countryId: 'THA', countryId2: 'TH', countryName: 'Thailand' },
      { countryId: 'TLS', countryId2: 'TL', countryName: 'Timor-Leste' },
      { countryId: 'TGO', countryId2: 'TG', countryName: 'Togo' },
      { countryId: 'TKL', countryId2: 'TK', countryName: 'Tokelau' },
      { countryId: 'TON', countryId2: 'TO', countryName: 'Tonga' },
      { countryId: 'TTO', countryId2: 'TT', countryName: 'Trinidad and Tobago' },
      { countryId: 'TUN', countryId2: 'TN', countryName: 'Tunisia' },
      { countryId: 'TUR', countryId2: 'TR', countryName: 'Turkey' },
      { countryId: 'TKM', countryId2: 'TM', countryName: 'Turkmenistan' },
      { countryId: 'TCA', countryId2: 'TC', countryName: 'Turks and Caicos Islands' },
      { countryId: 'TUV', countryId2: 'TV', countryName: 'Tuvalu' },
      { countryId: 'UGA', countryId2: 'UG', countryName: 'Uganda' },
      { countryId: 'UKR', countryId2: 'UA', countryName: 'Ukraine' },
      { countryId: 'ARE', countryId2: 'AE', countryName: 'United Arab Emirates' },
      { countryId: 'GBR', countryId2: 'GB', countryName: 'United Kingdom' },
      { countryId: 'USA', countryId2: 'US', countryName: 'United States' },
      { countryId: 'UMI', countryId2: 'UM', countryName: 'United States Minor Outlying Islands' },
      { countryId: 'VIR', countryId2: 'VI', countryName: 'United States Virgin Islands' },
      { countryId: 'URY', countryId2: 'UY', countryName: 'Uruguay' },
      { countryId: 'UZB', countryId2: 'UZ', countryName: 'Uzbekistan' },
      { countryId: 'VUT', countryId2: 'VU', countryName: 'Vanuatu' },
      { countryId: 'VEN', countryId2: 'VE', countryName: 'Venezuela' },
      { countryId: 'VNM', countryId2: 'VN', countryName: 'Vietnam' },
      { countryId: 'WLF', countryId2: 'WF', countryName: 'Wallis and Futuna Islands' },
      { countryId: 'ESH', countryId2: 'EH', countryName: 'Western Sahara' },
      { countryId: 'YEM', countryId2: 'YE', countryName: 'Yemen' },
      { countryId: 'ZMB', countryId2: 'ZM', countryName: 'Zambia' },
      { countryId: 'ZWE', countryId2: 'ZW', countryName: 'Zimbabwe' }
    ]);

    let issueCountry = this.get('issueCountry');
    if (!isNone(issueCountry)) {
      this._removeIssueCountry(issueCountry);
    }

    let filtered = this._filterWithoutSelectedItem();
    let selected = this._getSelectedCountries();

    this.set('filteredAccordionArticles', filtered);
    this.set('filteredSearchText', '');
    this.set('selectedCountries', selected);
  },
  _removeIssueCountry(issueCountry) {
    let countries = A(this.get('countries'));
    this._filterWithoutCountry(countries, issueCountry);
    this.set('countries', countries);
  },
  _filterWithoutCountry(countries, removeItem) {
    let findItem = countries.findBy('countryId2', removeItem);
    countries.removeObject(findItem);
    return countries;
  },
  _getSelectedCountries() {
    let arr = A();
    let countries = this.get('countries');
    if (countries) {
      let selectedItems = makeArray(this.get('selectedItems'));
      if (selectedItems && selectedItems.length > 0) {
        selectedItems.forEach(item => {
          let findedObj = A(countries).findBy('countryId', item);
          arr.pushObject(findedObj);
        });
      }
    }
    return arr;
  },
  _filterWithoutSelectedItem() {
    let arr = A();
    let countries = this.get('countries');
    if (countries) {
      let selectedItems = this._getSelectedCountries();
      if (selectedItems && selectedItems.length > 0) {
        countries.forEach(item => {
          let hasObj = false;
          for (let i = 0; i < selectedItems.length; i++) {
            if (selectedItems[i].countryId === item.countryId) {
              hasObj = true;
            }
          }
          if (!hasObj) {
            arr.pushObject(item);
          }
        });
      } else {
        countries.forEach(item => arr.pushObject(item));
      }
    }
    return arr;
  },
  actions: {
    keepOpenList() {
      this.set('showFilteredResult', true);
    },
    selectOneCountry(item) {
      this.set('filteredSearchText', '');
      later(() => {
        this.set('filteredAccordionArticles', this._filterWithoutSelectedItem());
        this.set('selectedCountries', this._getSelectedCountries());
      }, 300);
      this.set('showFilteredResult', false);
      this.sendAction('select-item', item);
    },
    removeOneCountry(item) {
      later(() => {
        this.set('filteredAccordionArticles', this._filterWithoutSelectedItem());
        this.set('selectedCountries', this._getSelectedCountries());
      }, 100);
      this.sendAction('remove-item', item);
    },
    filterCategories(value) {
      if (value) {
        value = value.trim();
      }
      let filterLetterLimit = 1;
      if (
        this.get('i18n.locale') &&
        (this.get('i18n.locale').toLowerCase() == 'zh-hk' || this.get('i18n.locale').toLowerCase() == 'zh-cn')
      ) {
        filterLetterLimit = 1;
      }
      if (value && value.length >= filterLetterLimit) {
        this.set('filteredArray', A());
        let sr = this.get('filteredArray');
        let filtered = this._filterWithoutSelectedItem();
        filtered.forEach(item => {
          let valueCap = value.toUpperCase();
          let countryName = item.countryName.toUpperCase();
          let indexNum = countryName.indexOf(valueCap);
          if (indexNum > -1) {
            sr.pushObject(item);
          }
        });
        if (this.get('filteredArray').length == 0) {
          let noRecordObject = {
            noRecord: true
          };
          this.get('filteredArray').pushObject(noRecordObject);
        }
        this.set('filteredAccordionArticles', this.get('filteredArray'));
        this.set('showFilteredResult', true);
        return;
      } else {
        this.set('filteredAccordionArticles', this._filterWithoutSelectedItem());
        this.set('showFilteredResult', true);
      }
    }
  }
});
