import Component from '@ember/component';
import layout from '../templates/components/add-remove-alias-names';
import { isEmpty } from '@ember/utils';
import { A } from '@ember/array';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import EmberObject, { set } from '@ember/object';
import errorMessageSupport from 'rdc-ui-adn-components/mixins/error-message-support';

export default Component.extend(errorMessageSupport, {
  layout,
  store: service(),
  classNameBindings: [
    'hasError:has-error',
    'reviewMode:is-reviewmode',
    'required:is-mandatory'
  ],
  classNames: ['rdc-component-base', 'multi-alias-name'],
  addButtonDisable: computed('fields.@each.{label,value}', 'hasError', 'fatalError', {
    get() {
      if (!isEmpty(this.fields)) {
        let emptyFields = this.fields.filter(item => {
          return isEmpty(item.value);
        });
        if (emptyFields.length > 0 || this.hasError || this.fatalError) {
          return true;
        } else {
          return false;
        }
      }
    }
  }),
  label: '',
  firstName: null,
  lastName: null,
  labelCount: 0,
  fatalError: false,
  maxlength: null,
  minLength: null,

  init() {
    this._super(...arguments);
    if (typeof this.value === 'object' && !isEmpty(this.value)) {
      this._populateValues();
    } else {
      this.set('fields', null);
    }
    this.firstName = this.get('store').peekRecord('field', 'FirstName').get('value');
    this.lastName = this.get('store').peekRecord('field', 'LastName').get('value');
  },

  /** Label Count **/
  _setLabelCount() {
    set(this, 'labelCount', 0);
    this.fields.forEach((item, index) => {
      let lbl = `${this.label} ${++this.labelCount}`;
      set(this.fields[index], 'label', lbl);
    });
  },

  // Value Prepopulation for Resume Flow
  _populateValues() {
    if (!isEmpty(this.value)) {
      this.set('fields', A([]));
      this.value.forEach(item => {
        this.get('fields').pushObject(item);
      });
      this._setLabelCount();
    }
  },

  // alias name validation
  _checkNames() {
    this._setLabelCount();
    let namesArr = [];
    this.fields.forEach(item => {
      namesArr.push(item.value);
    });
    this.set('hasError', false);
    this.set('fatalError', false);
    namesArr.forEach((name, index) => {
      if (!isEmpty(name) && name.length < 3) { // Alias Name should be minimum 3 characters
        this.set('fatalError', true);
      } else if (namesArr.indexOf(name) != index) { // Alias Name should not be duplicate
        this.set('hasError', true);
        this.set('fatalError', true);
      } else if (name === this.firstName || name === this.lastName) { // Alias Name should not be same as firstName || lastName
        this.set('hasError', true);
        this.set('fatalError', true);
      } else {
        this.set('value', this.fields);
      }
    });
  },

  actions: {
    addInputAliasName(){
      if (isEmpty(this.fields)) {
        this.set(
          'fields',
          A([
            EmberObject.create({
              value: ''
            })
          ])
        );
      } else {
        this.fields.pushObject(
          EmberObject.create({
            value: ''
          })
        );
      }
      this._checkNames();
    },
    focusOut() {
      this._checkNames();
    },
    //Remove Alias Name field by index
    removeInputAliasName(index) {
      this.fields.removeAt(index);
      this._checkNames();
    }
  }
});
