import Component from '@ember/component';
import layout from '../templates/components/agent-review-button';

export default Component.extend({
  layout,

  actions:{
    agentAction(action){
      this.action(action);
    }
  }
});
