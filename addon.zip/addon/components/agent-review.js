import Component from '@ember/component';
import layout from '../templates/components/agent-review';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import EmberObject from "@ember/object";
import { htmlSafe } from '@ember/string';

export default Component.extend({
  layout,
  store: service(),
  classNames: ['agent-review'],

  init(){
    this._super(...arguments);
    this.agentData();
  },

  agentData(){
    if(!isEmpty(this.get('label'))){
      let titleobj = EmberObject.create({});
      let obj = EmberObject.create({});
      
      let label = JSON.parse(this.label.replace(/'/g, '"'));
        
      Object.keys(label).forEach((key) => {
       let fieldId = key;
       if(fieldId === 'title'){
         titleobj['title'] = label[key];
       }
      
      let field = this.store.peekRecord('field',fieldId);
      if(!isEmpty(field) && !isEmpty(field.value)){
        if(fieldId === 'verifyBy'){
          titleobj[label[key]] = htmlSafe(field.value);
        } else if(fieldId === 'DesignationLOV'){
          obj[label[key]] = htmlSafe(field.value.label);
        } else if(field.fieldType === 'rdc-currency'){
          let config = this.store.peekRecord('fieldConfig', `${fieldId}-Config`)
          obj[label[key]] = htmlSafe(`${config.prefix} ${field.value}`);
        } else {
          obj[label[key]] = htmlSafe(field.value);
        }
      }
      });
      this.set('titleobj',titleobj);
      this.set('formatedData',obj);
   }
  }
});