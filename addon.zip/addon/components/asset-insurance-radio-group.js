import Component from '@ember/component';
import layout from '../templates/components/asset-insurance-radio-group';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';

export default Component.extend({
  layout,
  classNames: ['rdc-component-base asset-insurance-radio-group'],
  hasCloseBtn: true,
  insuranceImgUrl: computed('currentField', {
    get() {
      return this.get('parentView.fieldConfig.imageUrl');
    }
  }),
  init() {
    this._super(...arguments);
    /* To disable the next button if the value not selected in the section.
     * handling the validation in UI since CSL display rules to validate breaks the functionality.
     */
    this.enableDisableNextButton();
  },
  /* Inorder to use the below action. Make sure the following points,
   * This action is used to make unique radio section between different radiogroup fields in same section.
   * make sure all the radio group fields are in same section.
   * make sure there are no other fields other than the required radio groups in this section.
   */
  selectUniqueRadioValueAcrossRadioGroups() {
    // To reset the other radiogroup fields to make the radio select unique value across groups.
    let currentField = this.get('parentView');
    currentField.get('sectionGroup.sections').forEach(section => {
      section.get('fields').forEach(field => {
        // since the functional component doesn't have id, using the field-content attribute.
        let compId = this.get('fieldContent');
        // Selecting the section of the radio group alone and leaving out the rest of the section in the page.
        if (field.get('id') === compId) {
          section.get('fields').forEach(field => {
            if (field.get('id') !== compId) {
              // setting the other fields value in the same section to null.
              field.set('value', null);
            }
          });
        }
      });
    });
  },
  // To enable disable the page button.
  enableDisableNextButton() {
    let currentField = this.get('parentView');
    // defaulting the page next button enable.
    currentField.get('page').set('isFormBlocked', false);
    currentField.get('sectionGroup.sections').forEach(section => {
      section.get('fields').forEach(field => {
        // since the functional component doesn't have id, using the field-content attribute.
        let compId = this.get('fieldContent');
        // Selecting the section of the radio group alone and leaving out the rest of the section in the page.
        if (field.get('id') === compId) {
          // filtering the fields that have null value.
          let emptyValueFields = section.get('fields').filter(field => {
            return isEmpty(field.get('value'));
          });
          // if all the fields in the section are having value null then disable next button.
          if (emptyValueFields.length === section.get('fields').length && !currentField.get('page.isFormBlocked')) {
            currentField.get('page').set('isFormBlocked', true);
          }
        }
      });
    });
  },
  actions: {
    showBenefits() {
      this.setProperties({
        showActionSheet: true,
        staticPopup: 'rdc-insurance-learn-more',
        insuranceName: this.get('fieldContent')
      });
    },
    onCancel() {
      this.set('showActionSheet', false);
    },
    select(selectedValue) {
      this.set('value', selectedValue);
      this.selectUniqueRadioValueAcrossRadioGroups();
      this.enableDisableNextButton();
    }
  }
});
