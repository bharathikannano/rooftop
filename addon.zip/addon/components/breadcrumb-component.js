import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import layout from '../templates/components/breadcrumb-component';
import { later } from '@ember/runloop';

export default Component.extend({
  layout,
  router: service(),
  i18n: service(),
  fap: service(),
  breadcrumbService: service(),
  helpServicesLink: computed(function() {
    return this.get('breadcrumbService').get('breadcrumbEntries');
  }),
  init() {
    this._super(...arguments);
    let helpServicesLink = this.get('breadcrumbService').get('breadcrumbEntries');
    this.set('helpAndServiceLinks', helpServicesLink);
  },
  selectedBreadCrumb: null,

  actions: {
    breadcrumbList: function(value) {
      this.set('selectedBreadCrumb', null);
      if (value['query-param'] && document.getElementById(value['query-param'])) {
        later(function() {
          document.getElementById(value['query-param']).scrollIntoView();
        }, 0);
      } else if (value['query-param']) {
        this.router.transitionTo('rdc-ui-eng-service-requests.' + value['action-url']);
        later(function() {
          document.getElementById(value['query-param']).scrollIntoView();
        }, 0);
        if (document.getElementById('tab-create-request')) {
          document.getElementById('tab-create-request').className += ' active';
        }
      } else {
        this.router.transitionTo('rdc-ui-eng-service-requests.' + value['action-url']);
      }
    },
    closePopupAction() {
      this.sendAction('action');
    }
  }
});
