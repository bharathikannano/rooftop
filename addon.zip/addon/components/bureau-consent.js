import Component from '@ember/component';
import layout from '../templates/components/bureau-consent';
import { inject as service } from '@ember/service';

export default Component.extend({
  layout,
  classNames: ['bureau-consent-popup'],
  i18n: service()
});
