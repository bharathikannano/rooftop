import { inject as service } from '@ember/service';
import Component from '@ember/component';
import { computed } from '@ember/object';

export default Component.extend({
  rdcModalManager: service(),
  i18n: service(),
  queries: service('customer-info'),

  init() {
    this.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    this._super(...arguments);
  },
  cardMasking: computed(function() {
    if (
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'hk') ||
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'sg')
    ) {
      return false;
    } else {
      return true;
    }
  }),

  actions: {
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    },
    selectAllList: function(CardDetails) {
      CardDetails.CreditCardDetails.forEach(function(element) {
        //element = Ember.Object.create(element);
        if (!element.get('alerts')) {
          if (CardDetails.CreditCardDetails.selectAll) {
            element.set('checked', true);
          } else {
            element.set('checked', false);
          }
        }
      });
      CardDetails.CreditCardDetails.toggleProperty('selectAll');
      this.sendAction('enableNext');
    },
    tooltipReset: function(cardDetails) {
      cardDetails.forEach(function(cards) {
        cards.set('tooltipdisplay', false);
      });
    },
    supplementaryModal: function(CreditCardDetail) {
      let message = this.get('i18n').t('ServiceRequest.COMMON.systemError');
      let title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
      // let cards;
      this.get('rdcModalManager')
        .showInfoModal('supplementary-card', {
          cards: CreditCardDetail,
          title,
          message,
          customClass: 'service-journey-supplementary-cards',
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
          iconClass: 'service-journey-system-error-icon'
        })
        .then(() => {
          this.controllerFor('serviceRequest').set('systemErrorPopup', false);
          this.transitionTo('serviceRequest.new-request');
        });
    },

    tooltipSelection: function(creditCardDetail, cardDetails) {
      cardDetails.forEach(function(cards) {
        if (creditCardDetail.cardID != cards.cardID) cards.set('tooltipdisplay', false);
      });
      creditCardDetail.toggleProperty('tooltipdisplay');
    },
    addActiveClass: function(cardDetail, cardDetails) {
      if (!cardDetail.get('alerts')) {
        cardDetail.toggleProperty('checked');
        this.sendAction('enableNext');
        cardDetails.forEach(function(cards) {
          cards.set('tooltipdisplay', false);
        });
      }
      let clength = cardDetails.length.toString();
      let checkedCount = 0;
      let alertsCount = 0;
      cardDetails.forEach(function(cards) {
        if (cards.checked) {
          ++checkedCount;
        }
        if (cards.alerts) {
          ++alertsCount;
        }
      });
      if (!cardDetail.get('alerts')) {
        if (clength == (checkedCount + alertsCount).toString()) {
          cardDetails.toggleProperty('selectAll');
          this.sendAction('enableNext');
        } else if (clength > (checkedCount + alertsCount).toString()) {
          cardDetails.set('selectAll', true);
          this.sendAction('enableNext');
        }
      }
    }
  }
});
