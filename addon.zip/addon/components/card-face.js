import { set } from '@ember/object';
import Component from '@ember/component';

export default Component.extend({
  init() {
    this.sendAction();
    this._super(...arguments);
  },

  actions: {
    selectCard(cardDetail) {
      let data = this.get('model');
      data.forEach(item => {
        if (item.image == cardDetail.image && item['sub-type'] == cardDetail['sub-type']) {
          cardDetail.selectedImage = 'true';
          set(item, 'isSelected', 'selected');
        } else {
          cardDetail.selectedImage = '';
          set(item, 'isSelected', '');
        }
      });
      this.sendAction();
    },
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    }
  }
});
