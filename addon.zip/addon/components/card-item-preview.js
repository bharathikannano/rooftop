import { isNone } from '@ember/utils';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';

export default Component.extend({
  ccimagesfromjs: '',
  queries: service('customer-info'),
  showPrimaryTextForCurrentCountry: computed(function() {
    let countryCode = this.get('queries.countryName').toUpperCase();
    if (countryCode == 'SG' || countryCode == 'MY') {
      return false;
    }
    return true;
  }),
  cardMasking: computed(function() {
    if (this.get('queries.countryName') != 'SG') {
      return true;
    } else {
      return false;
    }
  }),
  isPrimary: computed(function() {
    let primaryFlag = this.cardItem.get('primaryFlag');
    if (primaryFlag == 'Y') {
      return true;
    } else {
      return false;
    }
  }),
  init() {
    this.errors = [];
    if (!isNone(this.cardItem)) {
      let cardName = this.cardItem.get('cardImageName');
      if (!isNone(cardName) && cardName.length > 0) {
        this.set('ccimagesfromjs', 'https://av.sc.com/configuration/content/images/' + cardName + '.png');
      }
    }

    this.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    this._super(...arguments);
  },
  actions: {
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    }
  }
});
