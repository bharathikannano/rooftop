import { isNone, isBlank } from '@ember/utils';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';

export default Component.extend({
  ccimagesfromjs: '',
  queries: service('customer-info'),
  showPrimaryTextForCurrentCountry: computed(function() {
    let countryCode = this.get('queries.countryName');
    if (!isNone(countryCode) && !isBlank(countryCode)) {
      countryCode = countryCode.toUpperCase();
      /**
       * The below line not used in repective hbs. So, commented for lint error: ember/no-side-effects
       * this.set('countryCode', countryCode); **/
    }
    if (countryCode == 'SG' || countryCode == 'MY') {
      return false;
    }
    return true;
  }),
  cardMasking: computed(function() {
    if (this.get('queries.countryName') != 'SG') {
      return true;
    } else {
      return false;
    }
  }),
  isPrimary: computed(function() {
    let primaryFlag = this.rowData.get('primaryFlag');
    if (primaryFlag == 'Y') {
      return true;
    } else {
      return false;
    }
  }),
  init() {
    this.errors = [];
    if (!isNone(this.rowData)) {
      let cardImageName = this.rowData.get('cardImageName');
      //var cardType = (this.get('cardType').string).replace(' ', '').toLowerCase();
      if (!isNone(cardImageName) && cardImageName.length > 0) {
        this.set('ccimagesfromjs', 'https://av.sc.com/configuration/content/images/' + cardImageName + '.png');
      }
    }

    this.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    this._super(...arguments);
  },

  actions: {
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    }
  }
});
