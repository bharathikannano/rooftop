import { inject as service } from '@ember/service';
import Component from '@ember/component';
import layout from '../templates/components/card-type';

export default Component.extend({
  layout,
  rdcModalManager: service(),
  i18n: service(),
  init() {
    this._super(...arguments);
    if (this.get('desktop')) {
      this.set('getcardData', this.get('cardType'));
      this.set('getcardTypeError', this.get('cardTypeError'));
      this.set('initialSlide', this.get('initialSlider'));
    } else {
      this.set('getcardData', this.get('model.cardType'));
      this.set('getcardTypeError', this.get('model.cardTypeError'));
      this.set('initialSlide', this.get('model.initialSlider'));
    }
    this.send('triggerSlider', this.get('getcardData'), this.get('getcardTypeError'), this.get('initialSlide'));
  },
  actions: {
    slickInit: function() {
      this.$('.carousel-card-type').slick({
        centerMode: true,
        arrows: true,
        centerPadding: '60px',
        slidesToShow: 3,
        focusOnSelect: false,
        accessibility: false,
        initialSlide: this.get('initialSlide'),
        responsive: [
          {
            breakpoint: 3000,
            settings: {
              centerMode: false,
              slidesToShow: 4,
              slidesToScroll: 1,
              focusOnSelect: true
            }
          },
          {
            breakpoint: 992,
            settings: {
              centerMode: false,
              slidesToShow: 3,
              slidesToScroll: 1,
              focusOnSelect: true
            }
          },
          {
            breakpoint: 768,
            settings: {
              centerPadding: '156px',
              slidesToShow: 1
            }
          },
          {
            breakpoint: 481,
            settings: {
              centerPadding: '86px',
              slidesToShow: 1
            }
          },
          {
            breakpoint: 415,
            settings: {
              centerPadding: '71px',
              slidesToShow: 1
            }
          },
          {
            breakpoint: 376,
            settings: {
              centerPadding: '61px',
              slidesToShow: 1
            }
          },
          {
            breakpoint: 321,
            settings: {
              centerPadding: '43px',
              slidesToShow: 1
            }
          }
        ]
      });
    },
    slickAfterChange: function(e) {
      this.set('typeDesc', this.get('descData')[e.currentSlide]._data.typeDesc);
      this.set('cardTitle', this.get('descData')[e.currentSlide]._data.cardTitle);
      this.set('cardDesc', this.get('descData')[e.currentSlide]._data.cardDesc);
      this.set('cardImage', this.get('descData')[e.currentSlide]._data.imgname);
      this.set('type', this.get('descData')[e.currentSlide]._data.type);
      this.set('slidervalue', e.currentSlide);
      if (this.get('desktop')) {
        this.sendAction('action', this, e.currentSlide);
        this.send('removeUnSelectedAcc');
      }
    },
    selectCard() {
      this.get('rdcModalManager').closeModalResolve(this);
    },

    removeUnSelectedAcc() {
      this.get('selectCardself')
        .controller.get('items')
        .forEach(data => {
          if (
            data.SelectedValue != 'selected' &&
            (data.accountName == 'OtherAccount1' || data.accountName == 'OtherAccount2')
          ) {
            this.get('selectCardself')
              .controller.get('items')
              .removeObject(data);
            this.get('selectCardself').controller.set('btnAddAccount', true);
          }
        });
    },
    closeModal: function() {
      this.sendAction('onCloseReject');
    },
    triggerSlider: function(cardData, cardTypeError, initialSlider) {
      this._super(...arguments);
      this.set('cartTypeErrorTit', this.get('i18n').t('ServiceRequest.COMMON.cardTypeErrornocardsTit'));
      this.set('cartTypeErrorDesc', this.get('i18n').t('ServiceRequest.COMMON.cardTypeErrornocardsDesc'));
      this.set('cardTypeComp', cardData);
      if (cardTypeError == 'noActiveCards') {
        this.set('cartTypeErrorTit', this.get('i18n').t('ServiceRequest.COMMON.cardTypenocardsTit'));
        this.set('cartTypeErrorDesc', this.get('i18n').t('ServiceRequest.COMMON.cardTypenocardsDesc'));
      }
      if (cardData != undefined && cardData.get('length') > 0) {
        this.set('descData', cardData.content);
        cardData.forEach((item, index) => {
          if (index == 0) {
            this.set('cardTitle', item.get('cardTitle'));
            this.set('cardDesc', item.get('cardDesc'));
            this.set('typeDesc', item.get('typeDesc'));
            this.set('cardImage', 'https://av.sc.com/configuration/content/images/' + item.get('defaultImg') + '.png');
            this.set('type', item.get('type'));
          }
          if (navigator.userAgent.indexOf('rv:11.0') > 0) {
            if (item.get('cardTitle').length > 40) {
              item.set('hasEllipsis', 'has--ellipsis');
            } else {
              item.set('hasEllipsis', '');
            }
          }
          item.get('images').forEach(data => {
            if (data['sub-type'] == 'N/A') {
              item.get('imgname') == undefined ? item.set('imgname', data['imageBytes']) : '';
            }
          });
        });

        this.sendAction('action', this, initialSlider);
      }
    }
  }
});
