/*eslint-disable no-mixed-spaces-and-tabs*/

import { typeOf } from '@ember/utils';
import { htmlSafe } from '@ember/string';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
export default Component.extend({
  allowManyActiveItems: false,
  isSelected: false,
  ccimagesfromjs: '',
  selectAndRedirect: false,
  classNameBindings: ['addactiveclass'],
  addactiveclass: false,
  queries: service('customer-info'),
  i18n: service(),
  routing: service('-routing'),
  cardMasking: computed(function() {
    if (this.get('queries.countryName') != 'SG' && this.get('queries.countryName') != 'HK') {
      return true;
    } else {
      return false;
    }
  }),
  cardDesc: computed(function() {
    let cardType = this.get('cardtypeCode');
    if (this.get('queries.countryName') == 'HK') {
      let CardDesc = null;
      if (cardType == 'creditCard') {
        let digit = this.cardItem.get('descCode').toString()[0],
          setDefault;
        setDefault =
          digit == 5
            ? 'MaestroCard'
            : digit == 4
            ? 'VisaCard'
            : digit == 0
            ? 'AmexCard'
            : digit == 6
            ? 'CUPCard'
            : 'DefaultCard';
        CardDesc = this.get('i18n').t('ServiceRequest.creditCardDesc.' + this.cardItem.get('descCode'), {
          default: 'ServiceRequest.defaultcreditCardDesc.' + setDefault
        });
      } else if (cardType == 'debitCard') {
        CardDesc = this.get('i18n').t('ServiceRequest.debitCardDesc.' + this.cardItem.get('cardLangCd'), {
          default: 'ServiceRequest.debitCardDesc.defaultDebit'
        });
      }

      return new htmlSafe(CardDesc);
    } else {
      return new htmlSafe(this.get('ccname'));
    }
  }),
  primaryFlagtext: computed(function() {
    let getPrimeFlag = this.get('primaryFlag');
    if (getPrimeFlag) {
      if (getPrimeFlag == 'Y') {
        return this.get('i18n')
          .t('ServiceRequest.CREDITCARD.cardSetting.isPrimary.primary')
          .toString();
      } else {
        return this.get('i18n')
          .t('ServiceRequest.CREDITCARD.cardSetting.isPrimary.supplementary')
          .toString();
      }
    }
  }),
  init() {
    this.errors = [];
    let cardName = this.cardItem.get('cardImageName');
    //var cardType = (this.get('cardType').string).replace(' ', '').toLowerCase();
    try {
      if (cardName.length > 0) {
        this.set('ccimagesfromjs', 'https://av.sc.com/configuration/content/images/' + cardName + '.png');
      }
    } catch (error) {
      this.set('ccimagesfromjs', false);
    }

    if (typeOf(this.get('cardStatusRequired')) == 'undefined') {
      this.set('cardStatus', '');
      this.set('statuscolor', '');
    }

    let isConfirm = this.get('isConfirm');

    if (isConfirm != 'true') {
      this.classNames = this.classNames.concat('col-lg-12 col-md-12 border-bottom');
    }

    if (this.get('displayContent')) {
      this.set('maskConfig', this.get('queries').loanMaskConfig());
    } else {
      this.set('maskConfig', this.get('queries').cardMaskConfig());
    }

    let cardType = this.get('cardtypeCode');
    if (
      this.get('queries.countryName') == 'HK' &&
      this.get('routing.currentRouteName') == 'rdc-ui-eng-service-requests.card-block.status' &&
      cardType != 'creditCard' &&
      this.cardItem.get('data.statuscolor') == 'bgcolor-green'
    ) {
      this.set('debitCardReplace', true);
    } else {
      this.set('debitCardReplace', false);
    }

    this._super(...arguments);
  },

  didUpdateAttrs() {
    if (this.get('selectedValue') == 'selectAll') {
      this.set('addactiveclass', true);
    } else {
      this.set('addactiveclass', false);
    }
  },

  actions: {
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    },
    addActiveClass: function(editable, item, multiple = true) {
      if (editable) {
        if (!multiple) {
          this.sendAction('seldesel', multiple);
        }
        if (item.get('alerts') && this.get('showAlertDuplicate')) {
          item.set('isSelected', false);
        } else {
          item.toggleProperty('isSelected');
        }
        this.sendAction('enableNext', this);
      }
    },
    callReplaceDebitCard: function() {
      this.sendAction('enableNext', this);
    },
    checkVerticalCard: function(event) {
      this.set('verticalImage', event.target.naturalHeight > event.target.naturalWidth ? true : false);
    },
    tooltipSelection: function(cardDetail) {
      cardDetail.toggleProperty('tooltipdisplay');
    }
  }
});
