import Component from '@ember/component';
import layout from '../templates/components/cardslist-component';

export default Component.extend({
  layout,
  lable: null,
  cardType: null,
  classNames: ['rdc-cards'],
  allowManyActiveItems: false,
  seldesel: true,
  selectedValue: '',
  init() {
    this._super(...arguments);
    this.set('CreditCardDetails', []);

    if (this.get('CardDetails') != undefined) {
      if (this.get('CardDetails').filterBy('isSelected').length == this.get('CardDetails.length')) {
        this.set('seldesel', false);
      }
      this.get('CardDetails').forEach((item) => {
        if(item.get('alerts') && this.get('showAlertDuplicate')){
          item.set('disableCard', true);
        }
      });
    }
  },
  actions: {
    seldesel: function(multiple = true) {
      if (!multiple) {
        this.set('seldesel', false);
      }
      if (this.get('seldesel') == true) {
        this.CardDetails.forEach(function(item) {
          if (!item.get('disableCard') ) {
            item.set('isSelected', true);
          }
        });
        this.set('seldesel', false);
      } else {
        this.CardDetails.forEach(function(item) {
          if (!item.get('disableCard')) {
            item.set('isSelected', false);
          }
        });
        this.set('seldesel', true);
      }
      this.send('sendAction');
    },

    enableNext(selectedCardData) {
      if (
        this.get('showAlertDuplicate') && this.get('CardDetails').filterBy('alerts') &&
        this.get('CardDetails').filterBy('isSelected').length ===
          this.get('CardDetails.length') - this.get('CardDetails').filterBy('alerts').length
      ) {
        this.set('seldesel', false);
        this.send('sendAction', selectedCardData);
      } else if (this.get('CardDetails').filterBy('isSelected').length == this.get('CardDetails.length')) {
        this.set('seldesel', false);
        this.send('sendAction', selectedCardData);
      } else if (this.get('CardDetails').filterBy('isSelected').length > 0 || this.get('CardDetails.length') == 1) {
        this.set('seldesel', true);
        this.send('sendAction', selectedCardData);
      } else {
        this.send('sendAction');
      }
    },
    sendAction(selectedCardData) {
      this.sendAction('enableNext', selectedCardData);
    }
  }
});
