import Component from '@ember/component';
import layout from '../templates/components/cart-details';

export default Component.extend({
  layout,
  showCartDetails: false,
  init() {
    this._super(...arguments);
  },
  classNames: ['cart-details-component'],
  actions: {
    onCartSelection() {
      this.sendAction('closeCart');
    },
    onDeleteItem(productItem, category) {
      this.sendAction('onProductSelection', productItem, category);
    },
    onApply() {
      this.sendAction('onApply');
    }
  }
});
