import { later } from '@ember/runloop';
import Component from '@ember/component';
import layout from '../templates/components/casa-singleselection-component';

export default Component.extend({
  layout,

  allowManyActiveItems: false,
  actions: {
    addActiveClass: function(element, parentElement) {
      let self = this;
      let arrayIndex = 0;
      if (!element.get('isSelected')) {
        parentElement.forEach(function(elementVal, index) {
          if (elementVal.id == element.id) {
            arrayIndex = index;
          }

          elementVal.set('isSelected', false);
          elementVal.set('checked', false);
          elementVal.set('disableAmountText', true);
          elementVal.set('amountEntered', '');
          self.send('recalculateExcessBalance', elementVal);
        });
      }
      element.set('isSelected', true);
      element.set('checked', true);
      element.set('disableAmountText', false);
      parentElement.showAmountAndReasonSection = true;
      this.sendAction('enableAmountSection');

      if (!self.get('media.isMobile')) {
        arrayIndex = arrayIndex * 2;
        let getEle = this.get('element').getElementsByTagName('input')[arrayIndex];
        later(function() {
          getEle.focus();
        }, 0);
      }
    },

    enableNext() {
      this.sendAction('enableNext');
    },
    recalculateExcessBalance(element) {
      this.sendAction('recalculateExcessBalance', element.amountEntered, element);
    },

    focussError(element) {
      if (element.errorText) {
        document.getElementById('currencyText').classList.remove('focusedcss');
      }
    }
  }
});
