import { inject as service } from '@ember/service';
import Component from '@ember/component';
import layout from '../templates/components/cheque-multiselect-list';
import constants from '../constants';
export default Component.extend({
  layout,
  queries: service('customer-info'),
  allowManyActiveItems: false,
  actions: {
    tooltipSelection: function(element, parentElement, event) {
      event.preventDefault();

      element.toggleProperty('tooltipdisplay', true);
      parentElement.forEach(function(elementVal) {
        if (elementVal.id != element.id) elementVal.set('tooltipdisplay', false);
      });
    },
    checkboxSelection: function(element, parentElement, model, confirmScreen, event) {
      let casaParent = parentElement.get('eligibleCasas');
      event.preventDefault();
      element.toggleProperty('checked', true);
      if (constants.ChequeBookFeatures.leavesSelection.indexOf(this.get('queries.countryName')) != -1) {
        element.toggleProperty('leavesSelectionDisplay');
      }
      let anyOneDeselected = false;
      casaParent.forEach(function(elementVal) {
        if (!elementVal.get('alerts')) {
          if (!elementVal.get('checked')) {
            anyOneDeselected = true;
          }
        }
        elementVal.set('tooltipdisplay', false);
      });
      if (anyOneDeselected) {
        model.set('selectAll', true);
      } else {
        model.set('selectAll', false);
      }
      if (!confirmScreen) this.sendAction('enableNextBtn');
    }
  }
});
