import Component from '@ember/component';
import layout from '../templates/components/click-to-chat';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import { injectPlugin } from '../helpers/inject-plugin';

export default Component.extend({
  layout,
  fap: service(),
  queries: service('customer-info'),
  didRender() {
    this._super(...arguments);
    const country = this.get('queries.countryName');
    if (!isEmpty(document.getElementById('c2cStacy'))) {
      return;
    }
    if (this.get('fap').isEnabled('clicktochat')) {
      const attrs = `{
        "id": "c2cStacy",
        "data-pagename": "helpandservices.html",
        "src": "/retail/clicktochat/${country.toLowerCase()}/clicktochat.js"
      }`;
      injectPlugin(attrs);
    }
  }
});
