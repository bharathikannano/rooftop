import Component from '@ember/component';
import layout from '../templates/components/credit-balance-list';

export default Component.extend({
  layout,
  lable: null,
  cardType: null,
  classNames: ['rdc-cards'],
  allowManyActiveItems: false,
  selectedValue: '',
  init() {
    this._super(...arguments);
    this.set('CreditCardDetails', []);
  },
  actions: {
    enableNext() {
      this.sendAction('enableNext');
    },

    recalculateExcessBalance(enteredBalance, element) {
      this.sendAction('recalculateExcessBalance', enteredBalance, element);
    },

    enableAmountSection: function() {
      this.sendAction('enableAmountSection');
    }
  }
});
