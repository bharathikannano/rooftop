import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';

export default Component.extend({
  allowManyActiveItems: false,
  isSelected: false,
  ccimagesfromjs: '',
  classNameBindings: ['addactiveclass'],
  addactiveclass: false,
  queries: service('customer-info'),
  lowerCardName: computed(function() {
    return this.get('ccname');
  }),
  init() {
    this._super(...arguments);
    this.set('errors', []);
    if (this.cardItem) {
      let cardName = this.cardItem.get('cardImageName');
      if (cardName.length > 0) {
        this.set('ccimagesfromjs', 'https://av.sc.com/configuration/content/images/' + cardName + '.png');
      }
    }
  },

  actions: {
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    },
    addActiveClass: function(editable, item) {
      if (editable) {
        item.toggleProperty('isSelected');
        this.sendAction('enableNext');
      }
    }
  }
});
