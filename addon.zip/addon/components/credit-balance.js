import { later } from '@ember/runloop';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
export default Component.extend({
  allowManyActiveItems: false,
  isSelected: false,
  ccimagesfromjs: '',
  classNameBindings: ['addactiveclass'],
  addactiveclass: false,
  queries: service('customer-info'),
  lowerCardName: computed(function() {
    return this.get('ccname');
  }),

  init() {
    this.errors = [];

    if (this.cardItem) {
      let cardName = this.cardItem.get('cardImageName');
      if (cardName.length > 0) {
        this.set('ccimagesfromjs', 'https://av.sc.com/configuration/content/images/' + cardName + '.png');
      }
    }
    this._super(...arguments);
  },

  actions: {
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    },
    addActiveClass: function(editable, item, parentElement) {
      if (editable) {
        parentElement.forEach(function(elementVal) {
          elementVal.set('isSelected', false);
        });

        item.toggleProperty('isSelected');
        this.sendAction('enableNext');
      }
    },

    refundAmount: function(element, parentElement) {
      let self = this;
      if (!element.get('isSelected')) {
        parentElement.forEach(function(elementVal) {
          elementVal.set('isSelected', false);
          elementVal.set('disableAmountText', true);
          elementVal.set('amountEntered', '');
          self.send('recalculateExcessBalance', elementVal);
        });
      }
      element.set('isSelected', true);
      element.set('disableAmountText', false);
      this.sendAction('enableAmountSection');

      if (!self.get('media.isMobile')) {
        let getEle = this.get('element').getElementsByTagName('input')[0];
        later(function() {
          getEle.focus();
        }, 0);
      }
    },

    recalculateExcessBalance(element) {
      this.sendAction('recalculateExcessBalance', element.amountEntered, element);
    },

    focussError(element) {
      if (element.errorText) {
        document.getElementById('currencyText').classList.remove('focusedcss');
      }
    }
  }
});
