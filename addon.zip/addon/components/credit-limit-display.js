import Component from '@ember/component';
import layout from '../templates/components/credit-limit-display';

export default Component.extend({
  layout,
  classNames: ['credit-limit-display'],
});
