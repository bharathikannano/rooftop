import { computed, set } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import { later } from '@ember/runloop';

export default Component.extend({
  verticalImage: false,
  allowManyActiveItems: false,
  isTransactionSel: false,
  ccimagesfromjs: '',
  classNameBindings: ['addactiveclass', 'selectTransaction'],
  addactiveclass: false,
  totalVal: 0,
  i18n: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  router: service(),
  lowerCardName: computed(function() {
    return this.get('ccname').toLowerCase();
  }),
  val: computed(function() {
    return;
  }),
  cardDesc: computed(function() {
    let cardType = this.get('cardType').string;
    if (this.get('queries.countryName') == 'HK' && (cardType == 'Credit Card' || cardType == '信用卡')) {
      let digit = this.cardItem.get('descCode').toString()[0],
        CardDesc,
        setDefault;
      setDefault =
        digit == 5
          ? 'MaestroCard'
          : digit == 4
          ? 'VisaCard'
          : digit == 0
          ? 'AmexCard'
          : digit == 6
          ? 'CUPCard'
          : 'DefaultCard';
      CardDesc = this.get('i18n').t('ServiceRequest.creditCardDesc.' + this.cardItem.get('descCode'), {
        default: 'ServiceRequest.defaultcreditCardDesc.' + setDefault
      });
      /**
       * The below line not used in repective hbs. So, commented for lint error: ember/no-side-effects
       * this.set('desc', CardDesc); **/
      return CardDesc;
    } else {
      return this.get('cardItem.data.desc');
    }
  }),

  init() {
    this._super(...arguments);
    let cardName = '';
    if (this.cardItem) {
      cardName =
        this.ccDetails && this.ccDetails.isGroupFlag
          ? this.cardItem.get('cardImageName')
          : this.cardItem.get('cardImageName');
      if (cardName.length > 0) {
        this.set('ccimagesfromjs', 'https://av.sc.com/configuration/content/images/' + cardName + '.png');
      } else {
        this.set('ccimagesfromjs', 'https://placehold.it/60x40');
      }

      //Masking for MY Non Staff
      this.set('cardMasking', this.queries.cardMasking());
      this.set('maskConfig', this.queries.cardMaskConfig());
    }
    if (this.charge) {
      this.set('cardItem.disabledFlag', true);
    }
  },
  actions: {
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    },
    addActiveClass: function(editable, item, groupingItem) {
      if (
        !item.isSelected &&
        this.get('ccDetails').filterBy('isSelected').length >= 5 &&
        (this.ccDetails.countryCode != 'LK' && this.ccDetails.countryCode != 'NP' && this.ccDetails.countryCode != 'BN')
      ) {
        let message = this.get('i18n').t('ServiceRequest.CCFEEWAVIER.cardLimitMsg');
        this.get('rdcModalManager').showDialogModal({
          level: 'info',
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        });
      } else if (
        !item.isSelected &&
        this.get('ccDetails').filterBy('isSelected').length >= 4 &&
        (this.ccDetails.countryCode === 'NP' || this.ccDetails.countryCode === 'BN')
      ) {
        let message = this.get('i18n').t('ServiceRequest.CCFEEWAVIER.cardLimitMsgNP_BN');
        this.get('rdcModalManager').showDialogModal({
          level: 'info',
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        });
      } else if (
        !item.isSelected &&
        this.get('ccDetails').filterBy('isSelected').length >= 7 &&
        this.ccDetails.countryCode === 'LK'
      ) {
        let message = this.get('i18n').t('ServiceRequest.CCFEEWAVIER.cardLimitMsgLK');
        this.get('rdcModalManager').showDialogModal({
          level: 'info',
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        });
      } else {
        if (event.srcElement.type != 'number') {
          if (this.ccDetails.isGroupFlag) {
            if (editable) {
              if (this.ccDetails.countryCode == 'MY') {
                if (item.get('cardRewardCategory') == 'A') {
                  this.ccDetails.get('groupD')[0].forEach(cardDetail => {
                    set(cardDetail, 'isSelected', false);
                  });
                }
                if (item.get('cardRewardCategory') == 'B') {
                  this.ccDetails.get('groupC')[0].forEach(cardDetail => {
                    set(cardDetail, 'isSelected', false);
                  });
                }
              }
              if (this.ccDetails.countryCode == 'HK') {
                if (item.get('currencyCode') == 'HKD') {
                  this.ccDetails.get('groupD')[0].forEach(cardDetail => {
                    set(cardDetail, 'isSelected', false);
                  });
                }
                if (item.get('currencyCode') == 'CNY') {
                  this.ccDetails.get('groupC')[0].forEach(cardDetail => {
                    set(cardDetail, 'isSelected', false);
                  });
                }
              }
              set(item, 'disabledFlag', false);
              if (item.isSelected) {
                set(item, 'isSelected', false);
              } else {
                set(item, 'isSelected', true);
              }
              this.sendAction('enableNext');
            }
            if (!item.isSelected) {
              item.disabledFlag = true;
            }
          } else if (this.ccDetails.groupAccountNumberFlag) {
            let primaryType = item.get('primaryFlag');
            if (item.isSelected) {
              set(item, 'isSelected', false);
            } else {
              set(item, 'isSelected', true);
            }
            groupingItem.values.forEach(childItem => {
              if (childItem.id != item.id) {
                if (childItem.get('primaryFlag') === primaryType) {
                  set(childItem, 'isSelected', false);
                }
              }
            });
            this.sendAction('enableNext');
          } else {
            if (editable) {
              item.toggleProperty('isSelected');
              item.set('disabledFlag', false);
              let getEle = event.target.getElementsByTagName('input')[0];
              later(() => {
                if (getEle) getEle.focus();
              }, 0);
              this.sendAction('enableNext');
            }
            if (event.target.className == 'childborder childborder-charge' && !item.get('isSelected')) {
              item.set('disabledFlag', true);
              item.set('textData', '');
            }
          }
        }
      }
    },

    selectTransaction: function(editable, item, parentVal, rewardFlag, cardDetails) {
      let amountExcdVal = 0;
      let amountValFlag = false;
      let enableflag = false;
      let errorText = false;
      let showErrFlag = false;
      let pSflag = false;
      let message = this.get('i18n').t('ServiceRequest.CCFEEWAVIER.cardPreSelectionMsg');

      if (event.srcElement.type != 'number') {
        item.toggleProperty('transactionSelected');

        if (!item.get('transactionSelected')) {
          set(item.data, 'errorText', false);
          set(item.data, 'transacOrgnAmount', item.data.transactionAmount);

          parentVal.forEach(childData => {
            childData.get('cardtransactions').forEach(cardTransactionVal => {
              if (cardTransactionVal.get('errorText')) {
                errorText = true;
              }
            });
          });
          if (errorText) {
            set(this.model, 'limitExcdOverRideFlag', true);
          } else {
            set(this.model, 'limitExcdOverRideFlag', false);
          }
        }
        cardDetails.get('cardtransactions').forEach(childVal => {
          if (
            item.get('transactionSelected') &&
            childVal.id == item.get('id') &&
            !childVal.get('transactionSelected')
          ) {
            childVal.set('transactionSelected', true);
          }
          if (!item.get('transactionSelected') && childVal.id == item.get('id')) {
            childVal.set('transactionSelected', false);
          }
          if (
            this.countryCode === 'BN' &&
            this.router.currentRouteName === 'rdc-ui-eng-service-requests.card-feewavier.cards-point'
          ) {
            if (childVal.primarySuppInd == 'P' && cardDetails.get('cardtransactions').length == 2) {
              pSflag = true;
            }
          }
        });
        if (
          this.countryCode === 'BN' &&
          this.router.currentRouteName === 'rdc-ui-eng-service-requests.card-feewavier.cards-point'
        ) {
          cardDetails.get('cardtransactions').forEach(childVal => {
            if (item.primarySuppInd === 'S' && !childVal.get('transactionSelected') && pSflag) {
              if (item.get('transactionSelected')) {
                showErrFlag = true;
              }
            } else if (
              item.primarySuppInd === 'P' &&
              !item.get('transactionSelected') &&
              childVal.get('transactionSelected') &&
              pSflag
            ) {
              showErrFlag = false;
              childVal.set('transactionSelected', false);
            }
          });

          if (showErrFlag) {
            if (item.primarySuppInd === 'S') {
              item.set('transactionSelected', false);
            } else if (item.primarySuppInd === 'P') {
              item.set('transactionSelected', true);
            }

            this.get('rdcModalManager').showDialogModal({
              level: 'info',
              message,
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
              iconClass: 'service-journey-info-icon',
              popupClass: 'service-journey-info-popup'
            });
          }
        }
        if (!rewardFlag) {
          if (item.get('transactionSelected')) {
            this.set(
              'totalVal',
              parseFloat(this.get('totalVal')) +
                (item.data.transacOrgnAmount
                  ? parseFloat(item.data.transacOrgnAmount)
                  : parseFloat(item.data.transactionAmount))
            );
          } else {
            this.set(
              'totalVal',
              parseFloat(this.get('totalVal')) -
                (item.data.transacOrgnAmount
                  ? parseFloat(item.data.transacOrgnAmount)
                  : parseFloat(item.data.transactionAmount))
            );
          }

          parentVal.forEach(element => {
            if (element.get('cardEligibility')) {
              if (element.get('cardEligibility').eligibleReversalCapAmount > 0) {
                amountValFlag = true;
                amountExcdVal = parseFloat(element.get('cardEligibility').eligibleReversalCapAmount);
              }
            }
          });
          if (amountValFlag) {
            if (amountExcdVal >= this.get('totalVal')) {
              enableflag = true;
              this.sendAction('enableNextButton', item, parentVal, enableflag);
            } else {
              enableflag = false;
              this.sendAction('enableNextButton', item, parentVal, enableflag);
            }
          } else {
            enableflag = true;
            this.sendAction('enableNextButton', item, parentVal, enableflag);
          }
        } else {
          if (item.get('transactionSelected')) {
            this.set(
              'totalVal',
              parseFloat(this.get('totalVal')) + parseFloat(item.data.equivalentRewardPoints.rewardsPoints)
            );
          } else {
            this.set(
              'totalVal',
              parseFloat(this.get('totalVal')) - parseFloat(item.data.equivalentRewardPoints.rewardsPoints)
            );
          }

          parentVal.forEach(element => {
            if (element.get('availableCustomerRewardpoint') && element.get('availableCustomerRewardpoint') > 0) {
              amountValFlag = true;
              amountExcdVal = parseInt(element.get('availableCustomerRewardpoint'));
            }
          });

          if (amountValFlag) {
            if (amountExcdVal >= this.get('totalVal')) {
              enableflag = true;
              this.sendAction('enableNextButton', item, parentVal, enableflag);
            } else {
              enableflag = false;
              this.sendAction('enableNextButton', item, parentVal, enableflag);
            }
          } else {
            enableflag = true;
            this.sendAction('enableNextButton', item, parentVal, enableflag);
          }
        }
      }
    },
    textAmountChargeOverride: function(editable, transactionDetails, CardDetails, cardItem, overrideFlag) {
      let enterValue;
      let amountValFlag = false;
      let enableflag = false;
      let amountExcdVal;
      let actualAmount;
      let thisObj = this;
      let limitedAmount;
      let percentageEligible;
      let overrideLimitAmtFlag = false;

      transactionDetails.set('transactionSelected', true);
      enterValue =
        transactionDetails.get('data.transacOrgnAmount') != ''
          ? parseFloat(transactionDetails.get('data.transacOrgnAmount'))
          : '';
      actualAmount = parseFloat(transactionDetails.get('data.transactionAmount'));
      percentageEligible = cardItem.get('cardEligibility')
        ? parseFloat(cardItem.get('cardEligibility.percentageEligible'))
        : '';
      limitedAmount = (actualAmount / percentageEligible).toFixed('2');
      if (
        thisObj.get('queries.countryName') == 'IN' &&
        !overrideFlag &&
        cardItem.get('cardEligibility.percentageEligible')
      ) {
        CardDetails.forEach(cardDetailVal => {
          cardDetailVal.get('cardtransactions').forEach(cardTransactionVal => {
            if (cardTransactionVal.get('transactionAmount') < cardTransactionVal.get('transacOrgnAmount')) {
              overrideLimitAmtFlag = true;
            }
          });
        });

        if (actualAmount < enterValue) {
          transactionDetails.set('data.errorText', true);
          transactionDetails.set('data.limitedAmount', limitedAmount);
          if (transactionDetails.get('transactionSelected') && transactionDetails.get('data.errorText')) {
            set(this.model, 'limitExcdOverRideFlag', true);
          } else {
            set(this.model, 'limitExcdOverRideFlag', false);
          }
          set(this.model, 'overrideLimitFlag', false);
          this.sendAction('reasonSel', '');
          this.sendAction('radioOverRideAction', false);
          this.sendAction('enableNextButton', transactionDetails, CardDetails, true);
          if (limitedAmount < enterValue) {
            let exceedAmount = enterValue.toString().slice(0, -1);
            transactionDetails.set('data.transacOrgnAmount', exceedAmount);
            set(this.model, 'limitExcdOverRideFlag', false);
          }
        } else {
          transactionDetails.set('data.transacOrgnAmount', enterValue);
          transactionDetails.set('data.errorText', false);
          if (overrideLimitAmtFlag) {
            set(this.model, 'limitExcdOverRideFlag', true);
          } else {
            set(this.model, 'limitExcdOverRideFlag', false);
          }
          this.sendAction('reasonSel', '');
          this.sendAction('enableNextButton', transactionDetails, CardDetails, true);
          this.sendAction('radioOverRideAction', false);
          set(this.model, 'overrideLimitFlag', false);
        }

        if (transactionDetails.get('data.transacOrgnAmount')) {
          transactionDetails.set('data.transactionFlag', true);
        } else {
          transactionDetails.set('data.transactionFlag', false);
        }
      } else {
        if (actualAmount < enterValue) {
          let exceedAmount = enterValue.toString().slice(0, -1);
          transactionDetails.set('data.transacOrgnAmount', exceedAmount);
        } else {
          transactionDetails.set('data.transacOrgnAmount', enterValue);
        }

        if (transactionDetails.get('data.transacOrgnAmount')) {
          transactionDetails.set('data.transactionFlag', true);
        } else {
          transactionDetails.set('data.transactionFlag', false);
        }

        this.set('totalVal', 0);

        cardItem.get('cardtransactions').forEach(childVal => {
          if (
            transactionDetails.get('transactionSelected') &&
            childVal.id == transactionDetails.get('id') &&
            !childVal.get('transactionSelected')
          ) {
            childVal.set('transactionSelected', true);
          }
          if (!transactionDetails.get('transactionSelected') && childVal.id == transactionDetails.get('id')) {
            childVal.set('transactionSelected', false);
          }
        });

        cardItem.get('cardtransactions').forEach(childVal => {
          if (parseFloat(childVal.get('transacOrgnAmount')) && childVal.get('transactionSelected')) {
            thisObj.set(
              'totalVal',
              parseFloat(thisObj.get('totalVal')) + parseFloat(childVal.get('transacOrgnAmount'))
            );
          } else if (childVal.get('transactionSelected')) {
            thisObj.set(
              'totalVal',
              parseFloat(thisObj.get('totalVal')) + parseFloat(childVal.get('transacOrgnAmount'))
            );
          }
        });

        CardDetails.forEach(element => {
          if (element.get('cardEligibility')) {
            if (element.get('cardEligibility').eligibleReversalCapAmount > 0) {
              amountValFlag = true;
              amountExcdVal = parseFloat(element.get('cardEligibility').eligibleReversalCapAmount);
            }
          }
        });
        if (amountValFlag) {
          if (amountExcdVal >= this.get('totalVal')) {
            enableflag = true;
            this.sendAction('enableNextButton', transactionDetails, CardDetails, enableflag);
          } else {
            enableflag = false;
            this.sendAction('enableNextButton', transactionDetails, CardDetails, enableflag);
          }
        } else {
          enableflag = true;
          this.sendAction('enableNextButton', transactionDetails, CardDetails, enableflag);
        }
      }
    },

    textAmountCharge: function(editable, textAmount, transactionDetails) {
      transactionDetails.set('data.disabledFlag', false);
      transactionDetails.set('isSelected', true);
      let exceedAmount;
      let txtAmtSplit;
      let numValue;
      let decimalValue;

      if (textAmount) {
        txtAmtSplit = parseFloat(textAmount)
          .toFixed('2')
          .split('.');
        numValue = txtAmtSplit[0];
        decimalValue = txtAmtSplit[1];
        if (numValue.length < 6 && decimalValue.length < 3) {
          exceedAmount = textAmount;
        } else {
          exceedAmount = textAmount.toString().slice(0, -1);
        }
        transactionDetails.set('data.disabledFlag', false);
        transactionDetails.set('data.textData', exceedAmount);
        this.sendAction('enableNext');
      } else {
        transactionDetails.set('data.disabledFlag', true);
        transactionDetails.set('isSelected', false);
        transactionDetails.set('data.textData', '');
        this.sendAction('enableNext');
      }
    },
    checkVerticalCard: function(event) {
      this.set('verticalImage', event.target.naturalHeight > event.target.naturalWidth ? true : false);
    }
  }
});
