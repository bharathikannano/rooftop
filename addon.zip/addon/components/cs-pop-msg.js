import Component from '@ember/component';
import layout from '../templates/components/cs-pop-msg';
import { computed } from '@ember/object';
import { htmlSafe } from '@ember/string';

export default Component.extend({
  layout,
  label: '',
  showMsg: false,
  iconClass: '',
  hasIcon: computed('iconClass', {
    get() {
      return this.get('iconClass') && this.get('iconClass').length;
    }
  }),
  mergedClasses: computed('layoutClass', function() {
    return this.get('layoutClass');
  }),
  htmlSafeLabel: computed('label', {
    get() {
      return htmlSafe(this.get('label'));
    }
  })
});
