import Component from '@ember/component';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';

export default Component.extend({
  queries: service('customer-info'),
  customersData: computed('queries.customersData', function() {
    return this.get('queries.customersData');
  }),
  customerFlowFlag: computed('queries.customerFlowFlag', function() {
    return this.get('queries.customerFlowFlag');
  })
});
