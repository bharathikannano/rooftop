import Component from '@ember/component';
import layout from '../templates/components/customer-login-redirect';
import config from '../config/environment';
import { computed } from '@ember/object';
import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';

export default Component.extend({
  layout,
  classNames: ['login-redirect'],
  axwayConfig: service(),
  htmlSafeLabel: computed('label', {
    get() {
      return htmlSafe(this.get('label'));
    }
  }),
  actions:{
    goToETB: function() {
      if(window.cordova){
        window.location.href = window.location.protocol + '//' + window.location.host + '/exit?RedirPageId=applyProductsETB';
      }else if (this.get('axwayConfig.country') === 'AE') {
        window.location.href = config.backToiBankNTBURL['AE'];
      } else {
         document.location.href = config.backToiBankURL;
      }
    }
  }
});
