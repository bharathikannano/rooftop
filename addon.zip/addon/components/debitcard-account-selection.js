import { A } from '@ember/array';
import { set } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';

export default Component.extend({
  i18n: service(),
  rdcModalManager: service(),
  init() {
    let SelectedData;
    let accountTypes = this.accountTypes != undefined ? this.accountTypes : A();
    if (accountTypes.modelName == 'casa') {
      accountTypes.forEach(data => {
        if (
          data.get('blockListCat').toLowerCase() == this.get('accountTypeFilter') &&
          data.get('isAccType') == this.get('accountName')
        ) {
          SelectedData = {
            name:
              data.get('subProductDescription') +
              ', ' +
              data.get('accountNumber') +
              ', ' +
              data.get('currencyCode') +
              ' ' +
              data.get('currentBalance') +
              ' ' +
              data.get('accountEligibility'),
            value: data.get('accountNumber')
          };
        }
      });
      set(this, 'selectedFromAcc', SelectedData);
    }
    this._super(...arguments);
  },

  actions: {
    // On Selecting of Account(Desktop) options are dynamically modified by using below actions
    openingAccDropdown(getvalue) {
      let options = A();
      let accountTypes = this.accountTypes != undefined ? this.accountTypes : A();
      accountTypes.forEach(data => {
        let values = {
          name:
            data.get('subProductDescription') +
            ', ' +
            data.get('accountNumber') +
            ', ' +
            data.get('currencyCode') +
            ' ' +
            data.get('currentBalance') +
            ' ' +
            data.get('accountEligibility'),
          value: data.get('accountNumber')
        };
        if (data.get('blockListCat').toLowerCase() == getvalue && data.get('isSelected') != 'true') {
          options.pushObject(values);
        }

        this.set('options', options);
      });
    },

    // Updating the model data after the account selection
    selectedAccount(selectedFromAcc) {
      if (selectedFromAcc != undefined) {
        if (this.get('accountValue') != selectedFromAcc.value) {
          this.set('accountValue', selectedFromAcc.value);
          this.set('SelectedValue', 'selected');
          let accountTypesData = this.get('selectCardself.context.accountTypesData');
          accountTypesData.forEach(item => {
            if (item.get('data.accountNumber') == selectedFromAcc.value) {
              item.set('isSelected', 'true');
              item.set('isAccType', this.get('accountName'));
            } else if (
              item.get('data.accountNumber') != selectedFromAcc.value &&
              item.get('isAccType') == this.get('accountName')
            ) {
              item.set('isSelected', 'false');
              item.set('isAccType', '');
            }
          });
          let self = this.get('selectCardself');
          self.controller.get('items').length < 3 &&
          self.controller.get('items').length < self.currentModel.accountTypesData.content.length
            ? self.controller.set('btnAddAccount', true)
            : self.controller.set('btnAddAccount', false);
          self.controller.get('items').length > 1 && this.get('accountName') != 'Primary'
            ? this.set('deleteOption', true)
            : this.set('deleteOption', false);
          this.send('removeUnSelectedAcc');
          this.sendAction('action', 'accountSelected');
        }
      }
    },

    // Following action triggered when selecting of accounts and cardType in Mobile view
    actionModalPopup(
      title,
      accountList,
      carousel,
      desktop,
      getAccname,
      subTitleTxt,
      accountTypeFilter,
      cardTypeError,
      initialSlider
    ) {
      this.send('removeUnSelectedAcc');
      if (carousel) {
        this.get('rdcModalManager')
          .showInfoModal('card-type', {
            title: title,
            cardType: accountList,
            customClass: 'rdc-modal-fullscreen',
            showCrossIcon: true,
            desktop: desktop,
            cardTypeError: cardTypeError,
            initialSlider: initialSlider
          })
          .then(item => {
            let cardTypeData = this.get('selectCardself.controller.cardTypedata');
            cardTypeData.forEach(data => {
              if (data.get('type') == item.get('type')) {
                data.set('isSelectedType', 'true');
              } else {
                data.set('isSelectedType', '');
              }
            });
            this.set('labelValue', item.typeDesc);
            this.set('cardImage', item.cardImage);
            this.set('SelectedValue', 'selected');
            this.sendAction('action', item.get('slidervalue'));
          });
      } else {
        this.get('rdcModalManager')
          .showInfoModal('accountselect-action-modal', {
            title: title,
            accountList: accountList,
            subTitleTxt: subTitleTxt,
            customClass: 'rdc-modal-fullscreen',
            debitFrom: this.get('debitFrom'),
            showCrossIcon: true,
            accountTypeFilter: accountTypeFilter
          })
          .then(item => {
            this.set('SelectedValue', 'selected');
            let accDetails = item.data;
            let accDetailsString =
              accDetails.subProductDescription +
              ', ' +
              accDetails.accountNumber +
              ', ' +
              accDetails.currencyCode +
              ', ' +
              accDetails.currentBalance +
              ' ' +
              accDetails.accountEligibility;
            this.set('labelValue', accDetailsString);
            this.set('accountNumber', accDetails.accountNumber);
            let accountTypesData = this.get('selectCardself.context.accountTypesData');
            accountTypesData.forEach(item => {
              if (item.get('data.accountNumber') == accDetails.accountNumber) {
                item.set('isSelected', 'true');
                item.set('isAccType', this.get('accountName'));
              } else if (
                item.get('data.accountNumber') != accDetails.accountNumber &&
                item.get('isAccType') == this.get('accountName')
              ) {
                item.set('isSelected', 'false');
                item.set('isAccType', '');
              }
            });

            let self = this.get('selectCardself');
            self.controller.get('items').length < 3 &&
            self.controller.get('items').length < self.currentModel.accountTypesData.content.length
              ? self.controller.set('btnAddAccount', true)
              : self.controller.set('btnAddAccount', false);
            self.controller.get('items').length > 1 && this.get('accountName') != 'Primary'
              ? this.set('deleteOption', true)
              : this.set('deleteOption', false);
            this.sendAction('action', 'enableNextAccountSelected');
          });
      }
    },

    deleteSelectedAccount(item) {
      this.sendAction('action', item);
    },

    // Removing the accounts field when no accounts are selected.
    removeUnSelectedAcc() {
      this.get('selectCardself')
        .controller.get('items')
        .forEach(data => {
          if (this.get('accountName') != 'OtherAccount1' && this.get('accountName') != 'OtherAccount2') {
            if (
              data.SelectedValue != 'selected' &&
              (data.accountName == 'OtherAccount1' || data.accountName == 'OtherAccount2')
            ) {
              this.get('selectCardself')
                .controller.get('items')
                .removeObject(data);
              this.get('selectCardself').controller.set('btnAddAccount', true);
            }
          }
        });
    }
  }
});
