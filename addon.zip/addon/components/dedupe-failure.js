import Component from '@ember/component';
import layout from '../templates/components/dedupe-failure';
import { computed, set } from '@ember/object';
import { inject as service } from '@ember/service';
export default Component.extend({
  layout,
  i18n: service(),
  customerInfo: service(),
  isAppDedupe: false,
  classNames: ['dedupe-failure', 'product-fallback'],
  classNameBindings: ['isAppDedupe'],
  mobileNumber: computed(function() {
    return this.get('customerInfo.resumeApplicationMobNo');
  }),
  buttonActionToHome: true,
  init() {
    this._super();
    let types = ['etbResume', 'resumeViaMbnk', 'resumeViaIbnk'];
    let appDedupe =
      this.get('customerInfo.applyProductDedupeType') === 'appDedupe' || types.indexOf(this.get('fallbackType')) != -1
        ? true
        : false;
    set(this, 'isAppDedupe', appDedupe);
    if (
      this.get('fallbackType') === 'monthlyIncomeAlertMultiple' ||
      this.get('fallbackType') === 'monthlyIncomeAlertSingle'
    ) {
      this.set('buttonActionToHome', false);
    }
  },
  fallbackMessage: computed(function() {
    let fallbackType = this.get('fallbackType');
    let message;
    if (fallbackType == 'appSubmitDedupe') {
      message = this.get('i18n').t('productSummary.appSubmitDedupeMessage');
    } else if (fallbackType == 'monthlyIncomeAlertMultiple') {
      /**
       * moved the below code to init **/
      //this.set('buttonActionToHome', false);
      if( this.get('componentType') === 'CC')
        message = this.get('i18n').t('productSummary.incomeAlertMultipleCC');
      else {
        message = this.get('i18n').t('productSummary.incomeAlertMultiple');
      }
    } else if (fallbackType == 'monthlyIncomeAlertSingle') {
      /**
       * moved the below code to init **/
      //this.set('buttonActionToHome', false);
      if( this.get('componentType') === 'CC')
        message = this.get('i18n').t('productSummary.incomeAlertSingleCC');
      else {
        message = this.get('i18n').t('productSummary.incomeAlertSingle');
      }
    } else if (fallbackType == 'relPartyDedupe') {
      message = this.get('i18n').t('productSummary.relPartyDedupeMessage');
    } else if (fallbackType == 'appNTBApproved') {
      message = this.get('i18n').t('productSummary.appNTBApproved');
    } else if (fallbackType == 'etcCustomer') {
      message = this.get('i18n').t('productSummary.etbCustomerMessage');
    } else if (fallbackType == 'etbHardHold' || fallbackType == 'etbInactive') {
      message = this.get('i18n').t('productSummary.etbHardHoldMessage');
    } else if (fallbackType == 'icmDedupe') {
      message = this.get('i18n').t('productSummary.icmDedupeMessage');
    } else if (fallbackType == 'icmMobMismatch') {
      message = this.get('i18n').t('productSummary.icmMobMismatchMessage');
    } else if (fallbackType == 'onBoardingRisk') {
      message = this.get('i18n').t('productSummary.onBoardingRiskMessage');
    } else if (fallbackType == 'privateBankingFlag') {
      message = this.get('i18n').t('productSummary.privateBankingFlagMessage');
    } else if (fallbackType == 'isETBCSLDedupeMatch') {
      message = this.get('i18n').t('productSummary.isETBCSLDedupeMatch');
    } else if (fallbackType == 'isETB') {
      message = this.get('i18n').t('productSummary.isETB');
    } else if (fallbackType == 'isPurposeOfAccBusiness') {
      message = this.get('i18n').t('productSummary.isPurposeOfAccBusiness');
    } else if (fallbackType == 'sanctionCntry') {
      message = this.get('i18n').t('productSummary.sanctionCountry');
    } else if (fallbackType == 'isNonResident') {
      message = this.get('i18n').t('productSummary.isNonResident');
    } else if (fallbackType == 'purposeOfAccAlert') {
      message = this.get('i18n').t('productSummary.purposeOfAccAlertMsg');
    }
    return message;
  }),
  footerButtonText: computed(function() {
    let buttonText = this.get('i18n').t('productSummary.button.backToHomePage');
    return buttonText;
  }),
  dedupeType: computed(function() {
    return this.get('customerInfo.applyProductDedupeType');
  }),
  actions: {
    goResume() {
      this.sendAction('goToResume');
    },
    goBack() {
      if (!this.get('buttonActionToHome')) {
        this.sendAction('back');
      } else {
        this.sendAction('back', 'home');
      }
    }
  }
});
