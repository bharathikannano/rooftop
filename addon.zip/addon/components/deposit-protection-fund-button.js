import Component from '@ember/component';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import layout from '../templates/components/deposit-protection-fund-button';

export default Component.extend({
  layout,
  // Getting the store service.
  store: service(),
  // Adding component default class name.
  classNames: ['deposit-protection-fund-button'],
  // Defaulting the buttonType based on search field to differentiate between add and delete button.
  buttonType: computed('searchField', {
    get() {
      // To find the type of action from search field attribute.
      return !isEmpty(this.searchField) ? this.searchField : 'add';
    }
  }),
  depositActionField: computed('store', {
    get() {
      // Getting the field id dynamically from CSL in the field content attr.
      const fieldId = !isEmpty(this.get('fieldContent')) ? this.get('fieldContent') : 'DepositProtectionAction';
      // caching the field in which the add / delete action string has to be set.
      return this.store.peekRecord('field', fieldId);
    }
  }),
  // Getting the button index from field name inorder to set when add is clicked.
  buttonIndex: computed('name', {
    get() {
      // Slice of negative index always gives the last character of the string.
      return !isEmpty(this.name) ? parseInt(this.name.slice(-1)) : 1;
    }
  }),
  actions: {
    // To add a new regulation field set.
    addRegulation() {
      if (!isEmpty(this.depositActionField)) {
        let value = `${this.buttonType}${this.buttonIndex}`;
        this.depositActionField.set('value', value.toUpperCase());
      }
    }
  }
});
