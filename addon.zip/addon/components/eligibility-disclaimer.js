import Component from '@ember/component';
import layout from '../templates/components/eligibility-disclaimer';

export default Component.extend({
  layout,
  classNames: ['eligibility-disclaimer'],

  init() {
    this._super(...arguments);
  }
});
