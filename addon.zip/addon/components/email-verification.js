import { inject as service } from '@ember/service';
import Component from '@ember/component';
import { isEmpty } from '@ember/utils';
import layout from '../templates/components/email-verification';

export default Component.extend({
  layout,
  classNames: ['rdc-component-base rdc-text-input email-verification'],
  store: service(),
  i18n: service(),
  label: 'Enter Authorisation code',
  placeholder: 'Enter 6 digits',
  regexp: '^[0-9]{6}$',
  regexpErrorMessage: 'Invalid code',
  required: true,
  hideSkipButton: false,
  maxLength: 6,
  type: 'tel',
  moveToNextPage: () => {},
  next: () => {},
  init() {
    this._super(...arguments);
    let officeEmail = this.get('store').peekRecord('field', 'OfficeEmailAddress');
    let isValidAuthCode = this.get('store').peekRecord('field', 'IsValidAuthCode');
    if (!isEmpty(isValidAuthCode) && isValidAuthCode.value === 'Y') {
      this.set('hideSkipButton', true);
    }
    if (!isEmpty(officeEmail)) {
      this.set('officeEmail', officeEmail.value);
    }
    if (this.media.isDesktop) {
      this.set('type', 'password');
    }
  },

  actions: {
    keyDown() {
      this.set('hasError', false);
      this.set('errorMessage', '');
    },
    onVerify() {
      if (this.get('hasError')) {
        return;
      }
      if (!this.value) {
        this.set('hasError', true);
        this.set('errorMessage', this.get('i18n').t('applyProducts.verificationCodeRequired'));
        return;
      }
      let store = this.get('store');
      let verifyRetryCount = store.peekRecord('field', 'AuthRetryCount');
      let verifyMaxRetryCount = store.peekRecord('field', 'AuthMaxRetryCount');
      let skipField = this.get('store').peekRecord('field', 'AuthSkipFlag');
      if (!isEmpty(skipField)) {
        skipField.set('value', 'N');
      }
      let verificationCode = store.peekRecord('field', 'AuthCode');
      if (!isEmpty(verificationCode)) {
        verificationCode.set('value', this.value);
      }
      if (!isEmpty(verifyRetryCount) && !isEmpty(verifyMaxRetryCount)) {
        verifyRetryCount.set('value', parseInt(verifyRetryCount.value) + 1);
        this.next();
        if (verifyRetryCount.value > 0 && verifyRetryCount.value < parseInt(verifyMaxRetryCount.value)) {
          this.set('hasError', true);
          this.set('errorMessage', this.get('i18n').t('applyProducts.incorrectVerificationCode'));
        }
      }
    },

    onSkip() {
      let verificationCode = this.get('store').peekRecord('field', 'AuthCode');
      if (!isEmpty(verificationCode)) {
        verificationCode.set('value', null);
      }
      let skipField = this.get('store').peekRecord('field', 'AuthSkipFlag');
      if (!isEmpty(skipField)) {
        skipField.set('value', 'Y');
      }
      let goToNextpage = this.fallbackType === 'authVerifyAsset' ? true : false;
      this.moveToNextPage(goToNextpage);
    }
  }
});
