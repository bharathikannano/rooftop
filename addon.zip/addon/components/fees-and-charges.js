import Component from '@ember/component';
import layout from '../templates/components/fees-and-charges';

export default Component.extend({
  layout,
  classNames: ['fees-and-charges'],
  actions: {
    goToNext() {
      this.sendAction('transitionToApplyProducts', this.get('selectedProducts'));
    }
  }
});
