import Component from '@ember/component';
import layout from '../templates/components/fere-lightbox-receipt-page';

export default Component.extend({
  layout,
  classNames: ['fere-lightbox-receipt-page']
});
