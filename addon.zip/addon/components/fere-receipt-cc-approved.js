import Component from '@ember/component';
import layout from '../templates/components/fere-receipt-cc-approved';
import { set } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import config from '../config/environment';
import { getOwner } from '@ember/application';

export default Component.extend({
  layout,
  store: service(),
  router: service('-routing'),
  classNames: ['fere-receipt-cc-approved'],
  isAcknowledged: false,
  rdcLoadingIndicator: service(),
  axwayConfig: service(),
  showActionSheet: false,
  defaultRoute: "generic-fere-form",
  init() {
    this._super(...arguments);
    const mobileNumber = this.get('store').peekRecord('field', 'MobileNumber');
    if (mobileNumber) {
      this.set('mobileNumber', mobileNumber.value);
    }
  },
  getFieldValues(buttonData) {
    let finalArray = [];
    // isEmpty check.
    if (!isEmpty(buttonData) && !isEmpty(buttonData.reqFields) && !isEmpty(buttonData.paramNames)) {
      // splitting the values as sent by CSL.
      let filterParams = buttonData.paramNames.split('|'),
          reqFields = buttonData.reqFields.split('|');
      reqFields.forEach((fieldId, index) => {
        // getting the field value.
        const field = this.get('store').peekRecord('field', fieldId);
        // Pushing as array of object to be used which transition.
        if (!isEmpty(field)) {
          let obj = {};
          obj[filterParams[index]] = field.value;
          finalArray.push(obj);
        }
      });
    }
    return finalArray;
  },
  transistionToAnotherRoute(buttonData, stepName) {
    this.get('rdcLoadingIndicator').showLoadingIndicator();
      // To get the req field values to send as filter to CSL.
      let fieldvalues = this.getFieldValues(buttonData),
          relId = this.model.get('additionalInfo').ibankRelId ? this.model.get('additionalInfo').ibankRelId : null,
          sourceRefNo = this.model.get('id') ? this.model.get('id') : null,
          fereRoute = getOwner(this).lookup('route:fere-route'),
          route = buttonData.routeName ? buttonData.routeName : this.get('defaultRoute'),
          queryParams = {
            ctry: this.get('axwayConfig.country'),
            lang: 'en',
            ibankRelId: relId,
            sourceRefNo: sourceRefNo,
            stepName: stepName,
            id: 'W400'
          };
      // Looping the filter and appending to queryParams.
      if (!isEmpty(fieldvalues)) {
        fieldvalues.forEach(filter => {
          Object.keys(filter).forEach(key => {
            queryParams[key] = filter[key];
          });
        });
      }
      // TO transition to new form for creating login credentials.
      fereRoute.transitionTo(route, {
        queryParams: queryParams
      });
  },
  actions: {
    createCredentials(buttonData) {
      this.transistionToAnotherRoute(buttonData, 'CRT_USR');
    },
    balanceTransfer(buttonData) {
      this.transistionToAnotherRoute(buttonData, 'BAL_TRNS');
    },
    review() {
      set(this, 'isAcknowledged', true);
    },
    continue() {
      set(this, 'showActionSheet', true);
    },
    confirm() {
      set(this, 'isAcknowledged', true);
      this.sendAction('submitForm');
    },
    cancel() {
      set(this, 'showActionSheet', false);
    },
    submitForm() {
      this.sendAction('submitForm');
    },
    goHome() {
      if (window.cordova) {
        window.location.href =
          window.location.protocol + '//' + window.location.host + '/retail/api/security/v1/ssoRequest';
      } else {
        const preloginStatus =
          !this.store.peekRecord('field', 'RelationshipNo') ||
          this.store.peekRecord('field', 'RelationshipNo').value === 'NTB';
        if (this.get('axwayConfig.country') === 'AE' && preloginStatus) {
          window.location.href = config.backToiBankNTBURL['AE'];
        } else {
          document.location.href = config.backToiBankURL;
        }
      }
    }
  }
});
