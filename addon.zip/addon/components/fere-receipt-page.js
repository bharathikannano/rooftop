import Component from '@ember/component';
import layout from '../templates/components/fere-receipt-page';
import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';
import { set } from '@ember/object';
import $ from 'jquery';

export default Component.extend({
  layout,
  slideCount: null,
  currentSlide: 0,
  entityDetail: A([]),
  init() {
    this._super(...arguments);
    window.scrollTo(0, 0);

    if (!isEmpty(this.model.additionalInfo.entityDetail)) {
      set(this, 'entityDetail', this.model.additionalInfo.entityDetail);
    } else {
      this.entityDetail.pushObject({
        components: [],
        whatNext: this.model.additionalInfo.whatNext
      });
    }

    this.set('slideCount', this.entityDetail.length - 1);
  },
  actions: {
    slickInit() {
      $('.carousel-slick').slick({
        arrows: false,
        focusOnSelect: false,
        accessibility: false,
        mobileFirst: true,
        infinite: false
      });
    },
    slickBeforeChange(slick, currentSlide, nextSlide) {
      this.set('currentSlide', nextSlide);
    },
    goToPrevSlide() {
      $('.carousel-slick').slick('slickPrev');
    },
    goToNextSlide() {
      $('.carousel-slick').slick('slickNext');
    },
    goToSlide(idx) {
      $('.carousel-slick').slick('slickGoTo', idx);
    }
  }
});
