import Component from '@ember/component';
import layout from '../templates/components/forgot-bvn';
import CordovaMixin from 'rdc-ui-adn-fere/mixins/cordova-plugin-wrapper';

export default Component.extend(CordovaMixin, {
  layout,
  classNames: ['rdc-component-base forgot-bvn'],
  pluginName: 'CallNumber',
  actions: {
    onCancel() {
      this.get('cancel')();
    },
    dialNumber() {
      if (this.get('media.isDesktop')) {
        document.location.href = 'tel:*565*0#';
      } else {
        this._exec('callNumber', ['*565*0#', true]);
      }
    }
  }
});
