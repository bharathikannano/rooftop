import Component from '@ember/component';
import layout from '../templates/components/functional-accordion-item';
import { computed } from '@ember/object';

export default Component.extend({
  layout,
  classNames: ['functional-accordion-item'],
  activeItem: null,
  selectedChildItem: null,
  isExpanded: computed('activeItem', 'item', function() {
    return this.get('activeItem') === this.get('item');
  }),
  actions: {
    toggleStep: function(item) {
      this.toggleActiveItem(item);
    },
    setValues: function(child) {
      this.setValues(child, this.get('item'));
    }
  }
});
