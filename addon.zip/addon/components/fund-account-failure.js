/* eslint-disable no-redeclare */
/* global cordova */
import Component from '@ember/component';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from '../templates/components/fund-account-failure';

export default Component.extend({
  layout,
  classNames: ['rdc-component-base fund-account-failure'],
  axwayConfig: service(),
  // Since now category routing is based on country. Having a computed property.
  shouldGoToCateogry: computed('axwayConfig', function() {
    // category allowed countries.
    let categoryAllowedCountries = ['NG'];
    return categoryAllowedCountries.indexOf(this.get('axwayConfig.country')) !== -1;
  }),
  minAmount: computed('message', function() {
    return this.get('message');
  }),
  actions: {
    // To open fund account actionsheet in native.
    showAccountFundingOptions() {
      if (window.cordova) {
        cordova.exec(null, null, 'FundAccount', 'showInfo', []);
      }
    },
    closeActionSheet() {
      this.cancel();
    },
    close() {
      // To navigate to category page based on the 'shouldGoToCateogry' flag.
      let landingRoute = this.get('shouldGoToCateogry') ? 'category' : 'list';
      this.goToProductSelection(landingRoute);
    }
  }
});
