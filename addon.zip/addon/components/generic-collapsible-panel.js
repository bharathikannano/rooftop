import Component from '@ember/component';
import layout from '../templates/components/generic-collapsible-panel';

export default Component.extend({
  layout,
  header: '',
  message: '',
  init() {
    this._super(...arguments);
    const text = this.label.split('##');
    this.set('header', text[0]);
    this.set('message', text[1]);
  }
});
