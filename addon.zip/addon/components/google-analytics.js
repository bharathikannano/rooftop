import { inject as service } from '@ember/service';
import Component from '@ember/component';
import layout from '../templates/components/google-analytics';
import googleAnalytics from '../mixins/google-analytics';
import constants from '../constants';

export default Component.extend(googleAnalytics, {
  layout,
  queries: service('customer-info'),
  didRender() {
    this._super(...arguments);
    let routeName = this.routeName;
    if (constants.gaEnabledCountries.indexOf(this.get('queries.countryName')) != -1) {
      if (!this.get('queries.gaCalled')) {
        this.set('queries.gaCalled', true);
        this.gaUpdate(routeName);
      }
    }
  }
});
