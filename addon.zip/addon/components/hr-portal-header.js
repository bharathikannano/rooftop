import Component from '@ember/component';
import layout from '../templates/components/hr-portal-header';
import { inject as service} from '@ember/service';

export default Component.extend({
  layout,
  axwayConfig: service(),
  actions:{
    headerNavigation(selectedRoute){
      this.sendAction('headerNavigation',selectedRoute);
    },
    logout(){
      let redirectUrl = `${window.location.origin}/retail/login-app/#/agent-login?ctry=${this.get('axwayConfig.country')}&companyCode=${this.get('companyCode')}&hrEmployeeId=${this.get('hrName')}`;
      window.open(redirectUrl,'_top');
    }
  }
});
