import Component from '@ember/component';
import layout from '../templates/components/icdd-disclosure';
import { inject as service } from '@ember/service';
import { A } from '@ember/array';
import EmberObject from '@ember/object';
import { isEmpty } from '@ember/utils';
import { computed } from '@ember/object';

export default Component.extend({
  layout,
  classNames: ['icdd-disclosure'],
  i18n: service(),
  mainRadioValue: null,
  PEPRadioValue: null,
  sanctionRadioValue: null,
  adverseRadioValue: null,
  // To enable disable the submit button based on the values of radio group.
  enableSubmit: computed('mainRadioValue', 'PEPRadioValue', 'sanctionRadioValue', 'adverseRadioValue', {
    get() {
      return (
        !isEmpty(this.mainRadioValue) &&
        !isEmpty(this.PEPRadioValue) &&
        !isEmpty(this.sanctionRadioValue) &&
        !isEmpty(this.adverseRadioValue)
      );
    }
  }),
  init() {
    this._super(...arguments);
    this._setRadioGrpData();
  },
  // To make the Yes option of other radio groups as readOnly when No is selected in main radio group.
  _enabledisableYesOptions(readOnly) {
    // fieldOptions to be looped.
    let arr = ['PEPRadioFieldOptions', 'sactionRadioFieldOptions', 'adverseRadioFieldOptions'];
    arr.forEach(fieldOptions => {
      // making the first choice readonly..
      this.get(fieldOptions)[0].set('readonly', readOnly);
    });
  },
  // TO set the default radio grp data.
  _setRadioGrpData() {
    // creating the main radio field-options.
    this.set(
      'mainRadioFieldOptions',
      A([
        EmberObject.create({
          id: 'MAIN_YES_NO_CHOICENAME1',
          readonly: false,
          label: 'Yes',
          value: 'Y'
        }),
        EmberObject.create({
          id: 'MAIN_YES_NO_CHOICENAME2',
          readonly: false,
          label: 'No',
          value: 'N'
        })
      ])
    );
    this.set('mainRadioLable', this.get('i18n').t('productSummary.productList.icdd_disclosure.mainRadioLable'));

    // creating the PEP radio field-options.
    this.set(
      'PEPRadioFieldOptions',
      A([
        EmberObject.create({
          id: 'PEP_YES_NO_CHOICENAME1',
          readonly: false,
          label: 'Yes',
          value: 'Y'
        }),
        EmberObject.create({
          id: 'PEP_YES_NO_CHOICENAME2',
          readonly: false,
          label: 'No',
          value: 'N'
        })
      ])
    );
    this.set('PEPRadioLable', this.get('i18n').t('productSummary.productList.icdd_disclosure.PEPRadioLable'));

    // creating the sanctions radio field-options.
    this.set(
      'sactionRadioFieldOptions',
      A([
        EmberObject.create({
          id: 'sanction_YES_NO_CHOICENAME1',
          readonly: false,
          label: 'Yes',
          value: 'Y'
        }),
        EmberObject.create({
          id: 'sanction_YES_NO_CHOICENAME2',
          readonly: false,
          label: 'No',
          value: 'N'
        })
      ])
    );
    this.set('sanctionRadioLable', this.get('i18n').t('productSummary.productList.icdd_disclosure.sanctionRadioLable'));

    // creating the PEP radio field-options.
    this.set(
      'adverseRadioFieldOptions',
      A([
        EmberObject.create({
          id: 'adverse_YES_NO_CHOICENAME1',
          readonly: false,
          label: 'Yes',
          value: 'Y'
        }),
        EmberObject.create({
          id: 'adverse_YES_NO_CHOICENAME2',
          readonly: false,
          label: 'No',
          value: 'N'
        })
      ])
    );
    this.set('adverseRadioLable', this.get('i18n').t('productSummary.productList.icdd_disclosure.adverseRadioLable'));
  },
  actions: {
    //
    selectMainRadio() {
      if (this.mainRadioValue === 'N') {
        this.setProperties({
          PEPRadioValue: 'N',
          sanctionRadioValue: 'N',
          adverseRadioValue: 'N'
        });
        this._enabledisableYesOptions(true);
      } else if (this.mainRadioValue === 'Y') {
        this.setProperties({
          PEPRadioValue: null,
          sanctionRadioValue: null,
          adverseRadioValue: null
        });
        this._enabledisableYesOptions(false);
      }
    },
    submitDisclosure() {
      this.setDisclosure(this.mainRadioValue, this.PEPRadioValue, this.sanctionRadioValue, this.adverseRadioValue);
    }
  }
});
