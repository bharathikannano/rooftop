import Component from '@ember/component';
import layout from '../templates/components/ineligible-customer';

export default Component.extend({
  layout,
  classNames: ['ineligible-customer'],
  actions: {
    onButtonClick(type, resultType) {
      this.flagUpdate(this.get('message.isETB'), type, resultType);
    }
  }
});
