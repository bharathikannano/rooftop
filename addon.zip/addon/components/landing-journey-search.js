import { A } from '@ember/array';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import layout from '../templates/components/landing-journey-search';

export default Component.extend({
  layout,
  i18n: service(),
  articles: null,
  filteredArray: null,
  filteredCategory: computed({
    get() {
      return this.get('model.otherServiceLinks[0].subNavigationLinks');
    }
  }),
  init() {
    this._super(...arguments);
    this.set('filteredAccordionArticles', []);
    this.set('filteredSearchText', '');
  },
  actions: {
    filterCategories(value) {
      if (value) {
        value = value.trim();
      }
      let filterLetterLimit = 3;
      if (
        this.get('i18n.locale') &&
        (this.get('i18n.locale').toLowerCase() == 'zh-hk' || this.get('i18n.locale').toLowerCase() == 'zh-cn')
      ) {
        filterLetterLimit = 1;
      }
      if (value && value.length >= filterLetterLimit) {
        this.set('filteredArray', A());
        let sr = this.get('filteredArray');
        this.get('model').otherServiceLinks.forEach(function(item) {
          item['menu-items'].forEach(function(subitem) {
            let valueCap = value.toUpperCase();
            let categoryCap = subitem['menu-item-name'].toUpperCase();
            let labelText = subitem['menu-item-name'];
            let indexNum = categoryCap.indexOf(valueCap);
            let highlightTextVal = labelText.substr(indexNum, value.length);
            if (indexNum > -1) {
              let highlightText =
                labelText.substr(0, indexNum) +
                "<span class='status-highlight'>" +
                highlightTextVal +
                '</span>' +
                labelText.substr(indexNum + value.length);
              let formedObject = {
                category: item['menu-item-name'],
                subCategory: highlightText,
                route: subitem['action-url'],
                hrefUrl: subitem['href-url'],
                subMenuId: subitem['menu-item-id'],
                queryParam: subitem['query-param']
              };
              sr.pushObject(formedObject);
            }
          });
        });
        if (this.get('filteredArray').length == 0) {
          let noRecordObject = {
            noRecord: true
          };
          this.get('filteredArray').pushObject(noRecordObject);
        }
        this.set('filteredAccordionArticles', this.get('filteredArray'));

        return;
      }
      this.set('filteredAccordionArticles', []);
    }
  }
});
