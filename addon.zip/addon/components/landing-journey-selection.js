import { computed } from '@ember/object';
import Component from '@ember/component';
import layout from '../templates/components/landing-journey-selection';

export default Component.extend({
  layout,
  subCategoryArray: computed({
    get() {
      return this.get('model').otherServiceLinks[0]['menu-items'];
    }
  }),
  selectedRoute: computed({
    get() {
      return this.get('model').otherServiceLinks[0]['menu-items'][0]['action-url'];
    }
  }),
  selectedHref: computed({
    get() {
      return this.get('model').otherServiceLinks[0]['menu-items'][0]['href-url'];
    }
  }),
  filteredCategory: computed({
    get() {
      return this.get('model').otherServiceLinks[0]['menu-items'];
    }
  }),
  selectedCategory: computed({
    get() {
      return this.get('model').otherServiceLinks[0];
    }
  }),
  selectedSubCategory: computed({
    get() {
      this.send(
        'setRoute',
        this.get('model').otherServiceLinks[0]['menu-items'][0]['action-url'],
        this.get('model').otherServiceLinks[0]['menu-items'][0]['href-url']
      );

      return this.get('model').otherServiceLinks[0]['menu-items'][0];
    }
  }),
  actions: {
    categorySwitch: function(value) {
      this.set('selectedCategory', value);
      this.set('subCategoryArray', value['menu-items']);
      this.send('setRoute', value['menu-items'][0]['action-url'], value['menu-items'][0]['href-url']);
      this.set('selectedSubCategory', value['menu-items'][0]);
    },
    subCategorySwitch: function(value) {
      this.set('selectedSubCategory', value);
      this.send('setRoute', value['action-url'], value['href-url']);
      this.sendAction('validateCvd', value['menu-item-id']);
    },
    setRoute: function(route, hrefVal) {
      if (!route) {
        this.set('selectedHref', hrefVal);
        this.set('selectedRoute', null);
      } else {
        this.set('selectedHref', null);
        this.set('selectedRoute', route);
      }
    },
    invokeProceedClick: function() {
      this.sendAction(
        'proceedAction',
        this.get('selectedRoute'),
        this.get('selectedHref'),
        this.get('selectedSubCategory')['query-param'],
        this.get('selectedSubCategory')['menu-item-id']
      );
    }
  }
});
