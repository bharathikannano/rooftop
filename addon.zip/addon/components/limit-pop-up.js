import Component from '@ember/component';
import { inject as service } from '@ember/service';
import layout from '../templates/components/limit-pop-up';
import { computed } from '@ember/object';
import { isNone } from '@ember/utils';

export default Component.extend({
  layout,
  queries: service('customer-info'),
  rdcModalManager: service(),
  classNames: ['rdc-component-base rdc-radio-button-group'],
  didInsertElement() {
    this._super(...arguments);
    let model = this.model.data;
    let cardName = model.selectedCardObject.cardImageName;
    if (!isNone(cardName) && cardName.length > 0) {
      this.set('ccimagesfromjs', 'https://av.sc.com/configuration/content/images/' + cardName + '.png');
    }
    this.setProperties({
      radioGroup: model.radioGroup,
      selectedCardObject: model.selectedCardObject,
      label: this.model.title,
      cardMasking: model.cardMasking,
      limitNotes: model.limitNotes
    });
  },
  cardNoMaskConfig: computed(function() {
    return this.get('queries').cardMaskConfig();
  }),
  actions: {
    onSelect() {
      this.onCloseResolve(...arguments);
    },
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    }
  }
});
