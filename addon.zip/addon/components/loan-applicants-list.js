import Component from '@ember/component';
import layout from '../templates/components/loan-applicants-list';

export default Component.extend({
  layout,
  classNames: ['rdc-component-base loan-applicants-list'],
  activeTab: 'PROCESSING',

  actions: {
    switchTab(tab) {
      this.set('activeTab', tab);
      this.changeTab(tab);
    },

    paginationChange(value) {
      this.pageChange(value);
    },

    onVerify(applicant) {
      this.headerNavigation('hr-portal-applications', applicant);
    }
  }
});
