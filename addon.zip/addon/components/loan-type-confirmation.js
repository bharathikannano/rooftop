import Component from '@ember/component';
import { inject as service } from '@ember/service';
import layout from '../templates/components/loan-type-confirmation';

export default Component.extend({
  layout,
  i18n: service(),

  init() {
    this._super();
    let selectedCardType = this.get('selectedCardType');
    if (selectedCardType === 'CC') {
      this.set('newProduct', this.get('i18n').t('productSummary.productList.newCredit'));
      this.set('newProdIcon', 'uxlab-icon-sc-l-demand-draft');
      this.set('transferProduct', this.get('i18n').t('productSummary.productList.transferCredit'));
      this.set('transferProdIcon', 'uxlab-icon-sc-l-money-change-transfer-limit-01');
    } else if (selectedCardType === 'PL') {
      this.set('newProduct', this.get('i18n').t('productSummary.productList.newLoan'));
      this.set('newProdIcon', 'uxlab-icon-sc-l-demand-draft');
      this.set('transferProduct', this.get('i18n').t('productSummary.productList.transferLoan'));
      this.set('transferProdIcon', 'uxlab-icon-sc-l-money-change-transfer-limit-01');
    }
  },
  actions: {
    onLoanTypeSelection: function(loanType) {
      this.sendAction('onLoanTypeSelection', loanType);
    }
  }
});
