import Component from '@ember/component';
import { inject as service } from '@ember/service';
import layout from '../templates/components/merchant-validation';
import { A } from '@ember/array';

export default Component.extend({
  layout,
  store: service(),
  classNames: ['rdc-component-base rdc-text-input merchant-validation'],
  placeholder: 'Select a mobile number',
  didReceiveAttrs() {
    let mobileNo = A();
    let mobileNumbersList = this.get('merchantMobileNos') ? this.get('merchantMobileNos').split(',') : '';
    let validationType = this.get('merchantValidationType');
    mobileNumbersList.forEach(item => {
      let finalNumber = validationType === 'radio' ? item.replace(/.(?=.{4})/g, '*') : item;
      let mobileNoObject = {
        label: finalNumber,
        value: item
      };
      mobileNo.pushObject(mobileNoObject);
    });
    this.setProperties({
      mobileNumbers: mobileNo,
      validationType: validationType
    });
  },
  actions: {
    chooseMobileNumber(selectedMobileNo) {
      this.set('selectedMobileNo', selectedMobileNo);
      let store = this.get('store');
      if (this.get('validationType') === 'radio') {
        let primaryMobNo = store.peekRecord('field', 'ContactValue1'),
          alternateMobNo = store.peekRecord('field', 'ContactValue2');
        primaryMobNo.set('value', selectedMobileNo);
        // Set the non-selected Mobile number as alternate Mobile number
        this.get('mobileNumbers').map(number => {
          if (number.value !== selectedMobileNo) {
            alternateMobNo.set('value', number.value);
          }
        });
      } else {
        let MerchantMobileNo = store.peekRecord('field', 'MerchantMobileNo');
        MerchantMobileNo.set('value', selectedMobileNo.value);
      }
    },
    onNext() {
      this.sendAction('next');
    },

    onCancel() {
      this.set('selectedMobileNo', '');
      let store = this.get('store');
      let isValidPromoCode = store.peekRecord('field', 'IsValidPromoCode');
      isValidPromoCode.set('value', 'N');
      let MerchantMobileNo = store.peekRecord('field', 'MerchantMobileNo');
      MerchantMobileNo.set('value', '');
      let IsMerchantNoAvailable = store.peekRecord('field', 'IsMerchantNoAvailable');
      IsMerchantNoAvailable.set('value', 'N');
      let promoCancelFlag = store.peekRecord('field', 'PromoCancelFlag');
      promoCancelFlag.set('value', 'Y');
      this.cancel();
    }
  }
});
