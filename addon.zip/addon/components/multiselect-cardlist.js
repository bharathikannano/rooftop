import { inject as service } from '@ember/service';
import Component from '@ember/component';
import EmberObject, { computed, set } from '@ember/object';
import layout from '../templates/components/multiselect-cardlist';
export default Component.extend({
  customerInfo: service(),
  layout,
  i18n: service(),
  lable: null,
  classNames: ['rdc-cards'],
  allowManyActiveItems: false,
  seldesel: true,
  selectedValue: '',
  listId: computed(function() {
    return this.elementId;
  }),
  queries: service('customer-info'),
  selectedReasonFeeWav: computed(function() {
    if (this.model[0]) {
      return this.model[0].reasonSelected;
    }
  }),
  verticalImage: false,

  init() {
    this._super(...arguments);
    this.set('CreditCardDetails', []);
    this.set('errors', []);

    let percentageConvert;
    if (this.CardDetails) {
      if (this.selectedData) {
        this.CardDetails.forEach(childVal => {
          let cardName = childVal.get('cardImageName');
          if (cardName.length > 0) {
            childVal.set('ccimagesfromjs', 'https://av.sc.com/configuration/content/images/' + cardName + '.png');
          } else {
            childVal.set('ccimagesfromjs', 'https://placehold.it/60x40');
          }

          if (this.get('queries.countryName') == 'HK') {
            let digit = childVal.data.descCode.toString()[0],
              CardDesc,
              setDefault;
            setDefault =
              digit == 5
                ? 'MaestroCard'
                : digit == 4
                ? 'VisaCard'
                : digit == 0
                ? 'AmexCard'
                : digit == 6
                ? 'CUPCard'
                : 'DefaultCard';
            CardDesc = this.get('i18n').t('ServiceRequest.creditCardDesc.' + childVal.data.descCode, {
              default: 'ServiceRequest.defaultcreditCardDesc.' + setDefault
            });
            childVal.set('desc', CardDesc);
          } else {
            childVal.get('data.desc');
          }
          if (childVal.get('cardEligibility')) {
            if (childVal.get('cardEligibility').percentageEligible) {
              childVal.set('data.cardEligibility.percentageEligibleFlag', true);
              percentageConvert = parseFloat(childVal.get('cardEligibility').percentageEligible * 100);
              childVal.set('data.cardEligibility.percentageEligibleVal', percentageConvert);
            } else {
              childVal.set('data.cardEligibility.percentageEligibleFlag', false);
            }
          }
        });
      } else {
        this.CardDetails.forEach(childVal => {
          let cardName = childVal.get('cardImageName');
          if (cardName.length > 0) {
            this.set('ccimagesfromjs', 'https://av.sc.com/configuration/content/images/' + cardName + '.png');
          } else {
            this.set('ccimagesfromjs', 'https://placehold.it/60x40');
          }
        });
      }
    }

    //Masking for MY Non Staff
    this.set('cardMasking', this.customerInfo.cardMasking());
    this.set('maskConfig', this.customerInfo.cardMaskConfig());
  },

  actions: {
    enableNext() {
      if (this.CardDetails.isGroupFlag) {
        this.send('sendAction');
      } else {
        if (this.get('CardDetails').filterBy('isSelected').length == this.get('CardDetails.length')) {
          this.send('sendAction');
        } else if (this.get('CardDetails').filterBy('isSelected').length > 0 || this.get('CardDetails.length') == 1) {
          this.send('sendAction');
        } else {
          this.send('sendAction');
        }
        this.send('sendAction');
      }
    },

    sendAction() {
      this.sendAction('enableNext');
    },

    noCardImage(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    },

    enableNextButton(item, parent, flag) {
      let booleanFlag = false;

      parent.forEach(element => {
        element.get('cardtransactions').forEach(transactionElement => {
          let transactionEle = EmberObject.create(transactionElement);
          if (transactionEle.transactionSelected && flag) {
            booleanFlag = true;
          }
          if (booleanFlag) return;
        });
      });
      this.sendAction('enableNextButton', booleanFlag);
    },
    tooltipSelection: function(element, parentElement, event) {
      event.preventDefault();
      element.toggleProperty('tooltipdisplay', true);
      parentElement.forEach(elementVal => {
        if (elementVal.id != element.id) {
          elementVal.set('tooltipdisplay', false);
        }
      });

      if (element.get('tooltipdisplay')) {
        this.sendAction('tooltipOpacityFlag', true);
      } else {
        this.sendAction('tooltipOpacityFlag', false);
      }
    },

    textMandatryCheck: function() {
      this.sendAction('textDataCheck');
    },
    reasonSel: function(data) {
      this.set('selectedReasonFeeWav', data);
      this.sendAction('reasonSel', data);
    },
    hideTooltipSelection: function(element, parentElement, event) {
      event.preventDefault();
      element.set('tooltipdisplay', false);
      parentElement.forEach(elementVal => {
        if (elementVal.id != element.id) elementVal.set('tooltipdisplay', false);
      });
    },
    checkVerticalCard: function(data) {
      if (event.target.naturalHeight > event.target.naturalWidth) {
        set(data, 'verticalImage', true);
      } else {
        set(data, 'verticalImage', false);
      }
    },

    radioOverRideAction: function() {
      if (this.model[0].overrideLimitFlag) {
        set(this.model[0], 'overrideLimitFlag', false);
      } else {
        set(this.model[0], 'overrideLimitFlag', true);
      }
    }
  }
});
