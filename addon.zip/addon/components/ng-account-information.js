import Component from '@ember/component';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import layout from '../templates/components/ng-account-information';

export default Component.extend({
  layout,
  rdcModalManager: service(),
  i18n: service(),
  showActionSheet: false,
  classNames: ['ng-account-information'],
  specificAccountData: computed('data', 'accountType', function() {
    let data = {};
    if (this.data) {
      this.data.ngStartApplication.accountInformation.category.forEach(accountDetails => {
        if (accountDetails.title == this.get('accountType')) {
          data = accountDetails;
        }
      });
    }
    return data;
  }),
  actions: {
    noBVN() {
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message: this.get('i18n').t('ngBvnFlow.noBVN.message'),
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {})
        .catch(() => {});
    },
    closeActionSheet(sendAction) {
      if (sendAction) {
        this.get('closeAccountActionSheet')();
      } else {
        this.set('showActionSheet', false);
      }
    },
    liveSelfieInfo() {
      this.set('showActionSheet', true);
    }
  }
});
