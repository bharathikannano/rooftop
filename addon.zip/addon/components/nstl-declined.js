import Component from '@ember/component';
import layout from '../templates/components/nstl-declined';

export default Component.extend({
  layout,
  classNames: ['ineligible-customer', 'nstl-declined'],
  actions: {
    quitApplication() {
      window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
    }
  }
});
