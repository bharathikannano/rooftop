import Component from '@ember/component';
import layout from '../templates/components/product-details-box-view';

export default Component.extend({
  layout,
  classNames: ['product-details-box-view'],
  isReceiptPage: false,

  init() {
    this._super(...arguments);
    if (this.isReceiptPage) {
      if (this.info) {
        let [productName, productValue] = this.info.split('-');
        this.set('productName', productName);
        this.set('productValue', productValue);
      }
    }
  }
});
