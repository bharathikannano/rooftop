import Component from '@ember/component';
import layout from '../templates/components/product-fallback';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';

export default Component.extend({
  i18n: service(),
  layout,
  classNames: ['product-fallback'],
  axwayConfig: service(),
  isCDDRiskAvailableInfo: computed('axwayConfig', {
    get() {
      return this.get('i18n').t(
        'productSummary.isCDDRiskAvailable.info1_' + this.get('axwayConfig.country').toUpperCase(),
        {
          default: 'productSummary.isCDDRiskAvailable.default'
        }
      );
    }
  }),
  actions: {
    goToPreLogin() {
      this.sendAction('goToPreLogin');
    },
    submitForm() {
      this.next('terminateApp');
    }
  }
});
