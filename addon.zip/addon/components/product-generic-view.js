import Component from '@ember/component';
import layout from '../templates/components/product-generic-view';
import { isEmpty } from '@ember/utils';

export default Component.extend({
  layout,
  isReceiptPage: false,
  classNameBindings: ['showComponent:to-show:to-hide'],
  showComponent: false,
  init() {
    this._super(...arguments);
    if (this.isReceiptPage) {
      if (this.info) {
        let [decisionFlag, productTitle, productDescription] = this.info.split('-');
        this.set('decisionFlag', decisionFlag);
        this.set('productTitle', productTitle);
        this.set('productDescription', productDescription);
      }
      if (!isEmpty(this.decisionFlag) && this.decisionFlag === 'Yes') {
        this.set('showComponent', true);
      }
    }
  },
  actions: {
    balanceTransfer(buttonData) {
      this.balanceTransfer(buttonData);
    }
  }
});
