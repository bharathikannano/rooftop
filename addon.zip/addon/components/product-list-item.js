import Component from '@ember/component';
import layout from '../templates/components/product-list-item';
import { computed } from '@ember/object';
import { htmlSafe } from '@ember/string';

export default Component.extend({
  layout,
  selected: false,
  htmlSafeDesc: computed('data.productDescription', {
    get() {
      return htmlSafe(this.get('data.productDescription'));
    }
  }),
  init() {
    this._super(...arguments);
  },
  classNames: ['product-list-item'],
  actions: {
    onProductSelect: function(product, category) {
      this.sendAction('onProductSelection', product, category);
    },
    insuranceBanner(data) {
      this.get('insuranceBanner', data)();
    }
  }
});
