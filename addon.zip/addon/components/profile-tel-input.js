import Component from '@ember/component';
import layout from '../templates/components/profile-tel-input';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { scheduleOnce } from '@ember/runloop';
import { inject as service } from '@ember/service';

export default Component.extend({
  layout,
  classNames: ['profile-tel-input'],
  _innerRegExp: null,
  router: service(),
  /*
    Check prePopulated value has hypen (-)
  */
  formattingValue: computed('value', {
    get() {
      let selectedItem = this.element.querySelector('.country-detail')
      if (!isEmpty(this.value)) {
        return isEmpty(selectedItem) && !isEmpty(this.value);
      }
    }
  }),

  invalidNo: computed('value', {
    get() {
      return new RegExp('^[-][0-9]{1,16}$').test(this.value);
    }
  }),

  /*
    Invalid number checking from prepopulation & not changing value without user edits.
  */
  _setRegExp() {
    if (this.oldValue === this.value && !isEmpty(this.regexp) && this.invalidNo && !this.required) {
      this.set('_innerRegExp', this.regexp);
      this.set('regexp', null);
    } else if (this.oldValue !== this.value && !isEmpty(this._innerRegExp) && this.invalidNo && !this.required) {
      this.set('regexp', this._innerRegExp);
      this.set('_innerRegExp', null);
    }
  },

  didInsertElement() {
    this._super(...arguments);
    this._setRegExp();
  },

  didUpdateAttrs() {
    this._super(...arguments);
    scheduleOnce('render', this, () => {
      this._setRegExp();
    });
  },

  willDestroyElement() {
    this._super(...arguments);
    if (
      !isEmpty(this._innerRegExp) &&
      isEmpty(this.regexp) &&
      this.router.currentRouteName === 'rdc-ui-eng-service-requests.profileUpdate.ferePage'
    ) {
      this.set('regexp', this._innerRegExp);
    }
  },

  /*
    Adding '-' back if VALUE is invalid
  */
  invalidNoPopulate(value) {
    if (this.formattingValue && !isEmpty(this.value)) {
      this.set('value', `-${value}`);
    }
  },

  actions: {
    focusOut() {
      this.invalidNoPopulate(this.value);
      this._setRegExp();
    }
  }
});
