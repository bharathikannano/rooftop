import Component from '@ember/component';
import layout from '../templates/components/range-slider';

export default Component.extend({
  layout,
  minValue: 0,
  maxValue: null,
  rangeStep: null,
  disabled: false,
  type: 'range',
  value: null,
  required: false,

  onSelectedRange: () => {},

  classNames: ['range-slider-wrapper'],

  classNameBindings: ['required:is-mandatory', 'disabled:is-disabled', 'tooltipMessage:has-tooltip'],

  actions: {
    onSliderMoved(e) {
      let value = e.target.value;
      this.set('value', value);
      this.onSelectedRange(this.value);
    }
  }
});
