import Component from '@ember/component';
import { isEmpty } from '@ember/utils';
import { assign } from '@ember/polyfills';
import { inject as service } from '@ember/service';
import { scheduleOnce } from '@ember/runloop';
import { getOwner } from '@ember/application';
import layout from '../templates/components/rdc-accordion-select';

export default Component.extend({
  layout,
  classNames: ['rdc-accordion-select'],
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  activeItem: null,
  noAction: false,
  selectedChildItem: '',
  init() {
    this._super(...arguments);
    this.set('errorMsg', this.get('i18n').t('TRANSACTIONDISPUTE.reasonRequired'));
    if (this.get('action')) {
      this.set('noAction', true);
    }
    if (!isEmpty(this.value)) {
      let selectedParent = this.get('options').filterBy('value', this.value['parentValue'])[0];
      this.set('selectedChildItem', this.value['childValue']);
      this.send('toggleActiveItem', selectedParent);
    }

    if (this.reviewMode && !isEmpty(this.value)) {
      this.set('parentValue', this.value.parentLabel);
      this.set('childValue', this.value.label);
    }
  },

  triggerAction(action) {
    getOwner(this)
      .lookup('route:fere-route')
      .send(this.modal[action]);
  },

  actions: {
    toggleActiveItem(currentItem) {
      if (this.get('activeItem') !== currentItem) {
        this.set('activeItem', currentItem);
      } else {
        this.set('activeItem', null);
      }
    },
    setValues(child, item) {
      this.set('selectedChildItem', child.value);
      let selectedValue = {
        parentValue: item.value,
        childValue: child.value,
        label: child.label,
        parentLabel: item.label,
        value: 'dummy'
      };
      this.set('value', selectedValue);

      scheduleOnce('render', this, () => {
        if (this.get('action')) {
          if (this.modal) {
            this.get('rdcModalManager')
              [this.modal.type](assign({}, this.modal))
              .then(() => {
                this.triggerAction('acceptAction');
                this.set('modal', null);
              })
              .catch(() => {
                if (!isEmpty(this.modal.rejectAction)) {
                  this.triggerAction('rejectAction');
                }
                this.set('modal', null);
              });
          } else {
            this.set('modal', null);
            this.action();
          }
        }
      });
    }
  }
});
