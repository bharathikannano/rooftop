import { htmlSafe } from '@ember/string';
import { computed, setProperties } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import layout from '../templates/components/rdc-account-holder';

export default Component.extend({
  layout,
  i18n: service(),
  classNames: ['rdc-account-holder', 'rdc-collapsible-panel---no-decorator'],
  expandable: true,
  index: '',
  value: '',
  isOpen: false,
  label: '',
  type: '',
  required: true,
  isTypeInput: computed('type', {
    get() {
      return this.get('type') === 'input';
    }
  }),
  accountTitle: computed('index', {
    get() {
      let label;
      let index = this.get('index') + 1;
      if (this.get('index') == 0) {
        label = this.get('i18n').t('ServiceRequest.JOINTACCOUNT.primaryAccount') + ' #' + index;
      } else {
        label = this.get('i18n').t('ServiceRequest.JOINTACCOUNT.secondaryAccount') + ' #' + index;
      }

      return label;
    }
  }),

  init() {
    this._super(...arguments);
    this.set('field', {
      firstName: {},
      lastName: {},
      mobileNumber: {},
      emailAddress: {}
    });

    let field = this.get('field');
    setProperties(field.firstName, {
      name: 'firstName',
      label: htmlSafe(this.get('i18n').t('ServiceRequest.JOINTACCOUNT.firstName')).toString(),
      regexp: '^[a-zA-Z]+([ a-zA-Z])*$',
      hasError: false
    });
    setProperties(field.lastName, {
      name: 'lastName',
      label: htmlSafe(this.get('i18n').t('ServiceRequest.JOINTACCOUNT.lastName')).toString(),
      regexp: '^[a-zA-Z]+([ a-zA-Z])*$',
      hasError: false
    });
    setProperties(field.mobileNumber, {
      name: 'mobileNumber',
      label: htmlSafe(this.get('i18n').t('ServiceRequest.JOINTACCOUNT.mobileNumber')).toString(),
      regexp: '^[0-9]{11,}$',
      hasError: false
    });
    setProperties(field.emailAddress, {
      name: 'emailAddress',
      label: htmlSafe(this.get('i18n').t('ServiceRequest.JOINTACCOUNT.emailAddress')).toString(),
      regexp: '^\\w+([\\.\\-]?\\w+)*\\@\\w+([\\.\\-]?\\w+)*(\\.\\w{2,3})+$',
      hasError: false
    });
  },

  _validate() {
    let value = this.get('value');
    let field = this.get('field');
    let isValid = true;

    for (const prop in field) {
      isValid = isValid && !field[prop].hasError && !!value[prop];
    }

    this.set('value.hasError', !isValid);
  },

  actions: {
    focusOut() {
      this._validate();
      this.sendAction('focus-out');
    }
  }
});
