import Component from '@ember/component';
import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import layout from '../templates/components/rdc-account-list';

export default Component.extend({
  layout,
  i18n: service(),
  rdcLoadingIndicator: service(),
  store: service(),
  customerInfo: service(),
  classNames: ['rdc-component-base rdc-account-list'],
  accounts: A(),
  didInsertElement() {
    this._super(...arguments);
    this.set('cardSpacing', this.customerInfo.cardMaskConfig());
    if (this.apiUrl) {
      const peekAccounts = this.get('store').peekAll(this.apiModel);
      if (peekAccounts.length === 0) {
        this.get('rdcLoadingIndicator')
          .showLoadingIndicatorForPromise(
            this.get('store').query(this.apiModel, { filter: JSON.parse(this.apiUrl.replace(/'/g, '"')).filter })
          )
          .then(data => {
            if (!data.length) {
              this.set('noData', true);
              return;
            }
            this.set('accounts', data);
          });
      } else {
        this.set('accounts', peekAccounts);
      }
    } else if (this.reviewMode) {
      this.set('reviewValue', `${this.value.desc} ${this.value.cardNum}`);
    }
  },

  actions: {
    setSelectedAccount(account) {
      if (!isEmpty(this.value) && account.id === this.value.id) {
        this.sendAction('action');
        return;
      }
      this.accounts.forEach(item => {
        item.set('selected', false);
      });
      account.set('selected', true);
      let accountObj = {};
      account.constructor.eachAttribute(function(key) {
        //to remove attributes with undefined/null values
        if (!isEmpty(account[key])) {
          accountObj[key] = account[key];
        }
      });
      accountObj.id = account.get('id');
      this.set('value', accountObj);
      this.sendAction('action');
    }
  }
});
