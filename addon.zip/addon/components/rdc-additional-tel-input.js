import Component from '@ember/component';
import layout from '../templates/components/rdc-additional-tel-input';
import EmberObject, { set } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { A } from '@ember/array';

export default Component.extend({
  layout,
  classNames: ['rdc-component-base rdc-additional-tel-input'],

  required: false,
  reviewMode: false,
  regexp: null,
  errorLabel: '',
  hasErrorLabel: false,
  primaryMobileNumberError: false,
  previousMobileNumberError: false,
  hasError: false,
  validation: null,
  labelCount: 0,
  errorState: false,

  classNameBindings: [
    'hasError:has-error',
    'errorState',
    'hasLabel:no-label',
    'reviewMode:is-reviewmode',
    'required:is-mandatory'
  ],

  label: 'Additional Mobile Number',
  numberOfFields: 1,
  primaryMobileNumber: '',

  init() {
    this._super(...arguments);
    if (typeof this.value === 'object' && !isEmpty(this.value)) {
      this._setValues();
    } else {
      this.set('fields', null);
    }

    this._removeEmptyValues();
  },

  /** Label Count **/
  _setLabelCount() {
    set(this, 'labelCount', 0);
    this.fields.forEach((item, index) => {
      let lbl = `Additional Mobile Number ${++this.labelCount} (Optional)`;
      set(this.fields[index], 'label', lbl);
    });
  },

  /** Set Values **/
  _setValues() {
    this.set('fields', A([]));
    this.value.forEach(item => {
      this.get('fields').pushObject(item);
    });
    this._setLabelCount();
  },

  /** Removing empty values while loading component **/
  _removeEmptyValues() {
    if (!isEmpty(this.fields)) {
      this.fields.forEach(item => {
        if (isEmpty(item.value)) {
          this.value.removeObject(item);
          this.fields.removeObject(item);
          this._setLabelCount();
        }
      });
    }
  },

  checkExistingNumber() {
    let MobileValArr = [];

    this.fields.forEach(item => {
      MobileValArr.push(item.value);
    });

    this.set('errorState', false);
    this.set('previousMobileNumberError', false);
    this.set('primaryMobileNumberError', false);

    /** previousMobileNumberError and previousMobileNumberError handle **/
    MobileValArr.forEach((item, index) => {
      if (MobileValArr.indexOf(item) != index && item != null) {
        this.set('errorState', true);
        this.set('previousMobileNumberError', true);
        if (MobileValArr.indexOf(item) != index && (this.value[index] && !isEmpty(this.value))) {
          this.value.removeAt(index);
          this._setValues();
        }
      } else if (MobileValArr.includes(this.primaryMobileNumber) && !isEmpty(this.primaryMobileNumber)) {
        this.set('errorState', true);
        this.set('primaryMobileNumberError', true);
        if (!isEmpty(item) && item.includes(this.primaryMobileNumber)) {
          this.value.removeAt(index);
          this._setValues();
        }
      }
    });
  },

  actions: {
    /** addMoreNumber **/
    addMoreNumber() {
      if (isEmpty(this.fields)) {
        this.set(
          'fields',
          A([
            EmberObject.create({
              value: '',
              label: `Additional Mobile Number ${++this.labelCount} (Optional)`
            })
          ])
        );
      } else {
        this.fields.pushObject(
          EmberObject.create({
            value: '',
            label: `Additional Mobile Number ${++this.labelCount} (Optional)`
          })
        );
      }
      this.checkExistingNumber();
    },

    /** removeNumber **/
    removeNumber(index) {
      this.fields.removeAt(index);
      this._setLabelCount();
      this.set('value', this.fields);
      this.checkExistingNumber();
    },

    chooseDestination() {
      this.set('value', this.fields);
      this.checkExistingNumber();
    },

    focusOut() {
      this.set('value', this.fields);
      this.checkExistingNumber();
    }
  }
});
