import Component from '@ember/component';
import layout from '../templates/components/rdc-aip-component';

export default Component.extend({
  layout,
  classNames: ['rdc-text-input rdc-aip-component'],
  init() {
    this._super(...arguments);
    this.set('allLabels', JSON.parse(this.label.replace(/'/g, '"')));
  }
});
