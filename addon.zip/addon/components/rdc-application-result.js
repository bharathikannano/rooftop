import Component from '@ember/component';
import layout from '../templates/components/rdc-application-result';
import { inject as service } from '@ember/service';
import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';

export default Component.extend({
  layout,
  i18n: service(),
  store: service(),
  classNames: ['rdc-application-result'],
  isAppSofDecline: false,
  productSteps: A([]),
  action: () => {},
  init() {
    this._super(...arguments);
    let steps = A([
      {
        title: this.get('i18n').t('applyProducts.applicationResult.step1'),
        status: 'is-active'
      },
      {
        title: this.get('i18n').t('applyProducts.applicationResult.step2')
      },
      {
        title: this.get('i18n').t('applyProducts.applicationResult.step3')
      }
    ]);
    let ProductDescription = this.get('store').peekRecord('field', 'ProductDescription');
    if (!isEmpty(ProductDescription) && !isEmpty(ProductDescription.value)) {
      [this.accountName, this.cardImgSource] = ProductDescription.value.split('#');
    }
    this.set('productSteps', steps);
    this.appResultType = this.get('searchField') || this.get('appResultType');
    this.classNames = ['rdc-application-result', this.appResultType];

    let pcoDecline = this.appResultType === 'appDeclineSoft';
    let clientDeclineNtb = this.appResultType === 'declineSoftBundleFlag';
    let clientDeclineEtb = this.appResultType === 'declineHardBundleFlag';

    this.set('pcoDecline', pcoDecline);
    this.set('clientDeclineNtb', clientDeclineNtb);
    this.set('clientDeclineEtb', clientDeclineEtb);

    let info =
        this.get('pcoDecline')
          ? this.get('i18n').t('applyProducts.applicationResult.pcoDeclineInfo')
          : this.get('clientDeclineNtb') ? this.get('i18n').t('applyProducts.applicationResult.declineBundledInfo')
          : this.get('clientDeclineEtb') ? this.get('i18n').t('applyProducts.applicationResult.declineBundledInfo') : '',
      btnLabel =
      this.get('pcoDecline')
          ? this.get('i18n').t('ServiceRequest.COMMON.button.quitApplication')
          : this.get('clientDeclineNtb') ? this.get('i18n').t('ServiceRequest.COMMON.button.continueApplication')
          : this.get('clientDeclineEtb') ? this.get('i18n').t('ServiceRequest.COMMON.button.quitApplication') : '';

    // overriding the title info and btn label for referred flow.
    if (this.get('appResultType') === 'appReferred') {
      this.set('title', this.get('i18n').t('applyProducts.applicationResult.referredTitle'));
      info = this.get('i18n').t('applyProducts.applicationResult.referredInfo');
      btnLabel = this.get('i18n').t('ServiceRequest.COMMON.button.ok');
    }

    this.setProperties({
      info: info,
      btnLabel: btnLabel,
      btnSecLabel: this.get('i18n').t('ServiceRequest.COMMON.button.back')
    });
  },
  actions: {
    onVerify(updateFlag, terminateFlag) {
      // app refered happens only in ETB flow and on close should move to service-request.
      if (this.get('appResultType') === 'appReferred') {
        this.flagUpdate(true, 'close');
      } else {
        // To execute below action "field-action": "applicationResult" should be configured in CSL side.
        // updateFlag => hbs, secound & third Param from above flag.
        this.action(updateFlag, terminateFlag, this.get('appResultType'));
      }
    }
  }
});
