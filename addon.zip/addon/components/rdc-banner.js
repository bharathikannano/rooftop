import Component from '@ember/component';
import layout from '../templates/components/rdc-banner';

export default Component.extend({
  layout,
  classNames: ['insurance-banner'],
  actions: {
    insuranceBannerOkBtn() {
      this.closeInsuranceBanner();
    }
  }
});
