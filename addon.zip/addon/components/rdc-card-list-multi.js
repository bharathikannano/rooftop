import { readOnly, notEmpty } from '@ember/object/computed';
import Component from '@ember/component';
import layout from '../templates/components/rdc-card-list-multi';
import { A } from '@ember/array';
import { computed } from '@ember/object';

export default Component.extend({
  layout,
  reviewMode: false,
  options: A(),
  categorizeCard: false,
  value: A(),
  length: readOnly('value.length'),
  classNames: ['rdc-component-base rdc-card-list'],
  classNameBindings: [
    'hasError:has-error',
    'hasLabel::no-label',
    'labelPositionClasss',
    'reviewMode:is-reviewmode',
    'required:is-mandatory'
  ],
  hasLabel: notEmpty('label'),
  hasErrorLabel: notEmpty('errorLabel'),
  isNoOptions: computed('options', 'reviewMode', 'length', {
    get() {
      if (this.get('reviewMode')) {
        return false;
      } else {
        let options = this.get('options') && !!this.get('options').length;
        return !options;
      }
    }
  }),
  _updateValueByType() {
    if (this.get('categorizeCard') && this.get('value')) {
      this.set('valueByType', this._groupByType(this.get('value'), 'cardType'));
    }
  },

  _groupByType(list, property) {
    return list.reduce(function(rv, x) {
      (rv[x[property]] = rv[x[property]] || []).push(x);
      return rv;
    }, {});
  },

  init() {
    this._super(...arguments);
    this.setProperties({
      optionsByType: {},
      valueByType: {}
    });

    if (this.get('categorizeCard')) {
      this.set('optionsByType', this._groupByType(this.get('options'), 'cardType'));
    }
    this._updateValueByType();
  },

  actions: {
    selectAll(items) {
      let selected = this.get('value') || A();
      selected = selected.pushObjects(items);

      this.set('value', selected.uniq());
      this._updateValueByType();
    },
    deselectAll() {
      let selected = A();
      this.set('value', selected);
      this._updateValueByType();
    },
    removeCard(item) {
      let selected = this.get('value') || A();
      selected = selected.removeObject(item);
      if (selected.length < 1) {
        selected = A();
      }
      this.set('value', selected);
      this._updateValueByType();
    },
    selectCard(item) {
      let selected = this.get('value') || A();
      selected = selected.pushObjects([item]);
      this.set('value', selected.uniq());
      this._updateValueByType();
    }
  }
});
