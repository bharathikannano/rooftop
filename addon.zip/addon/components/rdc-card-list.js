import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import { A } from '@ember/array';
import layout from '../templates/components/rdc-card-list';

export default Component.extend({
  layout,
  reviewMode: false,
  i18n: service(),
  value: A(),
  options: A(),
  categorizeCard: false,
  isSelectAll: computed('value', 'option', 'length', {
    get() {
      let value = this._updateSelectedValue();
      let optionCount = this.get('options') && this.get('options').length;
      return value.length !== optionCount;
    }
  }),
  selected: computed('value', 'option', 'length', {
    get() {
      return this._updateSelectedValue();
    }
  }),
  _updateSelectedValue() {
    let value;

    value = this.get('value') || A();
    if (this.get('type')) {
      value = this.get('value')[this.get('type')] || A();
    }

    return value;
  },
  actions: {
    selectAll: function() {
      this.sendAction('selectAll', this.get('options'));
    },
    deselectAll: function() {
      this.sendAction('deselectAll', this.get('options'));
    },
    removeCard(item) {
      this.sendAction('removeCard', item);
    },
    selectCard(item) {
      this.sendAction('selectCard', item);
    }
  }
});
