/* global $ */
import Component from '@ember/component';
import { computed } from '@ember/object';
import layout from '../templates/components/rdc-card-number';
import { isEmpty } from '@ember/utils';
import errorMessageSupport from 'rdc-ui-adn-components/mixins/error-message-support';

export default Component.extend(errorMessageSupport, {
  layout,
  disabled: false,
  readonly: false,
  required: false,
  reviewMode: false,
  type: 'tel',
  regexp: null,
  label: '',
  errorLabel: '',
  hasErrorLabel: false,
  labelPosition: 'top',
  hasError: false,
  validation: null,
  formatNumber: true,
  maxlength: 19,
  cardValue: '',
  backupVal: '',
  labelPositionClasss: computed('labelPosition', {
    get() {
      if (this.get('labelPosition') === 'top') {
        return 'label-top';
      } else if (this.get('labelPosition') === 'left') {
        return 'label-left';
      } else {
        return 'full-width';
      }
    }
  }),

  classNames: ['rdc-component-base rdc-text-input rdc-card-number'],

  classNameBindings: [
    'isFocused:focusedcss',
    'hasLabel::no-label',
    'labelPositionClasss',
    'reviewMode:is-reviewmode',
    'hasError:has-error',
    'required:is-mandatory',
    'readonly:is-readonly',
    'disabled:is-disabled'
  ],

  value: '',

  isFocused: false,

  isValid: false,

  init() {
    this._super(...arguments);

    let value = this.get('value') && this.formatNumberWithSpace(this.get('value'));
    this.set('cardValue', value);
  },

  formatNumberWithSpace(num) {
    let value = num.toString().replace(/ /g, '');

    value = value.replace(/(\d{4})/g, '$1 ').replace(/(^\s+|\s+$)/, '');
    return value;
  },

  setValue(val) {
    let value = val.toString();

    this.set('cardValue', value);
    value = value.replace(/ /g, '');
    this.set('value', value);
  },

  setError(isValid) {
    if (!isValid) {
      this.set('isValid', false);
      this.set('hasError', true);
      this.set('errorLabel', this.get('i18n').t('FERE.validation.error.invalidCard'));
    } else {
      this.set('hasError', false);
      this.set('isValid', true);
      this.set('errorLabel', null);
    }
  },

  actions: {
    keyPress() {
      let evt = evt ? evt : window.event;
      let charCode = evt.which ? evt.which : evt.keyCode;

      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        evt.preventDefault();
      }

      if (charCode === 48 && this.get('value') === '0') {
        evt.preventDefault();
      }

      $('input').on('paste', function() {
        return false;
      });
    },

    keyDown() {
      this.sendAction('key-down');
    },

    keyUp: function() {
      let numRegexp = /^\d+$/;
      if (!numRegexp.test(event.target.value.replace(/\s/g, '')) && event.target.value) {
        this.$('input')[0].value = null;
        this.set('value', this.get('backupVal'));
      } else {
        this.set('backupVal', this.get('value'));
      }
      this.setValue(this.formatNumberWithSpace(this.get('cardValue')));
    },

    focusIn() {
      this.set('isFocused', true);
    },

    focusOut() {
      this.set('isFocused', false);
      this.focusOutValidation();

      if (!isEmpty(this.get('value'))) {
        this.setError(this.validateCardNumber(this.get('value')));
      }
    }
  },
  validateCardNumber(value) {
    let nCheck = 0,
      nDigit = 0,
      bEven = false;
    value = value.replace(/\D/g, '');
    for (let n = value.length - 1; n >= 0; n--) {
      let cDigit = value.charAt(n);
      nDigit = parseInt(cDigit, 10);
      if (bEven) {
        if ((nDigit *= 2) > 9) nDigit -= 9;
      }
      nCheck += nDigit;
      bEven = !bEven;
    }
    return nCheck !== 0 && nCheck % 10 == 0;
  }
});
