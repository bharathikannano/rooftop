import { computed } from '@ember/object';
import Component from '@ember/component';
import layout from '../templates/components/rdc-card';

export default Component.extend({
  layout,
  tagName: 'div',
  reviewMode: false,
  option: null,
  checked: computed('selected', 'option', 'length', {
    get() {
      return !this.get('reviewMode') && this.get('selected') && this.get('selected').indexOf(this.get('option')) > -1;
    }
  }),
  isSuccess: computed('option', 'length', {
    get() {
      let status = this.get('option').status;
      if (status) {
        status = status.toLowerCase();
        return status.includes('approved');
      }
      return false;
    }
  }),
  isFailed: computed('option', 'length', {
    get() {
      let status = this.get('option').status;
      if (status) {
        status = status.toLowerCase();
        return status.includes('reject') || status.includes('decline');
      }
      return false;
    }
  }),
  classNames: ['rdc-card-component'],
  classNameBindings: ['checked:checked'],
  init() {
    this._super(...arguments);

    let imageUrl = this.get('option').cardImage;
    let sourceSet = imageUrl + '.png 1x, ' + imageUrl + '@2x.png 2x, ' + imageUrl + '@3x.png 3x';

    this.set('cardImage', imageUrl + '.png');
    this.set('cardImageSrcSet', sourceSet);
  },
  actions: {
    selectCard(item) {
      if (!this.get('readonly')) {
        if (this.get('checked')) {
          this.sendAction('removeCard', item);
        } else {
          this.sendAction('selectCard', item);
        }
      }
    }
  }
});
