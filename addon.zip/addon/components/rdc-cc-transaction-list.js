import Component from '@ember/component';
import { inject as service } from '@ember/service';
import { A } from '@ember/array';
import EmberObject from '@ember/object';
import { isEmpty } from '@ember/utils';
import moment from 'moment';
import layout from '../templates/components/rdc-cc-transaction-list';

export default Component.extend({
  layout,
  store: service(),
  classNames: ['rdc-component-base rdc-cc-transaction-list'],
  rdcLoadingIndicator: service(),
  activeEle: 'all',
  rdcModalManager: service(),
  i18n: service(),
  transactions: A(),
  groupedTransaction: A(),
  reviewLabelHeader: A(),
  didInsertElement() {
    this._super(...arguments);
    if (this.reviewMode && this.label) {
      let titles = this.label.split('##');
      this.set('fieldLabel', titles[0]);
      titles.splice(0, 1);
      this.set('reviewLabelHeader', titles);
    } else if (this.readonly) {
      this.groupData(this.value, true);
    } else {
      if (this.value && this.value.length) {
        this.value.forEach(transaction => {
          transaction.isSelected = true;
        });
      }

      let apiDetail = JSON.parse(this.apiUrl.replace(/'/g, '"'));
      let filterParams = apiDetail.filter;
      apiDetail.filter.dynamicFields.forEach(item => {
        filterParams[item.filterName] = this.get('store').peekRecord('field', item.fieldId).value[item.attribute];
      });
      delete filterParams['dynamicFields'];

      this.get('rdcLoadingIndicator')
        .showLoadingIndicatorForPromise(
          this.get('store').query(this.apiModel, {
            filter: filterParams,
            page: apiDetail.param.page
          })
        )
        .then(data => {
          if (!data.length) {
            this.set('noData', true);
            return;
          }
          if (!this.value || !this.value.length) {
            data.forEach(transaction => {
              transaction.set('isSelected', false);
            });
          }
          this.set('transactions', data);
          this.groupData(data, false);
        });
    }
  },

  groupData(resultData, skipId) {
    let groupedTransaction = A();
    resultData.forEach(item => {
      if (item.visible) {
        if (!groupedTransaction.filterBy('date', item.txnDate).length) {
          groupedTransaction.pushObject(
            EmberObject.create({
              date: item.txnDate,
              dateString: moment(item.txnDate, 'DD/MM/YYYY').format('dddd, DD MMMM YYYY'),
              transaction: A()
            })
          );
          groupedTransaction
            .filterBy('date', item.txnDate)[0]
            .get('transaction')
            .pushObject(item);
        } else if (
          skipId ||
          groupedTransaction
            .filterBy('date', item.txnDate)[0]
            .get('transaction')
            .filterBy('id', item.id).length === 0
        ) {
          groupedTransaction
            .filterBy('date', item.txnDate)[0]
            .get('transaction')
            .pushObject(item);
        }
      }
    });
    this.set('groupedTransaction', groupedTransaction);
  },

  actions: {
    selectTransaction(transaction) {
      transaction.set('isSelected', !transaction.isSelected);
      let selectedTransactions = this.get('transactions').filterBy('isSelected', true);
      if (selectedTransactions.length > this.get('maxlength')) {
        transaction.set('isSelected', !transaction.isSelected);
        this.get('rdcModalManager').showDialogModal({
          level: 'warning',
          message: this.get('i18n').t('TRANSACTIONDISPUTE.limitInfo'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        });
        return;
      }

      selectedTransactions = this.get('transactions').filterBy('isSelected', true);
      let transactions = [];
      if (!selectedTransactions.length) {
        this.set('value', null);
      }
      selectedTransactions.forEach(transaction => {
        let transacObj = {};
        //to remove attributes with undefined/null values
        transaction.constructor.eachAttribute(function(key) {
          if (!isEmpty(transaction[key])) {
            transacObj[key] = transaction[key];
          }
        });
        transactions.push(transacObj);
      });

      this.set('value', transactions);
    }
  }
});
