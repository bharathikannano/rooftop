import { notEmpty, readOnly } from '@ember/object/computed';
import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import { computed } from '@ember/object';
import { A } from '@ember/array';
import layout from '../templates/components/rdc-cheque-book-list';

export default Component.extend({
  layout,
  reviewMode: false,
  classNames: ['rdc-component-base rdc-cheque-book-list'],
  classNameBindings: [
    'hasError:has-error',
    'hasLabel::no-label',
    'labelPositionClasss',
    'reviewMode:is-reviewmode',
    'required:is-mandatory'
  ],
  i18n: service(),
  hasLabel: notEmpty('label'),
  hasErrorLabel: notEmpty('errorLabel'),
  length: readOnly('value.length'),
  htmlSafeLabel: computed('label', {
    get() {
      return htmlSafe(this.get('label'));
    }
  }),
  isNoOptions: computed('options', 'reviewMode', 'length', {
    get() {
      if (this.get('reviewMode')) {
        return false;
      } else {
        let options = this.get('options') && !!this.get('options').length;
        return !options;
      }
    }
  }),
  value: A(),
  options: A(),
  isSelectAll: false,

  init() {
    this._super(...arguments);
    this._checkSelectAll();
  },

  _checkSelectAll() {
    let value, optionCount;
    value = this.get('value') || A();
    optionCount = this.get('options') && this.get('options').length;
    this.set('isSelectAll', value.length !== optionCount);
  },

  actions: {
    selectAll() {
      let items = this.get('options') || A();
      let selected = this.get('value') || A();
      selected = selected.pushObjects(items);
      this.set('value', selected.uniq());
      this._checkSelectAll();
    },

    deselectAll() {
      let selected = A();
      this.set('value', selected);
      this._checkSelectAll();
    },

    removeCheque(item) {
      let selected = this.get('value') || A();
      selected = selected.removeObject(item);
      if (selected.length < 1) {
        selected = A();
      }
      this.set('value', selected);
      this._checkSelectAll();
    },

    selectCheque(item) {
      let selected = this.get('value') || A();
      selected = selected.pushObjects([item]);
      this.set('value', selected.uniq());
      this._checkSelectAll();
    }
  }
});
