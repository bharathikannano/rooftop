import { computed } from '@ember/object';
import Component from '@ember/component';
import layout from '../templates/components/rdc-cheque-book';

export default Component.extend({
  layout,
  tagName: 'div',
  reviewMode: false,
  readonly: false,
  option: null,
  init() {
    this._super();
    this.set('selected', []);
  },
  checked: computed('selected', 'option', 'length', {
    get() {
      return !this.get('reviewMode') && this.get('selected') && this.get('selected').indexOf(this.get('option')) > -1;
    }
  }),
  classNames: ['rdc-cheque-book'],
  classNameBindings: ['checked:checked'],
  actions: {
    selectCheque(item) {
      if (!this.get('readonly')) {
        if (this.get('checked')) {
          this.sendAction('removeCheque', item);
        } else {
          this.sendAction('selectCheque', item);
        }
      }
    }
  }
});
