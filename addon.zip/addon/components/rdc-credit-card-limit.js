import Component from '@ember/component';
import layout from '../templates/components/rdc-credit-card-limit';
import { inject as service } from '@ember/service';

export default Component.extend({
  layout,
  store: service(),
  classNames: ['rdc-credit-card-limit'],
  init() {
    this._super(...arguments);
    if (this.get('store').peekRecord('field', 'MobileNumber')) {
      this.set('mobileNumber', this.get('store').peekRecord('field', 'MobileNumber').value);
    }
  },
  actions: {
    review() {
      this.get('review')();
    },
    continue() {
      this.get('continue')();
    }
  }
});
