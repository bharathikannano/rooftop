import Component from '@ember/component';
import layout from '../templates/components/rdc-cvv';
import { computed } from '@ember/object';
import RegExpMixin from '../mixins/regexp';
import errorMessageSupport from 'rdc-ui-adn-components/mixins/error-message-support';

export default Component.extend(RegExpMixin, errorMessageSupport, {
  layout,
  type: 'tel',
  value: '',
  backupVal: '',
  disabled: false,
  readonly: false,
  required: false,
  reviewMode: false,
  regexp: null,
  label: '',
  errorLabel: '',
  hasErrorLabel: false,
  labelPosition: 'top',
  mandatoryInput: null,
  maxlength: 3,
  hasError: false,
  validation: null,

  labelPositionClasss: computed('labelPosition', {
    get() {
      if (this.get('labelPosition') === 'top') {
        return 'label-top';
      } else if (this.get('labelPosition') === 'left') {
        return 'label-left';
      } else {
        return 'full-width';
      }
    }
  }),
  classNames: ['rdc-component-base rdc-text-input rdc-cvv-field-wrap'],
  classNameBindings: [
    'isDefault:rdc-default-text-input:rdc-text-input',
    'isFloating:has-floatlabel',
    'hasContent:has-content',
    'hasCurrencySymbol:has-prefix',
    'isValid:tick-enabled',
    'isFocused:focusedcss',
    'hasLabel::no-label',
    'labelPositionClasss',
    'reviewMode:is-reviewmode',
    'hasError:has-error',
    'required:is-mandatory',
    'readonly:is-readonly',
    'disabled:is-disabled'
  ],
  isValid: false,
  isDefault: false,

  actions: {
    keyPress() {
      let evt = evt ? evt : window.event;
      let charCode = evt.which ? evt.which : evt.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        evt.preventDefault();
      }
    },
    keyUp() {
      let numRegexp = /^\d+$/;
      if (!numRegexp.test(event.target.value) && event.target.value) {
        this.$('input')[0].value = null;
        this.set('value', this.get('backupVal'));
      } else {
        this.set('backupVal', this.get('value'));
      }
    },
    focusIn() {
      this.set('isFocused', true);
    },
    focusOut() {
      this.set('isFocused', false);
      this.focusOutValidation();
    }
  }
});
