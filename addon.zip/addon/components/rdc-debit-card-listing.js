import { notEmpty, readOnly } from '@ember/object/computed';
import Component from '@ember/component';
import { computed } from '@ember/object';
import { htmlSafe } from '@ember/string';
import layout from '../templates/components/rdc-debit-card-listing';

export default Component.extend({
  layout,
  label: null,
  reviewMode: false,
  labelPosition: 'top',

  labelPositionClasss: computed('labelPosition', {
    get() {
      if (this.labelPosition === 'top') {
        return 'label-top';
      } else if (this.labelPosition === 'left') {
        return 'label-left';
      } else {
        return 'full-width';
      }
    }
  }),

  classNames: ['rdc-component-base rdc-radio-button-group rdc-debit-card-listing'],
  classNameBindings: [
    'hasError:has-error',
    'hasLabel::no-label',
    'labelPositionClasss',
    'reviewMode:is-reviewmode',
    'required:is-mandatory',
    'readonly:is-readonly',
    'tooltipMessage:has-tooltip'
  ],

  disabled: false,

  /**
   * hasLabel for add css class based on label property value
   * add `no-label` css class when `label` property is empty
   * add `has-hasLabel` css class when component has value for `label` property
   *
   * @property `hasLabel`
   * @type {Boolean} - `false` when label is empty. `true` when label is not empty
   */
  hasLabel: notEmpty('label'),

  /**
   * hasErrorLabel for add css class based on errorLabel property value
   * add `has-error` css class when component has value for `errorLabel` property
   *
   * @property `hasErrorLabel`
   * @type {Boolean} - `false` when errorLabel is empty. `true` when errorLabel is not empty
   */
  hasErrorLabel: notEmpty('errorLabel'),

  value: null,

  selectedValue: readOnly('value'),

  htmlSafeLabel: computed('label', {
    get() {
      return htmlSafe(this.label);
    }
  }),

  reviewPageValue: computed('value', 'reviewMode', {
    get() {
      let options,
        value,
        reviewPageValue = '';

      value = this.value;
      options = this.options;
      if (this.reviewMode && value) {
        options.every(option => {
          if (reviewPageValue) {
            return false;
          }

          if (value == (option.get !== undefined ? option.get('value') : option['value'])) {
            reviewPageValue = option;
          }

          return true;
        });

        return reviewPageValue;
      } else {
        return '';
      }
    }
  }),
  actions: {
    select(selectedValue) {
      this.set('value', selectedValue);
      this.sendAction('action', selectedValue);
    }
  }
});
