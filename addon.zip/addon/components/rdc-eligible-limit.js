import Component from '@ember/component';
import layout from '../templates/components/rdc-eligible-limit';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';

export default Component.extend({
  layout,
  i18n: service(),
  store: service(),
  classNames: ['rdc-text-input rdc-eligible-limit'],
  classNameBindings: ['reviewMode:is-reviewmode'],
  // default PL journey values.
  plMinValue: '50000',
  plJumpValue: '10000',
  plMaxValue: '7000000',
  plFinalValue: '0',
  plTenure: '6',
  maxTenure: 0,
  insurancePremium: '0',
  showRecalculateSection: false,
  fatalError: false,
  disableCalcButton: false,
  // below computed property to show the review mode values with comma seperated.
  reviewModeInsuranceValue: computed('insurancePremium', {
    get() {
      return this.formatNumberWithCommas(this.get('insurancePremium'));
    }
  }),
  reviewModeLoanValue: computed('plFinalValue', {
    get() {
      return this.formatNumberWithCommas(this.get('plFinalValue'));
    }
  }),
  // using async for making the execution async.
  async init() {
    this._super(...arguments);
    // only if label is present the formatting will execute.
    if (!isEmpty(this.get('label'))) {
      // To support older way of formatting data for CC Zibuka.
      if (this.get('label').includes('##') && !isEmpty(this.get('value')) && this.get('value').includes('-')) {
        this._getSectionDataWithSplit();
        return;
      }
      await this._getSectionData();
    }
    // executing the dynamic methods.
    await this.execDynamicMethods();
    // executing the calculation logic on load for processing fee and insurance fee.
    if (!isEmpty(this.get('label')) && this.journeyType === 'PL') {
      await this._recalculate('onLoad');
    }

    // To show the page in review screen only if PL is selected.
    if (!isEmpty(this.journeyType) && this.journeyType === 'PL') {
      this.parentView.page.set('hideInReviewMode', false);
    } else {
      this.parentView.page.set('hideInReviewMode', true);
    }
  },

  // Directly executing the method sent in the field-content attribute.
  execDynamicMethods() {
    if (!isEmpty(this.get('fieldContent'))) {
      let arr = this.get('fieldContent')
        .replace(/'/g, '"')
        .split('|');
      arr.forEach(item => {
        // getting the executable function as JSON string and parsing it.
        let funcArg = JSON.parse(item);
        let argArr = funcArg.arguments.split(',');
        // Excuting the method directly sent from CSL.
        this[funcArg.functionName](...argArr);
      });
    }
  },

  // For setting the Max Value for the PL NTB and ETB journey from the field sent from CSL.
  setMaxLengthForPL(Maxfield, defaultFieldId) {
    let fieldContent = this.store.peekRecord('field', Maxfield);
    let defaultField = this.store.peekRecord('field', defaultFieldId);
    if (!isEmpty(fieldContent) && !isEmpty(fieldContent.value)) {
      let maxLength = fieldContent.value.toString().replace(/,/g, '');
      this.setProperties({
        plMaxValue: maxLength,
        plFinalValue: maxLength,
        valueCompValue: maxLength
      });
      // If default value is present then giving priority to default value
      if (!isEmpty(defaultField) && !isEmpty(defaultField.value)) {
        let defaultValue = defaultField.value.toString().replace(/,/g, '');
        this.setProperties({
          plFinalValue: defaultValue,
          valueCompValue: defaultValue
        });
      }
    }
  },

  // For setting the inital tenure from PCO call.
  setTenureForPL(Maxfield, defaultFieldId) {
    let fieldContent = this.store.peekRecord('field', Maxfield);
    let defaultField = this.store.peekRecord('field', defaultFieldId);
    if (!isEmpty(fieldContent) && !isEmpty(fieldContent.value)) {
      let tenure = fieldContent.value.toString();
      this.setProperties({
        maxTenure: parseFloat(tenure),
        plTenure: parseFloat(tenure),
        valueCompTenure: parseFloat(tenure)
      });
      // If default value is present then giving priority to default value
      if (!isEmpty(defaultField) && !isEmpty(defaultField.value)) {
        let defaultValue = defaultField.value.toString();
        this.setProperties({
          plTenure: parseFloat(defaultValue),
          valueCompTenure: parseFloat(defaultValue)
        });
      }
    } else {
      // setting default value incase PCO fails.
      this.set('maxTenure', '72');
    }
  },

  // TO format the final values with Commas..
  formatNumberWithCommas(num) {
    if (isEmpty(num)) {
      return;
    }
    let value = num.toString().replace(/,/g, '');
    let parts = value.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.join('.');
  },

  // The below method is fetch the total amount and set to another field since CSL cannot field bind on load.
  setTotalAmount(src, dest, outStnd, minTopup) {
    // This method is used only for pre-approved topup. if called from CSL.
    let sourceField = this.store.peekRecord('field', src),
      destinationField = this.store.peekRecord('field', dest),
      minTopupAmt = null,
      outStandAmt = null;
    if (!isEmpty(outStnd) && !isEmpty(minTopup)) {
      minTopupAmt = this.store.peekRecord('field', minTopup);
      outStandAmt = this.store.peekRecord('field', outStnd);
    }
    if (!isEmpty(sourceField) && !isEmpty(sourceField.value) && !isEmpty(destinationField)) {
      let value = sourceField.value.toString();
      value = Number(value.replace(/,/g, ''));
      if (!isNaN(value)) {
        value = Math.round(value).toString();
      } else {
        value = 0;
      }
      destinationField.set('value', value);
    }
    if (!isEmpty(outStandAmt) && !isEmpty(outStandAmt.value) && !isEmpty(minTopupAmt) && !isEmpty(minTopupAmt.value)) {
      let outStndvalue = outStandAmt.value.toString(),
        minTopupValue = minTopupAmt.value.toString();
      destinationField.set(
        'fieldConfig.minLength',
        Number(outStndvalue.replace(/,/g, '')) + Number(minTopupValue.replace(/,/g, ''))
      );
    }
  },

  // To set the attribute from source to attribute in destination.
  setSrcDestAttribute(srcField, srcAttribute, destField, destAttribute) {
    let sourceField = this.store.peekRecord('field', srcField),
      destinationField = this.store.peekRecord('field', destField);
    if (!isEmpty(sourceField) && !isEmpty(sourceField[srcAttribute]) && !isEmpty(destinationField)) {
      if (destinationField.get(destAttribute) === undefined) {
        destinationField.set(`fieldConfig.${destAttribute}`, sourceField[srcAttribute]);
      } else {
        destinationField.set(destAttribute, sourceField[srcAttribute]);
      }
    }
  },

  /* Giving the support for formatting the data using split with "##" method also,
     for a back up as the entire component is revamped.*/
  _getSectionDataWithSplit() {
    let label = this.get('label'),
      value = this.get('value'),
      labelAry = label.split('##'),
      valueAry = value.split('-'),
      obj = {},
      creditLimitObj = {};
    labelAry.forEach((key, index) => {
      if (index === 0) {
        this.set('sectionTitle', key);
      } else if (key === 'Credit Limit') {
        let innerCreditObj = {};
        innerCreditObj['label'] = `Your ${key}`;
        // To get the Eligibility Limit Value.
        if (isEmpty(this.get('retypeValue'))) {
          let creditLimitField = this.get('store').peekRecord('field', 'CreditLimit');
          innerCreditObj['value'] =
            !isEmpty(creditLimitField) && !isEmpty(creditLimitField.value) ? `KES ${creditLimitField.value}` : 'KES 0';
        } else {
          innerCreditObj['value'] = `KES ${this.get('retypeValue')}`;
        }
        creditLimitObj[`response_${index}`] = innerCreditObj;
      } else {
        let innerOtherObj = {};
        innerOtherObj['label'] = key;
        innerOtherObj['value'] = key === 'Annual fee' ? `KES ${valueAry[index - 1]}` : valueAry[index - 1];
        obj[`response_${index}`] = innerOtherObj;
      }
    });
    this.set('defaultResponseArray', [creditLimitObj, obj]);
  },

  // Checking if amount/tenure is valid.
  checkIfValid() {
    let finalValue = parseFloat(this.get('plFinalValue')),
      finalTenure = parseFloat(this.get('plTenure')),
      reg = new RegExp('^[0-9]+$|^$|^s$'),
      errorFlag = false;
    // Error validation for loan amount field..
    if (!reg.test(this.get('plFinalValue'))) {
      this.setError(false, 'input', 'NotNumber');
      errorFlag = true;
    } else if (isNaN(finalValue)) {
      this.setError(false, 'input', 'empty');
      errorFlag = true;
    } else if (finalValue < parseFloat(this.get('plMinValue'))) {
      this.setError(false, 'input', 'minimum');
      errorFlag = true;
    } else if (finalValue > parseFloat(this.get('plMaxValue'))) {
      this.setError(false, 'input', 'maximum');
      errorFlag = true;
    }

    // Error validation for Tenure field.
    if (!reg.test(this.get('plTenure'))) {
      this.setError(false, 'tenure', 'NotNumber');
      errorFlag = true;
    } else if (isNaN(finalTenure)) {
      this.setError(false, 'tenure', 'empty');
      errorFlag = true;
    } else if (finalTenure < 6) {
      this.setError(false, 'tenure', 'minimum');
      errorFlag = true;
    } else if (finalTenure > this.get('maxTenure')) {
      this.setError(false, 'tenure', 'maximum');
      errorFlag = true;
    }

    // removing the error message.
    if (!errorFlag) {
      this.setError(true);
    }
  },

  // Formatting the response received from CSL as string.
  _getSectionData() {
    let defaultResponseArray = [],
      preApprovedResponseArray = [],
      responseStringArray = this.get('label')
        .replace(/'/g, '"')
        .split('|');
    responseStringArray = responseStringArray.map(section => {
      // Parsing the stringified response to JSON.
      return JSON.parse(section);
    });
    // Spliting the section based on the length of the response.
    if (responseStringArray.length > 2) {
      // splitting the array into sections.
      defaultResponseArray = responseStringArray.splice(Math.max(responseStringArray.length - 2, 1));
      preApprovedResponseArray = responseStringArray;
    } else {
      defaultResponseArray = responseStringArray;
    }
    // getting field values.
    if (!isEmpty(preApprovedResponseArray)) {
      this._getFieldValues(preApprovedResponseArray, 'preApprovedResponseArray');
    }
    this._getFieldValues(defaultResponseArray, 'defaultResponseArray');
  },

  // Get the value of the fields sent from CSL for dispaying.
  _getFieldValues(responseArray, arrayName) {
    let formattedArray = [];
    responseArray.forEach(response => {
      let obj = {};
      Object.keys(response).forEach((key, index) => {
        let fieldId = key;
        if (fieldId === 'title') {
          this.set('sectionTitle', response[fieldId]);
        }
        if (fieldId === 'journeyType') {
          this.set('journeyType', response[fieldId]);
        }
        let field = this.store.peekRecord('field', fieldId),
          innerObj = {};
        // Pushing the key, value as {label: key, value: value} to avoid issues when using period in key string.
        if (!isEmpty(field)) {
          innerObj['label'] = response[key];
          innerObj['value'] = field.get('fieldConfig.prefix')
            ? `${field.get('fieldConfig.prefix')} ${this.formatNumberWithCommas(field.value)}`
            : field.value;
          obj[`response_${index}`] = innerObj;
        }
      });
      formattedArray.push(obj);
    });
    // Setting values to component property.
    this.set(`${arrayName}`, formattedArray);
  },

  // To re-calculate the repayment, processing fee and insurance premium for PL NTB and ETB.
  _recalculate(scenario) {
    // This simple method rounds a number.
    let round = function(x) {
      return Math.round(x);
    };

    let plAmnt = parseFloat(this.get('plFinalValue')),
      // Peeking the fields to set the calculated values.
      // fields for setting the default value for loan amnt and tenure.
      loanField = this.store.peekRecord('field', 'PLApprovedLimit'),
      tenureField = this.store.peekRecord('field', 'ReqLoanTenure'),
      // fields for repayment and intrestRate.
      repaymentAmntField = this.store.peekRecord('field', 'RevisedRepayLoanAmt'),
      interestRateField = this.store.peekRecord('field', 'InterestRate'),
      // fields for processing fee.
      arrangementFeeField = this.store.peekRecord('field', 'ArrangementFee'),
      // Fields for insurance premium.
      insurancePremiumField = this.store.peekRecord('field', 'InsurancePremiumAmount'),
      insurancePremiumValueField = this.store.peekRecord('field', 'InsurancePremiumRate'),
      monthlyEMI = 0,
      insurancePremium = 0,
      // Getting values from the field.
      interestRateValue =
        !isEmpty(interestRateField) && !isEmpty(interestRateField.value)
          ? parseFloat(interestRateField.value) / 100 / 12
          : 1,
      tenureValue = parseFloat(this.get('plTenure'));
    // default monthly repayment and insurance fee.
    if (!isEmpty(repaymentAmntField) && !isEmpty(repaymentAmntField.get('value'))) {
      let monthlyEMI = parseFloat(
        repaymentAmntField
          .get('value')
          .toString()
          .replace(/,/g, '')
      );
    }
    if (!isEmpty(insurancePremiumField) && !isEmpty(insurancePremiumField.get('value'))) {
      let insurancePremium = parseFloat(
        insurancePremiumField
          .get('value')
          .toString()
          .replace(/,/g, '')
      );
    }

    // Setting the default value for loan and tenure.
    loanField.set('value', this.get('plFinalValue').toString());
    tenureField.set('value', this.get('plTenure').toString());

    /* Base Formula given by country below,
     * "Total Loan Amount"*(((("Interest Rate"%/12)(1+("Interest Rate"%/12))^"Tenor")))/(((1+("Interest Rate"%/12))^"Tenor")-1)
     */
    // Now compute the monthly payment figure, according to base formula.
    // To set the repayment amount only on clicking calculate. Onload the value will come from PCO.
    if (isEmpty(scenario)) {
      let x = Math.pow(1 + interestRateValue, tenureValue);
      monthlyEMI = (plAmnt * x * interestRateValue) / (x - 1);
    }

    // calculating the insurance premium value.
    if (!isEmpty(insurancePremiumValueField) && !isEmpty(insurancePremiumValueField.get('value'))) {
      insurancePremium = round(plAmnt * (parseFloat(insurancePremiumValueField.get('value')) / 100));
    }

    // calculating the arrangement fee. 2.5% is the default percent of processing fee.
    let arrangementFee = round(plAmnt * (2.5 / 100));

    // Check that the result is a finite number and not on load. If so, display the results.
    if (!isNaN(monthlyEMI) && isEmpty(scenario)) {
      repaymentAmntField.set('value', this.formatNumberWithCommas(round(monthlyEMI)));
    }
    arrangementFeeField.set('value', this.formatNumberWithCommas(arrangementFee));
    insurancePremiumField.set('value', this.formatNumberWithCommas(insurancePremium));
    // Setting insurance value to component variable.
    this.set('insurancePremium', insurancePremium);
    // For setting the dummy value once the calculation is done so that the field will be visible in review screen.
    this.set('value', 'calculated');
    // To recalculate section data.
    this._getSectionData();
    this.setProperties({
      showRecalculateSection: false,
      fatalError: false
    });
  },

  // To set Error manually.
  setError(isValid, element, errorType) {
    if (!isValid) {
      this.setProperties({
        disableCalcButton: true,
        isValid: false,
        fatalError: true
      });
      if (element === 'input') {
        // setting spinner component error.
        this.set('hasErrorInput', true);
        let errorMsg = this.get('i18n').t('applyProducts.eligibilLimit.errorInput');
        if (errorType === 'empty') {
          errorMsg = this.get('i18n').t('applyProducts.eligibilLimit.errorInputEmpty');
        } else if (errorType === 'maximum') {
          errorMsg = this.get('i18n').t('applyProducts.eligibilLimit.errorInputMaximum');
        } else if (errorType === 'minimum') {
          errorMsg = `${this.get('i18n').t('applyProducts.eligibilLimit.errorInputMinimum')} ${this.plMinValue}`;
        } else if (errorType === 'NotNumber') {
          errorMsg = this.get('i18n').t('applyProducts.eligibilLimit.errorNotNumber');
        }
        this.set('errorLabelInput', errorMsg);
      } else if (element === 'tenure') {
        // setting tenure component error.
        this.set('hasErrorTenure', true);
        let errorMsg = this.get('i18n').t('applyProducts.eligibilLimit.errorTenure');
        if (errorType === 'empty') {
          errorMsg = this.get('i18n').t('applyProducts.eligibilLimit.errorTenureEmpty');
        } else if (errorType === 'maximum') {
          errorMsg = this.get('i18n').t('applyProducts.eligibilLimit.errorTenureMaximum');
        } else if (errorType === 'minimum') {
          errorMsg = this.get('i18n').t('applyProducts.eligibilLimit.errorTenureMinimum');
        } else if (errorType === 'NotNumber') {
          errorMsg = this.get('i18n').t('applyProducts.eligibilLimit.errorNotNumber');
        }
        this.set('errorLabelTenure', errorMsg);
      }
    } else {
      // setting everything to false and null. (All values are right)
      this.setProperties({
        disableCalcButton: false,
        hasErrorInput: false,
        hasErrorTenure: false,
        isValid: true,
        errorLabelInput: null,
        errorLabelTenure: null
      });
      if (!this.get('showRecalculateSection')) {
        this.set('fatalError', false);
      }
    }
  },

  actions: {
    recalculate() {
      this._recalculate();
    },

    // This triggers if the input-spinner value is changed through keypad / incremantor
    onValueChange() {
      // checking if there is any change in value. triggering validation only if change in value / tenure.
      if (
        parseFloat(this.get('valueCompValue')) !== parseFloat(this.get('plFinalValue')) ||
        parseFloat(this.get('valueCompTenure')) !== parseFloat(this.get('plTenure'))
      ) {
        this.setProperties({
          showRecalculateSection: true,
          fatalError: true,
          valueCompValue: this.get('plFinalValue'),
          valueCompTenure: this.get('plTenure')
        });
      }
      this.checkIfValid();
    }
  }
});
