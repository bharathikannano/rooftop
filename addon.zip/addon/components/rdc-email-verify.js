/* eslint-disable no-useless-escape */

import { notEmpty } from '@ember/object/computed';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import { computed } from '@ember/object';
import { isEmpty, isBlank } from '@ember/utils';
import $ from 'jquery';
import layout from '../templates/components/rdc-email-verify';
import RegExpMixin from '../mixins/regexp';
import errorMessageSupport from 'rdc-ui-adn-components/mixins/error-message-support';

export default Component.extend(RegExpMixin, errorMessageSupport, {
  layout,
  readonly: false,
  required: false,
  type: 'email',
  placeholder: '',
  regexp: null,
  inputPattern: '[0-9]*',
  regexpErrorMessage: null,
  errorLabel1: null,
  errorLabel2: null,
  hasErrorLabel: false,
  mandatoryInput: null,
  hasError: false,
  validation: null,
  classNames: ['rdc-component-base rdc-text-input'],
  value: null,
  isFocused: false,
  i18n: service(),
  classNameBindings: [
    'isDefault:rdc-default-text-input:rdc-text-input',
    'isFloating:has-floatlabel',
    'hasContent:has-content',
    'hasPrefix:has-prefix',
    'isValid:tick-enabled',
    'isFocused:focusedcss',
    'hasLabel::no-label',
    'reviewMode:is-reviewmode',
    'hasError:has-error',
    'required:is-mandatory',
    'readonly:is-readonly',
    'disabled:is-disabled',
    'tooltipMessage:has-tooltip'
  ],
  /**
   * hasContent to check the rdc-email-verify has value.
   * @property `hasContent`
   * @type {Boolean} - `false` when value is empty. `true` when value is not empty
   */
  hasContent: computed('hasPrefix', 'value', {
    get() {
      const value = this.get('value');
      const hasPrefix = this.get('hasPrefix');
      if (!!hasPrefix || !isBlank(value)) {
        return true;
      }
      return false;
    }
  }),
  hasPrefix: notEmpty('prefix'),
  isValid: false,
  isDefault: false,

  __onFocus() {
    this.set('isFocused', true);
  },

  __onFocusOut() {
    this.set('isFocused', false);
  },
  init() {
    this._super(...arguments);
    if (this.get('label')) {
      [this.emailLabel, this.reEmailLabel] = this.get('label').split('##');
    }
    this.set('emailLabel', this.emailLabel || this.get('i18n').t('emailVerify.emailLabel'));
    this.set('reEmailLabel', this.reEmailLabel || this.get('i18n').t('emailVerify.reEmailLabel'));

    let value = this.get('value');

    if (value) {
      this.set('emailValue', value);
      this.set('reValue', value);
    }
  },

  actions: {
    change() {
      this.sendAction('change');
    },
    keyPress() {
      this.sendAction('key-press');
      $('input').on('paste', function() {
        return false;
      });

      $('input').on('copy', function() {
        return false;
      });
    },
    keyUp() {
      this.sendAction('key-up');
    },
    focusIn() {
      this.__onFocus();
      this.sendAction('focus-in');
    },
    focusOut() {
      this.__onFocusOut();
      this.sendAction('focus-out');
      let reg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

      if (reg.test(this.get('emailValue'))) {
        this.set('isValid', true);
        this.set('hasError', false);
        this.set('errorLabel1', null);
        if (!isEmpty(this.get('reValue'))) {
          this.emailValidation();
        }
      } else {
        let message = this.get('i18n').t('emailVerify.error.invalid');
        this.set('isValid', false);
        this.set('hasError', true);
        this.set('errorLabel1', message);
      }
    },

    reKeyUp() {
      this.sendAction('key-up');
    },
    reFocusIn() {
      this.__onFocus();
      this.sendAction('focus-in');
    },
    reFocusOut() {
      this.__onFocusOut();
      this.sendAction('focus-out');

      let reg = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

      if (reg.test(this.get('reValue'))) {
        this.set('isValid', true);
        this.set('hasError', false);
        this.set('errorLabel1', null);
        if (!isEmpty(this.get('emailValue'))) {
          this.emailValidation();
        }
      } else {
        let message = this.get('i18n').t('emailVerify.error.invalid');
        this.set('isValid', false);
        this.set('hasError', true);
        this.set('errorLabel2', message);
      }
    }
  },

  emailValidation() {
    let email = this.get('emailValue');
    let reEmail = this.get('reValue');
    if (!isEmpty(email) && !isEmpty(reEmail)) {
      if (email !== reEmail) {
        this.set('value', null);
        this.setValidationError();
      } else {
        this.removeValidationError();
        this.set('value', email);
      }
    }
  },

  setValidationError() {
    let message = this.get('i18n').t('emailVerify.error.mismatch');
    this.set('isValid', false);
    this.set('hasError', true);
    this.set('errorLabel1', message);
    this.set('errorLabel2', message);
  },

  removeValidationError() {
    this.set('isValid', true);
    this.set('hasError', false);
    this.set('errorLabel1', null);
    this.set('errorLabel2', null);
  }
});
