import Component from '@ember/component';
import layout from '../templates/components/rdc-employer-name-lov';
import { inject as service } from '@ember/service';
import { get, set } from '@ember/object';
import { typeOf } from '@ember/utils';
import { task, timeout } from 'ember-concurrency';

const DEBOUNCE_MS = 500;

export default Component.extend({
  layout,
  store: service(),
  axwayConfig: service(),
  classNames: ['rdc-employer-name-lov'],
  value: null,
  searchEnabled: true,
  searchField: 'label',

  searchOption: task(function*(term) {
    if (term.length >= 3) {
      yield timeout(DEBOUNCE_MS);
      const options = yield get(this, 'store').query('employer', {
        filter: {
          employers: {
            keyword: term,
            country: get(this, 'axwayConfig.country')
          }
        }
      });
      set(this, 'fieldOptions', options);
    } else {
      set(this, 'fieldOptions', []);
    }
  }).restartable(),

  _prepopulateValue: task(function*() {
    if (typeOf(this.value) === 'string') {
      // On Server side the JsonApiId is changed to String (country-value) instead of the UUID.
      const id = `${get(this, 'axwayConfig.country')}-${this.value}`; // now id is concatenated like KE-4883
      const value = yield get(this, 'store').findRecord('employer', id);
      set(this, 'compValue', value);
    }
  }),

  init() {
    this._super(...arguments);
    this.fieldOptions = [];
    get(this, '_prepopulateValue').perform();
    set(this, 'compValue', this.value);
  },
  actions: {
    clearSearch() {
      set(this, 'fieldOptions', []);
    },
    closePopup() {
      get(this, '_prepopulateValue').perform();
      set(this, 'compValue', this.value);
      set(this, 'fieldOptions', []);
    }
  }
});
