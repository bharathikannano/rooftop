import Component from '@ember/component';
import layout from '../templates/components/rdc-input-ruler';
import { isEmpty } from '@ember/utils';
import RegExpMixin from '../mixins/regexp';
import errorMessageSupport from 'rdc-ui-adn-components/mixins/error-message-support';
import { A } from '@ember/array';
import EmberObject from '@ember/object';
import { computed } from '@ember/object';
import $ from 'jquery';

export default Component.extend(RegExpMixin, errorMessageSupport, {
  layout,
  disabled: false,
  readonly: false,
  required: false,
  reviewMode: false,
  type: 'tel',
  regexp: null,
  label: '',
  errorLabel: '',
  labelPosition: 'top',
  hasError: false,
  hasErrorLabel: false,
  regexpErrorMessage: null,
  maxlength: '',
  incrementer: '',
  minLength: '',
  extraMarker: computed({
    // setting the extra marker based on the device width.
    get() {
      let deviceWidth = window.innerWidth;
      if (deviceWidth <= 350) {
        return '8';
      } else if (deviceWidth > 350 && deviceWidth < 500) {
        return '10';
      } else {
        return '20';
      }
    }
  }),
  onChange: () => {},
  focusOut: () => {},

  classNames: ['rdc-component-base input-ruler-component'],

  classNameBindings: [
    'isFocused:focusedcss',
    'hasLabel::no-label',
    'labelPositionClasss',
    'reviewMode:is-reviewmode',
    'hasError:has-error',
    'required:is-mandatory',
    'readonly:is-readonly',
    'disabled:is-disabled',
    'tooltipMessage:has-tooltip'
  ],

  init() {
    this._super(...arguments);
    this.showRuler(this.value);
  },

  didInsertElement() {
    this._super(...arguments);
    this.toScroll(this.value);
    this.onScrollTrigger();
  },

  onScrollTrigger() {
    /*
     * TODO: Need to implement the scroll based value change here...
     */

    let rulerElement = this.element.querySelector(`#ruler-${this.maxlength}`).parentElement;
    let rulerComponent = this.element.querySelector('.input-ruler-height');
    // Setting the max scroll left.
    let maxScrollleft = rulerElement.offsetLeft - rulerComponent.offsetWidth / 2 + 6;
    // self-invoking function to handle when scroll ends..
    (function() {
      var timer;
      $('.ruler').on('scroll', function(evt) {
        clearTimeout(timer);
        timer = setTimeout(refresh, 250, evt);
      });
      var refresh = function(evt) {
        let ruler = evt.target;
        if (ruler.scrollLeft > maxScrollleft) {
          ruler.scrollLeft = maxScrollleft;
          $(ruler).css('overflow-x', 'hidden');
        } else {
          $(ruler).css('overflow-x', 'scroll');
        }
      };
    })();
  },

  showRuler(value) {
    let dynamicArray = A();
    /* extraMarker is used as invisible marker after the end of visible marker for scroll feature*/
    for (let i = Number(this.minLength); i <= Number(this.maxlength) + Number(this.get('extraMarker')); i++) {
      let dynamicObj = EmberObject.create({});
      dynamicObj['num'] = i;
      if (i <= this.maxlength) {
        dynamicObj['markerClass'] = 'marker';
      } else {
        dynamicObj['markerClass'] = 'dummy-marker';
      }
      if (!isEmpty(value) && i <= value) {
        dynamicObj['selected'] = 'fill-color';
      } else {
        dynamicObj['selected'] = 'no-fill';
      }
      if (i % this.incrementer === 0) {
        dynamicObj['class'] = 'large-marker';
        dynamicObj['value'] = i;
      } else {
        dynamicObj['class'] = 'small-marker';
      }
      dynamicArray[i] = dynamicObj;
    }
    this.set('dynamicArray', dynamicArray);
  },

  toScroll(value) {
    let reg = new RegExp('^\\d+$');
    if (reg.test(value)) {
      let rulerElement = this.element.querySelector(`#ruler-${value}`);
      if (isEmpty(rulerElement)) {
        return;
      }
      let rulerToScroll = rulerElement.parentElement;
      let ruler = this.element.querySelector('.ruler');
      let rulerComponent = this.element.querySelector('.input-ruler-height');
      let rulerValues = rulerComponent.getBoundingClientRect();
      // setting the padding left of the ruler to start from center.
      ruler.style.paddingLeft = `${rulerValues.width / 2 - 6}px`;
      // Setting the scroll left on click of the value of change of the value in text box.
      ruler.scrollLeft = rulerToScroll.offsetLeft - rulerComponent.offsetWidth / 2 + 6;
    }
  },

  actions: {
    changeValue(value) {
      if (!isEmpty(value)) {
        this.showRuler(value);
        this.set('value', value);
        this.set('retainValue', this.value);
        this.toScroll(this.value);
      }
      this.onChange(this.value);
    },

    focusOut() {
      this.focusOut();
    }
  }
});
