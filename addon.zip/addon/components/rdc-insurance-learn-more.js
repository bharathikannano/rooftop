import Component from '@ember/component';
import { inject as service } from '@ember/service';
import layout from '../templates/components/rdc-insurance-learn-more';
import { computed } from '@ember/object';

export default Component.extend({
  layout,
  classNames: ['rdc-component-base rdc-text-input rdc-insurance-learn-more'],
  i18n: service(),
  insuranceBenefitsContent: computed('insuranceName', {
    get() {
      let benefits = '';
      if (
        this.get('insuranceName')
          .toLowerCase()
          .includes('sanlam')
      ) {
        benefits = `applyProducts.insurance_sanlam`;
      } else if (
        this.get('insuranceName')
          .toLowerCase()
          .includes('prudential')
      ) {
        benefits = `applyProducts.insurance_prudential`;
      } else if (
        this.get('insuranceName')
          .toLowerCase()
          .includes('jubilee')
      ) {
        benefits = `applyProducts.insurance_jubilee`;
      }
      return benefits;
    }
  }),
  actions: {
    cancel() {
      this.cancel();
    }
  }
});
