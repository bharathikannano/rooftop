import { readOnly, notEmpty } from '@ember/object/computed';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';
import { set, computed } from '@ember/object';
import layout from '../templates/components/rdc-joint-account-holders';

export default Component.extend({
  layout,
  i18n: service(),
  reviewMode: false,
  disabled: false,
  readonly: false,
  required: false,
  errorLabel: null,
  hasErrorLabel: false,
  hasError: false,
  label: '',
  options: A(),
  value: A(),
  maxLength: 6,
  triggerValidation: null,
  length: readOnly('value.length'),

  classNames: ['rdc-component-base rdc-joint-account-holders'],
  classNameBindings: [
    'hasError:has-error',
    'hasLabel::no-label',
    'labelPositionClasss',
    'reviewMode:is-reviewmode',
    'required:is-mandatory'
  ],
  hasLabel: notEmpty('label'),
  accountByType: A(),

  isButtonDisabled: computed('disabled', 'value', 'length', {
    get() {
      if (!this.get('disabled')) {
        let length = this.get('value') ? this.get('length') : 0;
        return length >= this.get('maxLength');
      }

      return true;
    }
  }),

  _addNewAccount() {
    let item = {
      firstName: '',
      lastName: '',
      mobileNumber: '',
      emailAddress: '',
      accountType: 'new',
      type: 'input',
      hasError: true,
      label: ''
    };

    let value = this.get('value') || A();
    let length = value.length;
    item.label = this.get('i18n').t('ServiceRequest.JOINTACCOUNT.secondaryAccount') + ' #' + +length;
    value.pushObject(item);

    this.set('value', value);
  },

  _validate() {
    let values = this.get('value') || A();
    let isValid = true;

    values.forEach(value => {
      if (value.type === 'input') {
        isValid = isValid && !value.hasError;
      }
    });

    this.set('hasError', !isValid);
  },

  _groupByType(list, property) {
    let index = 0;
    return list.reduce(function(rv, x) {
      set(x, 'index', index);
      (rv[x[property]] = rv[x[property]] || []).push(x);
      index++;

      return rv;
    }, {});
  },

  init() {
    this._super(...arguments);
    let accountType = {};

    if (!isEmpty(this.get('value'))) {
      accountType = this._groupByType(this.get('value'), 'accountType');
      this.set('accountByType', accountType);
    }
  },

  actions: {
    addNewAccount(result) {
      let value = this.get('value') || A();
      if (value.length < this.get('maxLength')) {
        this._addNewAccount(result);
      }
    },

    focusOut() {
      this._validate();
    }
  }
});
