import Component from '@ember/component';
import { htmlSafe } from '@ember/string';
import { computed } from '@ember/object';
import layout from '../templates/components/rdc-label-image';
export default Component.extend({
  layout,
  htmlSafeLabel: computed('label', {
    get() {
      return htmlSafe(this.get('label'));
    }
  }),
  classNames: ['rdc-component-base', 'rdc-label-image'],
  imageUrl: computed('imageUrl', {
    get() {
      return this.get('imageUrl');
    }
  })
});
