import { notEmpty } from '@ember/object/computed';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';
import { computed } from '@ember/object';
import layout from '../templates/components/rdc-multi-nationality';

export default Component.extend({
  layout,
  i18n: service(),
  reviewMode: false,
  disabled: false,
  readonly: false,
  required: false,
  errorLabel: null,
  hasErrorLabel: false,
  hasError: false,
  label: '',
  options: A(),
  value: A(),
  maxFieldLength: 2,
  triggerValidation: null,
  fields: A(),
  length: 0,

  classNames: ['rdc-component-base rdc-multi-nationality'],
  classNameBindings: [
    'hasError:has-error',
    'hasLabel:no-label',
    'labelPositionClasss',
    'reviewMode:is-reviewmode',
    'required:is-mandatory'
  ],
  hasLabel: notEmpty('label'),
  accountByType: A(),

  showLabel: computed('reviewMode', 'length', {
    get() {
      return this.get('length') > 0 && !this.get('reviewMode');
    }
  }),

  isButtonDisabled: computed('disabled', 'length', {
    get() {
      if (!this.get('disabled') && !this.get('reviewMode')) {
        let length = this.get('length');
        return length >= this.get('maxFieldLength');
      }

      return true;
    }
  }),

  init() {
    this._super(...arguments);
    let values = A();

    if (!isEmpty(this.get('value')) && !isEmpty(this.get('options'))) {
      this.get('value').forEach(val => {
        let value = this.get('options').findBy('value', this._getValue(val, 'value'));
        if (value) {
          values.pushObject(value);
        }
      });
    }

    let firstField = {
      label: this.get('i18n').t('multiNationality.fieldLabel1'),
      value: values[0],
      errorMessage: '',
      visible: !!values[0]
    };

    let secondField = {
      label: this.get('i18n').t('multiNationality.fieldLabel2'),
      value: values[1],
      errorMessage: '',
      visible: !!values[1]
    };

    this.set('length', values.length);
    this.set('firstField', firstField);
    this.set('secondField', secondField);
  },

  _checkValue(fieldValue, value) {
    if (!isEmpty(fieldValue) && !isEmpty(fieldValue.get('value')) && value.id === fieldValue.id) {
      return true;
    }

    return false;
  },

  _getValue(option, name) {
    return option.get !== undefined ? option.get(name) : option[name];
  },

  actions: {
    addNewField() {
      let fieldLength = this.get('length');

      if (fieldLength < this.get('maxFieldLength')) {
        if (fieldLength === 0) {
          this.set('firstField.visible', true);
        } else {
          this.set('secondField.visible', true);
        }
        this.set('length', fieldLength + 1);
      }
    },

    selectedFirstOption(selected) {
      let values = A();
      let secondField = this.get('secondField.value');
      this.set('firstField.value', '');
      this.set('errorLabel', '');

      if (this._checkValue(secondField, selected)) {
        this.set('errorLabel', this.get('i18n').t('multiNationality.error'));
      } else {
        this.set('firstField.value', selected);

        if (!isEmpty(selected.get('value'))) {
          values.pushObject({
            value: selected.get('value')
          });
        }
      }

      if (!isEmpty(secondField) && !isEmpty(secondField.get('value'))) {
        values.pushObject({
          value: secondField.get('value')
        });
      }

      this.set('value', values);
    },

    selectedSecondOption(selected) {
      let values = A();
      let firstField = this.get('firstField.value');
      this.set('secondField.value', '');
      this.set('errorLabel', '');

      if (!isEmpty(firstField) && !isEmpty(firstField.get('value'))) {
        values.pushObject({
          value: firstField.get('value')
        });
      }

      if (this._checkValue(firstField, selected)) {
        this.set('errorLabel', this.get('i18n').t('multiNationality.error'));
      } else {
        this.set('secondField.value', selected);

        if (!isEmpty(selected.get('value')))
          values.pushObject({
            value: selected.get('value')
          });
      }

      this.set('value', values);
    }
  }
});
