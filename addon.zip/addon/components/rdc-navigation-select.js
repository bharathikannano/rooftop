import { htmlSafe } from '@ember/string';
import Component from '@ember/component';
import { set, computed } from '@ember/object';
import layout from '../templates/components/rdc-navigation-select';
export default Component.extend({
  layout,
  classNames: ['rdc-component-base', 'rdc-navigation-select'],
  classNameBindings: ['reviewMode:is-reviewmode'],
  label: '',
  options: null,
  value: null,
  reviewMode: false,
  isSuccess: computed('value', {
    get() {
      let status = this.get('value').status;
      if (status) {
        status = status.toLowerCase();
        return status.includes('approved');
      }

      return false;
    }
  }),
  isFailed: computed('value', {
    get() {
      let status = this.get('value').status;
      if (status) {
        status = status.toLowerCase();
        return status.includes('reject') || status.includes('decline');
      }

      return false;
    }
  }),
  htmlSafeLabel: computed('label', {
    get() {
      return htmlSafe(this.get('label'));
    }
  }),
  init() {
    this._super(...arguments);
    let cardType = this.get('options');
    if (cardType && !this.get('reviewMode')) {
      cardType.forEach(function(item, index) {
        if (item.cardImage) {
          let imageUrl = item.cardImage;
          set(cardType[index], 'imageUrl', imageUrl + '.png');
          set(
            cardType[index],
            'sourceSet',
            imageUrl + '.png 1x, ' + imageUrl + '@2x.png 2x, ' + imageUrl + '@3x.png 3x'
          );
        }
      });
    } else {
      if (this.get('value') && this.get('value').cardImage) {
        let imageUrl = this.get('value').cardImage;
        this.set('imageUrl', imageUrl + '.png');
        this.set('sourceSet', imageUrl + '.png 1x, ' + imageUrl + '@2x.png 2x, ' + imageUrl + '@3x.png 3x');
      }
    }
    this.set('displayOptions', cardType);
  },
  actions: {
    select(item) {
      this.set('value', item);
      this.sendAction('action');
    }
  }
});
