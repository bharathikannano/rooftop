import { notEmpty, readOnly } from '@ember/object/computed';
import Component from '@ember/component';
import { computed } from '@ember/object';
import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';
import layout from '../templates/components/rdc-online-terms-conditions';
import { inject as service } from '@ember/service';

export default Component.extend({
  layout,
  linksList: A([]),
  label: null,
  reviewMode: false,
  labelPosition: 'top',
  i18n: service(),
  labelPositionClasss: computed('labelPosition', {
    get() {
      if (this.get('labelPosition') === 'top') {
        return 'label-top';
      } else if (this.get('labelPosition') === 'left') {
        return 'label-left';
      } else {
        return 'full-width';
      }
    }
  }),
  classNames: ['rdc-component-base rdc-checkbox-group'],
  classNameBindings: [
    'hasError:has-error',
    'hasLabel::no-label',
    'labelPositionClasss',
    'reviewMode:is-reviewmode',
    'required:is-mandatory'
  ],
  disabled: false,
  hasLabel: notEmpty('label'),
  hasErrorLabel: notEmpty('errorLabel'),
  optionLabel: computed('options', {
    get() {
      return this._getLabel();
    }
  }),
  endLabel: computed('options', {
    get() {
      return this._getEndLabel();
    }
  }),
  selected: readOnly('value'),
  value: false,
  checked: false,
  fieldContent: '',
  tooltipMessage: '',
  generalDeclarationContent: computed('tooltipMessage', {
    get() {
      let messageFlag = this.get('tooltipMessage');
      let message;

      if (messageFlag == 'ETBSTF') {
        message = this.get('i18n').t('generalDeclaration.ETBSTF');
      } else if (messageFlag == 'ETPSTF') {
        message = this.get('i18n').t('generalDeclaration.ETPSTF');
      } else if (messageFlag == 'ETPSTN') {
        message = this.get('i18n').t('generalDeclaration.ETPSTN');
      } else if (messageFlag == 'ECOCASH') {
        message = this.get('i18n').t('generalDeclaration.ECOCASH');
      } else {
        message = this.get('i18n').t('generalDeclaration.declaration');
      }
      return message;
    }
  }),
  _getLabel(isInit) {
    let label;
    let options = this.get('options');

    if (options) {
      options.forEach(option => {
        label = this._getValue(option, 'label').split('#label');
        label[1] = label[1] || '';
        if (isInit) {
          this.set('linksContent', label[1].split('endlabel')[0]);
        }
      });
    }

    return label[0];
  },

  _getEndLabel() {
    let label;
    let options = this.get('options');

    if (options) {
      options.forEach(option => {
        label = this._getValue(option, 'label').split('#endlabel');
      });
    }

    return label[1];
  },

  _getValue(option, name) {
    return option.get !== undefined ? option.get(name) : option[name];
  },
  init() {
    this._super(...arguments);
    this.set('checked', this.get('value'));
    // separate the links and label
    this._getLabel(true);

    this.set('linksList', A([]));
    if (!isEmpty(this.linksContent)) {
      let linksContents = this.linksContent.split('#links');
      linksContents.forEach((linkContent, idx) => {
        let [text, link] = linkContent.split('#');
        let separtor = ',';
        if (idx === linksContents.length - 2) {
          separtor = '&amp';
        } else if (idx === linksContents.length - 1) {
          separtor = '';
        }
        if (text.indexOf('</br>') > -1) {
          separtor = '';
        }
        this.linksList.pushObject({
          text,
          link,
          separtor
        });
      });
    }
  },
  actions: {
    onClickAgreeTerms() {
      if (window.event.target.tagName === 'A') {
        return true;
      }
      this.toggleProperty('checked');
      if (!this.checked) {
        this.set('value', '');
        return;
      }
      this.set('value', this.checked);
    },
    acceptTerms() {
      this.set('checked', true);
      this.set('value', this.get('checked'));
    },
    rejectTerms() {
      this.set('checked', false);
      this.set('value', '');
    }
  }
});
