import Component from '@ember/component';
import layout from '../templates/components/rdc-online-terms-modal-confirm';
import { inject as service } from '@ember/service';
import { translationMacro as t } from 'ember-i18n';
import { htmlSafe } from '@ember/string';
import { isEmpty } from '@ember/utils';
import { computed } from '@ember/object';
import $ from 'jquery';
import { NetworkUnavailableError } from 'rdc-ui-adn-core/errors';

export default Component.extend({
  layout,
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  i18n: service(),
  axwayConfig: service(),
  termsUrl: '',
  content: '',
  divId: '',
  justPrompt: false,
  tagName: 'a',
  attributeBindings: ['href'],
  href: htmlSafe('javascript:void(0)'),
  title: t('generalDeclaration.title'),
  hasCloseBtn: true,
  htmlSafeTitle: computed('title', {
    get() {
      return htmlSafe(this.get('title'));
    }
  }),
  termsTitle: computed('title', {
    get() {
      let messageFlag = this.get('tooltipMessage');
      let message;
      if (messageFlag == 'ECOCASH') {
        message = this.get('i18n').t('generalDeclaration.ecocashTitle');
      } else {
        message = this.get('i18n').t('generalDeclaration.title');
      }
      return htmlSafe(message);
    }
  }),
  init() {
    this._super();
    if (this.media.isDesktop) {
      this.set('bpClass', 'is-desktop online-tnC');
    } else {
      // To the scroll down feature for only asset Onboarding feature.
      if (!isEmpty(this.get('axwayConfig.assetOnboarding')) && this.get('axwayConfig.assetOnboarding') === true) {
        this.set('hasCloseBtn', true);
        this.set('bpClass', 'online-tnC view-scroll-btn');
      } else {
        this.set('hasCloseBtn', false);
        this.set('bpClass', 'online-tnC');
      }
    }
    // this.set('shouldUseCordovaHTTP', window.cordova && window.device.platform === 'iOS' && window.cordovaHTTP);
  },

  loadTermsAndConditions() {
    const url = this.get('termsUrl').toString();

    if (!isEmpty(url)) {
      this.get('rdcLoadingIndicator').showLoadingIndicator();
      if (this.get('shouldUseCordovaHTTP')) {
        window.cordovaHTTP.get(url, {}, {}, response => {
          this.handleSuccess(response.data);
        }),
          () => {
            this.handleError();
          };
      } else {
        $.ajax({
          url: url,
          type: 'GET',
          success: data => this.handleSuccess(data),
          error: () => this.handleError()
        });
      }
    } else {
      if (this.get('axwayConfig.country') == 'CI') {
        this.openModal(this.get('content'));
      } else {
        this.set('showActionSheet', true);
        let model = {
          title: this.get('termsTitle'),
          content: this.get('content'),
          justPrompt: this.get('justPrompt'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.agree'),
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.close')
        };
        this.set('model', model);
        this.set('staticPopup', 'rdc-online-terms-modal-content');
      }
    }
  },

  handleSuccess(htmlContent) {
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
    const htmlBody = htmlContent
      .split('<body')[1]
      .split('>')
      .slice(1)
      .join('>')
      .split('</body>')[0];
    let tncHtml = $($.parseHTML(htmlBody))
      .find('#' + this.get('divId'))
      .clone();
    tncHtml = $(tncHtml)
      .wrap('<p/>')
      .parent()
      .html();

    this.openModal(tncHtml);
  },

  handleError() {
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
    return this.sendAction('error', new NetworkUnavailableError());
  },

  openModal(content) {
    this.get('rdcModalManager')
      .showModal('rdc-online-terms-modal-content', {
        modalType: 'fullScreen',
        level: 'warning',
        title: this.get('termsTitle'),
        content: content,
        justPrompt: this.get('justPrompt'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.accept'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok')
      })
      .then(() => {
        this.send('acceptTerms');
      })
      .catch(() => {
        this.send('rejectTerms');
      });
  },

  click(event) {
    this.loadTermsAndConditions();
    event.preventDefault();
  },

  actions: {
    showTermsAndConditions: function(shouldShow) {
      if (shouldShow) this.loadTermsAndConditions();
    },

    onClickAgreeTerms(e, agreed) {
      this.set('value', '');
      this.set('checked', agreed);

      if (this.get('checked')) {
        this.set('value', true);
      }
    },

    acceptTerms() {
      this.set('checked', true);
      this.set('value', this.get('checked'));
      this.sendAction('acceptTerms');
      this.set('showActionSheet', false);
    },

    rejectTerms() {
      this.set('checked', false);
      this.set('value', '');
      this.sendAction('rejectTerms');
      this.set('showActionSheet', false);
    }
  }
});
