import Component from '@ember/component';
import layout from '../templates/components/rdc-online-terms-modal-content';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import { computed } from '@ember/object';

export default Component.extend({
  layout,
  tagName: '',
  content: '',
  axwayConfig: service(),
  hideScroll: false,

  didInsertElement() {
    this._super(...arguments);
    let scrollingElement = document.querySelector('.online-tnC .content');
    this.set('scrollingElement', scrollingElement);
    this.set('calcHeight', scrollingElement.clientHeight);
    let scrollingElementHeight = this.scrollingElement.scrollHeight;

    scrollingElement.addEventListener('scroll', e => {
      // Adding a buffer a 50 inorder to hide the scroll down div when reached the end of button container.
      if (this.scrollingElement.scrollTop + this.scrollingElement.clientHeight + 50 >= scrollingElementHeight) {
        this.set('hideScroll', true);
      } else {
        this.set('hideScroll', false);
      }
    });
  },

  actions: {
    accept() {
      if (this.get('axwayConfig.country') == 'CI') {
        this.sendAction('onCloseResolve');
      } else {
        this.sendAction('accept');
      }
    },
    reject() {
      if (this.get('axwayConfig.country') == 'CI') {
        this.sendAction('onCloseReject');
      } else {
        this.sendAction('reject');
      }
    },
    scrollDown() {
      if (!isEmpty(this.scrollingElement)) {
        this.scrollingElement.scrollBy({ top: this.calcHeight - 70, left: 0, behavior: 'smooth' });
      }
    }
  }
});
