import Component from '@ember/component';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';
import { A } from '@ember/array';
import { htmlSafe } from '@ember/string';
import { isEmpty } from '@ember/utils';
import layout from '../templates/components/rdc-other-nationality';

export default Component.extend({
  layout,
  store: service(),
  label: 'Other Nationality (Optional)',
  maxlength: 1,
  primaryNationality: '',
  classNames: ['rdc-component-base rdc-other-nationality'],

  classNameBindings: [
    'otherNationalityError:has-error',
    'hasLabel:no-label',
    'labelPositionClasss',
    'reviewMode:is-reviewmode',
    'required:is-mandatory'
  ],

  htmlSafeLabel: computed('label', {
    get() {
      return htmlSafe(this.label);
    }
  }),

  addButtonDisable: computed('fields.[]', {
    get() {
      if (!isEmpty(this.fields)) {
        let emptyFields = this.fields.filter(item => {
          return item === null || item.length === 0;
        });
        if (emptyFields.length > 0) {
          return true;
        } else {
          return false;
        }
      }
    }
  }),

  init() {
    this._super(...arguments);
    this.primaryNationalityField = this.get('store').peekRecord('field', 'Nationality');

    if (!isEmpty(this.primaryNationalityField)) {
      this._getPrimaryNaionality();
    }
    this._populateValues();

    // Observing changes in Nationality field
    if (!isEmpty(this.primaryNationalityField)) {
      this.primaryNationalityField.addObserver('value', () => {
        if (!this.isDestroyed) {
          this._getPrimaryNaionality();
          this._isNationalityChanged();
        }
      });
    }
  },

  // getting PrimaryNaionality value
  _getPrimaryNaionality() {
    if (!isEmpty(this.primaryNationalityField.value)) {
      this.set('primaryNationality', this.primaryNationalityField.get('value').value);
    }
  },

  // Resume application - populating values
  _populateValues() {
    if (!isEmpty(this.value)) {
      this.set('fields', A([]));
      this.value.forEach(item => {
        this.get('fields').pushObject(item);
      });
    }
  },

  // checking primaryNationalityError while changing Nationality field
  _isNationalityChanged() {
    if (!isEmpty(this.fields)) {
      this.fields.forEach((item, index) => {
        if (item.value === this.primaryNationality) {
          this.set('otherNationalityError', true);
          this.set('primaryNationalityError', true);
          this.fields.removeAt(index);
          this.fields.pushObject([]);
        }
      });
      if (this.primaryNationalityError) {
        this.set('value', this.fields);
      }
    }
  },

  didInsertElement() {
    this._super(...arguments);
    this._isNationalityChanged();
  },

  didUpdateAttrs() {
    this._super(...arguments);
    this._populateValues();
  },

  actions: {
    // adding nationality
    addOtherNationality() {
      if (isEmpty(this.fields)) {
        this.set('fields', A([null]));
      } else {
        this.fields.pushObject([]);
      }
    },

    selectedValue(idx, selectedOption) {
      let duplicateCount = 0;

      // checking previousNationality
      if (this.fields.length > 1) {
        this.fields.forEach(item => {
          if (selectedOption.value === item.value) {
            this.set('otherNationalityError', true);
            this.set('previousNationalityError', true);
            this.set('primaryNationalityError', false);
            duplicateCount++;
          }
        });
      }

      // checking primaryNationality
      this.fields.forEach(() => {
        if (selectedOption.value === this.primaryNationality && !isEmpty(this.primaryNationality)) {
          this.set('otherNationalityError', true);
          this.set('primaryNationalityError', true);
          this.set('previousNationalityError', false);
          duplicateCount++;
        }
      });

      if (duplicateCount <= 0) {
        this.get('fields').replace(idx, 1, [selectedOption]);
        this.set('otherNationalityError', false);
        this.set('primaryNationalityError', false);
        this.set('previousNationalityError', false);
      } else {
        this.fields.removeAt(idx);
        this.fields.pushObject([]);
      }
      this.set('value', this.get('fields'));
    },

    // adding AdditionalNationality
    removeNationality(index) {
      this.fields.removeAt(index);
      this.set('otherNationalityError', false);
      this.set('previousNationalityError', false);
      this.set('primaryNationalityError', false);
      this.set('value', this.fields);
    }
  }
});
