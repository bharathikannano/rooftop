import { notEmpty } from '@ember/object/computed';
import $ from 'jquery';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import { computed } from '@ember/object';
import { isEmpty, isBlank } from '@ember/utils';
import layout from '../templates/components/rdc-pin-reset';
import RegExpMixin from '../mixins/regexp';
import errorMessageSupport from 'rdc-ui-adn-components/mixins/error-message-support';

export default Component.extend(RegExpMixin, errorMessageSupport, {
  layout,
  required: false,
  type: 'tel',
  regexp: null,
  inputPattern: '[0-9]*',
  maxlength: null,
  regexpErrorMessage: null,
  errorLabel1: null,
  errorLabel2: null,
  hasErrorLabel: false,
  mandatoryInput: null,
  hasError: false,
  validation: null,
  classNames: ['rdc-component-base rdc-text-input'],
  value: null,
  isFocused: false,
  i18n: service(),

  /**
   * hasContent to check the rdc-pin-reset has value.
   * @property `hasContent`
   * @type {Boolean} - `false` when value is empty. `true` when value is not empty
   */
  hasContent: computed('hasPrefix', 'value', {
    get() {
      const value = this.get('value');
      const hasPrefix = this.get('hasPrefix');
      if (!!hasPrefix || !isBlank(value)) {
        return true;
      }
      return false;
    }
  }),
  hasPrefix: notEmpty('prefix'),
  isValid: false,
  isDefault: false,

  __onFocus() {
    this.set('isFocused', true);
  },

  __onFocusOut() {
    this.set('isFocused', false);
  },
  init() {
    this._super(...arguments);
    this.setProperties({
      pinLabel: this.get('i18n').t('rdcPinreset.pinLabel'),
      rePinLabel: this.get('i18n').t('rdcPinreset.rePinLabel'),
      pinValue: '',
      reValue: '',
      maskValue: '',
      reMaskValue: ''
    });
  },

  actions: {
    change() {
      this.sendAction('change');
    },
    keyPress() {
      let evt = evt ? evt : window.event;
      let charCode = evt.which ? evt.which : evt.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        evt.preventDefault();
      }
    },
    keyUp() {
      this.set('maskValue', this.get('pinValue'));
    },
    focusIn() {
      this.__onFocus();
      this.sendAction('focus-in');
      $('.pin-real').focus();
      $('.pin').addClass('is-focus');
    },
    focusOut() {
      this.__onFocusOut();
      this.sendAction('focus-out');
      $('.pin').removeClass('is-focus');

      if (this.get('pinValue').length == '4' && !this.get('pinValue').includes('.')) {
        let pattern = '0123456789012345789';
        if (pattern.indexOf(this.get('pinValue')) == -1) {
          let res = /^(.)\1+$/.test(this.get('pinValue')) ? '1' : '0';
          if (res == '1') {
            let message = this.get('i18n').t('rdcPinreset.error.invalid');
            this.set('isValid', false);
            this.set('hasError', true);
            this.set('errorLabel1', message);
          } else {
            this.set('isValid', true);
            this.set('hasError', false);
            this.set('errorLabel1', null);
            if (!isEmpty(this.get('reValue'))) {
              this.pinValidation();
            }
          }
        } else {
          let message = this.get('i18n').t('rdcPinreset.error.invalid');
          this.set('isValid', false);
          this.set('hasError', true);
          this.set('errorLabel1', message);
        }
      } else {
        let message = this.get('i18n').t('rdcPinreset.error.invalid');
        this.set('isValid', false);
        this.set('hasError', true);
        this.set('errorLabel1', message);
      }
    },

    reKeyUp() {
      this.set('reMaskValue', this.get('reValue'));
    },
    reFocusIn() {
      this.__onFocus();
      this.sendAction('focus-in');
      $('.re-pin-real').focus();
      $('.re-pin').addClass('is-focus');
    },
    reFocusOut() {
      this.__onFocusOut();
      this.sendAction('focus-out');
      $('.re-pin').removeClass('is-focus');

      if (this.get('reValue').length == '4' && !this.get('reValue').includes('.')) {
        let pattern = '0123456789012345789';
        if (pattern.indexOf(this.get('reValue')) == -1) {
          let res = /^(.)\1+$/.test(this.get('reValue')) ? '1' : '0';
          if (res == '1') {
            let message = this.get('i18n').t('rdcPinreset.error.invalid');
            this.set('isValid', false);
            this.set('hasError', true);
            this.set('errorLabel2', message);
          } else {
            this.set('isValid', true);
            this.set('hasError', false);
            this.set('errorLabel2', null);
            if (!isEmpty(this.get('pinValue'))) {
              this.pinValidation();
            }
          }
        } else {
          let message = this.get('i18n').t('rdcPinreset.error.invalid');
          this.set('isValid', false);
          this.set('hasError', true);
          this.set('errorLabel2', message);
        }
      } else {
        let message = this.get('i18n').t('rdcPinreset.error.invalid');
        this.set('isValid', false);
        this.set('hasError', true);
        this.set('errorLabel2', message);
      }
    }
  },

  pinValidation() {
    let pin = this.get('pinValue');
    let rePin = this.get('reValue');
    if (!isEmpty(pin) && !isEmpty(rePin)) {
      if (pin !== rePin) {
        this.setValidationError();
      } else {
        this.removeValidationError();
      }
    }
    this.set('value', {
      value: pin,
      reValue: rePin
    });
  },

  setValidationError() {
    let message = this.get('i18n').t('rdcPinreset.error.mismatch');
    this.set('isValid', false);
    this.set('hasError', true);
    this.set('errorLabel1', message);
    this.set('errorLabel2', message);
  },

  removeValidationError() {
    this.set('isValid', true);
    this.set('hasError', false);
    this.set('errorLabel1', null);
    this.set('errorLabel2', null);
  }
});
