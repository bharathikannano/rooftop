import Component from '@ember/component';
import layout from '../templates/components/rdc-review-cc-limit';

export default Component.extend({
  layout,
  classNames: ['rdc-review-cc-limit'],
  actions: {
    confirm() {
      this.get('confirm')();
    },
    cancel() {
      this.get('cancel')();
    }
  }
});
