import Component from '@ember/component';
import layout from '../templates/components/rdc-static-popup';

export default Component.extend({
  layout,
  tagName: 'div',
  showActionSheet: false,
  hasCloseBtn: false
});
