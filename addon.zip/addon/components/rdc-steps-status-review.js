/* eslint-disable no-redeclare */
/* global cordova */
import Component from '@ember/component';
import constants from '../constants';
import layout from '../templates/components/rdc-steps-status-review';

export default Component.extend({
  layout,
  classNames: ['rdc-component-base'],
  showActionSheet: false,
  classNameBindings: ['isStatusCheck', 'isReceiptPage'],
  actions: {
    showAccountFundingOptions() {
      cordova.exec(null, null, 'FundAccount', 'showInfo', []);
    },
    showAccountFundingActionSheet() {
      this.setProperties({
        showActionSheet: true,
        hasCloseBtn: true
      });
    },
    closeActionSheet() {
      this.set('showActionSheet', false);
    },
    showInsuranceBannerOptions() {
      this.setProperties({
        showActionSheet: true,
        showInsuranceBanner: true,
        hasCloseBtn: false,
        data: constants.insuranceBanner
      });
    }
  }
});
