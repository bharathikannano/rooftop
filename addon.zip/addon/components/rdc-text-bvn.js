import Component from '@ember/component';
import layout from '../templates/components/rdc-text-bvn';

export default Component.extend({
  layout,
  classNames: ['rdc-component-base rdc-text-input rdc-text-bvn'],
  showActionSheet: false,
  classNameBindings: ['reviewMode:is-reviewmode'],
  actions: {
    forgetBvnAction() {
      this.setProperties({
        showActionSheet: true,
        staticPopup: 'forgot-bvn'
      });
    },
    onCancel() {
      this.set('showActionSheet', false);
    }
  }
});
