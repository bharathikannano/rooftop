import Component from '@ember/component';
import { inject as service } from '@ember/service';
import layout from '../templates/components/rdc-text-verify';
import { isEmpty } from '@ember/utils';
import { set, computed } from '@ember/object';

export default Component.extend({
  layout,
  i18n: service(),
  required: false,
  classNames: ['rdc-text-input rdc-text-verify'],
  hasError1: computed('errorLabel', {
    get() {
      return !isEmpty(this.errorLabel) ? true : false;
    }
  }),
  hasError2: computed('retypeErrorLabel', {
    get() {
      return !isEmpty(this.retypeErrorLabel) ? true : false;
    }
  }),
  type1: computed('maskField', {
    get() {
      let [mask, type] = this.maskField.split('#type');
      if ((mask === 'FIRST' || mask === 'BOTH') && type !== 'email') {
        return 'password';
      } else {
        return type;
      }
    }
  }),
  type2: computed('maskField', {
    get() {
      let [mask, type] = this.maskField.split('#type');
      if ((mask === 'SECOND' || mask === 'BOTH') && type !== 'email') {
        return 'password';
      } else {
        return type;
      }
    }
  }),
  mismatchMessage: null,
  validation: null,
  label1: null,
  label2: null,
  isFocused: false,
  value: '',
  retypeValue: '',
  regexMessage1: null,
  retypeErrorMessage: null,
  toUppercase: false,
  classNameBindings: [
    'isFloating:has-floatlabel',
    'hasContent:has-content',
    'hasPrefix:has-prefix',
    'isValid:tick-enabled',
    'isFocused:focusedcss',
    'hasLabel::no-label',
    'reviewMode:is-reviewmode',
    'required:is-mandatory',
    'readonly:is-readonly',
    'disabled:is-disabled',
    'tooltipMessage:has-tooltip',
    'hasError:has-error',
    'toUppercase:is-uppercase'
  ],

  init() {
    this._super(...arguments);

    this.set('maskField', this.maskField);
    // split the labels
    let [label1, label2] = this.get('label').split('##');
    this.set('label1', label1);
    this.set('label2', label2);
    let [regexMessage1, retypeErrorMessage] = this.get('regexpErrorMessage').split('##');
    set(this, 'regexMessage1', regexMessage1);
    set(this, 'retypeErrorMessage', retypeErrorMessage);
  },

  didInsertElement() {
    this._super(...arguments);
    if (isEmpty(this.retypeValue)) {
      this.set('retypeValue', !isEmpty(this.value) ? this.value : '');
    }
  },

  actions: {
    retypeFocusOut() {
      if (!isEmpty(this.retypeValue)) {
        if (this.value !== this.retypeValue && isEmpty(this.retypeErrorLabel)) {
          set(this, 'mismatchMessage', this.retypeErrorMessage);
        } else {
          set(this, 'mismatchMessage', null);
        }
      }
    },
    FocusOut() {
      if (!isEmpty(this.value) && !isEmpty(this.retypeValue)) {
        if (this.value !== this.retypeValue && isEmpty(this.retypeErrorLabel)) {
          set(this, 'mismatchMessage', this.retypeErrorMessage);
        } else {
          set(this, 'mismatchMessage', null);
        }
      }
    }
  }
});
