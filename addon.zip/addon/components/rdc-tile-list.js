import Component from '@ember/component';
import layout from '../templates/components/rdc-tile-list';
import { inject as service } from '@ember/service';
import { set } from '@ember/object';

export default Component.extend({
  layout,
  i18n: service(),
  router: service(),

  init() {
    this._super(...arguments);
    let mostPopularRequestsLength = this.model.mostPopularRequests.length;
    let count = mostPopularRequestsLength % 3;
    if (count == 2) {
      set(this.model.mostPopularRequests[mostPopularRequestsLength - 1], 'half', true);
      set(this.model.mostPopularRequests[mostPopularRequestsLength - 2], 'half', true);
    } else if (count == 1) {
      set(this.model.mostPopularRequests[mostPopularRequestsLength - 1], 'full', true);
    }
  },
  actions: {
    proceedClick(route, hrefUrl, params) {
      if (!route) {
        document.location.href = hrefUrl;
      } else {
        if (params) {
          let queryObj = {};
          let queryParams = params.split('|');
          queryParams.forEach(element => {
            queryObj[element.split(':')[0]] = element.split(':')[1];
          });
          this.router.transitionTo('rdc-ui-eng-service-requests.' + route, { queryParams: queryObj });
        }
        this.router.transitionTo('rdc-ui-eng-service-requests.' + route);
      }
    }
  }
});
