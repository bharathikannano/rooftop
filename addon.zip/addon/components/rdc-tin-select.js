import Component from '@ember/component';
import layout from '../templates/components/rdc-tin-select';
import { inject as service } from '@ember/service';
import { assign } from '@ember/polyfills';
import { set } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { scheduleOnce } from '@ember/runloop';
import EmberObject from '@ember/object';
import { A } from '@ember/array';

export default Component.extend({
  i18n: service(),
  layout,
  classNames: ['rdc-tin-select'],
  tinNumberRegExp: '^[a-zA-Z0-9]{1,30}$',
  tinNumberMaxLength: 30,
  tinCommentsRegExp: '^[a-zA-Z0-9 ]{5,250}$',
  tinCommentMaxLength: 90,
  specificReasonLabel: null,
  tinNumberRegExpMessage: 'Please enter a valid alpha numeric Tax Identification Number',
  tinCommentsRegExpMessage: 'Please give sufficient explanation within the comments field',
  selectedItems: null, // Array of strings
  selectedCountries: null, // Array of object
  labelOptions: null,
  classNameBindings: ['reviewMode:is-reviewmode'],
  /**
   * This function do value prepopulation
   * @param {Array of String} selectedItems
   */
  _valuePrePopulate() {
    let selectedItems   = [];
    let selectedCountries = [];
    this.value.forEach(val => {
      // eOps sent back isNoTinNumber as string 
      if (typeof val.isNoTinNumber === 'string') {
        val.isNoTinNumber = (val.isNoTinNumber.toLowerCase() === 'true') // convert string to boolean
      }      
      // loop into array of objects from store value
      selectedItems.push(val.label); // Array of strings for multiple selected
      let mergeVal = assign(
        EmberObject.create({
          tinLabel: `TIN (${val.label})`
        }),
        val
      );
      selectedCountries.push(mergeVal);
    });

    set(this, 'selectedItems', selectedItems);
    set(this, 'selectedCountries', A(selectedCountries));
  },

  /**
   * Power select multiple does not support for array of objects in value prepopulation.
   * So we sent array of strings into the Power Select multiple component
   */
  _setLabelOptions() {
    let labelOptions = [];
    this.options.forEach(option => {
      labelOptions.push(option.label);
    });
    set(this, 'labelOptions', labelOptions);
  },
  
  /**
   * create selectedCountries array of object from array of string.
   * @param {Array of object} selectedCountries
   */
  _emberObjectSelectedCountries(selectedCountries) {
    let selectedCountriesEmberObject = A();
    selectedCountries.forEach(filterCountry => {
      const mergeObj =  assign(EmberObject.create(filterCountry), EmberObject.create({
        tinErrors: EmberObject.create()
      }))
      selectedCountriesEmberObject.pushObject(mergeObj);
    });
    return selectedCountriesEmberObject;
  },

  /**
   * create selectedCountries array of object from array of string.
   * @param {Array of String} selectedItems
   */
  _setSelectedCountries(selectedItems) {
    // create selectedCountries array of object from array of string
    let selectedCountries = new Array(this.maxlength);
    let newValues = new Array(this.maxlength);
    selectedItems.forEach(selectedItem => {
      // to find the country value from oldValue
      let oldValue = {};
      let oldValueIndex;

      // to find the country value from selected countries
      let currentValue = {};

      // In resume flow, Whenever user has changed the value, we should check it exist already or not.
      if (!isEmpty(this.oldValue)) {
        oldValue = this.oldValue.findBy('label', selectedItem);
        oldValueIndex = this.oldValue.indexOf(oldValue); // Retain the order of selected oldValues
      }

      // Retain user already selected countries
      if (!isEmpty(this.selectedCountries)) {
        currentValue = this.selectedCountries.findBy('label', selectedItem);
      }

      // if it is exist we can merge with older value
      let mergeSelectedWithOldValue = assign(
        {
          label: selectedItem,
          tinLabel: `TIN (${selectedItem})`
        },
        oldValue,
        currentValue
      );
      // if it is exist we can merge with older value
      let mergeNewValueWithOldValue = assign(
        {
          label: selectedItem
        },
        oldValue,
        currentValue
      );
      // indert the value oldValue order else insert into the Last Item.
      let position = (oldValueIndex >= 0) ? oldValueIndex : newValues.length;
      selectedCountries.splice(position, 0, mergeSelectedWithOldValue);
      newValues.splice(position, 0, mergeNewValueWithOldValue);
    });
    const filterCountries = selectedCountries.filter(Boolean);
    const selectedCountriesEmberObject = this._emberObjectSelectedCountries(filterCountries);
    set(this, 'selectedCountries', selectedCountriesEmberObject);
    set(this, 'value', newValues.filter(Boolean));
  },

  _setValue() {
    let values = [];
    this.selectedCountries.forEach(selectedCountry => {
      // to find the country value from field options
      let fieldOption = this.options.findBy('label', selectedCountry.label);

      values.push({
        label: selectedCountry.label,
        value: fieldOption.value,
        tinNumber: selectedCountry.isNoTinNumber ? null : selectedCountry.tinNumber,
        isNoTinNumber: isEmpty(selectedCountry.tinNumber) ? selectedCountry.isNoTinNumber : false,
        noTinReason: selectedCountry.isNoTinNumber ? selectedCountry.noTinReason : null,
        tinSpecificReason:
          selectedCountry.noTinReason === 'B00' && selectedCountry.isNoTinNumber
            ? selectedCountry.tinSpecificReason
            : null
      });
    });
    set(this, 'value', values);
  },

  init() {
    this._super(...arguments);
    this._setLabelOptions();
    if (!isEmpty(this.value)) {
      this._valuePrePopulate();
      // convert normal JS array to ember array.
      set(this, 'oldValue', A(this.value));
    }
    set(this, 'specificReasonLabel', this.get('i18n').t('tinSelect.specificReasonLabel').toString());

    // set error propertis
    set(this, 'errors', EmberObject.create({
      selectError: null,
      tinErrors: null
    }));
  },

  didUpdateAttrs() {
    this._super(...arguments);    
    scheduleOnce('afterRender', this, () => {      
      if (!isEmpty(this.errorLabel)) {
        // Check whether errorLabel contains array or object.
        if (this.errorLabel.indexOf('[') >= 0) {
          set(this, 'errors.tinErrors', JSON.parse(this.errorLabel));
          this.errors.tinErrors.forEach(tinError => {
            this.selectedCountries[tinError.index].set('tinErrors', tinError);
          });
        } else {
          // otherwise it is selectbox error
          set(this, 'errors.selectError', this.errorLabel);  
        }      
      }
    });   
  },
  
  actions: {
    onclose() {
      if (isEmpty(this.selectedItems)) {
        set(this, 'errors.selectError', this.get('i18n').t('tinSelect.selectErrorMessage', {
          minlength: this.minLength,
          maxlength: this.maxlength,
          label: this.label
        }));
      } else {
        set(this, 'errors.selectError', null);
      }
    },

    onChange(selectedItems) {
      set(this, 'selectedItems', selectedItems);
      this._setSelectedCountries(selectedItems);
    },

    setValues(selectedCountry) {
      selectedCountry.set('tinErrors', null);
      this._setValue();
    },
  }
});
