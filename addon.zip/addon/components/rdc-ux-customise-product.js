import { isNone } from '@ember/utils';
import { A } from '@ember/array';
import Component from '@ember/component';
import layout from '../templates/components/rdc-ux-customise-product';

export default Component.extend({
  layout,
  classNames: ['rdc-ux-customise-product', 'view-fere', 'view-product-checkout'],
  classNameBindings: ['reviewMode:is-reviewmode'],
  label: '',
  reviewMode: false,

  imageClassName: '',

  currencyOptions: A([
    {
      label: 'XOF',
      value: 'xof'
    },
    {
      label: 'USD',
      value: 'usd'
    },
    {
      label: 'GBP',
      value: 'gbp'
    },
    {
      label: 'EURO',
      value: 'euro'
    }
  ]),

  radioGroup: A([
    {
      name: 'sc-about',
      value: '138',
      label: 'Encaissement de $138',
      ikon: 'radio-icon'
    },
    {
      name: 'sc-about',
      value: '100',
      label: '100 Crédits',
      ikon: 'radio-icon'
    }
  ]),
  giftValue: '',

  value: null,
  isCurrentAccountSelected: false,
  isExcelSaverAccountSelected: false,
  init() {
    this._super();
    this.set('currencyValues', ['xof']);
  },

  didInsertElement() {
    this._super(...arguments);
    let value = JSON.parse(this.get('value'));
    if (!isNone(value)) {
      this.set('currencyValues', value['currencyValues']);
      this.set('giftValue', value['giftValue']);
    }
    let isCurrentAccountSelected = localStorage.getItem('isCurrentAccountSelected');
    if (isCurrentAccountSelected === 'true') {
      this.set('isCurrentAccountSelected', true);
    }
    let isExcelSaverAccountSelected = localStorage.getItem('isExcelSaverAccountSelected');
    if (isExcelSaverAccountSelected === 'true') {
      this.set('isExcelSaverAccountSelected', true);
    }
  },

  click: function() {
    let value = {
      currencyValues: this.get('currencyValues'),
      giftValue: this.get('giftValue')
    };
    this.set('value', JSON.stringify(value));
  }
});
