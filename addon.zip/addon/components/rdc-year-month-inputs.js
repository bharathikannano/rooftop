import Component from '@ember/component';
import layout from '../templates/components/rdc-year-month-inputs';
import { inject as service } from '@ember/service';
import { set } from '@ember/object';
import errorMessageSupport from 'rdc-ui-adn-components/mixins/error-message-support';
import { scheduleOnce } from '@ember/runloop';

export default Component.extend(errorMessageSupport, {
  layout,
  i18n: service(),
  label: '',
  value: '',
  type: 'tel',
  classNames: ['rdc-component-base rdc-month-year'],
  classNameBindings: [
    'hasMonthErrorLabel:has-month-error',
    'hasYearErrorLabel:has-year-error',
    'hasPrefix:has-prefix',
    'isValid:tick-enabled',
    'isFocused:focusedcss',
    'hasError:has-error',
    'required:is-mandatory',
    'hasLabel::no-label',
    'reviewMode:is-reviewmode',
    'readonly:is-readonly',
    'disabled:is-disabled',
    'tooltipMessage:has-tooltip'
  ],
  month: '',
  year: '',
  placeholder: '',
  regexp: null,

  init() {
    this._super(...arguments);
    if (this.placeholder) {
      [this.placeholder1, this.placeholder2] = this.placeholder.split('##');
    }
    if (this.prefix) {
      [this.labelY, this.labelM] = this.prefix.split('##');
    }
    if (this.value) {
      [this.year, this.month] = this.value.split('-');
    }
  },
  setValue() {
    let val = `${this.year}-${this.month}`;
    set(this, 'value', val);
  },

  actions: {
    focusOut() {
      this.setValue();
      scheduleOnce('render', this, () => {
        this.focusOutValidation();
      });
    }
  }
});
