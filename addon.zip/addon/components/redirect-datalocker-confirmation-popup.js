import { inject as service } from '@ember/service';
import Component from '@ember/component';
import layout from '../templates/components/redirect-datalocker-confirmation-popup';
import config from '../config/environment';

export default Component.extend({
  layout,
  i18n: service(),
  actions: {
    confirmationNo() {
      this.sendAction('onCloseReject');
    },
    confirmationYes() {
      document.location.href = config.dataLockerURL;
      // this.set('currentModel.cancelPopup', false);
    }
  }
});
