import Component from '@ember/component';
import layout from '../templates/components/registry-consent';
import { inject as service } from '@ember/service';

export default Component.extend({
  layout,
  store: service(),
  classNames: ['registry-consent rdc-checkbox-group'],
  i18n: service(),
  hasCreditCard: false,
  required: false,
  classNameBindings: ['required:is-mandatory', 'hasError:has-error'],

  init() {
    this._super();
    let selectedProducts = this.get('store').peekRecord('field', 'ProductList').value;
    this.set('hasCreditCard', true);
    if (selectedProducts) {
      let products = selectedProducts.split(',');
      products.forEach(prod => {
        if (prod.split('~')[0] === 'OD') {
          this.set('hasCreditCard', false);
        }
      });
    }
  }
});
