import layout from '../templates/components/sr-top-from-card';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';
import { isEqual } from '@ember/utils';

export default Component.extend({
  i18n: service(),
  layout,
  queries: service('customer-info'),
  rdcModalManager: service(),
  showDiv: false,
  errorDisplay: 'tooltip',
  ccimagesfromjs: '',
  cardNum: '',
  desc: '',
  init() {
    let cardName, cardNum, cardDesc;
    this._super(...arguments);
    if (this.fdAccountFlag) {
      return;
    }
    if (this.rewardsCardList && this.rewardsCardList.length > 0) {
      this.rewardsCardList.forEach(cardDetail => {
        if (cardDetail.rewardsPoint && cardDetail.rewardsPoint.length > 0) {
          let card = [...cardDetail.rewardsPoint].shift();
          cardName = card['card-image-name'];
          cardNum = card['card-number'];
          cardDesc = card['credit-card-desc'];
        } else {
          cardName = cardDetail.get('cardImageName');
          cardNum = cardDetail.get('cardNum');
          cardDesc = cardDetail.get('desc');
        }
        cardDetail.set('ccimagesfromjs', 'https://av.sc.com/configuration/content/images/' + cardName + '.png');
        cardDetail.set('desc', cardDesc);
        cardDetail.set('cardNum', cardNum);

        if (this.posLimitFlag) {
          if (cardDetail.isSelected) {
            cardDetail.set('posLimit', this.posLimit);
            cardDetail.set('atmLimit', this.atmLimit);
          } else {
            cardDetail.set('posLimit', null);
            cardDetail.set('atmLimit', null);
          }
        }
      });
    }
    this.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
  },
  cardMasking: computed(function() {
    if (this.get('queries.countryName') == 'HK' || this.get('queries.countryName') == 'SG') {
      return false;
    } else {
      return true;
    }
  }),
  actions: {
    switchSelection(custCardDetails, cardDetail) {
      if (this.fdAccountFlag && typeof this.onFdClick === 'function') {
        this.onFdClick(cardDetail);
        return;
      }
      custCardDetails.forEach(function(elementVal) {
        if (elementVal.get('id') != cardDetail.get('id')) {
          elementVal.set('isSelected', false);
        }
      });
      cardDetail.toggleProperty('isSelected');
      if (cardDetail.isSelected) {
        this.enableNext(true);
      } else {
        if (this.posLimitFlag) {
          cardDetail.set('posLimit', null);
          cardDetail.set('atmLimit', null);
        }
        this.enableNext(false);
      }
    },
    showErrorMessage(cardDetail) {
      if (isEqual(this.errorDisplay, 'popup')) {
        this.errorPopup(cardDetail.errorMsg);
      } else {
        cardDetail.toggleProperty('toolTipDisplay', true);
      }
    },
    noCardImage(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    }
  }
});
