import Component from '@ember/component';
import layout from '../templates/components/service-request-status-bar';

export default Component.extend({
  layout,
  tagName: ''
});
