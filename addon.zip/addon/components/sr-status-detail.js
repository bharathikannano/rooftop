import Component from '@ember/component';
import layout from '../templates/components/sr-status-detail';
import { computed } from '@ember/object';
import { copy } from '@ember/object/internals';
import { isEmpty } from '@ember/utils';

export default Component.extend({
  layout,
  authVerifyResumeData: computed('expandedData', {
    get() {
      /*
       * To override the referral resume data for Auth verification for ZIBUKA project.
       * Then overriding the eventtype of the referral resume data and setting the authEventType value to eventType.
       */
      let expandedData = this.get('expandedData'),
        authVerifyResumeData = {};
      if (expandedData.get('referralResumeData')) {
        // TO clone the already existing object and override it.
        authVerifyResumeData = copy(JSON.parse(expandedData.get('referralResumeData')), true);
        if (!isEmpty(expandedData.get('additionalInfo.autheventType'))) {
          // Getting the autheventType from additionalInfo and setting as eventType.
          authVerifyResumeData.eventType = expandedData.get('additionalInfo.autheventType');
          // Changing the stepName if autheventType is present in additionalInfo.
          authVerifyResumeData.stepName = 'AUTH_REFERRAL';
        }
      }
      // returning as stringified value.
      return JSON.stringify(authVerifyResumeData);
    }
  })
});
