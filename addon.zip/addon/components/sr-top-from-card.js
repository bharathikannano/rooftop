import layout from '../templates/components/sr-top-from-card';
import { set, computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Component from '@ember/component';

export default Component.extend({
  i18n: service(),
  layout,
  queries: service('customer-info'),
  rdcModalManager: service(),
  showDiv: false,
  init() {
    this.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    this._super(...arguments);
  },
  cardMasking: computed(function() {
    if (this.get('queries.countryName') == 'HK' || this.get('queries.countryName') == 'SG') {
      return false;
    } else {
      return true;
    }
  }),
  actions: {
    tooltipSelection(cardDetail) {
      let fromCardTooltipText = this.get('i18n').t(
        'ServiceRequest.TRANSFEROFPAYMENTS.tooltip.fromCard.' + this.get('queries.countryName')
      ).string
        ? this.get('i18n').t(
            'ServiceRequest.CREDITBALANCEREFUND.notes.statementBalance.' + this.get('queries.countryName')
          ).string
        : this.get('i18n').t('ServiceRequest.TRANSFEROFPAYMENTS.tooltip.fromCard.default').string;
      cardDetail.toggleProperty('toolTipDisplay', true);
      cardDetail.set('fromCardTooltipText', fromCardTooltipText);
    },
    switchSelection(custCardDetails, cardDetail) {
      custCardDetails.forEach(function(elementVal) {
        if (elementVal.get('id') != cardDetail.get('id')) {
          elementVal.set('isSelected', false);
          elementVal.set('showDiv', false);
        }
      });
      if (!cardDetail.isSelected) {
        cardDetail.toggleProperty('isSelected');
        set(cardDetail, 'showDiv', true);
        set(cardDetail, 'madSelected', true);
        set(cardDetail, 'tadSelected', false);
        this.sendAction('enableNext', true);
      }
    },
    tadSelection(cardDetail) {
      if (cardDetail.disableStatementBal) {
        let message = this.get('i18n').t('ServiceRequest.TRANSFEROFPAYMENTS.disableTADMsg').string;
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'info',
            message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-system-error-popup'
          })
          .then(() => {
            set(cardDetail, 'tadSelected', false);
            set(cardDetail, 'madSelected', true);
          });
      } else {
        set(cardDetail, 'tadSelected', true);
        set(cardDetail, 'madSelected', false);
      }
    },
    madSelection(cardDetail) {
      if (cardDetail.madSelected) {
        set(cardDetail, 'madSelected', false);
        set(cardDetail, 'tadSelected', true);
      } else {
        set(cardDetail, 'madSelected', true);
        set(cardDetail, 'tadSelected', false);
      }
    }
  }
});
