import { later } from '@ember/runloop';
import layout from '../templates/components/sr-top-to-card';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import Component from '@ember/component';

export default Component.extend({
  layout,
  queries: service('customer-info'),
  cardSelectedIndex: null,
  init() {
    this.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    this._super(...arguments);
  },
  didUpdate() {
    let element = this.topToCardList.find(toCardDetail => {
      return toCardDetail.toCardSelected;
    });
    if (!isEmpty(element)) {
      this.send('verifyAmountEntered', element);
    }
  },
  cardMasking: computed(function() {
    if (this.get('queries.countryName') == 'HK' || this.get('queries.countryName') == 'SG') {
      return false;
    } else {
      return true;
    }
  }),
  actions: {
    toCardSelection(elementVal, elementArray, model) {
      let arrayIndex = 0;
      elementArray.forEach((element, index) => {
        if (element.get('id') != elementVal.get('id')) {
          element.set('toCardSelected', false);
          element.set('disableAmountText', true);
          element.set('amountEntered', '');
          element.set('errorText', false);
          this.sendAction('enableNext');
        } else {
          arrayIndex = index + 1;
          element.set('toCardSelected', true);
          element.set('disableAmountText', false);

          let userToCardAmount = element.amountEntered;
          let totalCredit = model.topToCardList.selectedAmount;
          let remainingbalance = 0;

          if (userToCardAmount == '' || userToCardAmount == undefined) {
            userToCardAmount = 0;
          }

          if (userToCardAmount % 1 === 0 && totalCredit % 1 === 0) {
            remainingbalance = totalCredit - userToCardAmount;
          } else {
            remainingbalance = (parseFloat(totalCredit) - parseFloat(userToCardAmount)).toFixed(2);
          }

          if (remainingbalance >= 0) {
            element.set('errorText', false);
            model.selectedFromCard.set('selectedAmount', remainingbalance);
          } else {
            element.set('errorText', true);
            model.selectedFromCard.set('selectedAmount', model.topToCardList.selectedAmount);
          }
        }
      });

      if (elementVal.toCardSelected) {
        arrayIndex = arrayIndex * 2 - 1;
        this.set('cardSelectedIndex', arrayIndex);
        let getEle = this.get('element').getElementsByTagName('input')[arrayIndex];
        later(function() {
          getEle.focus();
        }, 0);
      }
    },
    verifyAmountEntered(element) {
      let userToCardAmount = element.amountEntered;
      let totalCredit = this.model.topToCardList.selectedAmount;
      let remainingbalance = 0;
      if (userToCardAmount === '' || userToCardAmount === undefined) {
        userToCardAmount = 0;
      }

      if (userToCardAmount % 1 === 0 && totalCredit % 1 === 0) {
        remainingbalance = totalCredit - userToCardAmount;
      } else {
        remainingbalance = (parseFloat(totalCredit) - parseFloat(userToCardAmount)).toFixed(2);
      }

      if (remainingbalance >= 0) {
        element.set('errorText', false);
        this.model.selectedFromCard.set('selectedAmount', remainingbalance);
      } else {
        this.model.selectedFromCard.set('selectedAmount', this.model.topToCardList.selectedAmount);
        element.set('errorText', true);
      }

      let getEle = this.get('element').getElementsByTagName('input')[this.get('cardSelectedIndex')];
      getEle.focus();
      this.enableNext();
    }
  }
});
