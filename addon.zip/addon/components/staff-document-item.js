import Component from '@ember/component';
import layout from '../templates/components/staff-document-item';

export default Component.extend({
  layout,
  classNames: ['staff-document-item'],
  initiateJourney: () => {},
  actions: {
    initiateJourney(flow) {
      // TO initiate the document collection journey based on the flow.
      this.initiateJourney(flow, this.data);
    }
  }
});
