import { inject as service } from '@ember/service';
import Component from '@ember/component';
import layout from '../templates/components/status-detail-horizontal';
import { computed } from '@ember/object';

export default Component.extend({
  layout,
  queries: service('customer-info'),
  init() {
    this.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    this._super(...arguments);
  },
  cardMasking: computed(function() {
    if (
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'hk') ||
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'sg')
    ) {
      return false;
    } else {
      return true;
    }
  })
});
