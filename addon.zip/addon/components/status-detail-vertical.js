import Component from '@ember/component';
import layout from '../templates/components/status-detail-vertical';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';

export default Component.extend({
  layout,
  axwayConfig: service(),
  isASAFn: computed(function() {
    return ['VN', 'BN', 'NP', 'LK', 'BD'].indexOf(this.get('axwayConfig.country')) !== -1;
  })
});
