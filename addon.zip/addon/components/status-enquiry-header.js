import Component from '@ember/component';
import layout from '../templates/components/status-enquiry-header';

export default Component.extend({
  layout
});
