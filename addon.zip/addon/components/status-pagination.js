import { computed } from '@ember/object';
import Component from '@ember/component';
import layout from '../templates/components/status-pagination';
import { inject as service } from '@ember/service';

export default Component.extend({
  layout,
  i18n: service(),
  queries: service('customer-info'),
  mobileLimit: 5,
  selectedPageNumber: computed({
    get() {
      return 1;
    }
  }),
  footerText: computed({
    get() {
      return this.get('i18n').t('ServiceRequest.STATUSENQUIRY.statusOfRecords.' + this.get('queries.countryName'))
        .string
        ? this.get('i18n').t('ServiceRequest.STATUSENQUIRY.statusOfRecords.' + this.get('queries.countryName'))
        : this.get('i18n').t('ServiceRequest.STATUSENQUIRY.statusOfRecords');
    }
  }),
  desktopPaginationDisabled: computed({
    get() {
      if (this.get('totalPagesCount') <= 1) return true;
      else return false;
    }
  }),

  totalPaginationCount: computed({
    get() {
      if (this.get('model.processingGroup.meta').totalRecordsCount)
        return this.get('model.processingGroup.meta').totalRecordsCount;
    }
  }),

  totalActiveCount: computed({
    get() {
      return this.get('model.processingGroup.meta').activeRecordsCount;
    }
  }),
  totalPagesCount: computed({
    get() {
      let totalRecordsCount = this.get('totalPaginationCount');
      let totalPageCount = 1;
      let page0 = this.get('totalActiveCount') + 10;
      if (totalRecordsCount > page0) {
        let remainingPages = totalRecordsCount - page0;
        totalPageCount = totalPageCount + Math.ceil(remainingPages / 10);
      }
      return totalPageCount;
    }
  }),
  paginationOptions: computed({
    get() {
      let pagesArray = [];
      for (let i = 1; i <= this.get('totalPagesCount'); i++) pagesArray.push(i);
      return pagesArray;
    }
  }),
  showLoadMore: computed({
    get() {
      if (this.get('totalPaginationCount')) {
        let paginationFlag = this.get('totalActiveCount') + 5;
        if (this.get('totalPaginationCount') > paginationFlag) return true;
      }
      return false;
    }
  }),
  actions: {
    desktopDropdownSelect: function(value) {
      this.set('selectedPageNumber', value);
      this.sendAction('paginationChangeAction', value, this);
    },
    statusMobPaginationAction: function() {
      this.set('mobileLimit', this.get('mobileLimit') + 5);
      if (this.get('mobileLimit') + this.get('totalActiveCount') >= this.get('totalPaginationCount')) {
        this.set('showLoadMore', false);
      }
      this.sendAction('mobilePaginationChangeAction', this);
    },
    navEleClicked: function(type) {
      let element;
      if (type == 'prev') {
        if (this.get('selectedPageNumber') == 1 || this.get('totalPagesCount') <= 1) return;
        else {
          element = this.get('selectedPageNumber') - 1;
          this.sendAction('paginationChangeAction', element, this);
        }
      } else {
        if (this.get('selectedPageNumber') == this.get('totalPagesCount') || this.get('totalPagesCount') <= 1) return;
        else {
          element = this.get('selectedPageNumber') + 1;
          this.sendAction('paginationChangeAction', element, this);
        }
      }
      this.set('selectedPageNumber', element);
    }
  }
});
