import { inject as service } from '@ember/service';
import Component from '@ember/component';
import layout from '../templates/components/supplementary-card';

export default Component.extend({
  layout,
  i18n: service(),
  actions: {
    gotoBack() {
      this.sendAction('onCloseReject');
    }
  }
});
