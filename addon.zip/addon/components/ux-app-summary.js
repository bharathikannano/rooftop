import Component from '@ember/component';
import layout from '../templates/components/ux-app-summary';

export default Component.extend({
  layout,
  tagName: '',
  applicationId: null,
  isCurrentAccountSelected: false,
  isExcelSaverAccountSelected: false,
  product1: null,
  product2: null
});
