import Component from '@ember/component';
import layout from '../templates/components/virtual-card';
import { isEmpty } from '@ember/utils';

export default Component.extend({
  layout,
  disabled: false,
  readonly: false,
  required: false,
  reviewMode: false,
  regexp: null,
  label: '',
  errorLabel: '',
  hasErrorLabel: false,
  toUppercase: 'false',
  labelPosition: 'top',
  mandatoryInput: null,
  hasError: false,
  validation: null,
  maxlength: null,
  classNameBindings: ['isReceiptPage'],
  didRender() {
    this._super(...arguments);
    if (!isEmpty(this.get('value')) && !isEmpty(this.get('listOptions'))) {
      let results = this.get('listOptions').filter(field => {
        if (field.value === this.get('value')) {
          this.set('valueObj', field);
          return field;
        }
      });
      if (isEmpty(results)) {
        this.set('value', null);
      }
    }
    if (!isEmpty(this.get('value')) && !isEmpty(this.get('maxlength'))) {
      if (this.get('value').length > this.get('maxlength')) {
        this.set('value', this.get('value').substring(0, this.get('maxlength')));
      }
      this.set('maxNameLength', this.get('maxlength') - this.get('value').length);
    } else {
      this.set('maxNameLength', this.get('maxlength'));
    }
  },
  actions: {
    keyUp() {
      this.set('maxNameLength', this.get('maxlength') - this.get('value').length);
    },
    nameSelection(value) {
      this.set('value', value.value);
      this.set('valueObj', value);
    }
  }
});
