export default {
  createRequestTabActive: '200001',
  statusTabActive: '200002',
  createRequestBreadcrumbActive: '100001',
  statusBreadcrumbActive: '100002',
  breadCrumbsCategory: 'Bread Crumbs',
  tabCategory: 'Tab',
  mostPopularCategory: 'Most Popular',
  dropdownCategory: 'Menu Dropdown',
  usefulLinksCategory: 'Help & Useful Links',
  CHQBKREQ: 'chequeRequest.new-request',
  VIEWSTATUS: 'serviceRequest.status',
  CRDBLKREQ: 'card-block.select',
  CRDRPLREQ: 'card-replacement.select',
  CBRREQ: 'credit-balance-refund.new-request',
  CCCANCEL: 'card-cancellation.select',
  CCLOANCL: 'loan-closure.select',
  CCPINSET: 'credit-pin-change.select',
  CCPINACTV: 'credit-activation.select',
  CCSETTINGS: 'card-setting',
  CCSETTINGSD: 'card-setting.credit-card',
  APPLYPRODUCTS: 'product-list.list',
  APPLYPRODUCTS_CATEGORY: 'product-list.category',
  STARTAPPLICATION: 'start-application',
  ChequeBookFeatures: {
    leavesSelection: []
  },
  noOfLeaves: {
    default: ['30', '100', 'default:30']
  },
  gaEnabledCountries: ['IN', 'AE', 'SG', 'HK'],
  branchOptionFlowCountries: ['GH', 'ZM', 'NG', 'UG', 'TZ', 'ZW'],
  mvp2FlowCheque: ['SG'],
  cardSettingsConfig: {
    countriesToHideCountryLimitsSelection: ['SG']
  },
  COUNTRYCONFIG: {
    AE: {
      availableSettings: {
        tmpBlock: true,
        transactionLimit: true,
        paymentChannels: true,
        controlledCategories: true,
        countryLimits: true
      },
      minLimit: 100.0
    },
    MY: {
      availableSettings: {
        tmpBlock: true,
        transactionLimit: true,
        paymentChannels: true,
        controlledCategories: false,
        countryLimits: true
      },
      minLimit: 100.0
    },
    IN: {
      availableSettings: {
        tmpBlock: true,
        transactionLimit: true,
        paymentChannels: false,
        controlledCategories: false,
        countryLimits: false
      },
      minLimit: 1500.0
    },
    HK: {
      availableSettings: {
        tmpBlock: true,
        transactionLimit: true,
        paymentChannels: true,
        controlledCategories: true,
        countryLimits: true
      },
      minLimit: 200.0
    },
    SG: {
      availableSettings: {
        tmpBlock: true,
        transactionLimit: false,
        paymentChannels: false,
        controlledCategories: false,
        countryLimits: false
      },
      minLimit: 10.0
    },
    VN: {
      availableSettings: {
        tmpBlock: true,
        transactionLimit: true,
        paymentChannels: true,
        controlledCategories: true,
        countryLimits: true
      },
      minLimit: 100000.0
    }
  },
  genericRequestForm: {
    noDatastrings: [
      'ERR_CSL_DEBIT_CARDS_202',
      'ERR_CSL_DEBIT_CARDS_218',
      'CSL-DEBIT-CARD-202',
      'ERR_CSL_CREDIT_CARDS_CUSTOMER_NOT_FOUND',
      'ERR_CSL_DEBIT_CARDS_CUSTOMER_NOT_FOUND'
    ],
    texArea: {
      MY: [
        'RELETREQ',
        'RELONACC',
        'PRINREDC',
        'INRATWAI',
        'EPFWDLET',
        'REDSTREQ',
        'REPYSCHD',
        'OLOANLET',
        'RETLODOC',
        'GREQSTAC',
        'GREQSTCC',
        'GREQSTLA',
        'GREQSTGN'
      ],
      SG: [
        'CCINACCR',
        'CCSTDATC',
        'DBEMNAMC',
        'CCEMNAMC',
        'NISSUATM',
        'LINKMAIT',
        'GREQSTAC',
        'GREQSTCC',
        'GREQSTLA',
        'GREQSTGN',
        'GREQSTMO'
      ],
      BN: ['REQCLLET', 'CANCELSO', 'CLOFCASA', 'EUPLFTFD'],
      LK: [
        'AMCASTLK',
        'NFDSETLK',
        'BALCONAC',
        'STATSACC',
        'VISALETA',
        'STATSCCM',
        'VISALETC',
        'TRLINCER',
        'BALCONCC',
        'LOANONCC',
        'DRSTBKCC',
        'DRSTBKAC'
      ],
      NP: ['NFDSETNP', 'NFDREREQ', 'CCSDTCNP', 'SUPDETUD', 'LONCLTNP', 'COFORDNP'],
      IN: ['GREQSTAC', 'GREQSTCC', 'GREQSTLA', 'GREQSTGN', 'GREQSTTD'],
      BD: [
        'AMCASABD',
        'BALCNABD',
        'ENRSMSBD',
        'LOANOTBD',
        'LONCLTBD',
        'CCSDTCBD',
        'AMCASCBD',
        'LINKMABD',
        'STATSCBD',
        'CLOCRDBD'
      ],
      VN: [
        'LMTCONFL',
        'BALCONVN',
        'INTCONFL',
        'LOGCONFL',
        'PAYHISTL',
        'BANKCERT',
        'SLSPURAG',
        'CICCONFM',
        'CONFISUE',
        'COOFMAFA',
        'EXTLOAGR',
        'LATPAYHL',
        'LINCONFL',
        'LREPHIST',
        'LREPSCHE',
        'LSETTLEL',
        'PRPCONFL',
        'MAGRFAGR',
        'CERTCPTD'
      ]
    },
    docUpload: {
      MY: ['SURPFUND', 'REDSTREQ'],
      BN: ['UPDICEXP'],
      LK: ['VISAUPAC', 'VISAUPCC'],
      NP: ['SUPDETUD'],
      VN: ['RESCAUPD']
    },
    docSubmission: {
      SURPFUND: 'T0491',
      VISAUPCC: 'T0345',
      SUPDETUD: 'T0491',
      VISAUPAC: 'T0345',
      UPDICEXP: 'T0205',
      REDSTREQ: 'T0492',
      RESCAUPD: 'INC017DS',
      DEFAULTVALUE: 'T0000'
    },
    cslRequest: {
      CCARD: 'credit-card',
      DCARD: 'debit-card',
      PLOAN: 'loan',
      MLOAN: 'loan',
      LOAN: 'loan',
      DEPOSIT: 'casa',
      CASA: 'casa',
      CUSTOMER: 'customer'
    },
    inlineDuplicateChk: ['PLCLOSUR'],
    serviceType: {
      NISSUATM: {
        msgID: 'GRA001DC',
        refmsgId: 'RFA001EQ',
        submsgId: 'RFA001ST'
      },
      PLCLOSUR: {
        msgID: 'CCLOAN'
      },
      DBCREDLY: {
        msgID: 'GRA002DR'
      },
      CHQREDLY: {
        msgID: 'GRA003CQ'
      },
      MORTREPR: {
        msgID: 'GRL001MR'
      },
      COFORDNP: {
        msgID: 'GRL017OD',
        refmsgId: 'RFL017EQ',
        submsgId: 'RFL017ST'
      },
      SURPFUND: {
        msgID: 'GRL002PL',
        refmsgId: 'RFL002EQ',
        submsgId: 'RFL002ST'
      },
      RELETREQ: {
        msgID: 'GRL003RL',
        refmsgId: 'RFL003EQ',
        submsgId: 'RFL003ST'
      },
      RELONACC: {
        msgID: 'GRL004FF',
        refmsgId: 'RFL004EQ',
        submsgId: 'RFL004ST'
      },
      PRINREDC: {
        msgID: 'GRL005PR',
        refmsgId: 'RFL005EQ',
        submsgId: 'RFL005ST'
      },
      INRATWAI: {
        msgID: 'GRL006IR',
        refmsgId: 'RFL006EQ',
        submsgId: 'RFL006ST'
      },
      EPFWDLET: {
        msgID: 'GRL007CL',
        refmsgId: 'RFL007EQ',
        submsgId: 'RFL007ST'
      },
      REDSTREQ: {
        msgID: 'GRL008RS',
        refmsgId: 'RFL008EQ',
        submsgId: 'RFL008ST'
      },
      REPYSCHD: {
        msgID: 'GRL009RS',
        refmsgId: 'RFL009EQ',
        submsgId: 'RFL009ST'
      },
      OLOANLET: {
        msgID: 'GRL010IP',
        refmsgId: 'RFL010EQ',
        submsgId: 'RFL010ST'
      },
      RETLODOC: {
        msgID: 'GRL011OD',
        refmsgId: 'RFL011EQ',
        submsgId: 'RFL011ST'
      },
      ASCFINCP: {
        msgID: 'GRL012AI'
      },
      ASFMFEMI: {
        msgID: 'GRL013AF'
      },
      SATOFACC: {
        msgID: 'GRL014SA'
      },
      ARRBRKSC: {
        msgID: 'GRL015AB'
      },
      CCLOFDOC: {
        msgID: 'GRL016LD'
      },
      COFORDOC: {
        msgID: 'GRL017OD',
        refmsgId: 'RFL017EQ',
        submsgId: 'RFL017ST'
      },
      SALETREQ: {
        msgID: 'GRL018SL'
      },
      DOCRELES: {
        msgID: 'GRL019DR'
      },
      RFDEXEMI: {
        msgID: 'GRL020RE'
      },
      TNCCPRET: {
        msgID: 'GRL021TC'
      },
      REISSPTQ: {
        msgID: 'GRL022PT'
      },
      INTRELET: {
        msgID: 'GRL023IR'
      },
      CCINACCR: {
        msgID: 'GRC001CA',
        refmsgId: 'RFC001EQ',
        submsgId: 'RFC001ST'
      },
      CCSTDATC: {
        msgID: 'GRC002CD',
        refmsgId: 'RFC002EQ',
        submsgId: 'RFC002ST'
      },
      DBEMNAMC: {
        msgID: 'GRC003DN',
        refmsgId: 'RFC003EQ',
        submsgId: 'RFC003ST'
      },
      CCEMNAMC: {
        msgID: 'GRC004CN',
        refmsgId: 'RFC004EQ',
        submsgId: 'RFC004ST'
      },
      LINKMAIT: {
        msgID: 'GRC005LM',
        refmsgId: 'RFC005EQ',
        submsgId: 'RFC005ST'
      },
      SUBOLMIT: {
        msgID: 'GRC006SO'
      },
      UNSUBLMT: {
        msgID: 'GRC007UO'
      },
      COEAREDM: {
        msgID: 'GRC008ER'
      },
      CLAUTOAP: {
        msgID: 'GRC009AP'
      },
      ACTCCARD: {
        msgID: 'GRC010AC'
      },
      TDADRISU: {
        msgID: 'GRT001AR'
      },
      CLOFCASA: {
        msgID: 'GRA010CA',
        refmsgId: 'RFG057EQ',
        submsgId: 'RFG057ST'
      },
      REQCLLET: {
        msgID: 'GRG003CL',
        refmsgId: 'RFG003EQ',
        submsgId: 'RFG003ST'
      },
      CANCELSO: {
        msgID: 'GRA011SI',
        refmsgId: 'RFA011EQ',
        submsgId: 'RFA011ST'
      },
      UPDICEXP: {
        msgID: 'GRA012UE',
        refmsgId: 'RFA012EQ',
        submsgId: 'RFA012ST'
      },
      EUPLFTFD: {
        msgID: 'GRA013UP',
        refmsgId: 'RFG064EQ',
        submsgId: 'RFG064ST'
      },
      LONCLTLK: {
        msgID: 'GRL024CL',
        refmsgId: 'RFL024EQ',
        submsgId: 'RFL024ST'
      },
      AMCASTLK: {
        msgID: 'GRA004SI',
        refmsgId: 'RFA004EQ',
        submsgId: 'RFA004ST'
      },
      DORMACTV: {
        msgID: 'GRA005DR',
        refmsgId: 'RFA005EQ',
        submsgId: 'RFA005ST'
      },
      NFDSETLK: {
        msgID: 'GRA006FD',
        refmsgId: 'RFA006EQ',
        submsgId: 'RFA006ST'
      },
      BALCONAC: {
        msgID: 'GRA008BC',
        refmsgId: 'RFA008EQ',
        submsgId: 'RFA008ST'
      },
      WTHTACNL: {
        msgID: 'GRA007WT',
        refmsgId: 'RFA007EQ',
        submsgId: 'RFA007ST'
      },
      DRSTBKAC: {
        msgID: 'GRG001DB',
        refmsgId: 'RFG001EQ',
        submsgId: 'RFG001ST'
      },
      VISAUPAC: {
        msgID: 'GRG002VU',
        refmsgId: 'RFG002EQ',
        submsgId: 'RFG002ST'
      },
      STATSACC: {
        msgID: 'STMTREQI',
        refmsgId: 'RFG039EQ',
        submsgId: 'RFG039ST'
      },
      VISALETA: {
        msgID: 'GRA009VC',
        refmsgId: 'RFA009EQ',
        submsgId: 'RFA009ST'
      },
      STATSCCM: {
        msgID: 'STMTREQI',
        refmsgId: 'RFG039EQ',
        submsgId: 'RFG039ST'
      },
      VISALETC: {
        msgID: 'GRA009VC',
        refmsgId: 'RFA009EQ',
        submsgId: 'RFA009ST'
      },
      TRLINCER: {
        msgID: 'GRC011TC',
        refmsgId: 'RFC011EQ',
        submsgId: 'RFC011ST'
      },
      BALCONCC: {
        msgID: 'GRA008BC',
        refmsgId: 'RFA008EQ',
        submsgId: 'RFA008ST'
      },
      LOANONCC: {
        msgID: 'GRC012LC',
        refmsgId: 'RFC012EQ',
        submsgId: 'RFC012ST'
      },
      DRSTBKCC: {
        msgID: 'GRG001DB',
        refmsgId: 'RFG001EQ',
        submsgId: 'RFG001ST'
      },
      VISAUPCC: {
        msgID: 'GRG002VU',
        refmsgId: 'RFG002EQ',
        submsgId: 'RFG002ST'
      },
      AMCSTINP: {
        msgID: 'GRA004SI',
        refmsgId: 'RFA004EQ',
        submsgId: 'RFA004ST'
      },
      NFDSETNP: {
        msgID: 'GRA006FD',
        refmsgId: 'RFA006EQ',
        submsgId: 'RFA006ST'
      },
      DBREDYNP: {
        msgID: 'GRA002DR'
      },
      CQREDYNP: {
        msgID: 'GRA003CQ'
      },
      FDCNAHCY: {
        msgID: 'GRT003DR',
        refmsgId: 'RFT003EQ',
        submsgId: 'RFT003ST'
      },
      NFDREREQ: {
        msgID: 'GRT002DR',
        refmsgId: 'RFT002EQ',
        submsgId: 'RFT002ST'
      },
      CCSDTCNP: {
        msgID: 'GRC002CD',
        refmsgId: 'RFC002EQ',
        submsgId: 'RFC002ST'
      },
      SUPDETUD: {
        msgID: 'GRC013SC',
        refmsgId: 'RFC013EQ',
        submsgId: 'RFC013ST'
      },
      LONCLTNP: {
        msgID: 'GRL024CL',
        refmsgId: 'RFL024EQ',
        submsgId: 'RFL024ST'
      },
      CPORGDOC: {
        msgID: 'GRL017OD'
      },
      AMCASABD: {
        msgID: 'GRA004SI',
        refmsgId: 'RFA004EQ',
        submsgId: 'RFA004ST'
      },
      BALCNABD: {
        msgID: 'GRA008BC',
        refmsgId: 'RFA008EQ',
        submsgId: 'RFA008ST'
      },
      ENRSMSBD: {
        msgID: 'GRA014SE',
        refmsgId: 'RFA014EQ',
        submsgId: 'RFA014ST'
      },
      LOANOTBD: {
        msgID: 'GRL025CL',
        refmsgId: 'RFL025EQ',
        submsgId: 'RFL025ST'
      },
      LONCLTBD: {
        msgID: 'GRL024CL',
        refmsgId: 'RFL024EQ',
        submsgId: 'RFL024ST'
      },
      CCSDTCBD: {
        msgID: 'STMTCYDC',
        refmsgId: 'RFG042EQ',
        submsgId: 'RFG042ST'
      },
      AMCASCBD: {
        msgID: 'GRC014AB',
        refmsgId: 'RFC014EQ',
        submsgId: 'RFC014ST'
      },
      LINKMABD: {
        msgID: 'GRC015RM',
        refmsgId: 'RFC015EQ',
        submsgId: 'RFC015ST'
      },
      STATSCBD: {
        msgID: 'STMTREQI',
        refmsgId: 'RFG039EQ',
        submsgId: 'RFG039ST'
      },
      CLOCRDBD: {
        msgID: 'GRL024CL',
        refmsgId: 'RFL024EQ',
        submsgId: 'RFL024ST'
      },
      LMTCONFL: {
        msgID: 'GRC016CL',
        refmsgId: 'RFC016EQ',
        submsgId: 'RFC016ST'
      },
      BALCONVN: {
        msgID: 'GRA008BC',
        refmsgId: 'RFA008EQ',
        submsgId: 'RFA008ST'
      },
      INTCONFL: {
        msgID: 'GRC016IL',
        refmsgId: 'RFC016EQ',
        submsgId: 'RFC016ST'
      },
      LOGCONFL: {
        msgID: 'GRC016LL',
        refmsgId: 'RFC016EQ',
        submsgId: 'RFC016ST'
      },
      PAYHISTL: {
        msgID: 'GRC016HL',
        refmsgId: 'RFC016EQ',
        submsgId: 'RFC016ST'
      },
      BANKCERT: {
        msgID: 'GRL026BC',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      SLSPURAG: {
        msgID: 'GRL026PA',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      CICCONFM: {
        msgID: 'GRL026CI',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      CONFISUE: {
        msgID: 'GRL026TC',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      COOFMAFA: {
        msgID: 'GRL026MA',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      EXTLOAGR: {
        msgID: 'GRL026LA',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      LATPAYHL: {
        msgID: 'GRL026HL',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      LINCONFL: {
        msgID: 'GRL026CL',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      LREPHIST: {
        msgID: 'GRL026HL',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      LREPSCHE: {
        msgID: 'GRL009RS',
        refmsgId: 'RFL009EQ',
        submsgId: 'RFL009ST'
      },
      LSETTLEL: {
        msgID: 'GRL026SL',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      PRPCONFL: {
        msgID: 'GRL026PL',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      MAGRFAGR: {
        msgID: 'GRL026FA',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      CERTCPTD: {
        msgID: 'GRL026TD',
        refmsgId: 'RFL026EQ',
        submsgId: 'RFL026ST'
      },
      RESCAUPD: {
        msgID: 'GRC017CU',
        refmsgId: 'RFC017EQ',
        submsgId: 'RFC017ST'
      }
    },
    msgAddType: {
      AC: 'A',
      CC: 'C',
      MO: 'L',
      LA: 'L',
      TD: 'A',
      GN: 'G'
    },
    filterType: {
      GREQ_COER: ['COEAREDM'],
      GREQ_AMCC: ['ACTCCARD'],
      GREQ_AMORT: ['ASCFINCP', 'ASFMFEMI', 'SATOFACC', 'ARRBRKSC'],
      GREQ_DOCS: ['CCLOFDOC', 'COFORDOC', 'SALETREQ', 'DOCRELES'],
      GREQ_REMI: ['RFDEXEMI'],
      GREQ_TMS: ['TNCCPRET'],
      GREQ_PTQ: ['REISSPTQ'],
      GREQ_RIRL: ['INTRELET'],
      GREQ_PL: ['SURPFUND', 'RELETREQ'],
      GREQ_CLAUTOAP: ['CLAUTOAP'],
      GREQ_SUBOLMIT: ['SUBOLMIT'],
      GREQ_UNSUBLMT: ['UNSUBLMT'],
      GREQ_MORT: [
        'RELONACC',
        'PRINREDC',
        'INRATWAI',
        'EPFWDLET',
        'REDSTREQ',
        'REPYSCHD',
        'OLOANLET',
        'RETLODOC',
        'MORTREPR'
      ],
      GREQ_COFORDNP: ['COFORDNP'],
      GREQ_CHBR: ['CHQREDLY'],
      GREQ_TDAR: ['TDADRISU'],
      GREQ_CARDISSUE: ['NISSUATM'],
      GREQ_PLC_CLOSURE: ['PLCLOSUR'],
      GREQ_DBCREDLY: ['DBCREDLY'],
      GREQ_CLOL: ['LONCLTLK', 'LONCLTNP'],
      GREQ_ACSI: ['AMCASTLK', 'AMCSTINP'],
      GREQ_DORA: ['DORMACTV'],
      GREQ_NFDS: ['NFDSETLK', 'NFDSETNP'],
      GREQ_NFDREREQ: ['NFDREREQ'],
      GREQ_BLC: ['BALCONAC'],
      GREQ_WTCL: ['WTHTACNL'],
      GREQ_DSB: ['DRSTBKAC', 'DRSTBKCC'],
      GREQ_VIUP: ['VISAUPAC', 'VISAUPCC'],
      GREQ_STMT: ['STATSACC', 'STATSCCM'],
      GREQ_VCL: ['VISALETA'],
      GREQ_CONL: ['VISALETC'],
      GREQ_TIC: ['TRLINCER'],
      GREQ_BALC: ['BALCONCC', 'BALCONVN'],
      GREQ_LOC: ['LOANONCC'],
      GREQ_CALA: ['CLOFCASA'],
      GREQ_CASO: ['CANCELSO'],
      GREQ_EUFD: ['EUPLFTFD'],
      GREQ_RCL: ['REQCLLET'],
      GREQ_UIED: ['UPDICEXP'],
      GREQ_RDEL: ['DBREDYNP'],
      GREQ_CHQBOOK: ['CQREDYNP'],
      GREQ_FDAH: ['FDCNAHCY'],
      STMT_CYDC: ['CCSDTCNP'],
      GREQ_SDU: ['SUPDETUD'],
      GREQ_LTCC: ['LOANOTBD'],
      GREQ_CLET: ['LONCLTBD'],

      GREQ_LMTC: ['LMTCONFL'],
      GREQ_INTC: ['INTCONFL'],
      GREQ_LGRPC: ['LOGCONFL'],
      GREQ_PHL: ['PAYHISTL'],
      GREQ_BNKC: ['BANKCERT'],
      GREQ_SPAG: ['SLSPURAG'],
      GREQ_CICC: ['CICCONFM'],
      GREQ_CNFI: ['CONFISUE'],
      GREQ_CMFA: ['COOFMAFA'],
      GREQ_LAGR: ['EXTLOAGR'],
      GREQ_LPHL: ['LATPAYHL'],
      GREQ_LICL: ['LINCONFL'],
      GREQ_LREH: ['LREPHIST'],
      GREQ_LRES: ['LREPSCHE'],
      GREQ_LSL: ['LSETTLEL'],
      GREQ_PRCL: ['PRPCONFL'],
      GREQ_MORTVN: ['MAGRFAGR'],
      GREQ_COTD: ['CERTCPTD'],
      GREQ_RCU: ['RESCAUPD']
    },
    filters: {
      values: {
        GREQ_COER: {
          blkInd: ['02', '03', '05', '12', '15'],
          cardType: ['Loan on Card']
        },
        GREQ_PL: {
          opsTypeCode: 'GREQ_PL',
          include: 'offline'
        },
        GREQ_MORT: {
          opsTypeCode: 'GREQ_MORT',
          include: 'offline'
        },
        GREQ_COFORDNP: {
          opsTypeCode: 'GREQ_MORT',
          include: 'online'
        },
        GREQ_AMCC: {
          operationName: 'GREQ_CACT'
        },
        GREQ_AMORT: {
          opsTypeCode: 'GREQ_AMORT',
          include: 'offline'
        },
        GREQ_DOCS: {
          opsTypeCode: 'GREQ_DOCS',
          include: 'offline'
        },
        GREQ_REMI: {
          opsTypeCode: 'GREQ_REMI',
          include: 'offline'
        },
        GREQ_TMS: {
          opsTypeCode: 'GREQ_TMS',
          include: 'offline'
        },
        GREQ_PTQ: {
          opsTypeCode: 'GREQ_PTQ',
          include: 'offline'
        },
        GREQ_RIRL: {
          opsTypeCode: 'GREQ_RIRL',
          include: 'offline'
        },
        GREQ_CHBR: {
          operationName: 'GREQ_CHQBOOK'
        },
        GREQ_TDAR: {
          includeDealAccounts: true,
          productCode: 'CDA',
          accountStatus: ['O', 'A']
        },
        GREQ_CARDISSUE: {
          operationName: 'GREQ_CARDISSUE'
        },
        GREQ_PLC_CLOSURE: {
          operationName: 'GREQ_PLCLOSUR'
        },
        GREQ_DBCREDLY: {
          operationName: 'GREQ_RDEL'
        },
        GREQ_CLOL: {
          opsTypeCode: 'GREQ_CLOL',
          include: 'online'
        },
        GREQ_ACSI: {
          operationName: 'GREQ_ACSI'
        },
        GREQ_DORA: {
          operationName: 'GREQ_DORA'
        },
        GREQ_NFDS: {
          operationName: 'GREQ_NFDS'
        },
        GREQ_NFDREREQ: {
          operationName: 'GREQ_NFDR',
          includeDealAccounts: 'true'
        },
        GREQ_BLC: {
          operationName: 'GREQ_BLC'
        },
        GREQ_WTCL: {
          operationName: 'GREQ_WTCL'
        },
        GREQ_DSB: {
          operationName: 'GREQ_DSB'
        },
        GREQ_VIUP: {
          operationName: 'GREQ_VIUP'
        },
        GREQ_STMT: {
          operationName: 'GREQ_STMT'
        },
        GREQ_VCL: {
          operationName: 'GREQ_VCL'
        },
        GREQ_CONL: {
          operationName: 'GREQ_CONL'
        },
        GREQ_TIC: {
          operationName: 'GREQ_TIC'
        },
        GREQ_BALC: {
          operationName: 'GREQ_BALC'
        },
        GREQ_LOC: {
          operationName: 'GREQ_LOC'
        },
        GREQ_CALA: {
          operationName: 'GREQ_CALA'
        },
        GREQ_CASO: {
          operationName: 'GREQ_CASO'
        },
        GREQ_EUFD: {
          operationName: 'GREQ_EUFD'
        },
        GREQ_RCL: {
          operationName: 'GREQ_RCL'
        },
        GREQ_UIED: {
          operationName: 'GREQ_UIED'
        },
        GREQ_RDEL: {
          operationName: 'GREQ_RDEL'
        },
        GREQ_CHQBOOK: {
          operationName: 'GREQ_CHQBOOK'
        },
        GREQ_FDAH: {
          operationName: 'GREQ_FDAH',
          includeDealAccounts: 'true'
        },
        STMT_CYDC: {
          operationName: 'STMT_CYDC'
        },
        GREQ_SDU: {
          operationName: 'GREQ_SDU'
        },
        GREQ_CLAUTOAP: {
          operationName: 'GREQ_APRC'
        },
        GREQ_SUBOLMIT: {
          operationName: 'GREQ_SUBOLMT'
        },
        GREQ_UNSUBLMT: {
          operationName: 'GREQ_UNSUBOLMT'
        },
        GREQ_LTCC: {
          opsTypeCode: 'GREQ_LTCC'
        },
        GREQ_CLET: {
          opsTypeCode: 'GREQ_CLET'
        },

        GREQ_LMTC: {
          operationName: 'GREQ_LMTC'
        },
        GREQ_INTC: {
          operationName: 'GREQ_INTC'
        },
        GREQ_LGRPC: {
          operationName: 'GREQ_LGRPC'
        },
        GREQ_PHL: {
          operationName: 'GREQ_PHL'
        },
        GREQ_BNKC: {
          opsTypeCode: 'GREQ_BNKC',
          include: 'online'
        },
        GREQ_SPAG: {
          opsTypeCode: 'GREQ_SPAG',
          include: 'online'
        },
        GREQ_CICC: {
          opsTypeCode: 'GREQ_CICC',
          include: 'online'
        },
        GREQ_CNFI: {
          opsTypeCode: 'GREQ_CNFI',
          include: 'online'
        },
        GREQ_CMFA: {
          opsTypeCode: 'GREQ_CMFA',
          include: 'online'
        },
        GREQ_LAGR: {
          opsTypeCode: 'GREQ_LAGR',
          include: 'online'
        },
        GREQ_LPHL: {
          opsTypeCode: 'GREQ_LPHL',
          include: 'online'
        },
        GREQ_LICL: {
          opsTypeCode: 'GREQ_LICL',
          include: 'online'
        },
        GREQ_LREH: {
          opsTypeCode: 'GREQ_LREH',
          include: 'online'
        },
        GREQ_LRES: {
          opsTypeCode: 'GREQ_LRES',
          include: 'online'
        },
        GREQ_LSL: {
          opsTypeCode: 'GREQ_LSL',
          include: 'online'
        },
        GREQ_PRCL: {
          opsTypeCode: 'GREQ_PRCL',
          include: 'online'
        },
        GREQ_MORTVN: {
          opsTypeCode: 'GREQ_MORT',
          include: 'online'
        },
        GREQ_COTD: {
          opsTypeCode: 'GREQ_COTD',
          include: 'online'
        },
        GREQ_RCU: {
          operationName: 'GREQ_RCU'
        }
      },
      MY: {
        'credit-card': {
          default: {
            blkInd: ['02', '03', '05', '12', '15'],
            cardType: ['MasterCard', 'Visa']
          }
        }
      },
      IN: {
        'credit-card': {
          default: {
            cardStatus: ['1', '2'],
            blkInd: ['02', '09', '12', '15'],
            cardType: ['MasterCard', 'Visa']
          }
        },
        'debit-card': {
          default: {
            cardStatus: ['Active', 'Temp']
          }
        }
      },
      SG: {
        'credit-card': {
          default: {
            blkInd: ['02', '03', '05', '12', '15'],
            cardType: ['MasterCard', 'Visa'],
            expiredCard: 'N'
          }
        },
        'debit-card': {
          default: {
            blkInd: ['Active'],
            operationName: 'GREQ_DCARDLIST',
            expDtFlag: 'True'
          }
        }
      }
    },
    notesNumberRemovedInCountries: ['MY']
  },
  certificatesRequest: {
    filters: {
      TDS: {
        financialYears: {
          operationName: 'GREQ_TDS'
        },
        certificate: {
          operationName: 'GREQ_TDS',
          includeDealAccounts: 'true'
        }
      },
      IBC: {
        financialYears: {
          operationName: 'GREQ_IBC'
        },
        LK: {
          customer: {
            certificate: {
              operationName: 'GREQ_IBC'
            }
          }
        },
        customer: {
          certificate: {
            tpSystem: 'ICM',
            operationName: 'GREQ_IBC'
          }
        },
        certificate: {
          operationName: 'GREQ_IBC',
          includeDealAccounts: 'true'
        }
      },
      PI: {
        financialYears: {
          operationName: 'GREQ_PI'
        },
        certificate: {
          opsTypeCode: 'GREQ_PI',
          include: 'offline'
        },
        LK: {
          certificate: {
            opsTypeCode: 'GREQ_PI',
            include: 'online'
          }
        }
      }
    },
    query: {
      TDS: 'casa',
      PI: 'loan',
      IBC: 'customer'
    },
    payloadCertificateType: {
      TDS: 'TDS',
      PI: 'PI',
      IBC: 'IBS'
    }
  },
  duplicateStatement: {
    cslRequest: {
      CCARD: 'credit-card',
      LOAN: 'loan',
      CASA: 'casa'
    },
    product: {
      CCARD: 'cccard',
      LOAN: 'loan',
      CASA: 'account'
    },
    reviewCat: ['NONDLYCC'],
    filters: {
      ASA: {
        customerData: {
          operationName: 'GREQ_STMT'
        }
      },
      customerData: {
        tpSystem: 'ICM',
        operationName: 'GREQ_STMT'
      },
      productList: {
        NONDLYCC: {
          operationName: 'GREQ_CCRD'
        },
        loans: {
          opsTypeCode: 'GREQ_STMT',
          include: 'offline'
        },
        default: {
          operationName: 'GREQ_STMT'
        }
      },
      chargeAccount: {
        operationName: 'GREQ_STMT_CHRG'
      }
    },
    hideNotesCountries: ['NP', 'VN'],
    defaultEmail: ['IN', 'VNCCARD'],
    nonDataLockerCtry: ['NP', 'VN', 'BN']
  },

  TRANSACTION: {
    SG: {
      '30': ['31'],
      '40': ['41', '43']
    },
    MY: {
      '30': ['31'],
      '40': ['41', '43']
    },
    IN: {
      '30': ['31'],
      '40': ['41']
    },
    BN: {
      '30': ['31'],
      '40': ['41', '43'],
      '34': ['31', '33']
    },
    BD: {
      '005': ['025', '006'],
      '007': ['027'],
      '008': ['028']
    },
    LK: {
      '005': ['025', '006'],
      '007': ['027'],
      '008': ['028']
    },
    VN: {
      '005': ['025', '006'],
      '007': ['027'],
      '008': ['028'],
      '009': ['019']
    }
  },

  signatureUpdate: {
    prodCodeForTD: ['600', '601', '602', '604', '605', '616', '619', '624'],
    prodCodeForCASA: [
      '302',
      '306',
      '307',
      '309',
      '310',
      '313',
      '314',
      '317',
      '318',
      '319',
      '320',
      '324',
      '328',
      '331',
      '332',
      '334',
      '335',
      '402',
      '407',
      '412',
      '501',
      '502',
      '503',
      '504',
      '505',
      '506',
      '507',
      '508',
      '509',
      '510',
      '511',
      '512',
      '516'
    ],
    operatingInsCASA: ['001', '002', '003', '004', '005', '008', '009']
  },
  reinstateRewardPoints: {
    filters: {
      'rewards-accounts': {
        type: {
          EQ: 'dollarReinstate'
        }
      }
    }
  },
  posLimit: {
    filters: {
      CMBC: {
        SG: [
          {
            cardType: ['MasterCard', 'Visa'],
            expiredCard: 'N',
            cardStatus: '1',
            include: 'online',
            operationName: 'POSLIMIT'
          }
        ]
      },
      DCARD: {
        SG: [
          {
            blkInd: ['Active'],
            operationName: 'POSLIMIT'
          }
        ]
      },
      ALL: {
        SG: [
          {
            cardType: ['MasterCard', 'Visa'],
            expiredCard: 'N',
            cardStatus: '1',
            include: 'online',
            operationName: 'POSLIMIT'
          },
          {
            blkInd: ['Active'],
            operationName: 'POSLIMIT'
          }
        ]
      },
      entity: {
        CMBC: ['credit-card'],
        DCARD: ['debit-card'],
        ALL: ['credit-card', 'debit-card']
      },
      posLimits: {
        SG: ['200', '500', '1000', '2000', '3000', '4000', '5000', '10000', '15000', '20000']
      },
      atmLimits: {
        SG: ['4000']
      }
    }
  },
  insuranceBanner: {
    insuranceBannerTitle: 'Free Insurance Coverage',
    bannerContent:
      'Simply keep a balance of <b>GHS 5,000</b><br>(across your current or savings accounts)<br> at the end of each month and get free insurance coverage of the following month.',
    insuranceBenefitsTitle: 'Bancassurance Coverage Benefits',
    insuranceBenefitsContent: '<p>Death & Disablity - <b>GHS 5,000</b></p><p>Retrenchment- <b>GHS 3,000</b></p>',
    insuranceApplyTc:
      "<a href='https://av.sc.com/gh/content/docs/gh-insurance-campaign-tc.pdf' target='_blank'>Terms & conditions Apply</a>"
  },
  dcSettings: {
    atmLimitForMLD: [
      {
        id: 'ATM_POS_600',
        value: 'ATM Limit RM6,000 / POS Limit RM0',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_510',
        value: 'ATM Limit RM5,000 / POS Limit RM1,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_420',
        value: 'ATM Limit RM4,000 / POS Limit RM2,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_300',
        value: 'ATM Limit RM3,000 / POS Limit RM3,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_240',
        value: 'ATM Limit RM2,000 / POS Limit RM4,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_150',
        value: 'ATM Limit RM1,000 / POS Limit RM5,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_200',
        value: 'ATM Limit RM2,000 / POS Limit RM2,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_1100',
        value: 'ATM Limit RM1,000 / POS Limit RM1,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'Com_limit_6000',
        value: 'Combined ATM & POS Limit of RM6,000',
        name: 'atm-pos-limit'
      }
    ],
    atmPosLimitOptions: [
      {
        id: 'ATM_POS_100',
        value: 'ATM Limit RM10,000 / POS Limit RM0',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_910',
        value: 'ATM Limit RM9,000 / POS Limit RM1,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_820',
        value: 'ATM Limit RM8,000 / POS Limit RM2,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_730',
        value: 'ATM Limit RM7,000 / POS Limit RM3,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_640',
        value: 'ATM Limit RM6,000 / POS Limit RM4,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_550',
        value: 'ATM Limit RM5,000 / POS Limit RM5,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_460',
        value: 'ATM Limit RM4,000 / POS Limit RM6,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_370',
        value: 'ATM Limit RM3,000 / POS Limit RM7,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_280',
        value: 'ATM Limit RM2,000 / POS Limit RM8,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_190',
        value: 'ATM Limit RM1,000 / POS Limit RM9,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_440',
        value: 'ATM Limit RM4,000 / POS Limit RM4,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_330',
        value: 'ATM Limit RM3,000 / POS Limit RM3,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_220',
        value: 'ATM Limit RM2,000 / POS Limit RM2,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'ATM_POS_110',
        value: 'ATM Limit RM1,000 / POS Limit RM1,000',
        name: 'atm-pos-limit'
      },
      {
        id: 'Com_limit_1000',
        value: 'Combined ATM & POS Limit of RM10,000',
        name: 'atm-pos-limit'
      }
    ],
    atmIbftLimitOptions: [
      {
        id: 'ATM_IBFT_01',
        value: 'Standard limit RM10,000',
        name: 'atm-Ibft-limit'
      },
      {
        id: 'ATM_IBFT_02',
        value: 'Extended limit RM30,000',
        name: 'atm-Ibft-limit'
      }
    ],
    cumulativeLimitOptions: [
      {
        id: 'RM0',
        value: 'RM0',
        name: 'cumulative-limit'
      },
      {
        id: 'RM250',
        value: 'RM250',
        name: 'cumulative-limit'
      },
      {
        id: 'RM500',
        value: 'RM500',
        name: 'cumulative-limit'
      },
      {
        id: 'RM750',
        value: 'RM750',
        name: 'cumulative-limit'
      },
      {
        id: 'RM1000',
        value: 'RM1,000',
        name: 'cumulative-limit'
      },
      {
        id: 'RM1250',
        value: 'RM1,250',
        name: 'cumulative-limit'
      }
    ],
    dcSettingsRadioGroup: [
      {
        value: 'Opt In',
        label: 'Opt In'
      },
      {
        value: 'Opt Out',
        label: 'Opt Out'
      }
    ],
    optInOutOptions: [
      {
        id: 'optInOut1',
        value: 'I would like opt-in to Card-Not-Present transactions only.',
        name: 'optInOut'
      },
      {
        id: 'optInOut2',
        value: 'I would like opt-in to Overseas transactions only.',
        name: 'optInOut'
      },
      {
        id: 'optInOut3',
        value: 'I would like opt-in to both Card-Not-Present and Overseas transactions only.',
        name: 'optInOut'
      },
      {
        id: 'optInOut4',
        value: 'I would like to remain opted-out for both Card-Not-Present and Overseas transactions.',
        name: 'optInOut'
      }
    ]
  }
};
