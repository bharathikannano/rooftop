import { computed } from '@ember/object';
import Controller from '@ember/controller';

export default Controller.extend({
  cancelPopup: false,
  systemErrorPopup: false,
  loaderInProgress: false,
  bpClass: computed('media.{isMobile,isTablet,isDesktop}', {
    get() {
      let bp = 'is-mobile';
      if (this.get('media.isDesktop')) {
        bp = 'is-desktop';
      } else if (this.get('media.isTablet')) {
        bp = 'is-tablet';
      } else if (this.get('media.isMobile')) {
        bp = 'is-mobile';
      }
      return bp;
    }
  })
});
