import Controller from '@ember/controller';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import config from 'rdc-ui-eng-service-requests/config/environment';

export default Controller.extend({
  i18n: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  _error_pop_up(message) {
    this.get('rdcModalManager').showDialogModal({
      level: 'error',
      message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.' + message),
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },
  _parseCountryCode(srcURL) {
    let code = '';
    if (srcURL) {
      srcURL = srcURL.split('?')[1];
      if (srcURL) {
        srcURL = srcURL.split('&');
        for (let i = 0; i < srcURL.length; i++) {
          if (srcURL[i].indexOf('ctry') !== -1) {
            code = srcURL[i].split('=')[1];
          }
        }
      }
    }
    return code;
  },
  _trackEvent(a, l, v) {
    if (window.dataLayer) {
      let code = this._parseCountryCode(window.location.href);
      let dataObject = {
        event: 'trackEvent',
        'eventDetails.category': 'card management - card settings',
        'eventDetails.action': a || 'click',
        'eventDetails.label': '/' + code + '/service-request/card-setting/' + l
      };
      if (typeof v !== 'undefined') {
        dataObject['eventDetails.value'] = v;
      }
      window.dataLayer.push(dataObject);
    }
  },
  actions: {
    redirectToCardSettings: function(routeInfo, selectedCardId, mcOrVisa, cardStatus, activationStatus, schema) {
      let countryCode = this.get('queries.countryName');
      let cardStatusesForActivation = [];
      if (
        config.Filters.creditCardControl[countryCode] &&
        config.Filters.creditCardControl[countryCode].cardStatusForActivation
      ) {
        cardStatusesForActivation = config.Filters.creditCardControl[countryCode].cardStatusForActivation;
      }
      let SCHEMAS = ['VISA', 'MASTERCARD'],
        intSchema = 0;
      if (schema) {
        intSchema = SCHEMAS.indexOf(schema.toUpperCase()) + 1;
      }
      this.get('_trackEvent').call(this, 'card-item', 'select', intSchema);
      if (
        cardStatusesForActivation.includes(cardStatus) ||
        (!isEmpty(activationStatus) && activationStatus !== 'Active')
      ) {
        this._error_pop_up('INACTIVE');
        return;
      }
      if (!mcOrVisa) {
        this._error_pop_up('MCORVISA');
        return;
      }
      if (typeof routeInfo != 'undefined' && routeInfo.length > 0) {
        this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
        this.get('rdcLoadingIndicator').setThemeClass('ui10');
        this.transitionToRoute(routeInfo, selectedCardId);
      }
    }
  }
});
