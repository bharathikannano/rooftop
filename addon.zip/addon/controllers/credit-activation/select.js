import Controller from '@ember/controller';

export default Controller.extend({
  actions: {
    redirectToPinSet: function(routeInfo, selectedCardId) {
      if (typeof routeInfo != 'undefined' && routeInfo.length > 0) {
        this.transitionToRoute(routeInfo, selectedCardId);
      }
    }
  }
});
