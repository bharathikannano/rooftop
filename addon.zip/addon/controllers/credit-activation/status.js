import Controller from '@ember/controller';
import { inject as service } from '@ember/service';
export default Controller.extend({
  cardNoMaskConfig: '',
  cardMasking: true,
  queries: service('customer-info'),
  init() {
    this._super();
    this.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
  }
});
