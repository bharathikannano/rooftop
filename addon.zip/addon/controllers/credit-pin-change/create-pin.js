import { isBlank, isNone, isEqual } from '@ember/utils';
import { inject as service } from '@ember/service';
import Controller, { inject as controller } from '@ember/controller';
import CreditCardUtils from 'rdc-ui-eng-service-requests/mixins/credit-card-utils';

export default Controller.extend(CreditCardUtils, {
  i18n: service(),
  store: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  idle: service('idle-ticker'),
  pinSetupForm: service('pin-setup-form'),
  rdcLoadingIndicator: service(),
  pinSetupController: controller('credit-pin-change'),
  statusController: controller('credit-pin-change.status'),
  isButtonDisabled: true,
  pinLength: 6,
  init() {
    this._super();
    this.set('formData', {});
    if (this.get('media.isDesktop')) {
      this.set(
        'newPinChangeLabel',
        this.get('i18n')
          .t('ServiceRequest.CREDITCARD.pinSetup.pinChange.newPin')
          .toString()
      );
      this.set(
        'reEnterPinChangeLabel',
        this.get('i18n')
          .t('ServiceRequest.CREDITCARD.pinSetup.pinChange.reEnterPin')
          .toString()
      );
    } else {
      this.set(
        'newPinChangeLabelMob',
        this.get('i18n')
          .t('ServiceRequest.CREDITCARD.pinSetup.pinChange.newPinMob')
          .toString()
      );
      this.set(
        'reEnterPinChangeLabelMob',
        this.get('i18n')
          .t('ServiceRequest.CREDITCARD.pinSetup.pinChange.reEnterPinMob')
          .toString()
      );
    }
  },
  actions: {
    onFocusOut() {
      document.body.scrollTop = 0;
    },
    onKeyPress() {
      let evt;
      evt = evt ? evt : window.event;
      let charCode = evt.which ? evt.which : evt.keyCode;
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        evt.preventDefault();
      }
    },
    onEnterPIN() {
      let inputValue = event.target.value;
      this.set('formData.enterPin', inputValue);

      let countryCode = this.get('queries.countryName');

      if (!isNone(countryCode) && !isBlank(countryCode)) {
        countryCode = countryCode.toUpperCase();
      }

      let validPinInput = this.get('formData.enterPin')
        ? this.get('formData.enterPin').length == this.get('pinLength')
        : false;

      this.setProperties({
        errorMessage: '',
        isInvalidPin: false,
        isInvalidLength: false
      });

      if (validPinInput) {
        if (this.isSequenceOrContinuousSameNumber(inputValue)) {
          this.setProperties({
            errorMessage: '',
            isInvalidPin: true,
            isButtonDisabled: true
          });
        } else if (!isBlank(this.get('formData.reEnterPin'))) {
          if (!isEqual(this.get('formData.reEnterPin'), this.get('formData.enterPin'))) {
            this.setProperties({
              errorMessage: this.get('i18n').t('ServiceRequest.CREDITCARD.validation.pinNotSame.' + countryCode),
              isButtonDisabled: true
            });
          } else {
            this.setProperties({
              errorMessage: '',
              isButtonDisabled: false
            });
          }
        }
      } else {
        this.setProperties({
          errorMessage: '',
          isInvalidLength: true,
          isButtonDisabled: true
        });
      }
    },
    onReEnterPIN() {
      let inputValue = event.target.value;
      this.set('formData.reEnterPin', inputValue);

      let countryCode = this.get('queries.countryName');

      if (!isNone(countryCode) && !isBlank(countryCode)) {
        countryCode = countryCode.toUpperCase();
      }
      this.setProperties({
        isButtonDisabled: true,
        errorMessage: ''
      });

      let validPinInput = this.get('formData.reEnterPin')
        ? this.get('formData.reEnterPin').length == this.get('pinLength')
        : false;
      if (isEqual(this.get('formData.reEnterPin'), this.get('formData.enterPin'))) {
        this.setProperties({
          isButtonDisabled: false,
          errorMessage: ''
        });
        if (this.get('isInvalidPin')) {
          this.setProperties({
            errorMessage: '',
            isButtonDisabled: true
          });
        }
        if (this.get('isInvalidLength')) {
          this.setProperties({
            errorMessage: this.get('i18n').t('ServiceRequest.CREDITCARD.validation.enterValidPin.' + countryCode),
            isButtonDisabled: true
          });
        }
      } else if (validPinInput) {
        this.setProperties({
          errorMessage: this.get('i18n').t('ServiceRequest.CREDITCARD.validation.pinNotSame.' + countryCode),
          isButtonDisabled: true
        });
      }
    },
    goToBack() {
      this.get('store').unloadAll('credit-card');
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.transitionToRoute('credit-pin-change.select');
    },
    goToNextPage() {
      let countryCode = this.get('queries.countryName');

      if (!isNone(countryCode) && !isBlank(countryCode)) {
        countryCode = countryCode.toUpperCase();
      }

      //this.get('rdcLoadingIndicator').showLoadingIndicator();
      let formData = this.get('formData');
      let selectedCardObject = this.get('selectedCardObject');
      let postFormData = this.get('pinSetupForm').getFormData(selectedCardObject, formData);
      postFormData.creditCardPostData['pinChange'] = postFormData.pinChangePostData;
      postFormData.creditCardPostData['serviceHeader'] = this.get('i18n').t(
        'ServiceRequest.CREDITCARD.pinSetup.journeyHeader'
      );
      let creditCardPostData = this.get('store').createRecord('credit-card', postFormData.creditCardPostData);
      this.get('idle').resetTimer();
      let statusController = this.get('statusController');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      this.get('rdcLoadingIndicator').showLoadingIndicator(
        this.get('i18n').t('ServiceRequest.COMMON.loadingIndicatorText'),
        'rdc-loading-indicator'
      );
      creditCardPostData.save().then(
        data => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          statusController.set('receiptId', data.get('receiptId'));
          statusController.set('cardMasking', true);
          if (isEqual(countryCode, 'SG')) {
            statusController.set('cardMasking', false);
          }
          if (data.get('status') == '100') {
            statusController.set('transactionSuccess', true);
            statusController.set(
              'transactionSuccessMsg',
              this.get('i18n').t('ServiceRequest.CREDITCARD.pinSetup.status.transactionSuccessMsg')
            );
            statusController.set('resStatus', 'S');
          } else {
            statusController.set('transactionSuccess', false);
            statusController.set(
              'transactionFailedMsg',
              this.get('i18n').t('ServiceRequest.CREDITCARD.pinSetup.status.transactionSuccessFailure.' + countryCode)
            );
            statusController.set('resStatus', 'F');
          }
          this.get('store').unloadAll('credit-card');
          this.transitionToRoute('credit-pin-change.status');
        },
        error => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.errorHandler(error);
        }
      );
    }
  }
});
