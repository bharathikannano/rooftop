import Controller from '@ember/controller';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';

export default Controller.extend({
  i18n: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),

  actions: {
    redirectToDebitCardSettings(routeInfo, selectedCardId, alerts) {
      if (!isEmpty(alerts)) {
        this.get('rdcModalManager').showDialogModal({
          level: 'error',
          message: this.get('i18n').t('ServiceRequest.debitCardSettings.panelTitle.duplicateMessage'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        });
      } else {
        if (!isEmpty(routeInfo) && routeInfo.length > 0) {
          this.get('rdcLoadingIndicator').setThemeClass('ui10');
          this.transitionToRoute(routeInfo, selectedCardId);
        }
      }
    }
  }
});
