import Controller from '@ember/controller';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';
import config from '../constants';
import { isEmpty } from '@ember/utils';
import { htmlSafe } from '@ember/string';
export default Controller.extend({
  i18n: service(),
  customerInfo: service(),
  noTextarea: computed('customerInfo.{cardData.type,countryName}', function() {
    let textArea = config.genericRequestForm.texArea[this.customerInfo.countryName];
    if (isEmpty(textArea)) {
      return true;
    } else {
      return textArea.indexOf(this.customerInfo.cardData.type) === -1;
    }
  }),
  noDocupload: computed('customerInfo.{cardData.type,countryName}', function() {
    let docUpload = config.genericRequestForm.docUpload[this.customerInfo.countryName];
    if (isEmpty(docUpload)) {
      return true;
    } else {
      docUpload.indexOf(this.customerInfo.cardData.type) !== -1
        ? (this.customerInfo.cardData['docUpload'] = true)
        : (this.customerInfo.cardData['docUpload'] = false);
      return docUpload.indexOf(this.customerInfo.cardData.type) === -1;
    }
  }),
  notemessages: computed('customerInfo.{cardData.type}', function() {
    let footNote = this.target.currentPath.indexOf('select') !== -1 ? 'select' : 'upload';
    let getval = this.get('i18n')
      .t('ServiceRequest.genericRequest.' + this.customerInfo.cardData.type + '.notemessage.' + footNote, {
        default: 'ServiceRequest.genericRequest.none'
      })
      .toString();
    if (getval !== 'none') {
      let res = getval.split('<br>');
      let appendtext = '';
      for (let i = 0; i < res.length; i++) {
        appendtext += `<li>${res[i]}</li>`;
      }
      appendtext = `<ul>${appendtext}</ul>`;
      return new htmlSafe(appendtext);
    } else {
      return false;
    }
  }),
  notemessageHeader: computed('customerInfo.cardData.type', function() {
    let footNote = this.target.currentPath.indexOf('select') !== -1 ? 'select' : 'upload';
    let getval = this.get('i18n')
      .t(`ServiceRequest.genericRequest.${this.customerInfo.cardData.type}.notemessage.${footNote}Header`, {
        default: 'ServiceRequest.genericRequest.none'
      })
      .toString();
    if (getval !== 'none') {
      return getval;
    } else {
      return false;
    }
  })
});
