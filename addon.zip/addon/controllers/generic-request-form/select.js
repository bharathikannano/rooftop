import Controller from '../generic-request-form';
export default Controller.extend({});
