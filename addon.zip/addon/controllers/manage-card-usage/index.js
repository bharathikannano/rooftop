import Controller from '@ember/controller';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import config from 'rdc-ui-eng-service-requests/config/environment';

export default Controller.extend({
  i18n: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  customerInfo: service(),
  queries: service('customer-info'),

  _error_pop_up(message) {
    this.get('rdcModalManager').showDialogModal({
      level: 'error',
      message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.' + message),
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },

  actions: {
    redirectToCreditCardSettings: function(
      routeInfo,
      selectedCardId,
      mcOrVisa,
      cardStatus,
      activationStatus,
      cardType,
      cardNum
    ) {
      let countryCode = this.get('queries.countryName');
      let cardInfo = selectedCardId.concat('#' + cardType + '#' + cardNum);
      let cardStatusesForActivation = [];
      if (
        config.replacementFilters.creditCard[countryCode] &&
        config.replacementFilters.creditCard[countryCode].cardStatusForActivation
      ) {
        cardStatusesForActivation = config.replacementFilters.creditCard[countryCode].cardStatusForActivation;
      }
      if (
        cardStatusesForActivation.includes(cardStatus) ||
        (!isEmpty(activationStatus) && activationStatus !== 'Active')
      ) {
        this._error_pop_up('INACTIVE');
        return;
      }
      if (!mcOrVisa) {
        this._error_pop_up('MCORVISA');
        return;
      }
      if (typeof routeInfo != 'undefined' && routeInfo.length > 0) {
        this.get('rdcLoadingIndicator').setThemeClass('ui10');
        this.transitionToRoute(routeInfo, cardInfo);
      }
    },
    redirectToDebitCardSettings: function(routeInfo, selectedCardId, blkInd, cardType, cardNum) {
      let cardInfo = selectedCardId.concat('#' + cardType + '#' + cardNum);
      if (typeof routeInfo != 'undefined' && routeInfo.length > 0) {
        this.get('rdcLoadingIndicator').setThemeClass('ui10');
        this.transitionToRoute(routeInfo, cardInfo);
      }
    }
  }
});
