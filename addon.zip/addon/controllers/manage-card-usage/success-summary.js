import Controller from '@ember/controller';

export default Controller.extend({
  actions: {
    noCardImage: function(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    }
  }
});
