import Controller from '@ember/controller';

export default Controller.extend({
  actions: {
    slickBeforeChange(slick, currentSlide, nextSlide) {
      this.set('currentSlide', nextSlide);
    }
  }
});
