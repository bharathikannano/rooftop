import Controller from '@ember/controller';

export default Controller.extend({
  isCurrentAccountSelected: false,

  actions: {
    addToCart() {
      localStorage.setItem('isCurrentAccountSelected', 'true');
      this.toggleProperty('isCurrentAccountSelected');
    }
  }
});
