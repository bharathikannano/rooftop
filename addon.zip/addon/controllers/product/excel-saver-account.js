import Controller from '@ember/controller';

export default Controller.extend({
  isExcelSaverAccountSelected: false,

  actions: {
    addToCart() {
      localStorage.setItem('isExcelSaverAccountSelected', 'true');
      this.toggleProperty('isExcelSaverAccountSelected');
    }
  }
});
