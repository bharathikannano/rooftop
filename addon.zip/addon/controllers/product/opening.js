import Controller from '@ember/controller';

export default Controller.extend({
  isCurrentAccountSelected: false,
  isExcelSaverAccountSelected: false,

  init() {
    this._super();
    localStorage.removeItem('isCurrentAccountSelected');
    localStorage.removeItem('isExcelSaverAccountSelected');
  }
});
