import Controller from '@ember/controller';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';

export default Controller.extend({
  i18n: service(),
  axwayConfig: service(),
  hasError: false,
  // To set default country code for rdc-tel-input as there is no service here to fetch from CSL side.
  defaultCountryCode: computed('axwayConfig', {
    get() {
      let countryValue = this.get('axwayConfig.country');
      let countryCode = '';
      switch (countryValue) {
        case 'CI':
          countryCode = '225';
          break;
        case 'KE':
          countryCode = '254';
          break;
        case 'GH':
          countryCode = '233';
          break;
        case 'TZ':
          countryCode = '255';
          break;
        case 'UG':
          countryCode = '256';
          break;
        case 'ZM':
          countryCode = '260';
          break;
        case 'ZW':
          countryCode = '263';
          break;
        case 'BW':
          countryCode = '267';
          break;
        case 'NG':
          countryCode = '234';
          break;
        case 'AE':
          countryCode = '971';
          break;
        default:
      }
      return countryCode;
    }
  }),
  regexp: computed({
    get() {
      if (this.get('axwayConfig.country') == 'AE') {
        return '^((971\\-5(\\d)(?!\\1{7}$)\\d{7})|(?!971)[0-9]*\\-[0-9]{3,})$';
      } else {
        return '^[1-90-9\\-]{7,16}$';
      }
    }
  }),
  phoneNumber: computed({
    get() {
      if (this.get('axwayConfig.country') == 'AE') {
        return '+971';
      }
      return null;
    }
  }),
  label: computed({
    get() {
      return this.get('i18n')
        .t('preEtb.mobileNumber')
        .toString();
    }
  }),
  regexpErrorMessage: computed({
    get() {
      if (this.get('axwayConfig.country') == 'AE') {
        return this.get('i18n')
          .t('ServiceRequest.TRACKRESUME.mobileNumberErrorAE')
          .toString();
      } else {
        return this.get('i18n')
          .t('ServiceRequest.TRACKRESUME.mobileNumberLable')
          .toString();
      }
    }
  })
});
