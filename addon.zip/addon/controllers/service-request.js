import Controller from '@ember/controller';

export default Controller.extend({
  cancelPopup: false,
  systemErrorPopup: false,
  isValid: false
});
