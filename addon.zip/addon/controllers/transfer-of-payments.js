import Controller from '@ember/controller';
import { computed } from '@ember/object';

export default Controller.extend({
  bpClass: computed('media.{isMobile,isTablet,isDesktop}', {
    get() {
      let bp = 'is-mobile';
      if (this.get('media.isDesktop')) {
        bp = 'is-desktop';
      } else if (this.get('media.isTablet')) {
        bp = 'is-tablet';
      } else if (this.get('media.isMobile')) {
        bp = 'is-mobile';
      }
      return bp;
    }
  })
});
