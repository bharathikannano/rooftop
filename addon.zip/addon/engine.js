/* eslint-disable ember/avoid-leaking-state-in-ember-objects */
import Engine from 'ember-engines/engine';
import Resolver from 'ember-resolver';
import loadInitializers from 'ember-load-initializers';
import config from './config/environment';

const { modulePrefix } = config;

const Eng = Engine.extend({
  modulePrefix,
  Resolver,
  dependencies: {
    services: [
      'store',
      'session',
      '-document',
      'iframeManager',
      'rdcModalManager',
      'rdcLoadingIndicator',
      'otpManager',
      'i18n',
      'fap',
      'rdcAjax',
      'axwayConfig',
      'idleSessionTimer',
      'router',
      'adobeDataService',
      'adobeService'
    ]
  }
});

loadInitializers(Eng, modulePrefix);

export default Eng;
