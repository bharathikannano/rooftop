import { helper } from '@ember/component/helper';

export function cardnumberMasking(params) {
  let maskLength = Math.abs(params[2].showFirst + params[2].showLast - params[0].length);
  let mask = new Array(maskLength + 1).join('•');
  let cardNum = params[0].split('');

  if (params[1]) {
    cardNum.splice(params[2].showFirst, maskLength, mask);
    cardNum = cardNum.join('');
    let maskedNum = cardNum.split('');
    return addSpace(maskedNum, params[2].spacingIndex);
  } else {
    return addSpace(cardNum, params[2].spacingIndex);
  }
}

function addSpace(cardNumber, spacingIndex) {
  spacingIndex.forEach((item, i) => {
    cardNumber.splice(item + i, 0, ' ');
  });
  let number = cardNumber.join('');
  return number;
}

export default helper(cardnumberMasking);
