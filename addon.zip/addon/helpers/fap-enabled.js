export { default } from 'rdc-ui-adn-core/helpers/fap-enabled';
