import { helper } from '@ember/component/helper';

export function formatCurrency(params) {
  let amount = params[0];
  let formatedAmt;
  if (params[1] && params[1] == 'TOP') {
    formatedAmt = Number(amount)
      .toFixed(2)
      .replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  } else {
    formatedAmt = Number.isNaN(Number(amount)) ? 0 : Number(amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  return formatedAmt;
}

export default helper(formatCurrency);
