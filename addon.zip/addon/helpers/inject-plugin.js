import { helper } from '@ember/component/helper';

export function injectPlugin(params) {
  let scriptAttrs = JSON.parse(params);
  let scriptTagElement = document.createElement(`script`);
  Object.keys(scriptAttrs).forEach(attrs => {
    scriptTagElement.setAttribute(attrs, scriptAttrs[attrs]);
  });
  return document.head.appendChild(scriptTagElement);
}

export default helper(injectPlugin);
