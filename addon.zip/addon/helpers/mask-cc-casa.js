import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';
import Helper from '@ember/component/helper';

export default Helper.extend({
  queries: service('customer-info'),

  compute(params) {
    let type = params[0];
    let input = params[1];
    if (this.get('queries.countryName') != 'HK') {
      if (type == 'cc' || type == 'cbr') {
        let firstFourDigit = input.slice(0, 4);
        let secondTwoDigit = input.slice(4, 6);
        let lastFourDigit = input.slice(-4);
        let maskedChar =
          '<span>' +
          '&#8226;' +
          '<span>' +
          '<span>' +
          '&#8226;' +
          '<span>' +
          ' ' +
          '<span>' +
          '&#8226;' +
          '<span>' +
          '<span>' +
          '&#8226;' +
          '<span>' +
          '<span>' +
          '&#8226;' +
          '<span>' +
          '<span>' +
          '&#8226;' +
          '<span>' +
          ' ';
        let maskedValue = firstFourDigit + ' ' + secondTwoDigit + maskedChar + lastFourDigit;
        if ((type = 'cc' || type == 'cbr') && this.get('queries.countryName') == 'SG') {
          if (params[2]) {
            let cardNum = params[1].split('');
            let spacingIndex = params[2].spacingIndex;
            spacingIndex.forEach((item, i) => {
              cardNum.splice(item + i, 0, ' ');
            });
            let number = cardNum.join('');
            return number;
          } else {
            return input;
          }
        }
        return htmlSafe(maskedValue);
      } else if (type == 'casa') {
        let startingDigits = input.slice(0, input - 5);
        return startingDigits + '....';
      } else if (type === 'fd') {
        let lastFourDigits = input.slice(-4);
        let beforeLastFourDigits = input.slice(0, input.length - 4);
        beforeLastFourDigits = beforeLastFourDigits
          .split('')
          .map(() => '.')
          .join('');
        return beforeLastFourDigits + lastFourDigits;
      }
      return params;
    } else {
      return input;
    }
  }
});
