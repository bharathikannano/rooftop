import { helper } from '@ember/component/helper';
import { htmlSafe } from '@ember/string';

export function noteMessage(params /*, hash*/) {
  let appendtext = '';
  if (params) {
    let res = params.toString().split('<br>');
    res.forEach(element => {
      appendtext += `<li>${element}</li>`;
    });
    appendtext = `<ul>${appendtext}</ul>`;
  }
  return new htmlSafe(appendtext);
}

export default helper(noteMessage);
