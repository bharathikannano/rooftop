import { helper } from '@ember/component/helper';
import { isBlank, isNone, isEqual } from '@ember/utils';
export function parseData(params /*, hash*/) {
  let value = params[0];
  let attrs = params[1];
  if (!(isBlank(value) || isNone(value)) && !(isBlank(attrs) || isNone(attrs))) {
    value = value.toString();
    if (isEqual(attrs, 'desc')) {
      return value.split('-')[0];
    }
  }
  return value;
}

export default helper(parseData);
