import { helper } from '@ember/component/helper';

export function roundToFixed(params /*, hash*/) {
  return parseFloat(params[0]).toFixed(2);
}

export default helper(roundToFixed);
