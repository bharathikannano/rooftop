export { default } from 'ember-i18n/helper';
