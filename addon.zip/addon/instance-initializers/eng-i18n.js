import { A } from '@ember/array';
const matchKey = 'rdc-ui-eng-service-requests/locales/(.+)/translations$';

function getLocales() {
  return Object.keys(requirejs.entries)
    .reduce((locales, module) => {
      let match = module.match(matchKey);
      if (match) {
        locales.pushObject(match[1]);
      }
      return locales;
    }, A())
    .sort();
}

export function initialize(appInstance) {
  let locales = getLocales();
  locales.forEach(locale => {
    appInstance.dependencies.services.i18n.addTranslations(
      locale,
      require('rdc-ui-eng-service-requests/locales/' + locale + '/translations')['default']
    );
  });

  // appInstance.inject('route', 'foo', 'service:foo');
}

export default {
  name: 'eng-i18n',
  initialize
};
