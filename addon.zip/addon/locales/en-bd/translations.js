/* eslint-disable no-useless-escape */

export default {
  ServiceRequest: {
    COMMON: {
      genericError: {
        BD:
          "We've encountered an error with your request. Please cancel the request and try again. If the issue persists, please call our 24-hour Client Care Centre at +88 02 55669900 for immediate assistance."
      },
      systemError:
        "We've encountered an error with your request. Please cancel the request and try again. If the issue persists, please call our 24-hour Client Care Centre at +88 02 55669900 for immediate assistance."
    },
    CREDITCARD: {
      pinSetup: {
        status: {
          transactionSuccessFailure: {
            BD:
              "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +88 02 55669900 for immediate assistance."
          },
          transactionSuccessInComplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +88 02 55669900"
        }
      },
      activation: {
        status: {
          transactionSuccessFailure: {
            BD:
              "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +88 02 55669900 for immediate assistance."
          },
          transactionSuccessInComplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +88 02 55669900"
        }
      }
    },
    CARDBLOCK: {
      countryNotes: {
        BD:
          'Upon confirmation, your card(s) will be blocked immediately and you will not be able to use it. Please note that a blocked card cannot be reactivated.<br>You will not be liable for any transactions on the card(s) after this report. Any existing card balances will be transferred to the new replacement card(s).<br>We will send the replacement card(s) to your mailing address in our records. Please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any GIRO arrangement to your new credit card if applicable. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.'
      },
      statusMsg: {
        BD: {
          failure:
            "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +88 02 55669900 for immediate assistance.",
          incomplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +88 02 55669900"
        }
      }
    },
    CARDREPLACEMENT: {
      countryNotes: {
        BD:
          'This request is for replacement of<ul><li>Damaged cards or</li><li>Cards that have already been reported lost/stolen</li></ul>Credit/Debit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/ stolen card, please use the Report Lost/Stolen Card Service Request.<br>We will send the replacement card(s) to your mailing address in our records. If you have previously reported a lost or stolen card, please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any GIRO arrangement arrangement to your new credit card if applicable. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.'
      },
      statusMsg: {
        BD: {
          failure:
            "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +88 02 55669900 for immediate assistance.",
          incomplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +88 02 55669900"
        }
      }
    },
    CREDITBALANCEREFUND: {
      'phoneBankingHotline.text': {
        BD: '24/7 Phone Banking'
      },
      'notes.fromCard': {
        BD:
          '*To view and refund the exact amount including cents, please refer to your card balance in the main page.</br>*Excess Credit displayed is the excess credit card payment made by you, including the recent unbilled/unstatemented transactions.'
      }
    },
    genericRequest: {
      AMCASABD: {
        title: 'Amendment / Cancellation of SI for Credit Card Payment/Locker/other standing order',
        notemessage: {
          selectHeader:
            'This request allows you to amend or cancel your existing SI (Standing Instruction) against your accounts. Please refer to the notes below and provide the necessary information for your request.',
          select:
            '<div><b>For amendment:</b></div><ul><li>Select the account number above for which the current SI is set up.</li><li> In the next screen, provide the account number from which the new auto debit SI will take place.</li><li>Mention the credit card number for which the current SI is set up.</li><li>Provide the new SI percentage of total outstanding balance or mention minimum amount due.</li></ul><br><div><b>For Cancellation:</b></div><ul><li>Select the account number above for which the current SI is set up.</li><li>In the next screen, provide the credit card number for which the current SI is set up.</li></ul>',
          uploadHeader: 'Please refer to the notes below and provide the necessary information for your request.',
          upload:
            '<div><b>For amendment:</b></div><ul><li>Select the account number above for which the current SI is set up.</li><li>In the next screen, provide the account number from which the new auto debit SI will take place.</li><li> Mention the credit card number for which the current SI is set up.</li><li> Provide the new SI percentage of total outstanding balance or mention minimum amount due.</li></ul><br><div><b>For Cancellation:</b></div><ul><li>Select the account number above for which the current SI is set up.</li><li>In the next screen, provide the credit card number for which the current SI is set up.</li></ul>'
        }
      },
      BALCNABD: {
        title: 'Balance confirmation for Account',
        notemessage: {
          selectHeader:
            'This request allows you to request for balance confirmation of your account. Please refer to the notes below.',
          select:
            'Select the account number above for which you need the balance confirmation certificate.<br>Balance confirmation certificate will be delivered to your Mailing Address only.<br>You will get the balance confirmation of your account till 1 (one) day prior to your request date.<br>You authorize the Bank to debit/charge service fee for the issuance of the balance confirmation certificate (if applicable).',
          uploadHeader: 'Please refer to the notes below and provide the necessary information for your request.',
          upload:
            'Select the account number above for which you need the balance confirmation certificate.<br>Balance confirmation certificate will be delivered to your Mailing Address only.<br>You will get the balance confirmation of your account till 1 (one) day prior to your request date.<br>You authorize the Bank to debit/charge service fee for the issuance of the balance confirmation certificate (if applicable).'
        }
      },
      ENRSMSBD: {
        title: 'Enrolment for SMS Banking',
        notemessage: {
          selectHeader:
            'This request allows you to enroll for SMS Banking. Please refer to the notes below and provide the necessary information for your request.',
          select:
            'Select the account number above for which the SMS Banking enrolment needs to be done.<br>In the next screen provide your mobile number with proper country code. Please note, the mobile number you are providing should be updated with your account as prior requirement.',
          uploadHeader: 'Please refer to the notes below and provide the necessary information for your request.',
          upload:
            ' Select the account number above for which the SMS Banking enrolment needs to be done.<br>In the next screen provide your mobile number with proper country code. Please note, the mobile number you are providing should be updated with your account as prior requirement.'
        }
      },
      LOANOTBD: {
        title: 'Loan Outstanding & Loan tax Confirmation Certificate',
        notemessage: {
          selectHeader:
            'This request allows you to request for Loan Outstanding or Loan Tax Confirmation Certificate. Please refer to the notes below and provide the necessary information for your request.',
          select:
            'Select the loan account number above for which you need the Loan Outstanding or Loan Tax Confirmation Certificate.<br>Loan Outstanding or Loan Tax Confirmation Certificate will be delivered to your Mailing Address only.<br>For Loan Tax Confirmation Certificate mention the Tax year for which you need the certificate.<br>You authorize the Bank to debit/charge service fee for the issuance of the Loan Outstanding or Loan Tax Confirmation Certificate (if applicable).',
          uploadHeader:
            'This request allows you to request for Loan Outstanding or Loan Tax Confirmation Certificate. Please refer to the notes below and provide the necessary information for your request.',
          upload:
            'Select the loan account number above for which you need the Loan Outstanding or Loan Tax Confirmation Certificate.<br>Loan Outstanding or Loan Tax Confirmation Certificate will be delivered to your Mailing Address only.<br>For Loan Tax Confirmation Certificate mention the Tax year for which you need the certificate.<br>You authorize the Bank to debit/charge service fee for the issuance of the Loan Outstanding or Loan Tax Confirmation Certificate (if applicable).'
        }
      },
      LONCLTBD: {
        title: 'Loan Closure Letter',
        notemessage: {
          selectHeader: 'This request allows you to request for Loan Closure letter. Please refer to the Notes below.',
          select:
            'Select the loan account number above for which you need the Loan Closure letter.<br>Loan Closure letter will be delivered to your Mailing Address only.<br>You authorize the Bank to debit/charge service fee for the issuance of the Loan Closure Letter (if applicable).',
          uploadHeader: 'This request allows you to request for Loan Closure letter. Please refer to the Notes below.',
          upload:
            'Select the loan account number above for which you need the Loan Closure letter.<br>Loan Closure letter will be delivered to your Mailing Address only.<br>You authorize the Bank to debit/charge service fee for the issuance of the Loan Closure Letter (if applicable).'
        }
      },
      CCSDTCBD: {
        title: 'Credit Card Statement Cycle Date Change',
        notemessage: {
          selectHeader:
            'This request allows you to change your Credit Card billing date. Please refer to the Notes and provide the necessary information for your request.',
          select:
            'Select the Credit Card number above for which you want to change the billing date.<br> In the next screen provide the new billing date.<br>Gold/Silver Cardholders can select any date except 01-02, 23-24, 28-31st of the month.<br>Platinum/Signature Cardholders can select any date except 23-24 and 28-31st of the month.<br>SCB Staff Cardholder can select only 23rd of the month.<br>Cardholders with USD payment, can select only 24th of the month.',
          uploadHeader:
            'This request allows you to change your Credit Card billing date. Please refer to the Notes and provide the necessary information for your request.',
          upload:
            'Select the Credit Card number above for which you want to change the billing date.<br> In the next screen provide the new billing date.<br>Gold/Silver Cardholders can select any date except 01-02, 23-24, 28-31st of the month.<br>Platinum/Signature Cardholders can select any date except 23-24 and 28-31st of the month.<br>SCB Staff Cardholder can select only 23rd of the month.<br>Cardholders with USD payment, can select only 24th of the month.'
        }
      },
      AMCASCBD: {
        title: 'Amendment/Set up/Cancellation of standing instruction for Auto Bills Pay',
        notemessage: {
          selectHeader:
            'This request allows you to amend, set up or cancel your Standing Instruction (SI) for Auto Bills Pay. Please refer to the Notes below and provide the necessary information for your request.',
          select:
            'Select the Credit Card number above for which you want to amend/set up/cancel of Standing Instruction (SI) for Auto Bills Pay.<br>If the Auto Bills Pay type is ISP, in the next screen provide the ISP Company name, ISP Package name, ISP Login ID Name & ISP Beneficiary Name/Account No and mention whether the request is amendment, set up or cancellation.<br>If Auto Bills Pay type is Utility, provide the Utility Company name, Utility Consumer ID, any previous bill no with check digit (non-mandatory field) and Utility Beneficiary/Subscriber Name and mention whether the request is amendment, set up or cancellation.<br>If Auto Bills Pay type is Academic Institution, provide the Academic Institution name, Student name, Student ID, Student’s Parents name and mention whether the request is amendment, set up or cancellation.<br>If Auto Bills Pay type is Mobile Operator, provide the Billing date, Mobile company name, Mobile phone no, Beneficiary name, Billing Type: Prepaid or Postpaid and mention whether the request is amendment, set up or cancellation.',
          uploadHeader:
            'This request allows you to amend, set up or cancel your Standing Instruction (SI) for Auto Bills Pay. Please refer to the Notes below and provide the necessary information for your request.',
          upload:
            'Select the Credit Card number above for which you want to amend/set up/cancel of Standing Instruction (SI) for Auto Bills Pay.<br>If the Auto Bills Pay type is ISP, in the next screen provide the ISP Company name, ISP Package name, ISP Login ID Name & ISP Beneficiary Name/Account No and mention whether the request is amendment, set up or cancellation.<br>If Auto Bills Pay type is Utility, provide the Utility Company name, Utility Consumer ID, any previous bill no with check digit (non-mandatory field) and Utility Beneficiary/Subscriber Name and mention whether the request is amendment, set up or cancellation.<br>If Auto Bills Pay type is Academic Institution, provide the Academic Institution name, Student name, Student ID, Student’s Parents name and mention whether the request is amendment, set up or cancellation.<br>If Auto Bills Pay type is Mobile Operator, provide the Billing date, Mobile company name, Mobile phone no, Beneficiary name, Billing Type: Prepaid or Postpaid and mention whether the request is amendment, set up or cancellation.'
        }
      },
      LINKMABD: {
        title: 'Card Linking',
        notemessage: {
          selectHeader:
            'This request allows you to link your Credit Card with your existing iBanking profile. Please refer to the notes below and provide the necessary information for your request.',
          select:
            'Select the account number above for which you want to link the Credit Card.<br>In the next screen, provide the Credit Card number that you want to link.<br> If an active card is already linked, this link request will replace the existing linked card with the requested card.<br>If a closed card is already linked the Bank will delink the closed card and relink the requested card.',
          uploadHeader:
            'This request allows you to link your Credit Card with your existing iBanking profile. Please refer to the notes below and provide the necessary information for your request.',
          upload:
            'Select the account number above for which you want to link the Credit Card.<br>In the next screen, provide the Credit Card number that you want to link.<br> If an active card is already linked, this link request will replace the existing linked card with the requested card.<br>If a closed card is already linked the Bank will delink the closed card and relink the requested card.'
        }
      },
      STATSCBD: {
        title: 'Duplicate Statements for Credit Card',
        notemessage: {
          selectHeader:
            'This request allows you get the statement of your Credit Card. Please refer to the Notes below and provide the necessary information for your request.',
          select:
            "Write down the month name for which you want the statement<br>Write down your delivery option: Mailing Address or Email<br>You authorize the Bank to debit/charge service fee for the issuance of the statement<br>Card does not have any Return Mail Risk 'RS'",
          upload:
            "Write down the month name for which you want the statement<br>Write down your delivery option: Mailing Address or Email<br>You authorize the Bank to debit/charge service fee for the issuance of the statement<br>Card does not have any Return Mail Risk 'RS'"
        }
      },
      CLOCRDBD: {
        title: 'Credit Card Closure letter',
        notemessage: {
          selectHeader:
            'This request allows you to get the closure letter of your closed Credit Card. Please refer to the notes below.',
          select:
            "Select the credit card number from above for which you need the closure letter.<br>Selected card's status must be closed.<br>Credit card closure letter will be delivered to your Mailing Address only.",
          uploadHeader:
            'This request allows you to get the closure letter of your closed Credit Card. Please refer to the notes below.',
          upload:
            "Select the credit card number from above for which you need the closure letter.<br>Selected card's status must be closed.<br>Credit card closure letter will be delivered to your Mailing Address only."
        }
      }
    }
  },
  FERE: {
    page: {
      fileUploadInfoText: 'File format should be in JPG, PNG, PDF, ZIP or EML. The file size must not exceed 5MB.'
    }
  }
};
