/* eslint-disable no-useless-escape */

export default {
  ServiceRequest: {
    COMMON: {
      genericError: {
        BN:
          "We've encountered an error with your request. Please cancel the request and try again. If the issue persists, please call our 24-hour Client Care Centre at +673 2658000 for immediate assistance.",
        BNRISK: 'We are unable to proceed with your request, please call 2658000 for further assistance.'
      },
      systemError:
        "We've encountered an error with your request. Please cancel the request and try again. If the issue persists, please call our 24-hour Client Care Centre at +673 2658000 for immediate assistance."
    },
    CREDITCARD: {
      pinSetup: {
        countryNotes: {
          BN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 5-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 5-digit PIN, you will be required to enter the one-time password (OTP) sent to your registered mobile number.</li><li>DO NOT reveal your 5-digit PIN to anyone. The 5-digit PIN must be memorised and not be recorded anywhere.</li><li>DO NOT use easily recognised numbers such birthday, anniversary, national ID, telephone number etc. as your 5-digit PIN.</li><li>Avoid using sequential numbers (such as 12345) or same number more than twice (such as 22222) for your 5-digit PIN.</li><li>5-digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 5-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Call us at 265 8000 in case of any unauthorised transactions observed in your account.</li></ol></li></ol>"
        },
        status: {
          transactionSuccessFailure: {
            BN:
              "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +673 2658000 for immediate assistance."
          },
          transactionSuccessInComplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +673 2658000"
        }
      },
      activation: {
        countryNotes: {
          BN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 5-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 5-digit PIN, you will be required to enter the one-time password (OTP) sent to your registered mobile number.</li><li>DO NOT reveal your 5-digit PIN to anyone. The 5-digit PIN must be memorised and not be recorded anywhere.</li><li>DO NOT use easily recognised numbers such birthday, anniversary, national ID, telephone number etc. as your 5-digit PIN.</li><li>Avoid using sequential numbers (such as 12345) or same number more than twice (such as 22222) for your 5-digit PIN.</li><li>5-digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 5-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Call us at 265 8000 in case of any unauthorised transactions observed in your account.</li></ol></li></ol>"
        },
        status: {
          transactionSuccessFailure: {
            BN:
              "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +673 2658000 for immediate assistance."
          },
          transactionSuccessInComplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +673 2658000"
        }
      }
    },
    CARDBLOCK: {
      countryNotes: {
        BN:
          "Upon confirmation of this request, your card(s) will be blocked immediately and you will not be able to use it. This includes any supplementary cards. Please note a blocked card cannot be reactivated.<br><b>Card replacements are subjected to prevailing fees and charges as stipulated in the Bank'™s Tariff Booklet</b>. The Tariff Booklet is available on sc.com/bn.<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. Please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing, subscriptions and payment arrangements after receiving your replacement card.<br>For credit card replacements, your existing balances will be transferred to your replacement card.<br>Blocking of your card does not cancel the account. You will be liable for any transactions made using the card prior to the blocking."
      },
      statusMsg: {
        BN: {
          failure:
            "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +673 2658000 for immediate assistance.",
          incomplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +673 2658000"
        }
      }
    },
    CARDREPLACEMENT: {
      countryNotes: {
        BN:
          "This request is for replacement of<ul><li>Damaged cards or</li><li>Cards that have already been reported lost / stolen.</li></ul>Credit/Debit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/stolen card, please use the Report Lost / Stolen Card Service Request.<br><b>Card replacements are subjected to prevailing fees and charges as stipulated in the Bank'™s Tariff Booklet.</b>The Tariff Booklet is available on sc.com/bn.<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. Please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing, subscriptions and payment arrangements after receiving your replacement card.<br>For credit card replacements, your existing balances will be transferred to your replacement card."
      },
      statusMsg: {
        BN: {
          failure:
            "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +673 2658000 for immediate assistance.",
          incomplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +673 2658000"
        }
      }
    },
    CREDITBALANCEREFUND: {
      'phoneBankingHotline.text': {
        BN: '24/7 Phone Banking'
      },
      'notes.fromCard': {
        BN:
          '*The Credit Balance displayed above is excess credit card payment made by you. The excess Credit Balance has been rounded to the nearest BND.'
      }
    },
    CCFEEWAVIER: {
      countryLinksTxt: {
        BN: '24/7 Phone Banking hotline'
      },
      validationCountryNotes: {
        BN: 'Kindly contact our {{inter_link}} for further assistance.'
      },
      countryNotesTransactionPage: {
        BN: 'Displayed transactions are charges posted on the selected cards only.'
      },
      countryNotes: {
        BN:
          'For other fee waiver requests related to your credit card, please call our 24-Hour Client Care Center at +673 2658000. <br>Only credit card(s) that may be eligible will be shown. If you do not see your credit card, please call our 24-Hour Client Care Center at +673 2658000'
      }
    },
    genericRequest: {
      CLOFCASA: {
        title: 'Closure of Current or Savings Account',
        notemessage: {
          selectHeader:
            'This request is for closure of any active current or savings accounts you currently hold with the Bank.',
          select:
            "You must ensure that there are no remaining balances within the account(s) you request for closure.<br>The closure of account will be subjected to the Bank's approval.<br>We will not process your request for account closure if there are any lending facilities, standing instructions, safe deposit locker or wealth products linked to the account.",
          uploadHeader:
            'This request is for closure of any active current or savings accounts you currently hold with the Bank.',
          upload:
            "You must ensure that there are no remaining balances within the account(s) you request for closure.<br>The closure of account will be subjected to the Bank's approval.<br>We will not process your request for account closure if there are any lending facilities, standing instructions, safe deposit locker or wealth products linked to the account."
        }
      },
      REQCLLET: {
        title: 'Request for Clearance Letter',
        notemessage: {
          selectHeader:
            'This request is for the issuance of Clearance Letter from the Bank,to proceed with this request, please provide complete information of the following in the text box:',
          select:
            "The Standard Chartered Branch location you prefer to retrieve your clearance letter.<br>The name of addressee with the registered address.<br>For additional clearance letter, name of addressee with registered address and other relevant instructions such as number of printed copy required, etc.:<br>Retrieval of Clearance Letters are subjected to applicable fees and charges as stipulated in the Bank's Tariff Booklet, which is available on <a href=\"javascript:;\" onclick=\"window.open('https://www.sc.com/bn','_system')\">sc.com/bn</a>.<br>Your Request for Clearance Letter cannot be processed if you have existing lending facilities with the Bank.",
          uploadHeader:
            'This request is for the issuance of Clearance Letter from the Bank,to proceed with this request, please provide complete information of the following in the text box:',
          upload:
            "The Standard Chartered Branch location you prefer to retrieve your clearance letter.<br>The name of addressee with the registered address.<br>For additional clearance letter, name of addressee with registered address and other relevant instructions such as number of printed copy required, etc.:<br> Retrieval of Clearance Letters are subjected to applicable fees and charges as stipulated in the Bank's Tariff Booklet, which is available on <a href=\"javascript:;\" onclick=\"window.open('https://www.sc.com/bn','_system')\">sc.com/bn</a>.<br>Your Request for Clearance Letter cannot be processed if you have existing lending facilities with the Bank."
        }
      },
      CANCELSO: {
        title: 'Cancellation of Standing Order',
        notemessage: {
          selectHeader:
            'This request is for cancellation of existing Standing Orders. Details of your Standing Order can be accessed in the menu screen in Online Banking or SC Mobile App through "SC Standing Orders" Option. To proceed with this request, provide complete information of the following in the text box.',
          select: 'Clearly indicate start date of the Standing Order<br>Standing Order Amount',
          uploadHeader:
            'This request is for cancellation of existing Standing Orders. Details of your Standing Order can be accessed in the menu screen in Online Banking or SC Mobile App through "SC Standing Orders" Option. To proceed with this request, provide complete information of the following in the text box.',
          upload: 'Clearly indicate start date of the Standing Order<br>Standing Order Amount'
        }
      },
      UPDICEXP: {
        title: 'Update of IC Expiry Date',
        notemessage: {
          selectHeader: "This request is to update your Identity Card expiry date in our Bank's record.",
          select:
            'To proceed with your request, please attach a high quality photo or scanned image of the front side of your identity card. This service is applicable to Yellow IC and Red IC holders only.<ul><li>To ensure successful update of IC expiry date, you must ensure to attach  pictures of your IC with clear indications of your name, date of birth, address and new ic expiry date.</li><li>You are required to visit a nearest branch for update of IC Expiry if you have:<ul><li>been previously onboarded with a passport as your main identity document</li><li>changed your name, IC number or date of birth</li></ul></li></ul>',
          uploadHeader: "This request is to update your Identity Card expiry date in our Bank's record.",
          upload:
            'To proceed with your request, please attach a high quality photo or scanned image of the front side of your identity card. This service is applicable to Yellow IC and Red IC holders only.<ul><li>To ensure successful update of IC expiry date, you must ensure to attach  pictures of your IC with clear indications of your name, date of birth, address and new ic expiry date.</li><li>You are required to visit a nearest branch for update of IC Expiry if you have:<ul><li>been previously onboarded with a passport as your main identity document</li><li>changed your name, IC number or date of birth</li></ul></li></ul>'
        }
      },
      EUPLFTFD: {
        title: 'Early Upliftment of BND Fixed Deposit',
        notemessage: {
          selectHeader: 'This request is for early upliftment of your BND Fixed Deposit.',
          select:
            "To proceed with this request, please provide complete information of the following in the text box:<ul><li>Your current or saving account where the uplifted balance should be deposited into.</li><li>By requesting an early upliftment of your fixed deposit, you will be forgoing the potential interest payout.</li><li>Early upliftment of your fixed deposit is subjected to prevailing fees and charges as stipulted in the Bank's Tariff Booklet. The Tariff Booklet is available on <a href=\"javascript:;\" onclick=\"window.open('https:www.//sc.com/bn','_system')\">sc.com/bn</a>.</li><li>Your Request for Early Upliftment cannot be processed if you have existing lending facilities linked to the fixed deposit.</li></ul>",
          uploadHeader: 'This request is for early upliftment of your BND Fixed Deposit.',
          upload:
            "To proceed with this request, please provide complete information of the following in the text box:<ul><li>Your current or saving account where the uplifted balance should be deposited into.</li><li>By requesting an early upliftment of your fixed deposit, you will be forgoing the potential interest payout.</li><li>Early upliftment of your fixed deposit is subjected to prevailing fees and charges as stipulted in the Bank's Tariff Booklet. The Tariff Booklet is available on <a href=\"javascript:;\" onclick=\"window.open('https:www.//sc.com/bn','_system')\">sc.com/bn</a>.</li><li>Your Request for Early Upliftment cannot be processed if you have existing lending facilities linked to the fixed deposit.</li></ul>"
        }
      }
    },
    duplicateStatement: {
      error: {
        startDate: {
          error2: 'Start month should be less than current month'
        },
        endDate: {
          error2: 'End month should be less than current month'
        }
      }
    }
  },
  FERE: {
    page: {
      fileUploadInfoText: 'File format should be in JPG, PNG, PDF, ZIP or EML. The file size must not exceed 5MB.'
    }
  }
};
