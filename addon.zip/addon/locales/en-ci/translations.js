/* eslint-disable no-useless-escape */

export default {
  ServiceRequest: {
    LANDINGPAGE: {
      'header.title': 'Service request'
    }
  }
};
