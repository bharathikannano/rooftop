/* eslint-disable no-useless-escape */
export default {
  ServiceRequest: {
    CCFEEWAVIER: {
      statusMsg: {
        success: 'Your request has been submitted.<br>You will receive result notification in 3 working day.',
        hksuccessmsg: 'Your request has been submitted.<br>You will receive result notification in 3 working days.'
      }
    }
  }
};
