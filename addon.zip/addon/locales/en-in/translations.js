/* eslint-disable no-useless-escape */

export default {
  ServiceRequest: {
    CREDITCARD_ERROR_MAP: {
      'CSL-CC-301':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-302':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-303':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-304':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-305':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-306':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-307':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-308':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-312':
        'You have exceeded the PIN try limit. Kindly call our 24-hour Customer Care hotline for further assistance.',
      'CSL-CC-313':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-314':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-315':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-422':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline or walk in to any of our branches for further assistance.',
      'CSL-CC-423':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline or walk in to any of our branches for further assistance.',
      'CSL-CC-409':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-417':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-407':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-416': 'Please enter Standard Chartered Credit Card for activation.',
      'CSL-CC-415':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-405':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-414':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-404':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-413':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-403':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-412':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-402':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-411':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-401':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-410':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-418':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-316':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-OTP-1328':
        'Sorry, due to maximum invalid OTP attempts you will not receive any OTP for transactions for the next 24 hours.',
      '1308':
        'You have entered invalid one-time password (OTP). Please check and re-enter your one time password(OTP). (Error Code:1308)',
      '1307': 'Your one-time password (OTP) had expired. Please request for a new OTP. (Error Code:1307)',
      'CSL-OTP-1024': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-OTP-1026': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.'
    },
    genericRequest: {
      header: {
        title: {
          statusMsgCUSTOMER:
            'Thank you. Your request has been submitted and will be processed.<br><br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br><br>You may refer to your Secure Mailbox for status updates or view your submitted request under "Sent Items".'
        }
      },
      DBCREDLY: {
        title: 'Debit card redelivery',
        notemessage: {
          select:
            'Please ensure that your mailing address is updated correctly. Your card will be re-dispatched to this address.<br>Owing to the current lockdown, please expect a delay in delivery of your card.'
        }
      },
      CHQREDLY: {
        title: 'Cheque book redelivery',
        notemessage: {
          select:
            'Please ensure that your mailing address is updated correctly. Your cheque book will be re-dispatched to this address.<br>Owing to the current lockdown, please expect a delay in delivery of your cheque book.'
        }
      },
      CLAUTOAP: {
        title: 'Cancel auto apportionment of payment on all my Credit Cards',
        notemessage: {
          select:
            'The auto apportionment across your Credit cards will be cancelled within the next few working days. Please make separate payments for each of your credit cards and loans in the next payment cycle.'
        }
      },
      ACTCCARD: {
        title: 'Activate my Credit Card',
        notemessage: {
          select:
            'Please submit the request only if you have collected your card from a Branch or via speed post. Card will be activated within the next few working day.'
        }
      },
      ASCFINCP: {
        title: 'Amortization schedule - from inception',
        notemessage: {
          select:
            'The Amortisation Schedule will be sent to your registered mailing address to reach you within 4 working days. This schedule offers a view of the EMIs from inception of the loan with a breakup between Interest and Principal.'
        }
      },
      ASFMFEMI: {
        title: 'Amortization schedule - future EMI',
        notemessage: {
          select:
            'The Amortisation Schedule will be emailed to your registered email id within the next few working day. This schedule offers a view of the upcoming EMIs for the next 48 months of the loan with a breakup between Interest and Principal'
        }
      },
      SATOFACC: {
        title: 'Statement of Accounts',
        notemessage: {
          select:
            'A copy of your statement of account will be sent to your registered mailing address to reach you within 5 working days.'
        }
      },
      ARRBRKSC: {
        title: 'Arrear break up schedule',
        notemessage: {
          select:
            'Submit the request only if there was any arrear on the account. A copy of your statement of account will be sent to your registered mailing address. You can make an arrear payment by logging in to <a href="javascript:;" onclick="window.open(\'https://www.sc.com/in/payments\',\'_system\')">sc.com/in/payments</a><br> Owing to the current lockdown, please expect a delay in delivery of your arrear break up schedule.'
        }
      },
      CCLOFDOC: {
        title: 'List of documents for my Loan',
        notemessage: {
          select:
            'Please ensure that your mailing address is updated correctly. A copy of list of documents will be sent to your registered mailing address.<br>Owing to the current lockdown, please expect a delay in delivery of your documents.'
        }
      },
      COFORDOC: {
        title: 'Copy of original documents',
        notemessage: {
          select:
            'Please ensure that your mailing address is updated correctly. A copy of original documents will be sent to your registered mailing address. A retrieval charge is applicable ( Refer SOSC for checking the schedule of applicable charges) – Ensure to make the payment before submitting request ( account number 42405000223, IFSC Code no SCBL0036072 ) Please note, non-payment will lead to decline of request.<br>Owing to the current lockdown, please expect a delay in delivery of a copy   of your original documents.'
        }
      },
      SALETREQ: {
        title: 'Copy of Sanction Letter',
        notemessage: {
          select:
            'Please ensure that your mailing address is updated correctly. A copy of sanction letter will be sent to your registered mailing address.<br>Owing to the current lockdown, please expect a delay in delivery of your sanction letter.'
        }
      },
      DOCRELES: {
        title: 'Document release',
        notemessage: {
          select:
            'Submit the request if you have repaid complete loan amount. Once Loan documents are ready, follow up SMS will be sent with appointment details for document pick up.'
        }
      },
      RFDEXEMI: {
        title: 'Refund of excess payment',
        notemessage: {
          select:
            'Submit the request if there is any excess amount paid towards EMI. The refund will be initiated via NEFT to your NACH/SI account within the new few days.'
        }
      },
      TNCCPRET: {
        title: 'Copy of Terms and Conditions for my Loan',
        notemessage: {
          select:
            'A copy of Term and Conditions will be sent to your registered mailing address.<br>Owing to the current lockdown, please expect a delay in delivery of the Terms and Conditions copy.'
        }
      },
      REISSPTQ: {
        title: 'Reissuance of Loan Preclosure letter',
        notemessage: {
          select:
            '<b>This request is for receiving a copy of your loan preclosure letter, already issued to you in the last 30 day days. For a new request please visit our nearest branch or Call centre.</b><br>Pre-term Quote (PTQ) is requested if you wish to close or pre-close any active loan.<br>Please note that reissuance of the Pre-Term Quote (PTQ) will not accepted within 15 working days for your last PTQ request. PTQ will be resent to your registered email address.'
        }
      },
      INTRELET: {
        title: 'Copy of most recent Interest Rate Revision letter',
        notemessage: {
          select:
            'A copy of the last communication sent to your mailing address regarding an interest rate revision will be sent to your registered mailing address.<br> Owing to the current lockdown, please expect a delay in delivery of the interest rate revision communication.'
        }
      },
      TDADRISU: {
        title: 'Fixed Deposit Confirmation Advice',
        notemessage: {
          select:
            'Place this request to re-trigger Term Deposit (TD) advise to your registered email id within the new few days.'
        }
      }
    },
    certificatesRequest: {
      default: 'Request for Certificates',
      header: {
        subTitle: {
          select: 'Which certificate(s) are you looking for?',
          TDS: 'Financial year starts on 1st April and ends on <span>31st March</span> of the following year.',
          PI: 'Financial year starts on 1st April and ends on <span>31st March</span> of the following year.',
          IBC: 'Financial year starts on 1st April and ends on <span>31st March</span> of the following year.'
        }
      },
      pageLabels: {
        statusMsg:
          'Your request is submitted. Thank You. We will process your request within the next few days. You will receive a status update notification from us. To check the status , go to the ‘Status’ tab under Help & Services.'
      },
      countryNotes: {
        TDS:
          'Your request will be processed within the next few days.<br>Please ensure that you have updated your latest email id in bank records to receive these statements.<br>TDS certificate will be issued to you only if bank has deducted TDS from your account.',
        PI:
          'Your request will be processed within the next few days.<br>Please ensure that you have updated your latest email id in bank records to receive these statements.',
        IBC:
          'Your request will be processed within the next few days.<br>Please ensure that you have updated your latest email id in bank records to receive these statements.<br>Please check your eAdvices section in online banking for existing interest & balance certificates before raising this request.'
      }
    },
    duplicateStatement: {
      header: {
        title: {
          statusMsg:
            'Your request is submitted. Thank You. All your requests will be processed within the next few days. Home saver statements will take longer to process. You will receive a status update notification from us. To check the status , go to the ‘Status’ tab under Help & Services.',
          statusMsgCCNoN: 'Thank You. Your request has been submitted & will be processed within 5 working days. To check the status, please visit ‘Status’ Tab under Help & Services.'
          }
      },
      error: {
        default: 'Please enter a valid date',
        startDate: {
          error1: 'Start Date should not be more than 5 years'
        },
        endDate: {
          error1: 'End date should not be less than 5 years'
        },
        noData: {
          customerData:
            'For Statement request, you are required to update email id in bank records. To update email id, please visit profile tab and update you email id or visit your nearest branch.',
          NONDLYCC:
            'You do not have eligible card for redelivery. Please contact Call Centre or visit any nearest Standard Chartered Branch.'
        }
      },
      countryNotes: {
        default:
          'Please note you can download your last 24 months e-Statement by visiting e-Statement option in iBanking.<br>In case you have not subscribed for e-statements, visit estatement option in iBanking to subscribe now.<br>If you need statement which is not available in your estatements, then you may place a request here.<br>For Home Saver Loan account, an EMI break up of Principal and Interest is provided. For a detailed Statement, please apply for a statement request based on 11 Digit Home Saver Account under account management.<br>All your requests will be processed within the next few days. Home saver statements will take longer to process.',
        account:
          'Only the eligible account for cheque book will be shown. If you do not see you account, <a href="">contact our 24/7 Call Centre</a>.<br>Free may apply depending on the cheque book requested. Please check Bank’s <a>fee schedule</a> for more information.<br>Your Cheque Book will be sent to your registered mailing address. Please ensure your address is correct.',
        statement:
          'Please note you can download your last 24 months e-Statement by visiting e-Statement option in iBanking.<br>In case you have not subscribed for e-statements, visit estatement option in iBanking to subscribe now.<br>If you need statement which is not available in your estatements, then you may place a request here.<br>For Home Saver Loan account, an EMI break up of Principal and Interest is provided. For a detailed Statement, please apply for a statement request based on 11 Digit Home Saver Account under account management.<br>All your requests will be processed within the next few days. Home saver statements will take longer to process.',
        CCNonDelivery:
          'Your request will be processed within few working days.<br>Please ensure that you have updated your latest mailing address in bank records to receive deliverables.<br>Owing to the current lockdown, please expect a delay in delivery of your physical credit card.'
      }
    }
  },
  FERE: {
    page: {
      fileUploadInfoText: 'File format should be in JPG, PNG, PDF, ZIP or EML. The file size must not exceed 5MB.'
    }
  }
};
