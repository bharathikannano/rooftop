/* eslint-disable no-useless-escape */

export default {
  FERE: {
    page: {
      receipt: {
        receiptFAQText: 'See our frequently asked questions for more help.',
        receiptCallText: 'If you need further assistance, please call our 24-hour banking line',
        receiptPhoneNumber: '+254 203293900, +254 732143900 or +254 703093900',
        'button.getHelp': 'GET HELP',
        'button.creditLimit': 'Review my credit limit'
      }
    }
  },
  ServiceRequest: {
    LANDINGPAGE: {
      'header.title': 'Service request'
    },
    STATUSENQUIRY: {
      accountDetails: 'Application Details'
    },
    COMMON: {
      'productCategory.title': 'Which products would you like to apply for?',
      productOpening: {
        currentAccount: 'Current Account',
        excelAccount: 'Safari Savings Account'
      },
      systemError:
        'We are unable to complete your request at this time. Kindly cancel the request and try again or contact us on +254 20 329 3900 / +254 703 093 900 / +254 732 143900 for assistance if the problem persists.'
    },
    CREDITCARD_ERROR_MAP: {
      'CSL-CC-301':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 254 20 329 3900 for further assistance.'
    }
  },
  appSummary: {
    excelAccount: 'Safari Savings Account'
  },
  generalDeclaration: {
    title: 'General Declaration',
    declaration:
      "<div class='modal-terms-condition'><h3 class='general-info-head'>By accepting this application :</h3><ol><li>You represent and warrant that all information (including any documents) you have given to us in connection with the application is correct, complete and not misleading; You agree to inform us and provide adequate information (including any documents) in the event of any change in the information or documents provided to us in connection with the application.</li><li>You acknowledge that we may decline your application without giving you any reason for doing so. If this happens, no contractual relationship arises between us and you.</li><li>You confirm and give us consent to give any information in connection with this application (including your personal information) to any service provider (whether located in or outside of Kenya) for the purpose of providing any service to you in connection with this application (including data processing).</li><li>You declare that you have read and understood our Client Terms, Product Terms and Conditions, Online Terms and Conditions, Privacy Policy and all other the applicable documents referred to in Part A of our Client Terms forming our banking agreement which are provided on SC Mobile and also available on our website at sc.com/ke and you agree to be bound by them. You acknowledge that you are bound by any variation we may make to these documents, in accordance with our banking agreement. In particular, you understand that by entering into the banking agreement you give indemnities, authorisations, consents and waivers and agree to limitations on our liability.</li><li>You consent to us contacting you at the addresses, e-mail addresses and phone numbers you have provided to us, for verification/authentication for entering into the banking agreement and/or to give you information on other products and services that we, or our strategic partners, may offer.</li><li>You consent to us archiving and storing any information that we may obtain from you for purposes of entering into the banking agreement.</li><li>You agree that we will send electronic statements for your bank accounts and loan accounts by email to the personal email address provided by you. You also acknowledge that for your security, the Bank will register you for a prescribed set of SMS alerts.</li><li>You authorise us to disclose, obtain, verify and exchange any of the information you have given to us with anyone we may consider appropriate such as a government data base, regulatory authority or credit reference / rating agency or bureau.</li><li>You consent to us and to each of our subsidiaries and affiliates (including each branch or representative office) (“Standard Chartered Group”) its officers, employees, agents and advisers disclosing information relating to you (including details of our banking agreement, the accounts, the products or any arrangement with us) to our head office and any other member of the Standard Chartered Group in any jurisdiction (“Permitted Parties”); your employer professional advisers, service providers, Government population registration systems (whether located in or outside of Kenya) for the purposes of providing any service to you in connection with this application (including but not limited to data processing and using such existing data for verification purposes), or independent contractors to, or agents of, the Permitted Parties, such as debt collection agencies, data processing firms and correspondents who are under a duty of confidentiality to the permitted parties, any actual or potential participant or sub-participant in relation to any of our obligations under our banking agreement between us, or assignee, novatee or transferee (or any officer, employee, agent or adviser of any of them), any credit reference agency, rating agency, business alliance partner, insurer or insurance broker of, or direct or indirect provider of credit protection to, or any Permitted Parties; any court, tribunal or authority (including an authority investigating an offence or a tax authority) with jurisdiction over the Permitted Parties; a merchant or member of VISA International or Mastercard International where the disclosure is in connection with the use a card; any authorized person or any security provider; anyone we consider necessary in order to provide you with the services in connection with an account.</li><li>For the purposes of your application for a credit card, personal loan, home loan or auto loan you confirm that:<ul><li style='list-style-type:disc;'>none of your existing credit cards and/or other loans have been cancelled due to payment defaults.</li><li style='list-style-type:disc;'>you do not have any payments overdue by more than one month on any credit cards and/or other loans you have with other financial institutions.</li><li style='list-style-type:disc;'>you are not and have never been bankrupt and you have no intention to petition or are currently petitioning for bankruptcy.</li></ul></li><li>You acknowledge that insurance plans that accompany certain products are underwritten by third party insurers. Such insurers are not Standard Chartered Group associates or subsidiaries or related corporations. Such insurers are solely responsible for all coverage and compensation under the plans. We collect your information and send them to such insurers for processing and review. Collection of information does not necessarily mean that your insurance application will be approved.<ol type='a'><li>Should you opt to take an insurer from our panel, you agree that the insurance is underwritten by our Insurance Service Provider. Our Insurance Service Provider is solely responsible for all coverage and compensation under the plans.</li><li>Should you opt to take an insurer of your choice the same shall be subject to our consent which shall not be unreasonably withheld. You also understand that if you opt for your own choice of insurer, you are required to arrange with the said insurer to assign the cover to the Bank to the extent of the loan amount and total tenor applied for. We reserve the right to verify the details of the assigned policy. You also understand that you must present such cover to us prior to your loan being disbursed.</li></ol></li><li>If you are applying for a bundled product offer, you agree and acknowledge that we may vary, terminate or change the terms of the bundle by giving you notice. If you do not use any of the bundled products that you have applied for, we may withdraw the rewards that accompany the bundled products by giving you notice.</li><li>Subject to applicable local laws, you hereby consent for Standard Chartered PLC or any of its affiliates (collectively “the Bank”) to share your information with domestic and overseas regulators or tax authorities where necessary to establish your tax liability in any jurisdiction.</li><li>You undertake to provide the underlying documentation to support all foreign currency transactions above the equivalent of USD 10,000 conducted on your account or such other amount as the Central Bank of Kenya may determine from time to time. If you choose to transact through electronic banking, you undertake to provide such documentation within 5 banking days upon our demand.</li><li>You confirm that you have read and understood the contents of this declaration.You agree that the Bank is permitted to send this electronically executed application to you via email and that the terms and conditions it refers to and any instructions given herein shall have the same validity, admissibility and enforceability as if signed in physical form and you agree not to challenge the validity, admissibility or enforceability only on the basis that they are in electronic form.</li></ol></div>"
  },
  applyProducts: {
    applicationResult: {
      declineInfo:
        'Thank you for your credit card application.<br>Unfortunately, your application is not in line with some of our internal policies.<br><br>You may contact our client care centre at <br><u>+254 3293900</u> or visit any of <u>our branches</u> for more information'
    }
  },
  productSummary: {
    startApplication:{
      applicationSummary:{
        applyingForProduct:"You are applying for:"
      }
    }
  }
};
