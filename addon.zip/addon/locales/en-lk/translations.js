/* eslint-disable no-useless-escape */

export default {
  ServiceRequest: {
    COMMON: {
      genericError: {
        LK:
          "We've encountered an error with your request. Please cancel the request and try again. If the issue persists, please call our 24-hour Client Care Centre at +94 11 2 480480 for immediate assistance."
      },
      systemError:
        "We've encountered an error with your request. Please cancel the request and try again. If the issue persists, please call our 24-hour Client Care Centre at +94 11 2 480480 for immediate assistance."
    },
    CREDITCARD: {
      pinSetup: {
        status: {
          transactionSuccessFailure: {
            LK:
              "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +94 11 2 480480 for immediate assistance."
          },
          transactionSuccessInComplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +94 11 2 480480"
        }
      },
      activation: {
        status: {
          transactionSuccessFailure: {
            LK:
              "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +94 11 2 480480 for immediate assistance."
          },
          transactionSuccessInComplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +94 11 2 480480"
        }
      }
    },
    CARDBLOCK: {
      statusMsg: {
        LK: {
          failure:
            "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +94 11 2 480480 for immediate assistance.",
          incomplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +94 11 2 480480"
        }
      }
    },
    CARDREPLACEMENT: {
      countryNotes: {
        LK:
          'This request is for replacement of<ul><li>Damaged cards or</li><li>Cards that have already been reported lost/stolen</li></ul>Credit/Debit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/ stolen card, please use the Report Lost/Stolen Card Service Request.<br>We will send the replacement card(s) to your card delivery address in our records. If you have previously reported a lost or stolen card, please note that the replaced card will have a new number and PIN.<br>Card replacement charges will apply as per the tariff.<br>Please note that you will need to update your existing payment arrangements/ standing instructions given to third party (if any), after receiving your new card.<br>Any standing order placed from your Standard Chartered account to the above Credit Card, will be transferred to the new replacement card.'
      },
      statusMsg: {
        LK: {
          failure:
            "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Care Centre at +94 11 2 480480 for immediate assistance.",
          incomplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24-hour Client Care Centre at +94 11 2 480480"
        }
      }
    },
    CREDITBALANCEREFUND: {
      'phoneBankingHotline.text': {
        LK: '24/7 Phone Banking'
      },
      'notes.fromCard': {
        LK:
          '*To view and refund the exact amount including cents, please refer to your card balance in the main page.</br>*Excess Credit displayed is the excess credit card payment made by you, including the recent unbilled/unstatemented transactions.'
      }
    },
    CCFEEWAVIER: {
      countryLinksTxt: {
        LK: '24/7 Phone Banking hotline'
      },
      validationCountryNotes: {
        LK: 'Kindly contact our {{inter_link}} for further assistance.'
      },
      countryNotesTransactionPage: {
        LK:
          'Displayed transactions are charges posted on the selected cards only. <br>Credit Card Fee Waiver will be reviewed and approved as per banks discretion.'
      },
      countryNotes: {
        LK:
          'For other fee waiver requests related to your credit card, please call +94112480480. <br>Only credit card(s) that may be eligible will be shown. If you do not see your credit card, please call +94112480480. <br>Credit Card Fee Waiver will be reviewed and approved as per banks discretion.'
      }
    },
    genericRequest: {
      header: {
        title: {
          statusMsg:
            "You request is submitted.<br>Thank you. We will process your request. You will receive a status update notification from us.<br>To check the status, go to the 'Status’ tab under Help & Services.",
          statusMsgReferral:
            'We have received your response to our query and will process your request within 3 working days. Thank you.'
        }
      },
      LONCLTLK: {
        title: 'Closure Letter',
        notemessage: {
          selectHeader: 'This request is to receive a bank attested loan closure letter.',
          select:
            'Letter will be sent to the Mailing Address.<br>Request will be processed within 1 business working day.'
        }
      },
      AMCASTLK: {
        title: 'Amendment/Cancellation of standing instruction',
        notemessage: {
          selectHeader: 'This request is to amend or cancel an existing Standing Instruction.',
          select:
            'Standing Orders placed to Current and Saving Accounts are via SLIPS and to Cards are via RTGS.<br>Request will be processed within 2 working days.',
          uploadHeader: 'Please provide the following information for this request',
          upload:
            'Change Required - Amendment or Cancellation<br>Beneficiary Name<br>Amount<br>Current Standing Order Date'
        }
      },
      DORMACTV: {
        title: 'Dormant Reactivation',
        notemessage: {
          selectHeader: 'This request is to activate a dormant account.',
          select:
            'The Bank will action a debit and credit transaction for 1 currency unit will be triggered to activate the account.<br>Request will be processed within 1 business working day.'
        }
      },
      NFDSETLK: {
        title: 'Fixed Deposit',
        notemessage: {
          selectHeader: 'This request is to set up/ renew your Fixed Deposit account',
          select:
            'Applicable Published Rates and Tariffs will apply as per <a href="javascript:;" onclick="window.open(\'https://www.sc.com/lk/important-information/\',\'_system\')">https://www.sc.com/lk/important-information/.</a><br>Minimum FD opening criteria is LKR 50,000.<br>If no renewal choices are provided, the FD will automatically be renewed.<br>Interest earned will be credited onto the account debited to open the FD.<br>Request will be processed within 1 business working day.',
          uploadHeader: 'Please provide the following information for this request.',
          upload:
            'New or Renewal<br>Amount<br>Tenor – 1 Month, 3 Month, 6 Month & 12 Month<br>Choose i ii or iii<ul><li>Renewed automatically with interest</li><li>Renewed automatically and interest credited to the account used to open FD</li><li>Do not renew and credit interest to the account used to open FD</li></ul><br>If RM Managed - State the RM Name'
        }
      },
      BALCONAC: {
        title: 'Declaration of funds for Balance/ Visa request',
        notemessage: {
          selectHeader: 'This request is for a bank attested CASA balance confirmation letter.',
          select:
            'If balance confirmation is needed on all accounts held confirm on next screen.<br>Letter will be sent to the mailing address updated or collection point stated.<br>Request will be processed within 1 business working day.',
          uploadHeader: 'Please provide the following information for this request.',
          upload:
            'Specific account or all accounts under your relationship<br>Specify balance as of date<br>Embassy Name/ Bank Name and Address<br>Delivery/ Collection - Mailing address or Standard Chartered Branch or Email<br>Name of Standard Chartered Branch'
        }
      },
      WTHTACNL: {
        title: 'Withholding Tax confirmation letter',
        notemessage: {
          selectHeader: 'Request Bank Attested Witholding Tax Confirmation Letters.',
          select:
            'Letter will be sent to the Mailing Address updated.<br>Request will be processed within 1 business working day.'
        }
      },
      DRSTBKAC: {
        title: 'Door Step Banking',
        notemessage: {
          selectHeader: 'Request for door step banking agent to collect or deliver cash/ cheque to/from your CASA.',
          select:
            'Minimum transaction value will be LKR 25,000 up to a maximum daily limit of LKR 500,000.<br>This service is being provided at your request. Please proceed only if you have <b>read and understood</b> the applicable Door Step Banking Terms & Conditions.<br>The Bank will not accept any liability in the event that you have not read the applicable Terms and Conditions.<br>Service is only available in Colombo and Suburbs.<br>Pickup and delivery services are available from 9am to 7pm on weekdays and weekends (except public and bank holidays).<br>Please refer our tariff guide for applicable charges or click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/lk/priority/priority-benefits.html\',\'_system\')">https://www.sc.com/lk/priority/priority-benefits.html</a> for applicable Terms & Conditions.',
          upload:
            'Please ensure to capture below details in your request:<ul><li>Request type (Cash Delivery / Cash collection / Cheque collection /Credit Card Payment)</li><li>Amount</li><li>Full Name of the requester</li><li>Account Number / Credit Card Number</li><li>Identity Card Number (NIC, Passport or Driving License)</li><li>Residential address (registered with the bank)</li><li>Mobile number (registered with the bank)</li></ul><br>Details mentioned above will be used for verification purposes during collections and deliveries. Therefore, please ensure accuracy for a faster service.'
        }
      },
      VISAUPAC: {
        title: 'Visa Update',
        notemessage: {
          selectHeader: 'Request to Update Visa Documents.',
          select:
            'Attachment must be a clear Visa copy.<br>If Visa is on a new passport, copy is required to be certified by a lawyer, accountant, notaries public, commissioner of oaths or diplomatic mission.<br>Certifiers must place their provide their full name, signature, contact number and date.<br>Request will be processed within 1 business working day.'
        }
      },
      STATSACC: {
        title: 'Duplicate Statement Request',
        notemessage: {
          selectHeader: 'This is a request for bank attested physical CASA statements.',
          select:
            'If duplicate statements needed on all accounts held confirm on next screen.<br>Letter will be sent to the Mailing address updated or collection point stated.<br>Request will be processed within 1 business working day.<br>Charges will be applied as stated on <a href="javascript:;" onclick="window.open(\'https://www.sc.com/lk/important-information/\',\'_system\')">https://www.sc.com/lk/important-information/</a>',
          uploadHeader: 'Please provide the following information for this request.',
          upload:
            'Specific account or all accounts under your relationship<br>Requested Period<br>Delivery - Mailing address or Standard Chartered Branch<br>Name of Standard Chartered Branch'
        }
      },
      VISALETA: {
        title: 'Fixed Deposit Renewals',
        notemessage: {
          selectHeader: 'Request fixed deposit renewals.',
          select:
            'Applicable Published Rates and Tariffs will Apply.<br>If no renewal choices are provided, the FD will automatically be renewed.<br>Interest earned will be credited onto the account debited to open the FD.<br>Request will be processed within 1 business working day.',
          uploadHeader: 'Please provide the following information for this request.',
          upload:
            'Amount<br>Tenor – 1 Month, 3 Month, 6 Month & 12 Month<br>Choose i ii or iii<ul><li>Renewed automatically with interest</li><li>Renewed automatically and interest credited to the account used to open FD</li><li>Do not renew and credit interest to the account used to open FD</li></ul>'
        }
      },
      STATSCCM: {
        title: 'Duplicate Credit Card Statement Request',
        notemessage: {
          selectHeader: 'This is a request for bank attested physical card statements.',
          select:
            'If duplicate statements needed on all cards held confirm on next screen.<br>Letter will be sent to the Mailing address updated or collection point stated.<br>Request will be processed within 1 business working day.<br>Charges will be applied as stated on <a href="javascript:;" onclick="window.open(\'https://www.sc.com/lk/important-information/\',\'_system\')">https://www.sc.com/lk/important-information/</a>',
          uploadHeader: 'Please provide the following information for this request.',
          upload:
            'Specific account or all accounts under your relationship<br>Requested Period<br>Delivery - Mailing address or Standard Chartered Branch<br>Name of Standard Chartered Branch'
        }
      },
      VISALETC: {
        title: 'Visa Confirmation Letters',
        notemessage: {
          selectHeader: 'This is a request for bank attested letter for Visa purposes',
          select:
            'If visa confirmation needs information on all cards held confirm on next screen.<br>Letter will be sent to the mailing address updated or collection point stated.<br>Request will be processed within 1 business working day.',
          uploadHeader: 'Please provide the following information for this request',
          upload:
            'Specific card or all cards under your relationship<br>Specify balance as of date<br>Embassy Name and Address<br>Delivery - Mailing address or Standard Chartered Branch or Email<br>Name of Standard Chartered Branch'
        }
      },
      TRLINCER: {
        title: 'Travel Insurance Certificate',
        notemessage: {
          selectHeader:
            'This is a request for Travel Insurance Certificate for pre or post airline tickets purchased via StanChart credit card.',
          select:
            'Client can request certificates for pre purchase and post purchase of airline ticket<br>Letter will be sent to the mailing address updated or collection point stated.<br>Request will be effective within 1 working day.',
          uploadHeader: 'Please provide the following information for this request.',
          upload:
            'Purpose of letter - Pre purchase of air ticket or Post purchase confirmation on travel insurance<br>Solo or Family Travel Insurance<br>Any travel companion/ dependents state the following<ul><li>Name</li><li>Relationship</li><li>Passport Number</li></ul><br>Delivery - Mailing address or Standard Chartered Branch<br>Name of Standard Chartered Branch'
        }
      },
      BALCONCC: {
        title: 'Card Balance Declaration',
        notemessage: {
          selectHeader: 'This is a request for bank attested card balance confirmation letters.',
          select:
            'If balance confirmation needed on all cards held confirm on next screen.<br>Letter will be sent to the Mailing Address updated or collection point stated.<br>Request will be processed within 1 business working day.',
          uploadHeader: 'Please provide the following information for this request.',
          upload:
            'Specific card or all cards under your relationship<br>Specify balance as of date<br>Embassy Name/ Bank Name and Address<br>Delivery - Mailing address or Standard Chartered Branch<br>Name of Standard Chartered Branch or Email ID<br>Name of Standard Chartered Branch'
        }
      },
      LOANONCC: {
        title: 'Loan on Card',
        notemessage: {
          selectHeader: 'This is a request for a loan on card.',
          select:
            'Applicable Published Rates & Tariffs will apply as per <a href="javascript:;" onclick="window.open(\'https://www.sc.com/lk/important-information/\',\'_system\')">https://www.sc.com/lk/important-information/</a><br>If you hold an StanChart CASA, funds will be credited to the respective account<br>If you do not hold a StanChart CASA, please state the bank on the next screen<br>Request will be processed within 1 business working day.',
          uploadHeader: 'Please provide the following information for this request.',
          upload:
            'Loan Amount<br>Tenor - 1 Month 3 Month 6 Month 12 Month<br>Bank Name<br>Account Number<br>Branch Name<br>Account Name'
        }
      },
      DRSTBKCC: {
        title: 'Door Step Banking',
        notemessage: {
          selectHeader: 'Request for door step banking agent to Collect your credit card payment.',
          select:
            'Minimum transaction value will be LKR 25,000 up to a maximum daily limit of LKR 500,000.<br>This service is being provided at your request. Please proceed only if you have <b>read and understood</b> the applicable Door Step Banking Terms & Conditions.<br>The Bank will not accept any liability in the event that you have not read the applicable Terms and Conditions.<br>Service is only available in Colombo and Suburbs.<br>Pickup and delivery services are available from 9am to 7pm on weekdays and weekends (except public and bank holidays).<br>Please refer our tariff guide for applicable charges or click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/lk/priority/priority-benefits.html\',\'_system\')">https://www.sc.com/lk/priority/priority-benefits.html</a> for applicable Terms & Conditions.',
          upload:
            'Please ensure to capture below details in your request:<ul><li>Request type (Cash Delivery / Cash collection / Cheque collection /Credit Card Payment)</li><li>Amount</li><li>Full Name of the requester</li><li>Account Number / Credit Card Number</li><li>Identity Card Number (NIC, Passport or Driving License)</li><li>Residential address (registered with the bank)</li><li>Mobile number (registered with the bank)</li></ul><br>Details mentioned above will be used for verification purposes during collections and deliveries. Therefore, please ensure accuracy for a faster service.'
        }
      },
      VISAUPCC: {
        title: 'Visa Update',
        notemessage: {
          selectHeader: 'Request to Update Visa Documents.',
          select:
            'Attachment must be a clear Visa copy.<br>If Visa is on a new passport, copy is required to be certified by a lawyer, accountant, notaries public, commissioner of oaths or diplomatic mission.<br>Certifiers must place their provide their full name, signature, contact number and date.<br>Request will be processed within 1 business working day.'
        }
      }
    },
    certificatesRequest: {
      default: 'Request for Certificates',
      header: {
        optinalTitle: {
          title: 'Enter Account Information (Optional)',
          placeholder: 'Type decription (160 Character)'
        },
        subTitle: {
          select: 'Which certificate(s) are you looking for?',
          TDS: 'Financial year starts on 1st April and ends on <span>31st March</span> of the following year.',
          PI: 'Financial year starts on 1st April and ends on <span>31st March</span> of the following year.',
          IBC: 'Financial year starts on 1st April and ends on <span>31st March</span> of the following year.'
        }
      },
      pageLabels: {
        'comment-label': 'Comments',
        alertMsg: {
          TDS:
            'If you need TDS and Interest Certificate from specific accounts please enter their respective account numbers above',
          PI:
            'If you need Mortgage Certificate from specific accounts please enter their respective account numbers above',
          IBC:
            'If you need Balance Certificate from specific accounts please enter their respective account numbers above'
        },
        statusMsg:
          'Your request is submitted. Thank You. We will process your request within next working day. You will receive a status update notification from us. To check the status , go to the ‘Status’ tab under Help & Services.'
      },
      countryNotes: {
        default:
          'More information and supporting evidence provided at this point can increase your chance in getting a permanent refund.',
        TDS:
          'Your request will be processed and dispatched within next working day.<br>The certificate will be sent to your bank registered mailing address.',
        PI:
          'Your request will be processed and dispatched within next working day.<br>The certificate will be sent to your bank registered mailing address.',
        IBC:
          'Your request will be processed and dispatched within next working day.<br>The certificate will be sent to your bank registered mailing address.'
      }
    }
  },
  FERE: {
    page: {
      fileUploadInfoText: 'File format should be in JPG, PNG, PDF, ZIP or EML. The file size must not exceed 5MB.'
    }
  }
};
