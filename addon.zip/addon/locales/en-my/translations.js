/* eslint-disable no-useless-escape */

export default {
  ServiceRequest: {
    FDUPLIFTMENT: {
      successMsg:
        'Your request has been submitted and will be processed.<br/><br/>To check the status, go to the ‘Status’ tab under Help & Services.',
      successMsg2:
        'Your request has been submitted and will be processed.<br/>To check the status, go to the ‘Status’ tab under Help & Services.'
    },
    CREDITCARD: {
      cardSetting: {
        paymentChannelsPage: {
          optionContent1: 'This impacts all online transactions on your card except for recurring transactions.',
          optionContent2:
            'This impacts all transactions made when you tap your card or digital wallet near a credit card terminal. Sometimes, a PIN or signature may still be required.'
        },
        cardSettingsPage: {
          notes:
            '<ol><li>The specific control setting that is enabled under the Card Settings service does not override any limits set by the Bank, or the relevant card association (Visa International or Mastercard International).</li><li>When you are issued a replacement card with a different card number or a new card, you will be required to re-do or enable the Card Settings to avail the Card Settings services for the replacement card or new card.</li><li>These notes are to be read together with the Client Terms, the Credit Card Terms, the Additional Credit Card Services Guidelines, the Rewards Terms and any other documents referred to in Part A of our Client Terms forming our banking agreement. If there are any inconsistency between these notes and the Client Terms, the Credit Card Terms, the Additional Credit Card Services Guidelines, or the Rewards Terms, the Client Terms shall prevail.</li></ol>'
        },
        TMPTOOLTIP:
          'All transactions on your card will be blocked except for recurring transactions, ATM withdrawals and transactions which are not processed via Visa or Mastercard payment gateways ie. JomPAY, PayNet transactions, Fiserve transactions, etc.'
      }
    },
    CCFEEWAVIER: {
      'cardlist.header.mob': 'Select Transaction(s) to be Waived',
      'feetype.title': 'Fee Type',
      'cards.title': 'Transactions(s) to be Waived',
      statusMsg: {
        notStaffAssistSuccessMsg:
          "Your request has been submitted and will be processed.<br>To check the status, go to the 'Status' tab under Help & Services.<br>Thank you."
      },
      nonStaffAssistNoCCards: 'No eligible card detected.',
      nonStaffValidationCountryNotes: 'Sorry, you do not have any eligible credit card(s) to proceed for this request.'
    },
    CREDITCARD_ERROR_MAP: {
      'CSL-CC-301':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-302':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-303':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-304':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-305':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-306':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-307':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-308':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-312':
        'You have exceeded the PIN try limit. Kindly call our 24-hour Customer Care hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-313':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-314':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-315':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-422':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 or walk in to any of our branches for further assistance.',
      'CSL-CC-423':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 or walk in to any of our branches for further assistance.',
      'CSL-CC-409':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-417':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-407':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-416': 'Please enter Standard Chartered Credit Card for activation.',
      'CSL-CC-415':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-405':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-414':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-404':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-413':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-403':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-412':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-402':
        'We are unable to process your request as we are currently undergoing daily system maintenance. Please re-submit your request from 6am to 11pm. If your request is unsuccessful during the mentioned period, please call Client Care Centre at 1300 888 888 (or +603-7711 8888 if you are calling from overseas) for assistance.',
      'CSL-CC-411':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-401':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-410':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-418':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-CC-316':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 1 300 888 888/ +603 7711 8888 for further assistance.',
      'CSL-OTP-1328':
        'You have exceeded the PIN try limit. Kindly call our 24-hour Customer Care hotline at 1300 888 888/ + 603 7711 8888 for further assistance.',
      '1308':
        'You have entered invalid one-time password (OTP). Please check and re-enter your one time password(OTP). (Error Code:1308)',
      '1307': 'Your one-time password (OTP) had expired. Please request for a new OTP. (Error Code:1307)',
      'CSL-OTP-1024': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-OTP-1026': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.'
    },
    genericRequest: {
      header: {
        title: {
          PLCLOSUR: 'PLC account to be closed',
          labelMsgPLCLOSUR: 'Select the PLC account you wish to close',
          statusMsgPLCLOSUR:
            'Your request has been submitted and will be processed.<br><br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for your understanding.<br><br>To check the status, go to the `Status` tab under Help & Services.',
          statusMsgCUSTOMER:
            'Thank you. Your request has been submitted and will be processed.<br><br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for your understanding.<br><br>You may refer to your Secure Mailbox for status updates or view your submitted request under "Sent Items".',
          label1: 'Confirm Your Request',
          label2: 'Request type'
        },
        panelTitle: {
          'credit-card': 'Select Details'
        }
      },
      SUBOLMIT: {
        title: 'Subscribe for Overlimit',
        notemessage: {
          select:
            "This service request allows you to subscribe Overlimit for your credit card.<br>Overlimit Service is subject to Cardholder's good conduct of account with the Bank. A fee of RM50 will be charged if Cardholder exceeds his/her approved credit limit.<br>Your latest consent on Overlimit Service Subscription as provided herein will be used to update your records and will be applicable to all your credit card accounts (excluding supplementary and business cards) held with the Bank."
        }
      },
      UNSUBLMT: {
        title: 'Unsubscribe for Overlimit',
        notemessage: {
          select:
            "This service request allows you to unsubscribe Overlimit for your credit card.<br>Overlimit Service is subject to Cardholder's good conduct of account with the Bank. A fee of RM50 will be charged if Cardholder exceeds his/her approved credit limit.<br>Your latest consent on Overlimit Service Subscription as provided herein will be used to update your records and will be applicable to all your credit card accounts (excluding supplementary and business cards) held with the Bank."
        }
      },
      COEAREDM: {
        title: 'Closure of CashOne Account',
        notemessage: {
          select:
            'Please raise this Service Request for account closure upon full account settlement of your CashOne Account.'
        }
      },
      SURPFUND: {
        title: 'Personal Loan/Financing - Surplus Refund',
        notemessage: {
          select:
            "Please raise this Service Request for account surplus refund upon receiving the Bank's notification letter. Do complete the information requested in the letter and upload to the Service Request."
        }
      },
      RELETREQ: {
        title: 'Personal Loan/Financing - Release Letter Request',
        notemessage: {
          select:
            'Please raise this Service Request for release letter issuance upon full account settlement of your Personal Loan/Financing Account.<br>The Bank will process according to this specific request type based on the account that you have selected.',
          upload:
            'Please indicate the deliver mode in the text box:<ul><li>Send hard copy to your registered mailing address; or</li><li>Send soft copy to your primary email address.</li></ul><br>All information or requests other than the above indicated in the text box will not be fulfilled.'
        }
      },
      RELONACC: {
        title: 'Mortgage - Redeem of Loan/Financing Facility',
        notemessage: {
          select:
            ' Please raise this Service Request for loan redemption/account closure upon full account settlement of your housing loan/financing facility.<br>For property under construction, please enclose the Release Letter from developer.<br>We will release all your related loan documents to your appointed lawyer.<br>The Bank will process according to this specific request type based on the account that you have selected.',
          upload:
            'Please provide your appointed lawyer details in the text box:<ul><li>Name of the Lawyer firm;</li><li>Address;</li><li>Contact number;</li><li>Contact person.</li></ul><br>All information or requests other than the above indicated in the text box will not be fulfilled.'
        }
      },
      PRINREDC: {
        title: 'Mortgage - Principal Reduction',
        notemessage: {
          select:
            'This service request allows you to reduce your Loan/Financing principal amount.<br>Following the terms of the Letter of Offer, you hereby serve 1 (one) month notice to reduce your Loan/Financing principal.<br>The Bank will process according to this specific request type based on the account that you have selected.',
          upload:
            'Please provide the below informations in the text box:<ul><li>Posting date;</li><li>Account number;</li><li>Repayment/payment amount;</li><li>For Non BBA products, please specify whether you would like to revise the installment amount or reduce tenure.</li></ul>All information or requests other than the above indicated in the text box will not be fulfilled.<div><b>Important Note:</b></div><div><b>For Bai Bithaman Ajil (BBA) products only </b></div><ul><li>Principal Reduction can only be performed at   multiples of RM5,000 on the next due date when the Bank received the fund for Principal Reduction.</li><li>Revision of instalment amount after Principal Reduction is NOT allowed.<b>Applicable for all products (inclusive of Bai Bithaman Ajil)</b></li><li>Any amount prepaid is not available for redrawing for own use or future payment (NO reversal for Principal Reduction).</li><li>Monthly installment amount   will remain unchanged for Principal Reduction, unless there is a request to revise the installment amount.</li><li>Any amount in arrears will be paid, and the balance of the fund will then to be used for Principal Reduction.</li></ul>'
        }
      },
      INRATWAI: {
        title: 'Mortgage - Interest/Rental Rate Reduction',
        notemessage: {
          select:
            "This service request allows you to apply Interest/Rental rate reduction for your Loan/Financing facility, which is subject to Bank's approval.<br>The Bank will process according to this specific request type based on the account that you have selected.",
          upload:
            'Please provide the below informations in the text box:<ul><li>Reason of request;</li><li>Current Interest/Rental Rate;</li><li>Applied Interest/Rental Rate.</li></ul>All information or requests other than the above indicated in the text box will not be fulfilled.<br>You authorize the Bank to debit/charge service fee of RM50.00 (inclusive SST if applicable) upon acceptance of new rate from your Saving or Current account.'
        }
      },
      EPFWDLET: {
        title: '	Mortgage - Confirmation Letter for EPF Withdrawal',
        notemessage: {
          select:
            ' This service request allows you to apply for confirmation letter for EPF withdrawal which will be delivered to your registered mailing address.<br>The Bank will process according to this specific request type based on the account that you have selected.',
          upload:
            'Please indicate the reason in the text box:<ul><li>Reduce your Loan/Financing principal; or</li><li>Instalment payments for your Loan/Financing facility.</li></ul>All information or requests other than the above indicated in the text box will not be fulfilled.<br>You consent the Bank to debit/charge service fee of RM20.00 (inclusive SST if applicable) from your Saving or Current account.'
        }
      },
      REDSTREQ: {
        title: 'Mortgage - Redemption Statement Request',
        notemessage: {
          select:
            'This service request allows you to request for issuance of redemption statement for your Loan/Financing facility.<br>You hereby serve 1 (one) month notice to fully settle the above Loan/Financing account in accordance to the terms of the Letter of Offer.<br>You hereby authorize the Bank to cancel the un-drawn/un-disbursed portion of the Loan/Financing (if applicable) and hereby indemnify the Bank of any losses arising from said instruction.<br>For property still under construction, you are required to obtain Release letter from the developer if there is any outstanding undisbursed amount due to them.<br>The Bank will process according to this specific request type based on the account that you have selected.',
          upload:
            'Please provide the reason of your request & deliver mode in the text box:<ul><li>Send hard copy to your registered mailing address; or</li><li>Send soft copy to your primary email address.</li></ul>All information or requests other than the above indicated in the text box will not be fulfilled.<br>You consent the Bank to debit/charge service fee of RM50.00 (inclusive   SST if applicable) from your Saving or Current account.<div><b>IMPORTANT CLAUSE:</b></div><div><b>For MortgageOne, Saadiq My HomeOne-i and Business MortgageOne Product ONLY</b></div><div>I acknowledged and agreed that the Interest/Rental Saved amount will be removed from my account upon Redemption Statement issuance. In the event the loan/financing is not redeemed, I am required to earn the Interest/Rental Saved all over again.</div><div>The Bank is unable to reinstate back the Interest/Rental Saved after this Redemption Statement is issued.</div>'
        }
      },
      REPYSCHD: {
        title: 'Mortgage - Repayment/payment Schedule',
        notemessage: {
          select:
            'This service request allows us to issue repayment/payment schedule for your Standard Term Loan or DM My First Home-i.<br>The Bank will process according to this specific request type based on the account that you have selected.',
          upload:
            'Please indicate deliver mode in the text box:<ul><li>Send hard copy to your registered mailing address; or</li><li>Send soft copy to your primary email address.</li></ul>All information or requests other than the above indicated in the text box will not be fulfilled.<br>You consent the Bank to debit/charge service fee of RM25.00 (inclusive SST if applicable) from your Saving or Current account or term loan'
        }
      },
      OLOANLET: {
        title: 'Mortgage – Interest/Rental Paid Letter',
        notemessage: {
          select:
            'This service request allows us to issue the interest/rental paid letter for your Standard Term Loan or DM My First Home-i.<br>The Bank will process according to this specific request type based on the account that you have selected.',
          upload:
            'Please indicate the letter type that your request for and deliver mode in the text box:<ul><li>Send hard copy to your registered mailing address; or</li><li>Send soft copy to your primary email address.</li></ul>All information or requests other than the above indicated in the text box will not be fulfilled.<br>You consent the Bank to debit/charge service fee of RM25.00 (inclusive SST if applicable) from your Saving or Current account or term loan.'
        }
      },
      RETLODOC: {
        title: 'Mortgage - Copy of Original Documents',
        notemessage: {
          select:
            'This service request allows you to request for a Certified True Copy of the following documents for your loan/financing facility:<ul><li>Letter of Offer;</li><li>Loan/Financing Agreement;</li><li>Title;</li><li>Sales & Purchase Agreement;</li><li>Deed of Assignment;</li><li>Power of Attorney.</li></ul><br>We will send the said documents to your registered mailing address.<br>The Bank will process according to this specific request type based on the account that you have selected.',
          upload:
            'Please indicate the type of documents that you request for in the text box.<br>All information or requests other than the above indicated in the text box will not be fulfilled.<br>You consent the Bank to debit/charge service fee of RM25.00 (inclusive SST if applicable) per document from your Saving or Current account.'
        }
      },
      PLCLOSUR: {
        title: 'Closure of PLC Account',
        notemessage: {
          select:
            'You may raise this Service Request to close your PLC account upon full account settlement. It will take up to 5 working days to process your request.</br></br><div><b>*PLC</b> account means private label account, which is an account designated for certain programmes such as Balance Transfer/Balance Transfer Plus, FlexiPay/FlexiPay Plus, Flexi-On-Balance/Flexi-On-Balance Plus and Cheque-On-Call/Cheque-on-Call Plus. A separate PLC account will be used for each application under the respective programme</div>'
        }
      },
      GREQSTAC: {
        title: 'Other Request',
        notemessage: {
          upload:
            'If you wish to update your profile details, please select “Update Profile Details” menu at our Online Banking or SC Mobile.<br>Please try our “Search” function at Help and Services menu to check whether your request is available at our Online Banking or SC Mobile. If no, please state your request in the above text box.<br>The Bank will respond to you via Secure Mailbox if further information or clarification is required.<br>You may refer to your Secure Mailbox for status updates or view your submitted request under “Sent items”.<br>In light of the current situation, please note that there may be delay in processing of requests. Thank you for your patience and understanding.'
        }
      },
      GREQSTCC: {
        title: 'Other Request',
        notemessage: {
          upload:
            'If you wish to update your profile details, please select “Update Profile Details” menu at our Online Banking or SC Mobile.<br>Please try our “Search” function at Help and Services menu to check whether your request is available at our Online Banking or SC Mobile. If no, please state your request in the above text box.<br>The Bank will respond to you via Secure Mailbox if further information or clarification is required.<br>You may refer to your Secure Mailbox for status updates or view your submitted request under “Sent items”.<br>In light of the current situation, please note that there may be delay in processing of requests. Thank you for your patience and understanding.'
        }
      },
      GREQSTLA: {
        title: 'Other Request',
        notemessage: {
          upload:
            'If you wish to update your profile details, please select “Update Profile Details” menu at our Online Banking or SC Mobile.<br>Please try our “Search” function at Help and Services menu to check whether your request is available at our Online Banking or SC Mobile. If no, please state your request in the above text box.<br>The Bank will respond to you via Secure Mailbox if further information or clarification is required.<br>You may refer to your Secure Mailbox for status updates or view your submitted request under “Sent items”.<br>In light of the current situation, please note that there may be delay in processing of requests. Thank you for your patience and understanding.'
        }
      },
      GREQSTTD: {
        title: 'Other Request',
        notemessage: {
          upload:
            'If you wish to update your profile details, please select “Update Profile Details” menu at our Online Banking or SC Mobile.<br>Please try our “Search” function at Help and Services menu to check whether your request is available at our Online Banking or SC Mobile. If no, please state your request in the above text box.<br>The Bank will respond to you via Secure Mailbox if further information or clarification is required.<br>You may refer to your Secure Mailbox for status updates or view your submitted request under “Sent items”.<br>In light of the current situation, please note that there may be delay in processing of requests. Thank you for your patience and understanding.'
        }
      },
      GREQSTMO: {
        title: 'Other Request',
        notemessage: {
          upload:
            'If you wish to update your profile details, please select “Update Profile Details” menu at our Online Banking or SC Mobile.<br>Please try our “Search” function at Help and Services menu to check whether your request is available at our Online Banking or SC Mobile. If no, please state your request in the above text box.<br>The Bank will respond to you via Secure Mailbox if further information or clarification is required.<br>You may refer to your Secure Mailbox for status updates or view your submitted request under “Sent items”.<br>In light of the current situation, please note that there may be delay in processing of requests. Thank you for your patience and understanding.'
        }
      },
      GREQSTGN: {
        title: 'Other Request',
        notemessage: {
          upload:
            'If you wish to update your profile details, please select “Update Profile Details” menu at our Online Banking or SC Mobile.<br>Please try our “Search” function at Help and Services menu to check whether your request is available at our Online Banking or SC Mobile. If no, please state your request in the above text box.<br>The Bank will respond to you via Secure Mailbox if further information or clarification is required.<br>You may refer to your Secure Mailbox for status updates or view your submitted request under “Sent items”.<br>In light of the current situation, please note that there may be delay in processing of requests. Thank you for your patience and understanding.'
        }
      }
    },
    duplicateStatement: {
      productLabel: {
        loan: 'Loan/Financing Facility'
      },
      header: {
        title: {
          statusMsg:
            'Your request has been submitted and will be processed.<br><br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br><br>To check the status, go to the "Status" tab under Help & Services.',
          subInprogress: 'Submitted'
        }
      },
      pageLabels: {
        addressInfo:
          'By clicking "OK", we will charge the paper statement fee to your account. Please select which account for us to debit the charges in the next step.',
        address: {
          'message.text':
            'We will deliver paper statement copy to your registered mailing address by normal mail. It will take up to 10 working days for the statement to reach you. Please ensure your registered mailing address record is correct before proceeding to the next step.',
          'message.text.desktop':
            'We will deliver paper statement copy to your registered mailing address by normal mail. It will take up to 10 working days for the statement to reach you. Please ensure your registered mailing address record is correct before proceeding to the next step.'
        },
        email: {
          'message.text': 'Please validate your email record is correct before proceeding to the next step.',
          'message.text.desktop': 'Please validate your email record is correct before proceeding to the next step.'
        }
      },
      error: {
        noData: {
          customerNotEligible:
            'We are unable to process your request through digital channels. Kindly contact our Client Care Center or visit our nearest branch for assistance.',
          customerData: 'No eligible account for statement request.',
          nodebitAcc: 'Please select the delivery mode by email as you do not have any eligible account for charging.',
          addressRisk: 'Please update your mailing address before raising this service request. Thank you.'
        }
      },
      countryNotes: {
        default:
          'For statement request within 12 months, kindly download from our Online Banking &lt;eStatement & eAdvices&gt;.<br>You may request statement up to 7 years. For loan/financing facilities, statement is only applicable on half yearly basis.<br>Below are the charges for paper statement:<div><u>CREDIT CARD</u></div><ul><li>RM5 per copy for statement 36 months and below</li><li>RM10 per copy for statement above 36 months</li></ul><div><u>SAVINGS/CURRENT ACCOUNT</u></div><ul><li>RM5 for each monthly paper statement (waived for Basic Savings/Current Account)</li></ul><div><u>LOAN/FINANCING FACILITIES</u></div><ul><li>RM5 per cycle for statement within 1 year from date of first drawdown</li><li>RM10 per cycle for statement > 1 year after date of first drawdown</li></ul>',
        account:
          'For statement request within 12 months, kindly download from our Online Banking &lt;eStatement & eAdvices&gt;.<br>You may request statement up to 7 years. For loan/financing facilities, statement is only applicable on half yearly basis.<br>Below are the charges for paper statement:<div><u>CREDIT CARD</u></div><ul><li>RM5 per copy for statement 36 months and below</li><li>RM10 per copy for statement above 36 months</li></ul><div><u>SAVINGS/CURRENT ACCOUNT</u></div><ul><li>RM5 for each monthly paper statement (waived for Basic Savings/Current Account)</li></ul><div><u>LOAN/FINANCING FACILITIES</u></div><ul><li>RM5 per cycle for statement within 1 year from date of first drawdown</li><li>RM10 per cycle for statement > 1 year after date of first drawdown</li></ul>',
        statement:
          'For statement request within 12 months, kindly download from our Online Banking &lt;eStatement & eAdvices&gt;.<br>You may request statement up to 7 years. For loan/financing facilities, statement is only applicable on half yearly basis.<br>Below are the charges for paper statement:<div><u>CREDIT CARD</u></div><ul><li>RM5 per copy for statement 36 months and below</li><li>RM10 per copy for statement above 36 months</li></ul><div><u>SAVINGS/CURRENT ACCOUNT</u></div><ul><li>RM5 for each monthly paper statement (waived for Basic Savings/Current Account)</li></ul><div><u>LOAN/FINANCING FACILITIES</u></div><ul><li>RM5 per cycle for statement within 1 year from date of first drawdown</li><li>RM10 per cycle for statement > 1 year after date of first drawdown</li></ul>'
      }
    },
    TRANSFEROFPAYMENTS: {
      'header.title': 'Transfer of Payment - Credit Cards',
      'selectAccount.title': 'Select a Credit Card(s)',
      selectCard: 'Transfer amount from:',
      selectCardTo: 'Transfer amount to:',
      notes: {
        fromCard:
          '<ol><li>This service request allows you to transfer your recent payments credited, between your own credit cards.</li><li>Available Credit reflects total payments that we received after your last statement. Please allow 3 additional days from your payment date to be displayed.</li><li>The credit transfer will be reflected in your next billing statement.</li></ol>',
        toCard:
          '<ol><li>This service request allows you to transfer your recent payments credited, between your own credit cards.</li><li>Available Credit reflects total payments that we received after your last statement. Please allow 3 additional days from your payment date to be displayed.</li><li>The credit transfer will be reflected in your next billing statement.</li></ol>'
      },
      minimunAmtDue: 'Minimum Payment Due',
      totalPaymentCredit: 'Total Payment Credit',
      totalAmtDue: 'Total Amount Due',
      retainTxt: 'Select Amount to retain in this card:',
      transferableCredit: 'Transferable Credit*',
      dueDate: 'Due Date on',
      transferFrom: 'Transfer From',
      transferTo: 'Transfer To',
      'tooltip.fromCard': {
        default: 'There is no sufficient amount in your account to initiate the transfer.'
      },
      statusMsg: {
        success: 'Your request has been submitted.<br>We will send a confirmation SMS/Email in 1 working day.'
      },
      disableTADMsg:
        'You do not have sufficient Transferable Credit available in your credit card to initiate the request. Please select Minimum Payment Due to proceed with the request.',
      noCardTitile: 'No cards detected.',
      noCardMessage:
        'If you do not see the card you wish to make a transfer from, please contact our <a>24/7 Phone Banking</a> immediately.'
    }
  },
  FERE: {
    page: {
      fileUploadInfoText: 'File format should be in JPG, PNG, PDF, ZIP or EML. The file size must not exceed 5MB.'
    }
  }
};
