/* eslint-disable no-useless-escape */

export default {
  ServiceRequest: {
    LANDINGPAGE: {
      'header.title': 'Service request'
    },
    COMMON: {
      crsMessage: {
        CRSNTB:
          'You will not be able to proceed if you are not Tax Resident in at least one country. A tax resident of Nigeria means someone who has lived in Nigeria for at least 183 days (more than 6 months) in any 12 month period. Please contact your Tax Advisor for further information.'
      },
      crsProfielUpdate: {
        CRSETB:
          'Please update your Country of Tax Residency information to proceed with the request. Click on Service Requests -> Personal Details -> CRS Declaration to update details.',
        CRSNTB:
          'You will not be able to proceed if you are not Tax Resident in at least one country. A tax resident of Nigeria means someone who has lived in Nigeria for at least 183 days (more than 6 months) in any 12 month period. Please contact your Tax Advisor for further information.'
      }
    },
    CREDITCARD_ERROR_MAP: {
      'CSL-CC-301':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-302':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-303':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-304':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-305':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-306':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-307':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-308':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-312':
        'You have exceeded the PIN try limit. Kindly call our 24-hour Customer Care hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-313':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-314':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-315':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-422':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 or walk in to any of our branches for further assistance.',
      'CSL-CC-423':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 or walk in to any of our branches for further assistance.',
      'CSL-CC-409':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-417':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-407':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-416': 'Please enter Standard Chartered Credit Card for activation.',
      'CSL-CC-415':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-405':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-414':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-404':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-413':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-403':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-412':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-402':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-411':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-401':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-410':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline at 01 2704611 - 4 for further assistance.',
      'CSL-CC-418':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at  01 2704611 - 4 for further assistance.',
      'CSL-CC-316':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at  01 2704611 - 4 for further assistance.',
      'CSL-OTP-1328':
        'Sorry, due to maximum invalid OTP attempts you will not receive any OTP for transactions for the next 24 hours.',
      '1308':
        'You have entered invalid one-time password (OTP). Please check and re-enter your one time password(OTP). (Error Code:1308)',
      '1307': 'Your one-time password (OTP) had expired. Please request for a new OTP. (Error Code:1307)',
      'CSL-OTP-1024': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-OTP-1026': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.'
    }
  },
  generalDeclaration: {
    title: 'General Declaration',
    declaration:
      "<div class='modal-terms-condition'> <h3 class='general-info-head'>By accepting this application :</h3> <ol> <li>You represent and warrant that all information (including any documents) you have given to us in connection with the application is correct, complete and not misleading (If this is not the case you may be personally liable);</li> <li>You authorise us to verify any information you have given to us including your credit standing from anyone we may consider appropriate (such as an authority or credit reference agency) prior to providing any service (including loan processing) to you in connection with this application;</li> <li>You acknowledge that we may decline your application without giving you any reason for doing so. If this happens, no contractual relationship will arise between us and you;</li> <li>You affirm and declare that you have read and understood our Client Terms / Product Terms and Conditions / Online Terms and Conditions / Privacy Policy – and all other applicable documents referred to in our Client Terms forming our banking agreement which are provided on SC Mobile and available on our website at <a href='https://www.sc.com/ng'>www.sc.com/ng</a>. You acknowledge that you are bound by any variation we make to these documents in accordance with our banking agreement. In particular, you understand that by entering into our banking agreement you give relevant indemnities, authorisations, consents and waivers and agree to limitations on our liability;</li> <li>You consent to us contacting you through the physical addresses, e-mail addresses, phone numbers or any other contact details you have provided to us, for purposes of verification/authentication so as to enter into the banking agreement and/or to give you information on other products and services that we, or our strategic partners, may offer. In the event that you do not wish to receive any information about our products, services or offers of our strategic partners, you undertake to specifically advise us of this;</li> <li>You consent to us archiving, storing any information, including voice notes, videos and screenshots that we may obtain through (audio or video) calls or through text messages that we may partake in with you for verification/authentication so as to enter into the banking agreement;</li> <li>Where applicable, you agree that we will send electronic statements for your bank and loan accounts by email to the email addresses provided by you. However, we reserve the right to send paper correspondence and statements to your last known address as per our records;</li> <li>You consent to us and to each of our subsidiaries and affiliates (including each branch or representative office) (“Standard Chartered Group”) its officers, employees, agents and advisers disclosing information relating to you (including details of our banking agreement, the accounts, the products or any arrangement with us) to our head office and any other member of the Standard Chartered Group in any jurisdiction (“Permitted Parties”); your employer, professional advisers, service providers, Government population registration systems (whether located in or outside of Nigeria) for the purposes of providing any service to you in connection with this application (including but not limited to data processing and/or to use such existing data for verification purposes), or independent contractors to, or agents of, the Permitted Parties, such as debt collection agencies, data processing firms and correspondents who are under a duty of confidentiality to the permitted parties, any actual or potential participant or sub-participant in relation to any of our obligations under our banking agreement between us, or assignee, novatee or transferee (or any officer, employee, agent or adviser of any of them), any credit reference agency, rating agency, business alliance partner, insurer or insurance broker of, or direct or indirect provider of credit protection to, or any Permitted Parties; any court, tribunal or authority (including an authority investigating an offence) with jurisdiction over the Permitted Parties; a merchant or member of VISA International or Mastercard International where the disclosure is in connection with the use of a card; any authorized person or any security provider; anyone we consider necessary in order to provide you with the services in connection with an account;</li> <li>You acknowledge that we will register you for a prescribed set of SMS alerts, to be sent to the mobile telephone number registered with us;</li> <li>Subject to applicable local laws, you hereby consent for us and Standard Chartered PLC or any of its affiliates to share your information with domestic and overseas regulators or law enforcement authorities where this is necessary in our reasonable opinion.</li> <li>Where required by domestic or overseas regulators or tax authorities, you consent and agree that we may withhold from your account(s) such amounts as may be required under the applicable laws, regulations and directives.</li> <li>You undertake to notify us within 30 calendar days if there is a change in any information which you have provided to us.</li> <li>You acknowledge and agree that we have the right to set off any amount held in lien against which a credit facility has been granted to you by us or any other account you have with us that may have a credit balance, in the event of default. You authorise us to purchase such foreign currency with the monies standing to the credit of your account(s) as may be necessary, to effect the set off and settle any outstanding amount on the loan facility, where necessary to facilitate the offsetting of the facility in default. You agree that the lien will only be lifted upon full repayment of the facility(ies). You agree that you shall lay no claim whatsoever to the funds under lien until such time the facility is repaid in full.</li> <li>You agree that we are permitted (but not bound) to send this electronically executed application to you via email and that the terms and conditions and any instructions given herein shall have the same validity, admissibility and enforceability as if signed in physical form and you agree not to challenge the validity, admissibility or enforceability on the ground that our banking relationship or any part thereof was established on an electronic platform.</li> <li>You agree to provide your Taxpayer Identification Number (TIN) at account opening (where required), failing which you will be unable to operate the account until the TIN is provided.</li><li>You acknowledge that the information you have given us/Standard Chartered Bank in connection with this application and any related reportable account(s) may be provided, directly or indirectly, to any relevant tax authority, including the tax authorities of the country in which this account(s) is/are maintained and exchanged with tax authorities of another country or countries in which you may be resident for tax purposes pursuant to bilateral or multilateral agreements between governments to exchange financial account information.</li><li>You undertake to notify us/Standard Chartered Bank within 30 days of any change in circumstances which affects your tax residence status or where any information contained herein to become incorrect.</li><li> You certify that you are the account holder of all of the account(s) to which this information relates and declare that all statements made in this declaration are, to the best of your knowledge and belief, correct and complete.</li></ol></div>"
  }
};
