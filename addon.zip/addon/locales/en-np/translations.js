/* eslint-disable no-useless-escape */

export default {
  ServiceRequest: {
    COMMON: {
      genericError: {
        NP:
          "We've encountered an error with your request. Please cancel the request and try again. If the issue persists, please call our 24X7 Client Care Centre at 4781800 for immediate assistance."
      },
      'errorcard.content': 'Please contact 24X7 Client Care Center for immediate assistance.',
      systemError:
        "We've encountered an error with your request. Please cancel the request and try again. If the issue persists, please call our 24X7 Client Care Centre at 4781800 for immediate assistance.",
      cardTypenocardsDesc:
        'The selected account(s) to be linked does not have any eligible card for replacement. Kindly select other account(s) to proceed or contact our <a href="javascript:;">24X7 Client Care Center</a> for assistance.',
      contactLinksTxt: {
        default: '24X7 Client Care Center'
      }
    },
    LOANCLOSURE: {
      cardlistSubHeader:
        'If you do not see the card you wish to cancel in the list below, please contact our 24X7 Client Care Center immediately.',
      noCardsMessage:
        'If you do not see the card you wish to cancel in the list, please contact our 24X7 Client Care Center immediately.'
    },
    CREDITCARD: {
      pinSetup: {
        status: {
          transactionSuccessFailure: {
            NP:
              "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24X7 Client Care Centre at 4781800 for immediate assistance."
          },
          transactionSuccessInComplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24X7 Client Care Centre at 4781800"
        }
      },
      activation: {
        status: {
          transactionSuccessFailure: {
            NP:
              "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24X7 Client Care Centre at 4781800 for immediate assistance."
          },
          transactionSuccessInComplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24X7 Client Care Centre at 4781800"
        }
      }
    },
    CARDCANCELLATION: {
      noCardsMessage:
        'If you do not see the card you wish to cancel in the list, please contact our 24X7 Client Care Center immediately.',
      cardlistSubHeader:
        'If you do not see the card you wish to cancel in the list below, please contact our 24X7 Client Care Center immediately.'
    },
    CARDBLOCK: {
      cardlistSubHeader:
        'If you do not see the card you wish to block in the list below, please contact our 24X7 Client Care Center immediately.',
      countryNotes: {
        NP:
          'Upon confirmation, your card(s) will be blocked immediately and you will not be able to use it. Please note that a blocked card cannot be reactivated.<br>You will not be liable for any transactions on the card(s) after this report. Any existing card balances will be transferred to the new replacement card(s).<br>We will send the replacement card(s) to your mailing address in our records for Valley Branches and Pokhara Branch. For other branches, please visit the Bank to collect the cards. If you have previously reported a lost or stolen card, please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any Repayment Instruction to your new credit card if applicable. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.'
      },
      statusMsg: {
        NP: {
          failure:
            "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24X7 Client Care Centre at 4781800 for immediate assistance.",
          incomplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24X7 Client Care Centre at 4781800"
        }
      }
    },
    STATEMENTREQUEST: {
      notes:
        "Fee may be apply depending on the statement requested. Please check Bank's <a>fee schedule</a> for more information.<br> <br>Your statement will be sent to your registered mailing address. Please ensure your address is correct. Contact <a>24X7 Client Care Center</a> if you wish to update your address."
    },
    CCFEEWAVIER: {
      'text.systemError.content':
        'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24X7 Client Care Center for immediate assistance.',
      countryLinksTxt: {
        NP: '24X7 Client Care Center'
      },
      validationCountryNotes: {
        NP: 'Kindly contact our {{inter_link}} for further assistance.'
      },
      countryNotesTransactionPage: {
        NP: 'Displayed transactions are charges posted on the selected cards only.'
      },
      countryNotes: {
        NP:
          'For other fee waiver requests related to your credit card, please call our {{inter_link}} at 4781800. <br>Only credit card(s) that may be eligible will be shown. If you do not see your credit card, please call our {{inter_link}} at 4781800'
      }
    },
    TRANSFEROFPAYMENTS: {
      noCardMessage:
        'If you do not see the card you wish to make a transfer from, please contact our <a>24X7 Client Care Center</a> immediately.'
    },
    CARDREPLACEMENT: {
      countryNotes: {
        NP:
          'This request is for replacement of<ul><li>Damaged cards or</li><li>Cards that have already been reported lost/stolen</li></ul>Credit/Debit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/ stolen card, please use the Report Lost/Stolen Card Service Request.<br>We will send the replacement card(s) to your mailing address in our records for Valley Branches and Pokhara Branch. For other branches, please visit the Bank to collect the cards. If you have previously reported a lost or stolen card, please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any Repayment Instruction arrangement to your new credit card if applicable. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.'
      },
      statusMsg: {
        NP: {
          failure:
            "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24X7 Client Care Centre at 4781800 for immediate assistance.",
          incomplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our 24X7 Client Care Centre at 4781800"
        }
      }
    },
    CREDITBALANCEREFUND: {
      'phoneBankingHotline.text': {
        NP: '24/7 Phone Banking'
      },
      'notes.fromCard': {
        NP:
          '*To view and refund the exact amount including cents, please refer to your card balance in the main page.</br>*Excess Credit displayed is the excess credit card payment made by you, including the recent unbilled/unstatemented transactions.'
      }
    },
    genericRequest: {
      header: {
        title: {
          statusMsg:
            "Your request is submitted successfully for further processing. Thank You.<br>To check the status, go to the 'Status’ tab under Help & Services.",
          statusMsgReferral:
            'We have received your response to our query and will be processed within 3 working days. Thank you.<br>To check the status, go to the ‘Status’ tab under "Help & Services"'
        }
      },
      AMCSTINP: {
        title: 'Amendment / Cancellation of standing instruction',
        notemessage: {
          select:
            'This request is used for change amount or the date of execution or the cancellation of the standing instruction altogether.<br>Please ensure your email/mobile registered with us is valid before submitting this request. We will be communicating with you via email/SMS.<br>Standing Instruction requested for amendment or deletion has to be correctly.<br>The requests will take 24 business hours for execution.'
        }
      },
      NFDSETNP: {
        title: 'New Fixed Deposit Set-up',
        notemessage: {
          selectHeader: 'This request is used to set-up a new Fixed Deposit.',
          select:
            'Please ensure your email/mobile registered with us is valid before submitting this request. We will be communicating with you via email/SMS. In order to apply the Fixed Deposit through this channel<ul><li>You agree that; you have read, understood and accepted the <a href="javascript:;" onclick="window.open(\'https://www.sc.com/np/help-centre/download-centre.html\',\'_system\')">Terms & Conditions</a> pertaining to Fixed Deposit Application.</li><li>You agree with the prevailing <a href="javascript:;" onclick="window.open(\'https://www.sc.com/np/\',\'_system\')">Interest Rate</a>.</li><li>Only the clients who have already submitted the FATCA (Foreign Currency Tax Compliance Act) form to the bank are eligible to apply Fixed Deposit through this channel.</li><li>The requests will take 24 business hours for execution.</li><li>The copy of Fixed Deposit Confirmation advice will be sent to you in your email address registered with us. If you need the original advice, go to “Fixed Deposit Confirmation Advice in hard copy” navigation for the request under Create Request and Fixed Deposit option or you are requested to visit the branch where your account is maintained.</li></ul>',
          upload:
            'Please provide the amount in Figure & words<br>Please provide the tenure 3; 6; 12 months, or others.<br>Please provide the Interest Payment Cycle Quarterly or Upon Maturity<br>Please provide instruction at maturity :<ul><li>Uplift my/our deposit and credit the principal to my/our account along with any accrued interest.</li><li>Rollover principal along with Interest accrued thereon for a similar term at the rate interest prevailing at the time of renewal.</li><li>Rollover Principal and credit the interest to my/our Account.</li></ul>'
        }
      },
      DBREDYNP: {
        title: 'Debit Card redelivery',
        notemessage: {
          selectHeader:
            'This request is used to ask for re-delivery of the Debit Card; if your original request for Debit Card delivery is not successful.',
          select:
            'Please ensure your email/mobile registered with us is valid before submitting this request. We will be communicating with you via email/SMS.<br>Our representative will contact you once the card is ready for delivery.'
        }
      },
      CQREDYNP: {
        title: 'Cheque book redelivery',
        notemessage: {
          selectHeader:
            'This request is used to ask for re-delivery of the Cheque Book; if your original request for Cheque Book delivery is not successful.',
          select:
            'Please ensure your email/mobile registered with us is valid before submitting this request. We will be communicating with you via email/SMS.<br>Our representative will contact you once the Cheque Book is ready for delivery.'
        }
      },
      FDCNAHCY: {
        title: 'Fixed Deposit Confirmation Advice',
        notemessage: {
          select:
            'This request is used to ask for the Fixed Deposit Confirmation Advice in Hard Copy. Our representative will contact you once the Advice is ready for delivery.'
        }
      },
      NFDREREQ: {
        title: 'Fixed Deposit Renewal Request',
        notemessage: {
          selectHeader:
            'This request is used to request for renewal of existing Fixed Deposit which otherwise was set for upliftment at maturity.',
          select:
            'Please ensure your email/mobile registered with us is valid before submitting this request. We will be communicating with you via email/SMS.<br>In order to apply the Fixed Deposit through this channel.<ul><li>You agree that; you have read, understood and accepted the <a href="javascript:;" onclick="window.open(\'https://www.sc.com/np/help-centre/download-centre.html\',\'_system\')">Terms & Conditions</a> pertaining to Fixed Deposit Application.</li><li> You agree with the prevailing <a href="javascript:;" onclick="window.open(\'https://www.sc.com/np/\',\'_system\')">Interest Rate</a></li></ul><br>Only the clients who have already submitted the FATCA (Foreign Currency Tax Compliance Act) form to the bank are eligible to apply Fixed Deposit through this channel.<br>The requests will take 24 business hours for execution.<br>The copy of Fixed Deposit Confirmation advice will be sent to you in your email address registered with us. If you need the original advice, go to “Fixed Deposit Confirmation Advice in hard copy” navigation for the request under Create Request and Fixed Deposit option or you are requested to visit the branch where your account is maintained.',
          upload:
            'Please provide the tenure 3;6;12 months, or others <br>Please provide the Interest Payment Cycle Quarterly or Upon Maturity.<br>Please provide instruction at maturity :<ul><li>Uplift my/our deposit and credit the principal to my/our account along with any accrued interest.</li><li>Rollover principal along with Interest accrued thereon for a similar term at the rate interest prevailing at the time of renewal.</li><li>Rollover Principal and credit the interest to my/our Account.</li></ul>'
        }
      },
      CCSDTCNP: {
        title: 'Credit Card Statement Cycle Date Change',
        notemessage: {
          selectHeader: 'This request is used to change the date of statement generation for credit card',
          select:
            'Please ensure your email/mobile registered with us is valid before submitting this request. We will be communicating with you via email/SMS.',
          upload: 'Please provide the date on which you need the statement to be set up e.g 4th of every cycle.'
        }
      },
      SUPDETUD: {
        title: 'Supplementary Detail Update',
        notemessage: {
          selectHeader: 'This request is used to change personal information of supplementary card holder.',
          select:
            'Please ensure your email/mobile registered with us is valid before submitting this request. We will be communicating with you via email/SMS.<br>Name & Date of Birth change of existing supplementary card holder will require supporting documents.'
        }
      },
      LONCLTNP: {
        title: 'Loan Closure Letter',
        notemessage: {
          selectHeader: 'This request is used to request for the letter of confirmation of loan closure',
          select:
            'Please ensure your email/mobile registered with us is valid before submitting this request. We will be communicating with you via email/SMS.'
        }
      },
      COFORDNP: {
        title: 'Copy of Original Documents',
        notemessage: {
          selectHeader:
            'This request is used to ask for the photocopy of the original security document held by the bank as a part of loan application.',
          select:
            ' Please ensure your email/mobile registered with us is valid before submitting this request. We will be communicating with you via email/SMS.'
        }
      }
    },
    duplicateStatement: {
      error: {
        startDate: {
          error1: 'Start date should not be less than 1 year'
        },
        endDate: {
          error1: 'End date should not be less than 1 year'
        }
      },
      countryNotes: {
        statement:
          'eStatement will be delivered to your email address registered with us. Please ensure your email address is updated.'
      }
    },
    signatureUpdate: {
      header: {
        title: {
          accountSelectLabel: 'Select the Account(s) you wish to update:',
          selectProduct: 'Select Product',
          step1label: 'Step 1: Capture your Signature',
          step2label: 'Step 2: Review Scanned Signature',
          accountTypeLbl: 'Current/Savings Accounts',
          instruction1: 'Sign your signature on white paper.',
          instruction2:
            'Place your signature on a flat surface. Ensure that your signature is not positioned upside-down.<br><br>Take a picture of your signature with your camera in landscape mode. You may also upload an existing picture of your signature from your phone. (PNG, JPEG format only , max File Size 5MB)',
          instruction3:
            'Take a picture of your signature with your camera in landscape mode. You may also upload an existing picture of your signature from your phone. (PNG, JPEG format only , max File Size 5MB)',
          instruction4:
            "You may send us only one signature per update. For joint-accounts, you will have sign-in to your partner's account to update their signature.",
          reviewInstruction:
            ' Please review the captured image below to ensure that your signature is not positioned upside-down and all details are not out of focus or missing due to glare or shadow.',
          reviewlbl: 'REVIEW SCANNED SIGNATURE',
          requestProcessed: 'Your request is being processed!',
          statusInfoDesktop1:
            'We will send you notifications when there are updates or if we require more information from you.',
          statusInfoDesktop2:
            'Stay updated on all your service requests on the "Help & Services" page by going on to the "Status" section.',
          refNo: ' Reference Number',
          statusNoteInfo: 'Please quote this reference number for all future correspondences related to this request.'
        },
        countryNotes:
          '<ol><li>The scanned copy of the proposed new signature should be clear and legible for bank use.</li><li>In case of joint account- full name of the person whose signature is being updated should be provided.</li></ol>'
      }
    }
  }
};
