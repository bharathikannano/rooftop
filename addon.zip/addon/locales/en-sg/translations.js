export default {
  ServiceRequest: {
    COMMON: {
      button: {
        resetAnotherCards: 'Change Another Pin'
      },
      termsAndConditions:
        'Note: This feature allows you to temporarily block transactions on your Stan Chart Credit Card. This is applicable only for transactions posted real time via VISA/Mastercard gateways. Please refer to T&Cs for more details.<br><br><ol><li>These terms and conditions ("Terms") apply to your use of the Card Settings service provided by Standard Chartered.</li><br/><li>The Card Settings service is provided as part of the Bank’s <i>electronic banking services</i>, and accordingly:<ol><li>these Terms are in addition to and shall be read with the Customer Terms, our privacy notice published in our website and any other documents forming part of our banking agreement (and any reference to the terms and conditions of the Customer Terms shall include reference to these Terms).</li><br/><li>The meaning of key words printed <i>like this</i> is explained in the Customer Terms unless defined in these Terms. The Customer Terms may be accessed at sc.com/ae.</li><br/><li>In the event of any conflict or inconsistency, these Terms shall prevail over the Customer Terms to the extent of such conflict or inconsistency.</li><br/></ol></li><br/><li>The Card Settings service allows you to enable certain control settings on your credit card that are switched via the relevant card association (i.e. Visa or MasterCard in this case). While this covers the majority of transactions on your <i>credit card</i>, there are certain instances where the settings enabled by you under the Card Settings service will not work. Such instances include, without limitation as below:<ol><li>If your <i>credit card</i> has a Visa or MasterCard badge in addition to another <i>card association</i> or domestic network badge, and at the time of the transaction you or the <i>merchant</i> opt to switch it via that other <i>card association</i> or domestic network;</li><br/><li>When you make a withdrawal at an ATM (this is because many transactions using the ATM are not switched via the relevant <i>card association</i> (i.e. Visa or MasterCard in this case));</li><br/><li>When your card is used for a recurring transaction; the Card Settings service does not block your recurring transactions in order to not interfere with your ongoing subscription or bill payments; and</li><br/><li>When you enable a setting under the Card Settings service to control the type of transaction or merchant category to use your <i>credit card</i> for and the <i>merchant</i> or merchant acquirer has not conformed to the relevant <i>card association</i> (i.e. Visa or MasterCard in this case)\'s mandatory Payment Card Industry (PCI) compliance requirements by providing accurate information about the merchant category code ("MCC") and type of transaction that it accepts.</li><br/></ol></li><br/><li>There is a specific setting under the Card Settings service which you can enable to block overseas card transactions. It is important to note that this feature or setting applies only to card-present transactions. When you block overseas card transactions under the Card Settings service, you remain able to make card-not-present transactions i.e. Mail Order/Telephone Order ("MOTO") and ecommerce transactions. This means that you will still be able to use your <i>credit card</i> for e-commerce transactions and MOTO transactions whether the transaction amount is in local or foreign currency.</li><br/><li>By using the Card Settings service, you acknowledge and agree that:<ol><li>You are a registered and valid user of our <i>mobile banking services</i>;</li><br/><li>We may send notices and communications to you electronically including by fax, email or SMS in the event you make a transaction on your credit card which triggers the settings which you have enabled under the Card Settings service; in the event that you have registered to use the Notification Hub service, we may send you such notices and communications via the Notification Hub service (which utilises Push Notification) as the main communication channel by electronic means or any other communication channels that we so choose;</li><br/><li>You consent to the use and disclosure of your credit card information (including but not limited to <i>credit card</i> account number) and the settings enabled by you under the Card Settings service to the relevant <i>card association</i> (i.e. Visa or MasterCard in this case) for the purpose of the relevant <i>card association</i> (i.e. Visa or MasterCard in this case) in assisting the Bank to provide the Card Settings service;</li><br/><li>You are aware of the instances under Section 3 above where certain settings enabled by you under the Card Settings service do not work; and</li><br/><li>You are aware that when you block overseas card transactions under the Card Settings service, you remain able to make card-not-present transactions i.e. MOTO transactions and e-commerce transactions as mentioned under Section 4 above.</li><br/></ol></li><br/><li>You may access the Card Settings service to change or reset your settings at any time by [using the navigation menu of the <i>mobile app</i>] once you are signed into the <i>mobile app</i>. To change any settings, you will need to log in to the <i>mobile app</i> and undergo additional security authentication. If you do not use the Card Settings service, your credit card will still work and remain subject to any usage restrictions imposed by the relevant <i>card association</i> (i.e. Visa or MasterCard in this case) or by the Bank.</li><br/><li>If you inform us that the security of your <i>mobile app or security code</i> has been compromised or that the <i>electronic equipment</i> which you use to access any <i>electronic banking services</i> is lost or stolen, we may require you to change the <i>security code</i>, re-register for the Card Settings service or cease the use of the Card Settings service.</li><br/><li>You understand the need to protect your mobile device and shall be responsible for all use of your mobile device (whether authorised by you or otherwise) to access the Card Settings service.</li><br/><li>In addition to the disclaimers and your liability stated in our Customer Terms (as found in the link above):<ol><li>We do not represent or warrant that the Card Settings service will be accessible at all times, or function with any electronic equipment, software, infrastructure or other <i>electronic banking services</i> that we may offer from time to time;</li><br/><li>The Card Settings service is intended as a tool to help you stay in control of the use of your <i>credit card</i> and combat fraud. Standard Chartered Bank does not guarantee that the settings enabled by you under the Card Settings service will be applied to the rule categories or payment control types you had intended for and we cannot be held responsible for unintended consequences of using the Card Settings service;</li><br/><li>We are not responsible for any erroneous or fraudulent MCC used to classify the business of the <i>merchant</i> as provided by the <i>merchant</i>, merchant acquirer or <i>card association</i>;</li><br/><li>Unless a law prohibits us from excluding or limiting our liability, we are not liable for any loss you incur in connection with the use or attempted use of the Card Settings service, or your instructions, or any unauthorised transactions through or in connection with the Card Settings service;</li><br/><li>You shall indemnify us from all loss and damage which we may incur in connection with any improper use of the Card Settings service; and</li><br/><li>You are personally responsible for the security of your mobile or communications device.</li><br/></ol></li><br/></ol>'
    },
    CREDITCARD: {
      pinSetup: {
        journeyHeader: 'Credit Card Pin Change',
        status: {
          transactionSuccessMsg: 'Your 5-digit Pin has been changed successfully'
        }
      },
      cardSetting: {
        countryLimitsPage: {
          countryNotifications: 'Enable Overseas Transactions'
        }
      },
      sgNotStaffAssist: {
        notes: 'By submitting this request, you are agreeing to the terms as set out in our '
      }
    },
    CREDITCARD_ERROR_MAP: {
      'CSL-CC-301':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-302':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-303':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-304':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-305':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-306':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-307':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-308':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-312':
        'You have exceeded the PIN try limit. Kindly call our 24-hour Customer Care hotline at +65 6747 7000 for further assistance.',
      'CSL-CC-313':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-314':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-315':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-422':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline at +65 6747 7000 or walk in to any of our branches for further assistance.',
      'CSL-CC-423':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline at +65 6747 7000 or walk in to any of our branches for further assistance.',
      'CSL-CC-409':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-417':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-407':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-416': 'Please enter Standard Chartered Credit Card for activation.',
      'CSL-CC-415':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-405':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-414':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-404':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-413':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-403':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-412':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-402':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-411':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-401':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-410':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-418':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-316':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-OTP-1328':
        'Sorry, due to maximum invalid OTP attempts you will not receive any OTP for transactions for the next 24 hours.',
      'CSL-SEC-519': 'Max retry attempt reached, kindly reset.',
      '1308':
        'You have entered invalid one-time password (OTP). Please check and re-enter your one time password(OTP). (Error Code:1308)',
      '1307': 'Your one-time password (OTP) had expired. Please request for a new OTP. (Error Code:1307)',
      'CSL-OTP-1024': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-OTP-1026': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-CC-324':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-325':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-424':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-425':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-426':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-427':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-428':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-429':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-430':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.'
    },
    CARDCANCELLATION: {
      countryNotes: {
        SG:
          '<ol><li><b>If you are expecting any refund or payment of any Cashback</b>, please apply to cancel your card after you have received those payments. In the event there is any balance on the card from a refund or Cashback after it has been cancelled, please make arrangements for how you would like to receive payment.</li><li>Your selected card(s) will be temporarily blocked upon submission of the request. Please note that we may need to call you after submission of your request to confirm further details.</li><li>Please note that any supplementary cards will also be cancelled when you cancel the main card.</li><li>If you have any recurring payment arrangements, such as GIRO or standing instructions, please notify the merchant(s) immediately to cancel any further payments to the card.</li><li>If there are any transactions that are not yet posted to your card, they will be reflected in subsequent statements. Please continue to pay your outstanding balances.</li><li>Any existing rewards points and cashback that has not been posted will automatically be forfeited. If you wish to utilise your rewards points, please redeem your points before cancelling the credit card.</li><li>Existing fees and charges, excluding annual fees, are still applicable. Refer to our <a href="https://www.sc.com/sg/terms-and-conditions/" target="_blank"> credit cards terms and conditions</a> for more details.</li></ol>'
      },
      confirmationNotes: {
        SG:
          '<ol><li><b>If you are expecting any refund or payment of any Cashback</b>, please apply to cancel your card after you have received those payments. In the event there is any balance on the card from a refund or Cashback after it has been cancelled, please make arrangements for how you would like to receive payment.</li><li>Your selected card(s) will be temporarily blocked upon submission of the request. Please note that we may need to call you after submission of your request to confirm further details.</li><li>Please note that any supplementary cards will also be cancelled when you cancel the main card.</li><li>If you have any recurring payment arrangements, such as GIRO or standing instructions, please notify the merchant(s) immediately to cancel any further payments to the card.</li><li>If there are any transactions that are not yet posted to your card, they will be reflected in subsequent statements. Please continue to pay your outstanding balances.</li><li>Any existing rewards points and cashback that has not been posted will automatically be forfeited. If you wish to utilise your rewards points, please redeem your points before cancelling the credit card.</li><li>Existing fees and charges, excluding annual fees, are still applicable. Refer to our <a href="https://www.sc.com/sg/terms-and-conditions/" target="_blank"> credit cards terms and conditions</a> for more details.</li></ol>'
      }
    },
    CCFEEWAVIER: {
      countryNotes: {
        SGNOTSTAFFASSIST: 'By submitting this request, you are agreeing to the terms as set out in our'
      },
      countryLinks: {
        SG: {
          notStaffAssist: {
            sgNonStaffAssistCollapsiblePanel:
              '<ul><li>Only the credit card late fee amount displayed can be reversed in the account(s) selected if approved by the Bank</li><li>By submitting this request, you are agreeing to the terms as set out in our <a href="javascript:;" onclick="window.open(\'https://av.sc.com/sg/content/docs/scb-cc-tc.pdf\',\'_system\')">Credit Card Terms</a>,<a href="javascript:;" onclick="window.open(\'https://av.sc.com/sg/content/docs/scb-sg-customer-terms-updated.pdf\',\'_system\')">Customer Terms</a> and <a href="javascript:;" onclick="window.open(\'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf\',\'_system\')">Pricing Guide</a></li></ul>',
            sgNonStaffAssistPopText:
              'By submitting this request, you are agreeing to the terms as set out in our <a href="javascript:;" onclick="window.open(\'https://av.sc.com/sg/content/docs/scb-cc-tc.pdf\',\'_system\')">Credit Card Terms</a>,<a href="javascript:;" onclick="window.open(\'https://av.sc.com/sg/content/docs/scb-sg-customer-terms-updated.pdf\',\'_system\')">Customer Terms</a> and <a href="javascript:;" onclick="window.open(\'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf\',\'_system\')">Pricing Guide</a>'
          }
        }
      }
    },
    genericRequest: {
      header: {
        title: {
          statusMsgReferralCCSTDATC:
            'We have received your response to our query. If successful, please note that your new credit card cycle will be effective from the next statement.<br>As we are currently experiencing a high volume of requests, we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.',
          CUSTOMERLbl:
            'Please select from our range of service requests available under the Help & Service menu. If you are unable to find a suitable request, please describe your request in the section below.',
          statusMsgCUSTOMER:
            'Thank you. Your request has been submitted and will be processed.<br><br>Please expect a delay in processing as we are currently experiencing a high volume of requests. We will attend to your request as soon as possible. Thank you for your patience and understanding.<br><br>You may refer to your Secure Mailbox for status updates or view your submitted request under "Sent Items".'
        }
      },
      MORTREPR: {
        title: 'Mortgage Repricing',
        notemessage: {
          select:
            'This request is for the revision of your Mortgage Loan interest rate package.<br>Please ensure your email address registered with us is valid before submitting this request as we will be communicating with you via your registered email.<br>Please note that your Mortgage Loan should not be within any lock-in period. Penalty charges will apply if you reprice your housing loan within the lock-in period.<br>Please refer to the terms <u><a href="javascript:;" onclick="window.open(\'https://www.sc.com/sg/borrow/mortgages/loanrepricing/\',\'_system\')">here</a></u> for our Mortgage rates. The Bank reserves the right to revise the packages at the Bank’s discretion.<br>Repricing is subject to the Bank’s approval.',
          upload:
            'This request is for the revision of your Mortgage Loan interest rate package.<br>Please ensure your email address registered with us is valid before submitting this request as we will be communicating with you via your registered email.<br>Please note that your Mortgage Loan should not be within any lock-in period. Penalty charges will apply if you reprice your housing loan within the lock-in period.<br>Please refer to the terms <u><a href="javascript:;" onclick="window.open(\'https://www.sc.com/sg/borrow/mortgages/loanrepricing/\',\'_system\')">here</a></u> for our Mortgage rates. The Bank reserves the right to revise the packages at the Bank’s discretion.<br>Repricing is subject to the Bank’s approval.'
        }
      },
      CCINACCR: {
        title: 'Early Payment of Credit Card Instalment Plan',
        notemessage: {
          select:
            'This request is for an early payment of your existing credit card instalment plan.<br>Please refer to your latest credit card statement and provide the following information:<ul><li><b>Full description of the instalment plan transaction, and</b></li><li><b>Exact monthly instalment amount billed</b></li></ul><br>Please note that there can only be one credit card instalment plan acceleration per request.<br>For the redemption of a loan, please submit a Closure of CashOne/Credit Card Instalment Loan request instead.',
          upload:
            'This request is for an early payment of your existing credit card instalment plan.<br>Please refer to your latest credit card statement and provide the following information:<ul><li><b>Full description of the instalment plan transaction, and</b></li><li><b>Exact monthly instalment amount billed</b></li></ul><br>Please note that there can only be one credit card instalment plan acceleration per request.<br>For the redemption of a loan, please submit a Closure of CashOne/Credit Card Instalment Loan request instead.'
        }
      },
      CCSTDATC: {
        title: 'Credit Card Statement Cycle Date Change',
        notemessage: {
          select:
            "This request is to change your credit card's statement cycle date.<br>Please provide the following information:<ul><li>A new statement cycle date from the 3rd to the 27th of the month</li></ul><br>Your request will be processed and once it is approved:<ul><li>The statement due date, which is approximately 22 days from the statement cycle date, will be adjusted accordingly.</li><li>The new statement cycle date will be effective for all the credit cards you hold with the Bank, regardless of the number of credit cards you have selected in this request.</li><li>The new statement cycle will also be effective for all the other accounts under the same consolidated statement (if applicable).</li></ul><br>The change in statement cycle date will start after the current statement due date and before the next statement generation date (i.e. your existing statement cycle date).",
          upload:
            "This request is to change your credit card's statement cycle date.<br>Please provide the following information:<ul><li>A new statement cycle date from the 3rd to the 27th of the month</li></ul><br>Your request will be processed and once it is approved:<ul><li>The statement due date, which is approximately 22 days from the statement cycle date, will be adjusted accordingly.</li><li>The new statement cycle date will be effective for all the credit cards you hold with the Bank, regardless of the number of credit cards you have selected in this request.</li><li>The new statement cycle will also be effective for all the other accounts under the same consolidated statement (if applicable).</li></ul><br>The change in statement cycle date will start after the current statement due date and before the next statement generation date (i.e. your existing statement cycle date)."
        }
      },
      DBEMNAMC: {
        title: 'Debit /ATM Card Embossed Name Change',
        notemessage: {
          select:
            'This request is for a change of embossed name for your selected debit/ATM card.<br>Please provide the following information:<ul><li><b>Preferred (new) embossed name</b></li></ul><br>The characters allowed is between 3 and 19 characters, including spacing. Special characters like symbols and numbers are not allowed.<br>Once ready, the replacement card with new embossed name will be sent to your account’s mailing address in our records.<br>Please note you may need to update your existing card billing and payment arrangements (if any) after receiving your replacement card.<br>For replacement of damaged card, please submit a Card Replacement request instead.',
          upload:
            'This request is for a change of embossed name for your selected debit/ATM card.<br>Please provide the following information:<ul><li><b>Preferred (new) embossed name</b></li></ul><br>The characters allowed is between 3 and 19 characters, including spacing. Special characters like symbols and numbers are not allowed.<br>Once ready, the replacement card with new embossed name will be sent to your account’s mailing address in our records.<br>Please note you may need to update your existing card billing and payment arrangements (if any) after receiving your replacement card.<br>For replacement of damaged card, please submit a Card Replacement request instead.'
        }
      },
      CCEMNAMC: {
        title: 'Credit Card Embossed Name Change',
        notemessage: {
          select:
            'This request is for a change of embossed name for your selected credit card.<br>Please provide the following information:<ul><li><b>Is the new embossed name is for the Principal or Supplementary card holder,</b></li><li><b>Both the current embossed name and preferred (new) embossed name</b></li></ul><br>The characters allowed is between 3 and 19 characters, including spacing. Special characters like symbols and numbers are not allowed.<br>Once ready, the replacement card with new embossed name, as well as a new principal card (if applicable) and any supplementary card(s), will be sent to your mailing address in our records.<br>Please note that this request impacts the card details for all cards in this credit card account. You may need to update your existing card billing and payment arrangements (if any) after receiving your replacement card.<br>For replacement of damaged card, please submit a Card Replacement request instead.',
          upload:
            'This request is for a change of embossed name for your selected credit card.<br>Please provide the following information:<ul><li><b>Is the new embossed name is for the Principal or Supplementary card holder,</b></li><li><b>Both the current embossed name and preferred (new) embossed name</b></li></ul><br>The characters allowed is between 3 and 19 characters, including spacing. Special characters like symbols and numbers are not allowed.<br>Once ready, the replacement card with new embossed name, as well as a new principal card (if applicable) and any supplementary card(s), will be sent to your mailing address in our records.<br>Please note that this request impacts the card details for all cards in this credit card account. You may need to update your existing card billing and payment arrangements (if any) after receiving your replacement card.<br>For replacement of damaged card, please submit a Card Replacement request instead.'
        }
      },
      NISSUATM: {
        title: 'Debit/ATM Card New Issuance',
        notemessage: {
          select:
            'This request is for the issuance of a new debit/ATM card for your selected Current/Savings account.<br>Please provide the following information:<ul><li><b>Preferred embossed name for your debit/ATM card</b></li></ul><br>An eligible card will be issued based on the account type.<br>The characters allowed is between 3 and 19 characters, including spacing. Special characters like symbols and numbers are not allowed.<br>Once ready, the new card will be sent to your account’s mailing address in our records.<br>For replacement of damaged card, please submit a Card Replacement request instead.',
          upload:
            'This request is for the issuance of a new debit/ATM card for your selected Current/Savings account.<br>Please provide the following information:<ul><li><b>Preferred embossed name for your debit/ATM card</b></li></ul><br>An eligible card will be issued based on the account type.<br>The characters allowed is between 3 and 19 characters, including spacing. Special characters like symbols and numbers are not allowed.<br>Once ready, the new card will be sent to your account’s mailing address in our records.<br>For replacement of damaged card, please submit a Card Replacement request instead.'
        }
      },
      LINKMAIT: {
        title: 'Link/delink Your Account(s) To Card',
        notemessage: {
          select:
            'This request is to link/delink a Current or Savings account to/from the selected card.<br>Please provide the following information:<ul><li><b>Account number, and</b></li><li><b>Instruction to link/delink account</b></li></ul><br>Each eligible card can be linked to a maximum of 1 Current account and 1 Savings account.<br>Account linkage to credit cards is only applicable for the principal card holder.<br>If a card that is not multi-currency enabled is linked to a multi-currency account, you may only be able to access the SGD funds in your account. Please refer to the relevant website and terms for details.<br>USD High Debit card can only be linked to either: <ul><li>USD$aver account, or</li><li>USD High account</li></ul>',
          upload:
            'This request is to link/delink a Current or Savings account to/from the selected card.<br>Please provide the following information:<ul><li><b>Account number, and</b></li><li><b>Instruction to link/delink account</b></li></ul><br>Each eligible card can be linked to a maximum of 1 Current account and 1 Savings account.<br>Account linkage to credit cards is only applicable for the principal card holder.<br>If a card that is not multi-currency enabled is linked to a multi-currency account, you may only be able to access the SGD funds in your account. Please refer to the relevant website and terms for details.<br>USD High Debit card can only be linked to either: <ul><li>USD$aver account, or</li><li>USD High account</li></ul>'
        }
      }
    },
    duplicateStatement: {
      header: {
        title: {
          statusMsg:
            "Your request has been submitted and will be processed. <br><br> We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br><br>To check the status, go to the 'Status’ tab under Help & Services.",
          subInprogress: 'Your request is being submitted'
        },
        subTitle: {
          select: 'Please select the product you require statement(s) for:',
          product: 'Please select the account that you require a statement for:',
          account: 'Select a debit account for the relevant charges to be deducted from'
        },
        panelTitle: {
          select: 'Select Product',
          product: 'Select Account',
          statement: 'Enter your account details',
          account: 'Debiting Account Selection'
        }
      },
      pageLabels: {
        startDate: 'Start of statement cycle date',
        endDate: 'End of statement cycle date',
        product: 'Product Selected',
        ConfirmProduct: 'Selected Account',
        deliveryModeconfirm: 'Statement Type',
        debitedAccount: 'Account to be debited for statement request charges',
        address: {
          'message.text': 'We will send the paper statement(s) to your account mailing address.',
          'message.text.desktop': 'We will send the paper statement(s) to your account mailing address.'
        },
        email: {
          'message.text':
            'We will send the eStatement(s) to your registered email address. Please ensure your email address is up-to-date before proceeding.',
          'message.text.desktop':
            'We will send the eStatement(s) to your registered email address. Please ensure your email address is up-to-date before proceeding.'
        },
        deliveryMode: {
          text: 'How would you like to receive your statement?',
          email: 'eStatement',
          address: 'Paper Statement'
        }
      },
      countryNotes: {
        default:
          '<div>Depending on your statement cycle, you may have to request for 2 statements to obtain all transaction details in an entire month.</div><div>For example, if your statement cycle starts and ends on the 15th of each month and you want statement to reflect all the transactions in January - enter "01/2020" and "02/2020" as you will need your Febuary statement as well to include all transactions from 15th to 31st January.</div><br>If you have requested for paper statement to be mailed to you, we will send it to your account\'s mailing address that you have registered with us.<br>Please ensure your email address/mailing address with us is up-to-date before submitting this request. <br>Charges may apply. Please ensure there are sufficient funds in your debit account before you submit a request. You may refer to our pricing guide <a href="javascript:;" onclick="window.open(\'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf\',\'_system\')">here</a> for more details.<br>eStatements are available for retrieval via Online Banking and SC Mobile for up to 18 months progressively without any charge. ',
        statement:
          '<div>Depending on your statement cycle, you may have to request for 2 statements to obtain all transaction details in an entire month.</div><div>For example, if your statement cycle starts and ends on the 15th of each month and you want statement to reflect all the transactions in January - enter "01/2020" and "02/2020" as you will need your Febuary statement as well to include all transactions from 15th to 31st January.</div><br>If you have requested for paper statement to be mailed to you, we will send it to your account\'s mailing address that you have registered with us.<br>Please ensure your email address/mailing address with us is up-to-date before submitting this request. <br>Charges may apply. Please ensure there are sufficient funds in your debit account before you submit a request. You may refer to our pricing guide <a href="javascript:;" onclick="window.open(\'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf\',\'_system\')">here</a> for more details.<br>eStatements are available for retrieval via Online Banking and SC Mobile for up to 18 months progressively without any charge. ',
        account:
          '<div>Depending on your statement cycle, you may have to request for 2 statements to obtain all transaction details in an entire month.</div><div>For example, if your statement cycle starts and ends on the 15th of each month and you want statement to reflect all the transactions in January - enter "01/2020" and "02/2020" as you will need your Febuary statement as well to include all transactions from 15th to 31st January.</div><br>If you have requested for paper statement to be mailed to you, we will send it to your account\'s mailing address that you have registered with us.<br>Please ensure your email address/mailing address with us is up-to-date before submitting this request. <br>Charges may apply. Please ensure there are sufficient funds in your debit account before you submit a request. You may refer to our pricing guide <a href="javascript:;" onclick="window.open(\'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf\',\'_system\')">here</a> for more details.<br>eStatements are available for retrieval via Online Banking and SC Mobile for up to 18 months progressively without any charge. '
      },
      error: {
        commonError: {
          statmentInprogress:
            "There is already an existing statement request submitted for processing. To check on the status of your requests, go to 'Status' tab under Help & Services."
        },
        noData: {
          loan: 'You do not have any eligible loan(s) for this request.',
          casa: 'You do not have any eligible account(s) for this request.',
          nodebitAcc: 'You do not have eligible account(s) to be debited for this request.',
          default: 'You do not have any eligible card(s) for this request.'
        }
      }
    },
    signatureUpdate: {
      header: {
        title: {
          step1: 'Step 1:',
          step2: 'Step 2:',
          step3: 'Step 3:',
          accountSelectLabel: 'Select the account(s) you wish to update:',
          selectProduct: 'Select Account(s)',
          step1label: 'Capture your Signature',
          step2label: 'Review Signature',
          accountTypeLbl: 'Current/Savings Accounts',
          timeaccountLbl: 'Time Deposit',
          instruction1: 'Sign your name on a blank piece of white paper (preferably with a black ink)',
          instruction2: 'Take a portrait picture of your signature',
          desktopInstruction2: 'Take a picture of your signature',
          instruction3:
            'Upload a picture of your signature in PNG, JPG, JPEG format only(max file size 5MB) in the next step.',
          reviewInstruction:
            'Please review and ensure that the image of your signature below is accurately positioned and not out of focus.',
          requestProcessed: 'Submitted',
          statusInfoDesktop1: 'Your request has been submitted and will be processed.',
          statusInfoDesktop2:
            'We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding',
          statusInfoDesktop3: "To Check the status, go to 'Status' tab under Help & Services",
          statusNoteInfo: 'Please quote this reference number for all future correspondences related to this request.',
          desktopUploadInstruction:
            'Sign your signature on white paper. Upload a picture of your signature from your computer.(PNG, JPG, JPEG format only. Max File Size 5MB)'
        },
        countryNotes:
          '<ul><li>Your request to update your signature record with the Bank only applies to account(s) under your personal name.</li><li>To update your signature records for joint account(s), the joint account holder(s) will have to login and submit a separate request.</li><li>Please note that your updated signature record for your current and/or savings account(s) will also apply to your investment account(s), if any.</li><li>Please continue to use your existing signature record until you receive a confirmation of your updated signature from us.</li></ul>'
      }
    }
  },
  FERE: {
    page: {
      fileUploadInfoText: 'File format should be in JPG, PNG, PDF, ZIP or EML. The file size must not exceed 5MB.'
    }
  }
};
