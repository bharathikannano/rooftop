/* eslint-disable no-useless-escape */

export default {
  FERE: {
    action: {
      modal: {
        message: 'Are you sure you want to leave the form without submitting?',
        resetMessage: 'Are you sure you want to revert the change?',
        quitApp: {
          title: 'Quit Application?',
          messageEmailSms: 'An Email and SMS will be sent with a link to continue your application.',
          messageProgressLost: 'Your current progress will be lost.'
        }
      },
      button: {
        confirm: 'CONFIRM',
        cancel: 'CANCEL',
        YES: 'YES',
        NO: 'NO',
        edit: 'Edit',
        reset: 'RESET',
        save: 'SAVE',
        close: 'CLOSE'
      }
    },
    validation: {
      error: {
        labelNameError: 'should be less than the account balance',
        message: ' is required',
        dateExpired: 'The date is expired',
        dateInvalid: 'The date is invalid / Incorrect date format.',
        dateFuture: 'The future date is unavailable.',
        invalidCard: 'Invalid card number.',
        invalidEmiratesId: 'Your Emirates ID Number is invalid',
        invalidResidentialCountry: 'Please select a valid residential country.',
        invalidGender: 'Please select a valid title, this does not match your earlier selected gender.'
      }
    },
    page: {
      receipt: {
        title: 'Reference Number',
        description: 'Please quote this reference number for all future correspondences related to this request.',
        'button.blocked': 'NEXT',
        failed: 'Failed!'
      },
      jumpTolabel: 'Jump to Section',
      step: 'of',
      top: 'TOP',
      loading: 'Loading...',
      fileUploadInfoText: 'File format should be in JPG, PNG or PDF. The combined total file size must not exceed 10MB.'
    }
  },
  ServiceRequest: {
    COMMON: {
      subCategoryText: {
        pinChange: 'Debit Card Pin Change'
      },
      genericError: {
        VN:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our Client Care Center (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for immediate assistance.'
      },
      systemError:
        'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our Client Care Center (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for immediate assistance.',
      'systemError.title': 'System Error',
      button: {
        okDone: 'OK'
      },
      termsAndConditions:
        '<ol><li>These terms and conditions ("Terms") apply to your use of the Card Settings service provided by Standard Chartered (Vietnam) Limited (“the Bank" or “we” or “Standard Chartered”).</li><li>The Card Settings service is provided as part of the Bank’s <i>electronic banking services</i>, and accordingly:<ol><li>these Terms are in addition to and shall be read with the General Terms and Conditions, our privacy notice published in our website and any other documents forming part of our banking agreement (and any reference to the terms and conditions of the General Terms and Conditions shall include reference to these Terms).</li><li>The meaning of key words printed <i>like this</i> is explained in the General Terms and Conditions unless defined in these Terms. The General Terms and Conditions may be accessed on our public website.</li><li>In the event of any conflict or inconsistency, these Terms shall prevail over the General Terms and Conditions to the extent of such conflict or inconsistency.</li></ol></li><li>The Card Settings service allows you or an <i>authorized person</i> to enable the following control settings on your <i>card</i>:<ol><li>Temporary lock/block;</li><li>Notification or declining of overseas card-present transactions;</li><li>Transaction limit;</li><li>Types of transactions/payment channels; and</li><li>Notification of merchant categories.</li></ol></li><li style="list-style-type:none;">We would highlight that:<ol><li>paragraph a (Temporary lock/block) does not apply to recurring transactions;</li><li>paragraph b (Notification or declining of overseas card-present transactions) applies only to card-present transactions occurring overseas. When you enable this control setting under the Card Settings service, you remain able to use your <i>card</i> for online transactions anywhere whether the transaction amount is in local or foreign currency;</li><li>the amount or limit set by you under paragraph c (Transaction limit) is based on the currency of the country where your <i>card</i> is issued; note that overseas or non-local transactions are subject to the same exchange rate as that which applies to currency conversions on your <i>card</i>;</li><li>a type of transaction/payment channel or a combination of transaction/payment channels under paragraph d (Types of transactions/payment channels) can be set;</li><li>paragraph e (Notification of merchant categories) when enabled provides notifications to be sent to you when transactions with merchants of certain merchant categories set by you are made; it does not impose restrictions on such transactions.</li></ol></li><li style="list-style-type:none;">It is important to note that the Card Settings service (which includes all of the control settings, paragraph a to e above) does not apply to the following types of transactions on your <i>card</i>:<ol><li>transactions whereby you, an <i>authorised person</i> or a <i>merchant</i> opt to switch the transaction to a card association other than Visa International or Mastercard International;</li><li>usage of Standard Chartered Bank <i>ATMs</i>;</li><li>transfers made via <i>Online Banking</i> or <i>mobile banking</i> from your <i>card</i> to other SCB accounts;</li><li>transactions on your <i>card</i> made at a <i>merchant</i> which is acquired (through an Acquirer, in this case including First Data Merchant Solutions, using the Bank’s BINs via a sponsorship arrangement) in the same country as where your <i>card</i> is issued; and</li><li>any other types of transactions as we would inform you from time to time.</li></ol></li></ol><ol start="4"><li>By using the Card Settings service, you acknowledge and agree that:<ol><li>We may send notices and communications to you electronically including by fax, email push notification, or SMS in the event you make a transaction on your <i>card</i> which triggers the control settings which you have enabled under the Card Settings service; in the event that you have registered to use the Inbox Notification service, we may send you such notices and communications via the SC Mobile Inbox Notifications service (which utilises Push Notification) as the main communication channel by electronic means or any other communication channels that we so choose;</li><li>You consent to the use and disclosure of your <i>card</i> information (including <i>card</i> number) and the specific control settings enabled by you under the Card Settings service to the relevant <i>card association</i> for the purpose of the relevant <i>card association</i> in assisting the Bank to provide the Card Settings service;</li><li>The specific control setting under the Card Settings service that is enabled does not override any limits set by the relevant <i>card association</i> or by the Bank and your <i>card</i> remains subject to any limits imposed by the relevant <i>card association</i> or the Bank; and</li><li>The Card Settings service is intended as a tool to help you stay in control of the use of your <i>card</i> and combat fraud. You further acknowledge that you are aware that when you enable a control setting under the Card Settings service pertaining to paragraph 3d (types of transactions/payment channels) or 3e (merchant categories) above, it is possible that inaccurate information about the merchant category code or type of transaction/payment channel could have been or could be provided/selected by the <i>merchant</i> or Acquirer in non-conformity with the relevant <i>card association</i>\'s Payment Card Industry (PCI) compliance requirements or rules, resulting in unintended or ineffective control settings.</li></ol></li><li>You may access the Card Settings service to change or reset the control settings at any time. To change any control settings, you will need to log in to the <i>mobile app</i> or <i>Online Banking</i> and undergo additional security authentication.</li><li>If you inform us that the security of your <i>electronic equipment</i> or <i>security code</i> has been compromised or that the <i>electronic equipment</i> which you use to access any <i>electronic banking services</i> is lost or stolen, <i>we</i> may require you to change the <i>security code</i>, or cease the use of the Card Settings service.</li><li>You are responsible for:<ol><li>The <i>security code</i> used to access the Card Settings service; and</li><li>The security of your mobile device.</li></ol></li><li>In addition to the disclaimers and your liability stated in our General Terms and Conditions (as found in the link above):<ol><li>Due to various technical issues, we do not represent or warrant that the Card Settings service will be accessible at all times, or function with any electronic equipment, software, infrastructure or other electronic banking services that we may offer from time to time;</li><li>We shall not be responsible for any loss or damage you or an authorised person incur directly or indirectly in connection with your use of or access to the Card Settings service as a result of any inaccurate merchant category code or type of transaction/payment channel as provided/selected by the merchant or Acquirer in non-conformity with the relevant card association\'s PCI compliance requirements or rules;</li><li>Unless due to our direct fault, we are not liable for any loss you or an authorised person incur in connection with the misuse or attempted misuse of the Card Settings service, or your improper instructions, or any unauthorised transactions due to your direct fault through or in connection with the Card Settings service;</li><li>You shall indemnify us from all loss and damage which we may incur directly in connection with any of your improper use of the Card Settings service due to your direct fault to the extent permitted by laws;</li><li>You are personally responsible for the security of your mobile or communications device; and</li><li>You acknowledge that any control settings you have enabled on your card under the Card Settings service will not automatically be carried over when you are issued a replacement or new card (except where you are issued a replacement or new card with the same card number); when you are issued a replacement or new card with a different card number, you will be required to re-do or enable the control settings in order to avail the Card Settings service for that replacement or new card.</li></ol></li></ol><br/><b>Meaning of words</b><br/><br/>Push Notification is a service provided by Apple and Google for their respective mobile operating systems i.e. iOS and Android respectively through which an iOS or Android mobile app can send a user (who has installed the mobile app) a notification.<br/><br/>Acquirer is a bank or financial institution that processes card payments on behalf of a merchant. The acquirer allows merchants to accept debit or credit card payments from the card-issuing banks within a card association.<br/><br/>Effective from 03 February, 2020'
    },
    CREDITCARD_ERROR_MAP: {
      'CSL-CC-422':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our Client Care Centre +84 28 3911 0000 or walk into any of our branches for further assistance.',
      'CSL-CC-423':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our Client Care Centre +84 28 3911 0000 or walk into any of our branches for further assistance.'
    },
    CREDITCARD: {
      cardSetting: {
        NOTICE: {
          MCORVISA: 'Sorry, Card Settings is currently only available for MasterCard credit cards.'
        }
      },
      pinSetup: {
        status: {
          cardDetails: 'Credit Card Detail',
          transactionSuccessFailure: {
            VN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our Client Care Center (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for assistance.'
          },
          transactionSuccessInComplete:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our Client Care Center (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for assistance.'
        },
        pinChange: {
          newPinMob: 'Enter your new Card PIN',
          reEnterPinMob: 'Re-Enter your PIN'
        }
      },
      activation: {
        status: {
          transactionSuccessFailure: {
            VN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our Client Care Center (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for assistance.'
          },
          transactionSuccessInComplete:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our Client Care Center (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for assistance.'
        },
        selectPage: {
          sectionHeaderMob: 'Select a Card you want to activate'
        },
        pinChange: {
          newPinMob: 'Enter your new Card PIN',
          reEnterPinMob: 'Re-Enter your PIN'
        }
      }
    },
    CARDBLOCK: {
      cardlistSubHeader:
        'If you do not see the card you wish to block in the list below, please contact our Client Care Centre (24/7) immediately.',
      countryNotes: {
        VN:
          'Upon confirmation, your card(s) will be blocked immediately and you will not be able to use it. Please note that a blocked card cannot be reactivated.<br>You will not be liable for any transactions on the card(s) after this report. Any existing card balances will be transferred to the new replacement card(s).<br> We will send the replacement card(s) to your mailing address in our records. Please note that the replaced card will have a new number and the PIN will need to be set up again on Online Banking. A fee for card replacement will also be applied as per current tariff.<br/>- For Credit Card, kindly find <u><a href="https://www.sc.com/global/av/vn-credit-card-fees-charges-en.pdf" target="_blank">here</a></u> for more information.<br/>- For Individual Debit Card, kindly find <u><a href="https://www.sc.com/global/av/vn-individual-banking-tariff.pdf" target="_blank">here</a></u> for more information.<br/>- For Priority Debit Card, kindly find <u><a href="https://www.sc.com/global/av/vn-priority-banking-tariff.pdf" target="_blank">here</a></u> form more information. <br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.'
      },
      statusMsg: {
        VN: {
          success:
            "Request submission successful. We have blocked your card(s) and will be processing your replacement card(s). To check the status, go to the 'Status’ tab under Help & Services.",
          failure:
            "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our Client Care Centre (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for immediate assistance.",
          incomplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our Client Care Centre (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for immediate assistance."
        }
      }
    },
    CARDREPLACEMENT: {
      countryNotes: {
        VN:
          'This request is for replacement of cards that have already been reported lost/stolen. Credit/Debit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/ stolen card, please use the Report Lost/Stolen Card Service Request.<br>We will send the replacement card(s) to your mailing address in our records. Please note that the replaced card will have a new number and the PIN will need to be set up again on Online Banking. A fee for card replacement will also be applied as per current tariff. Kindly find <u><a href="https://www.sc.com/global/av/vn-credit-card-fees-charges-en.pdf" target="_blank">here</a></u> for more information.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.'
      },
      statusMsg: {
        VN: {
          success:
            "Request submission successful. We will be processing your replacement card(s). To check the status, go to the 'Status’ tab under Help & Services.",
          failure:
            "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our Client Care Centre (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for immediate assistance.",
          incomplete:
            "We've encountered an error with some of your cards. Please resubmit a new request for these cards. If the issue persists, please call our Client Care Centre (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for immediate assistance."
        }
      }
    },
    genericRequest: {
      LMTCONFL: {
        title: 'Credit Card limit confirmation letter',
        notemessage: {
          select:
            'Please input the date range you would like us to issue a letter for.<br> Fee & charges (if any) will be posted into your credit card account, please ensure you have sufficient limit for fee/charges collection.Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/global/av/vn-credit-card-fees-charges-en.pdf\',\'_system\')">here</a> for existing Standard Chartered Credit Card Fees & Charges.<br>Your request will be processed and delivered to your registered mailing address in 5 working days. Please ensure your registered mailing address is valid before submitting request.<br>You can check the progress of your request under tab Status. During processing  request, we may need additional clarification and will notify you via SMS or Email.'
        }
      },
      BALCONVN: {
        title: 'Credit Card balance confirmation letter',
        notemessage: {
          select:
            'Please input the date range you would like us to issue a letter for.<br> Fee & charges (if any) will be posted into your credit card account, please ensure you have sufficient limit for fee/charges collection.Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/global/av/vn-credit-card-fees-charges-en.pdf\',\'_system\')">here</a> for existing Standard Chartered Credit Card Fees & Charges.<br>Your request will be processed and delivered to your registered mailing address in 5 working days. Please ensure your registered mailing address is valid before submitting request.<br>You can check the progress of your request under tab Status. During processing  request, we may need additional clarification and will notify you via SMS or Email.'
        }
      },
      INTCONFL: {
        title: 'Credit Card Interest confirmation letter',
        notemessage: {
          select:
            'Please input the date range you would like us to issue a letter for.<br> Fee & charges (if any) will be posted into your credit card account, please ensure you have sufficient limit for fee/charges collection.Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/global/av/vn-credit-card-fees-charges-en.pdf\',\'_system\')">here</a> for existing Standard Chartered Credit Card Fees & Charges.<br>Your request will be processed and delivered to your registered mailing address in 5 working days. Please ensure your registered mailing address is valid before submitting request.<br>You can check the progress of your request under tab Status. During processing  request, we may need additional clarification and will notify you via SMS or Email.'
        }
      },
      LOGCONFL: {
        title: 'Credit Card Loan Group confirmation letter',
        notemessage: {
          select:
            'Please input the date range you would like us to issue a letter for.<br> Fee & charges (if any) will be posted into your credit card account, please ensure you have sufficient limit for fee/charges collection.Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/global/av/vn-credit-card-fees-charges-en.pdf\',\'_system\')">here</a> for existing Standard Chartered Credit Card Fees & Charges.<br>Your request will be processed and delivered to your registered mailing address in 5 working days. Please ensure your registered mailing address is valid before submitting request.<br>You can check the progress of your request under tab Status. During processing  request, we may need additional clarification and will notify you via SMS or Email.'
        }
      },
      PAYHISTL: {
        title: 'Credit Card payment history letter',
        notemessage: {
          select:
            'Please input the date range you would like us to issue a letter for.<br> Fee & charges (if any) will be posted into your credit card account, please ensure you have sufficient limit for fee/charges collection.Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/global/av/vn-credit-card-fees-charges-en.pdf\',\'_system\')">here</a> for existing Standard Chartered Credit Card Fees & Charges.<br>Your request will be processed and delivered to your registered mailing address in 5 working days. Please ensure your registered mailing address is valid before submitting request.<br>You can check the progress of your request under tab Status. During processing  request, we may need additional clarification and will notify you via SMS or Email.'
        }
      },
      RESCAUPD: {
        title: 'Resident Card Update',
        notemessage: {
          upload:
            'Please upload Resident Document (both sides). <b>Valid Resident Document is:</b> VISA/ permanent resident card/ temporary resident card shows that you are allowed to stay in Vietnam in at least 12 months or more and is still valid at least 3 months since now.<br>You can check the progress of your request under tab Status. During processing  request, we may need additional clarification and will notify you via SMS or Email.'
        }
      },
      BANKCERT: {
        title: 'Bank Certificate',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      SLSPURAG: {
        title: 'BUC Sales & Purchase Agreement',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      CICCONFM: {
        title: 'CIC confirmation',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      CONFISUE: {
        title: 'Confirmation issuance that SCB is keeping title deed as a collateral',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      COOFMAFA: {
        title: 'Copy of Mortgage agreement or Facility agreement',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      EXTLOAGR: {
        title: 'Extract loan agreement',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      LATPAYHL: {
        title: 'Late payment history letter',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      LINCONFL: {
        title: 'Loan information confirmation letter',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      LREPHIST: {
        title: 'Loan Repayment History / Summary',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      LREPSCHE: {
        title: 'Loan Repayment Schedule',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      LSETTLEL: {
        title: 'Loan settlement letter',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      PRPCONFL: {
        title: 'Loan settlement letter, Partial repayment confirmation letter',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      MAGRFAGR: {
        title: 'Mortgage agreement or Facility agreement',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      },
      CERTCPTD: {
        title: 'Photocopy of / Certified true copy of title deed',
        notemessage: {
          select:
            'Fee & charges (if any) will be posted into your CASA account, please ensure you have sufficient balance for fee/charges collection. Or your request will be rejected Please refer click <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/ \',\'_system\')">here</a> for tariff details.<br>Your request will be processed and delivered to your registered mailing address/email or selected Branch in 5 working days. Please ensure your registered mailing address/Email is valid before submitting request.<br> You can check the progress of your request under tab Status.<br><b>For following requests, pls input collateral information/address:</b>Copy of Mortgage agreement or Facility agreement BUC Sales & Purchase Agreement Mortgage agreement or Facility agreement Photocopy of / Certified true copy of  title deed Confirmation issuance that SCB is keeping title deed as a collateral'
        }
      }
    },
    duplicateStatement: {
      header: {
        title: {
          statusMsg:
            'Your Statement Request is successfully submitted.<br>You can track the status at any time by going to Help & Services > tab Status.',
          subInprogress: 'Thank you'
        },
        subTitle: {
          select: 'Please select an account/ card you require statement for',
          product: 'Please select an account/ card you require statement for',
          account: 'Select an account to be debited for issuance fee collection'
        }
      },
      pageLabels: {
        account: 'ACCOUNT/ CARD',
        startDate: 'FROM STATEMENT MONTH',
        endDate: 'TO STATEMENT MONTH',
        debitedAccount: 'DEBIT ACCOUNT',
        'deliveryMode.text': 'DELIVERY METHOD',
        deliveryModeconfirm: 'Delivery Mode'
      },
      countryNotes: {
        default:
          '<div><b>Account Statement:</b></div><ul><li>For the list of transactions in past 1 year from the current date, it is available and ready to be downloaded at any time. Please go to Account > Transaction History.</li><li>Account Statement request which is made under this feature is subjected to existing <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/en/interest-rates/\',\'_system\')">Tariffs</a>. Please ensure account has sufficient balance for fee collection.</li><li>E-statement will be proceeded within 3 working days. Paper statement will be proceeded within 5 working days</li></ul><br><div><b>Credit Card Statement:</b></div><ul><li>This feature is applicable for resending Credit Card E-statement within 1 year from today.</li><li>If you wish to issue E-statement older than 1 year from today or Paper Statement with bank confirmation, please contact our Client Care Center (24/7) at +842839110000.</li><li>E-statement will be proceeded within 1 working day.</li></ul><br>If Statement Start date is prior to Account opening date, we will proceed from Account opening date.<br>We will send statement to your registered email or postal address. Please ensure it is updated before submitting request.',
        account:
          '<div><b>Account Statement:</b></div><ul><li>For the list of transactions in past 1 year from the current date, it is available and ready to be downloaded at any time. Please go to Account > Transaction History.</li><li>Account Statement request which is made under this feature is subjected to existing <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/en/interest-rates/\',\'_system\')">Tariffs</a>. Please ensure account has sufficient balance for fee collection.</li><li>E-statement will be proceeded within 3 working days. Paper statement will be proceeded within 5 working days</li></ul><br><div><b>Credit Card Statement:</b></div><ul><li>This feature is applicable for resending Credit Card E-statement within 1 year from today.</li><li>If you wish to issue E-statement older than 1 year from today or Paper Statement with bank confirmation, please contact our Client Care Center (24/7) at +842839110000.</li><li>E-statement will be proceeded within 1 working day.</li></ul><br>If Statement Start date is prior to Account opening date, we will proceed from Account opening date.<br>We will send statement to your registered email or postal address. Please ensure it is updated before submitting request.',
        statement:
          '<div><b>Account Statement:</b></div><ul><li>For the list of transactions in past 1 year from the current date, it is available and ready to be downloaded at any time. Please go to Account > Transaction History.</li><li>Account Statement request which is made under this feature is subjected to existing <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/en/interest-rates/\',\'_system\')">Tariffs</a>. Please ensure account has sufficient balance for fee collection.</li><li>E-statement will be proceeded within 3 working days. Paper statement will be proceeded within 5 working days</li></ul><br><div><b>Credit Card Statement:</b></div><ul><li>This feature is applicable for resending Credit Card E-statement within 1 year from today.</li><li>If you wish to issue E-statement older than 1 year from today or Paper Statement with bank confirmation, please contact our Client Care Center (24/7) at +842839110000.</li><li>E-statement will be proceeded within 1 working day.</li></ul><br>If Statement Start date is prior to Account opening date, we will proceed from Account opening date.<br>We will send statement to your registered email or postal address. Please ensure it is updated before submitting request.'
      },
      error: {
        default: 'Please enter a valid month',
        startDate: {
          error1: 'Start Date should not be more than 7 years',
          error2: 'Start / End month should not be greater than today date.',
          error3: 'Start date should be less than end date'
        },
        endDate: {
          error1: 'End date should not be less than 7 years',
          error2: 'Start / End month should not be greater than today date.',
          error3: 'End month should be equal or greater than Start month'
        },
        creditCard: {
          startDate: {
            error1: 'Maximum requested period is the last 1 year.'
          },
          endDate: {
            error1: 'Maximum requested period is the last 1 year.'
          }
        },
        casa: {
          startDate: {
            error1: 'Maximum requested period is the last 5 years.'
          },
          endDate: {
            error1: 'Maximum requested period is the last 5 years.'
          }
        },
        commonError: {
          noEligible: 'Sorry, you don’t have eligible account(s)/ cards(s) for this request.'
        },
        casaError: {
          msg: "You may obtain past 12 months' statements from Online Banking."
        },
        noData: {
          customerNotEligible: "You don't have eligible account(s) for this request."
        }
      }
    }
  }
};
