/* eslint-disable no-useless-escape */

export default {
  ServiceRequest: {
    LANDINGPAGE: {
      'header.title': 'Service request'
    },
    CREDITCARD_ERROR_MAP: {
      'CSL-CC-301':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-302':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-303':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-304':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-305':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-306':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-307':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-308':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-312':
        'You have exceeded the PIN try limit. Kindly call our 24-hour Customer Care hotline at 5247 for further assistance.',
      'CSL-CC-313':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-314':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-315':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-422':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline at 5247 or walk in to any of our branches for further assistance.',
      'CSL-CC-423':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline at 5247 or walk in to any of our branches for further assistance.',
      'CSL-CC-409':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-417':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-407':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-416': 'Please enter Standard Chartered Credit Card for activation.',
      'CSL-CC-415':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-405':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-414':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-404':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-413':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-403':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-412':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-402':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-411':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-401':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-410':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-CC-418':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at  5247 for further assistance.',
      'CSL-CC-316':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline at 5247 for further assistance.',
      'CSL-OTP-1328':
        'Sorry, due to maximum invalid OTP attempts you will not receive any OTP for transactions for the next 24 hours.',
      '1308':
        'You have entered invalid one-time password (OTP). Please check and re-enter your one time password(OTP). (Error Code:1308)',
      '1307': 'Your one-time password (OTP) had expired. Please request for a new OTP. (Error Code:1307)',
      'CSL-OTP-1024': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-OTP-1026': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.'
    }
  },
  generalDeclaration: {
    title: 'General Declaration',
    declaration:
      "<div class='modal-terms-condition'><h3 class='general-info-head'>By accepting this application :</h3><ol><li>You represent and warrant that all information (including any documents) you have given to us in connection with the application is correct, complete and not misleading. (If this is not the case you may be personally liable.);</li><li>You authorise us to verify any of the information you have given to us or your credit standing from anyone we may consider appropriate (such as an authority or credit reference agency);</li><li>You acknowledge that we may decline your application without giving you any reason for doing so. If this happens, no contractual relationship arises between us and you;</li><li>You confirm and agree that we may give any information in connection with this application (including your personal information) to any service provider (whether located in or outside of Zambia) for the purposes of providing any service to you in connection with this application (including data processing);</li><li>You declare that you have read and understood our Client Terms /Product Terms and conditions/Online Terms and Conditions/ Privacy Policy - and all other the applicable documents referred to in Part A of our Client Terms forming our banking agreement which are provided on SC Mobile and available on <a href='https://www.sc.com/zm'>www.sc.com/zm</a>. You acknowledge that you are bound by any variation we make to these documents, in accordance with our banking agreement. In particular, you understand that by entering into our banking agreement you give indemnities, authorisations, consents and waivers and agree to limitations on our liability;</li><li>You consent to us contacting you at the addresses, e-mail addresses and phone numbers you have provided to us, to be contacted through WhatsApp or any similar application or video channels, for verification/authentication for entering into the banking agreement and/or to give you information on other products and services that we, or our strategic partners, may offer;</li><li>You consent to us archiving, storing any information, videos, screenshots, etc. that the we may obtain through WhatsApp calls or through videocalls that we may conduct with you for verification/authentication for entering into the banking agreement;</li><li>Where applicable, you agree that we will send electronic statement for your bank accounts and loan accounts by email to the email addresses provided by you;</li><li>You consent to us and to each of our subsidiaries and affiliates (including each branch or representative office) (\"Standard Chartered Group\") its officers, employees, agents and advisers disclosing information relating to you (including details of our banking agreement, the accounts, the products or any arrangement with us) to our head office and any other member of the Standard Chartered Group in any jurisdiction (\"Permitted Parties\"); your employer professional advisers, service providers, Government population registration systems (whether located in or outside of Zambia) for the purposes of providing any service to you in connection with this application (including but not limited to data processing and/or to use such existing data for verification purposes), or independent contractors to, or agents of, the Permitted Parties, such as debt collection agencies, data processing firms and correspondents who are under a duty of confidentiality to the permitted parties, any actual or potential participant or sub-participant in relation to any of our obligations under our banking agreement between us, or assignee, novatee or transferee (or any officer, employee, agent or adviser of any of them), any credit reference agency, rating agency, business alliance partner, insurer or insurance broker of, or direct or indirect provider of credit protection to, or any Permitted Parties; any court, tribunal or authority (including an authority investigating an offence) with jurisdiction over the Permitted Parties; a merchant or member of VISA International or Mastercard International where the disclosure is in connection with the use a card; any authorized person or any security provider; anyone we consider necessary in order to provide you with the services in connection with an account;</li><li>You acknowledge that the bank will register you for a prescribed set of SMS alerts, to be sent to the number registered with the bank</li><li><p>For the purposes of your application of a credit card or personal loan / finance application - if any (including personal instalment loan, personal revolving loan and personal line of credit/ overdraft) or Home Loan / Home Finance application or Auto Loan / Auto Finance application you confirm that:</p><ol type='a'><li>none of your existing credit cards and/or unsecured loan / finance have been cancelled due to payment defaults,</li><li>you do not have any payments overdue by more than one month on any loans / finances or credit cards you have with other financial institutions,</li><li>you are not and have never been bankrupt and you have no intention to petition or are currently petitioning for bankruptcy;</li></ol></li><li>You acknowledge that insurance plans that accompany certain products are underwritten by third parties insurers. Such insurers are not Standard Chartered Group associates or subsidiaries or related corporations. Such insurers are solely responsible for all coverage and compensation under the plans. We collect your information and send them to such insurers for processing and review. Collection of information does not necessarily mean that your insurance application will be approved; and</li><li>You understand and agree that the bank has the right (upon giving you notice) to amend or withdraw any rewards that may accompany the bundled products that you have applied for. In particular if you do not use any of the bundled products that you have applied for, the Bank may upon giving you notice withdraw the rewards that accompany the bundled products,</li><li>Subject to applicable local laws, I hereby consent for Standard Chartered PLC or any of its affiliates (collectively \"the Bank\") to share my information with domestic and overseas regulators or tax authorities where necessary to establish my tax liability in any jurisdiction.</li><li>Where required by domestic or overseas regulators or tax authorities, I consent and agree that the Bank may withhold from my account(s) such amounts as may be required according to applicable laws, regulations and directives.</li><li>I undertake to notify the Bank within 30 calendar days if there is a change in any information which I have provided to the Bank.</li><li>You agree that we have the right to set off the amount held in lien against which a cash secured facility(ies) has been granted to you by us or any other account you have with us that may have a credit balance, in the event of default. You authorise us to purchase such foreign currency with the monies standing to the credit of your account(s) as may be necessary, to effect the set off and settle any outstanding amount on the loan facility, where necessary to facilitate the offsetting of the facility in default. You agree that the lien will only be lifted upon full repayment of the facility(ies). You agree that you shall lay no claim whatsoever to the funds under lien until such time the facility is repaid in full.</li><li>You undertake to provide the underlying or supporting documentation to support all foreign currency transactions above the equivalent of USD 10,000 conducted on your account or such other amount as the Bank of Zambia may determine from time to time. If you chose to transact through electronic banking, you undertake to provide such documentation within 5 banking days upon the Bank's demand.</li><li>You agree that the Bank is permitted to send this electronically executed application to you via email and that the terms and conditions and any instructions given herein shall have the same validity, admissibility and enforceability as if signed in physical form and you agree not to challenge the validity, admissibility or enforceability only on the basis that they are in electronic form.</li></div>"
  }
};
