/* eslint-disable no-useless-escape */

export default {
  generic: {
    back: 'BACK',
    login: 'LOGIN',
    termsAndCondition: 'Terms and Conditions',
    on: 'ON',
    off: 'OFF',
    yes: 'YES',
    no: 'NO',
    ok: 'OK',
    cancel: 'Cancel',
    continue: 'Continue',
    new: 'NEW',
    done: 'DONE',
    logout: 'Logout',
    coming_soon: 'coming soon..'
  },
  FERE: {
    action: {
      modal: {
        message: 'Please confirm leave the form without submitting?',
        resetMessage: 'Are you sure you want to revert the change?',
        quitApp: {
          title: 'Quit Application?',
          messageEmailSms: 'An Email and SMS will be sent to you with a link to continue your application later.',
          messageProgressLost: 'Your current progress will be lost.'
        }
      },
      button: {
        confirm: 'CONFIRM',
        cancel: 'CANCEL',
        YES: 'YES',
        NO: 'NO',
        edit: 'Edit',
        reset: 'RESET',
        save: 'SAVE',
        close: 'CLOSE'
      }
    },
    validation: {
      error: {
        labelNameError: 'should be less than the account balance',
        message: ' is required',
        dateExpired: 'The date is expired',
        dateInvalid: 'The date is invalid / Incorrect date format.',
        dateFuture: 'The future date is unavailable',
        invalidCard: 'Invalid card number.',
        invalidEmiratesId: 'Your Emirates ID Number is invalid',
        invalidResidentialCountry: 'Please select a valid residential country.',
        invalidGender: 'Please select a valid title, this does not match your earlier selected gender.',
        dateInputError: {
          label: 'This field',
          beforeError: '{{label}} must be before {{date}}',
          afterError: '{{label}} must be after {{date}}'
        }
      }
    },
    page: {
      receipt: {
        title: 'Reference Number',
        description: 'Please quote this reference number for all future correspondences related to this request.',
        'button.blocked': 'NEXT',
        failed: 'Failed!'
      },
      jumpTolabel: 'Jump to Section',
      step: 'of',
      top: 'TOP',
      loading: 'Loading...',
      fileUploadInfoText:
        'File format should be in JPG, PNG or PDF. The combined total file size must not exceed 10MB.',
      of: 'of'
    }
  },
  ServiceRequest: {
    StaffProductCategory: {
      headerText: 'What would you like to do?',
      eligibilityCheck: 'Eligibility Check',
      creditCard: 'Credit Card',
      cashOne: 'Cash One',
      application: 'Application',
      ntbCreditCard: 'NTB Credit Card',
      notAuthorizedText: 'You are not authorized to sell this product. <br /> Please contact your administrator.',
      okay: 'OKAY',
      aipDeclinedTitle: 'Sorry, looks like we need more information.',
      aipDeclineMessage:
        'Thank you for your application.<br>Unfortunately, your application is not in line with some of our internal policies.',
      aipUserDeclinedTitle: 'Looks like our offer did not match your expectation :( ',
      aipUserDeclinedMessage: 'Thanks for applying!',
      aipDeclinedReasonHeader: 'Reason for Decline',
      aipDeclinedButton: 'OK',
      aipUserDeclinedButton: 'Quit Application',
      ntbOnboarding: 'New to Bank Onboarding',
      documentCollection: 'Documents Collection',
      ntbAttestationMessage:
        'Before proceeding, please confirm that you have met the client in person, sighted and verified their original identification document which you will upload in this journey.',
      ntbAttestationButtonLabel: 'CONFIRM & PROCEED',
      terminateRoute: {
        header: 'Terminate Case'
      },
      documentCollectionRoute: {
        header: 'Documents Collection',
        refNumberLabel: 'REF NUM:',
        companyNamelabel: 'COMPANY NAME:',
        terminateCaseLabel: 'TERMINATE CASE',
        noItemsMessage: "You don't have any pending items in your queue."
      }
    },
    COMMON: {
      addOtherNationality: '+ ADD OTHER NATIONALITY',
      loadingIndicatorText: 'Loading...',
      'notes.title': 'NOTES',
      'creditcard.title': 'Credit Card',
      'debitcards.title': 'Debit Card',
      'productlist.title': 'Select one or more accounts to open',
      'productCategory.title': 'Explore our full range of banking products',
      'nocard.header': 'No cards detected.',
      'nocard.content': 'You do not have any eligible Cards to be updated.',
      'nocard.SG.content': 'Sorry, you do not have any eligible cards for this request.',
      'nocard.MY.content': 'You do not have any card to proceed with this request.',
      'errorcard.header': 'Unable to retrieve card details.',
      'errorcard.content': 'Please contact 24/7 Phone Banking team for immediate assistance.',
      'errorcard.content.VN': 'Please contact our 24/7 Client Care Center for immediate assistance',
      'errorcard.content.AE':
        'Please contact <a href="javascript:;" onclick="window.open(\'https://www.sc.com/ae/contact-us/\',\'_system\')">24/7 Phone Banking</a> team for immediate assistance.',
      'debit.header': 'No debit cards detected.',
      'debit.content': 'You do not have any eligible ATM/Debit Card(s) to be updated.',
      'debit.SG.content': 'Sorry, you do not have any eligible ATM or debit cards for this request.',
      'debit.MY.content': 'You do not have any debit/ATM card to proceed with this request.',
      'credit.header': 'No credit cards detected.',
      'credit.content': 'You do not have any eligible Credit Card(s) to be updated.',
      'credit.SG.content': 'Sorry, you do not have any eligible credit cards for this request.',
      'credit.MY.content': 'You do not have any credit card to proceed with this request.',
      backToHelpAndServicesText: 'Are you sure you want to return to Help & Services?',
      backToiBankText: 'Are you sure you want to return to account overview/homepage?',
      backToiBankBefAckText: 'Are you sure you want to return to account overview/homepage and cancel your request?',
      backToMobileBankText: 'Are you sure you want to return to account overview/homepage?',
      backToMobileBankBefAckText:
        'Are you sure you want to return to account overview/homepage and cancel your request?',
      genericError: {
        MY:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our client care center on 1 300 888 888/ +603 7711 8888 for any assistance',
        MYCB:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our client care center on 1800 888 998 or +603-78496888 for any assistance.',
        AE:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our <a href="javascript:;" onclick="window.open(\'https://www.sc.com/ae/contact-us/\',\'_system\')">24/7 Phone Banking</a> for immediate assistance.',
        KE:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our client care center on 254 20329 3900 for any assistance',
        GH:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our client care center on 0302 740100 for any assistance',
        ZM:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
        BW:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our client care center on +267 3615800 for any assistance',
        NG:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our client care center on +234 1 270 4611 / +234 1 270 4612 / +234 1 270 4613 / +234 1 270 4614 for any assistance',
        IN:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
        HK:
          'We are unable to process your request at the moment. Please contact us: Standard Chartered Banking Service Hotline (Including ATM card) (852) 2886-8888.',
        HKCB:
          'We are unable to process your request at the moment. Please contact us: Standard Chartered Credit Card 24-hour Customer Service Hotline (852) 2886-4111. Standard Chartered Banking Service Hotline (Including ATM card) (852) 2886-8888.',
        HKCR:
          'We are unable to process your request at the moment. Please contact us: Standard Chartered Credit Card 24-hour Customer Service Hotline (852) 2886-4111.',
        SG:
          'We are unable to process your request at the moment. Please try again or contact our Customer Service Hotline at 1800 747 7000 or +65 6747 7000 from overseas.',
        VN:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking Client Care Center (24/7) at +84 28 3911 0000 or +84 24 3696 0000 for immediate assistance',
        BN:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
        BD:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
        NP:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24X7 Client Care Center for immediate assistance.',
        LK:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
        default:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.'
      },
      navigationSelectLabel: {
        chequeLabel: 'Cheque Number Range:',
        accountNumberLabel: 'Account Number:'
      },
      maintanence: {
        title: 'We are currently performing maintenance work to enhance your mobile Banking experience.',
        message: 'The service will resume shortly. We apologise for any inconvenience caused.',
        button: 'OK'
      },
      sessionExpire: {
        title: 'Sorry, this session has been timed out for security reasons.',
        message: 'Please resume your application to continue.',
        button: 'OK'
      },
      popup: {
        title: 'Do you want to update your contact details?',
        message:
          'Your current progress will be lost. You will need to submit a new request after updating your details.'
      },
      recordNotExist: 'Record does not exist',
      systemError:
        'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
      'systemError.AE':
        'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our <a href="javascript:;" onclick="window.open(\'https://www.sc.com/ae/contact-us/\',\'_system\')">24/7 Phone Banking</a> for immediate assistance.',
      'systemError.KE':
        'We have encountered technical error while processing your request. Please contact our client care center on 254203293900 for immediate assistance.',
      'systemError.HK':
        'We are unable to process your request at this time. Please try again. For Enquires, please call 28868868.',
      'systemError.NP':
        'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24X7 Client Care Center for immediate assistance.',
      'systemError.title': 'System Error',
      termsAndConditions:
        '<ol><li>These terms and conditions ("Terms") apply to your use of the Card Settings service provided by Standard Chartered.</li><br/><li>The Card Settings service is provided as part of the Bank’s <i>electronic banking services</i>, and accordingly:<ol><li>these Terms are in addition to and shall be read with the Customer Terms, our privacy notice published in our website and any other documents forming part of our banking agreement (and any reference to the terms and conditions of the Customer Terms shall include reference to these Terms).</li><br/><li>The meaning of key words printed <i>like this</i> is explained in the Customer Terms unless defined in these Terms. The Customer Terms may be accessed at sc.com/ae.</li><br/><li>In the event of any conflict or inconsistency, these Terms shall prevail over the Customer Terms to the extent of such conflict or inconsistency.</li><br/></ol></li><br/><li>The Card Settings service allows you to enable certain control settings on your credit card that are switched via the relevant card association (i.e. Visa or MasterCard in this case). While this covers the majority of transactions on your <i>credit card</i>, there are certain instances where the settings enabled by you under the Card Settings service will not work. Such instances include, without limitation as below:<ol><li>If your <i>credit card</i> has a Visa or MasterCard badge in addition to another <i>card association</i> or domestic network badge, and at the time of the transaction you or the <i>merchant</i> opt to switch it via that other <i>card association</i> or domestic network;</li><br/><li>When you make a withdrawal at an ATM (this is because many transactions using the ATM are not switched via the relevant <i>card association</i> (i.e. Visa or MasterCard in this case));</li><br/><li>When your card is used for a recurring transaction; the Card Settings service does not block your recurring transactions in order to not interfere with your ongoing subscription or bill payments; and</li><br/><li>When you enable a setting under the Card Settings service to control the type of transaction or merchant category to use your <i>credit card</i> for and the <i>merchant</i> or merchant acquirer has not conformed to the relevant <i>card association</i> (i.e. Visa or MasterCard in this case)\'s mandatory Payment Card Industry (PCI) compliance requirements by providing accurate information about the merchant category code ("MCC") and type of transaction that it accepts.</li><br/></ol></li><br/><li>There is a specific setting under the Card Settings service which you can enable to block overseas card transactions. It is important to note that this feature or setting applies only to card-present transactions. When you block overseas card transactions under the Card Settings service, you remain able to make card-not-present transactions i.e. Mail Order/Telephone Order ("MOTO") and ecommerce transactions. This means that you will still be able to use your <i>credit card</i> for e-commerce transactions and MOTO transactions whether the transaction amount is in local or foreign currency.</li><br/><li>By using the Card Settings service, you acknowledge and agree that:<ol><li>You are a registered and valid user of our <i>mobile banking services</i>;</li><br/><li>We may send notices and communications to you electronically including by fax, email or SMS in the event you make a transaction on your credit card which triggers the settings which you have enabled under the Card Settings service; in the event that you have registered to use the Notification Hub service, we may send you such notices and communications via the Notification Hub service (which utilises Push Notification) as the main communication channel by electronic means or any other communication channels that we so choose;</li><br/><li>You consent to the use and disclosure of your credit card information (including but not limited to <i>credit card</i> account number) and the settings enabled by you under the Card Settings service to the relevant <i>card association</i> (i.e. Visa or MasterCard in this case) for the purpose of the relevant <i>card association</i> (i.e. Visa or MasterCard in this case) in assisting the Bank to provide the Card Settings service;</li><br/><li>You are aware of the instances under Section 3 above where certain settings enabled by you under the Card Settings service do not work; and</li><br/><li>You are aware that when you block overseas card transactions under the Card Settings service, you remain able to make card-not-present transactions i.e. MOTO transactions and e-commerce transactions as mentioned under Section 4 above.</li><br/></ol></li><br/><li>You may access the Card Settings service to change or reset your settings at any time by [using the navigation menu of the <i>mobile app</i>] once you are signed into the <i>mobile app</i>. To change any settings, you will need to log in to the <i>mobile app</i> and undergo additional security authentication. If you do not use the Card Settings service, your credit card will still work and remain subject to any usage restrictions imposed by the relevant <i>card association</i> (i.e. Visa or MasterCard in this case) or by the Bank.</li><br/><li>If you inform us that the security of your <i>mobile app or security code</i> has been compromised or that the <i>electronic equipment</i> which you use to access any <i>electronic banking services</i> is lost or stolen, we may require you to change the <i>security code</i>, re-register for the Card Settings service or cease the use of the Card Settings service.</li><br/><li>You understand the need to protect your mobile device and shall be responsible for all use of your mobile device (whether authorised by you or otherwise) to access the Card Settings service.</li><br/><li>In addition to the disclaimers and your liability stated in our Customer Terms (as found in the link above):<ol><li>We do not represent or warrant that the Card Settings service will be accessible at all times, or function with any electronic equipment, software, infrastructure or other <i>electronic banking services</i> that we may offer from time to time;</li><br/><li>The Card Settings service is intended as a tool to help you stay in control of the use of your <i>credit card</i> and combat fraud. Standard Chartered Bank does not guarantee that the settings enabled by you under the Card Settings service will be applied to the rule categories or payment control types you had intended for and we cannot be held responsible for unintended consequences of using the Card Settings service;</li><br/><li>We are not responsible for any erroneous or fraudulent MCC used to classify the business of the <i>merchant</i> as provided by the <i>merchant</i>, merchant acquirer or <i>card association</i>;</li><br/><li>Unless a law prohibits us from excluding or limiting our liability, we are not liable for any loss you incur in connection with the use or attempted use of the Card Settings service, or your instructions, or any unauthorised transactions through or in connection with the Card Settings service;</li><br/><li>You shall indemnify us from all loss and damage which we may incur in connection with any improper use of the Card Settings service; and</li><br/><li>You are personally responsible for the security of your mobile or communications device.</li><br/></ol></li><br/></ol>',
      'termsAndConditions.title': 'Terms & Conditions',
      breadcrumbHome: 'You are in Home',
      refNumber: 'Reference No.',
      cardTypenocardsTit: 'No eligible card detected.',
      cardTypenocardsDesc:
        'The selected account(s) to be linked does not have any eligible card for replacement. Kindly select other account(s) to proceed or contact our <a href="javascript:;">24/7 Phone Banking</a> for assistance.',
      cardTypeErrornocardsTit: 'Unable to retrieve data.',
      cardTypeErrornocardsDesc:
        'We are unable to retrieve your account details at this moment.<br>Kindly select other account(s) or try again later.',
      pageTitles: {
        applyProduct: {
          AE: 'New Credit Card Application',
          default: 'Open a New Account'
        },
        openNewAccount: 'Open a New Account',
        profileUpdate: 'Update Profile',
        letterRequests: 'Letter Request',
        chequeBookActivation: 'Cheque Book Activation',
        chequeBookStop: 'Cheque Book Stop/Block',
        confirmCheque: 'Confirm a Cheque',
        newChequeBookRequest: 'New Cheque Book Request',
        accountClosure: 'Account Closure',
        manageSignatory: 'Manage Signatory',
        signataireUpdate: 'Signature Update',
        sweepTransfer: 'Sweep Transfer',
        requestStatement: 'Request Statement',
        fixedDeposit: 'Fixed Deposit',
        demanDraft: 'Demand Draft/Manager Cheque',
        upliftFixed: 'Uplift Fixed Deposit',
        debitCardActivationPinset: 'Debit Card Activation and PIN set',
        debitCardBlockAndReplace: 'Debit Card Block and Replace',
        debitCardReplace: 'Debit Card Replace',
        debitCardPinRest: 'Debit Card PIN Reset',
        communProcess: 'Communication Preferences',
        jointAccountManagement: 'Joint Account Management',
        accountInformation: 'Account Information',
        visaTransfer: 'Fund My Account'
      },
      progress: {
        title1: 'Enter Details',
        title2: 'Confirm Details',
        title3: 'Select Details',
        title4: 'Select Your ATM Card Design',
        steptxt: 'Step',
        step1: '1 of 2',
        step2: '2 of 2',
        step12: 'Step 1 of 2',
        step22: 'Step 2 of 2',
        step13: '1 of 3',
        step23: '2 of 3',
        step33: '3 of 3',
        step14: '1 of 4',
        step24: '2 of 4',
        step34: '3 of 4',
        step44: '4 of 4',
        step15: '1 of 5',
        step25: '2 of 5',
        step35: '3 of 5',
        step45: '4 of 5',
        step55: '5 of 5',
        success: 'Success',
        submit: 'Submitted',
        failure: 'Failed',
        incomplete: 'Incomplete',
        syserror: 'System Error',
        submitted: 'Submitted',
        plsselect: 'Please Select',
        subInprogress: 'Your request is submitted and being processed.',
        stepOf: 'of'
      },
      text: {
        selectAll: 'Select All',
        deselectAll: 'Deselect All',
        english: 'English',
        chinese: 'Chinese',
        new: 'New'
      },
      button: {
        cancel: 'CANCEL',
        agree: 'AGREE',
        next: 'NEXT',
        ok: 'OK',
        confirm: 'CONFIRM',
        yes: 'Yes',
        no: 'No',
        done: 'DONE',
        back: 'BACK',
        loadMore: 'LOAD MORE',
        sendOtp: 'SEND OTP',
        sNext: 'Next',
        sPrev: 'Prev',
        quitApplication: 'QUIT APPLICATION',
        continueApplication: 'CONTINUE APPLICATION',
        continueBrowsing: 'CONTINUE BROWSING',
        proceed: 'PROCEED',
        close: 'CLOSE',
        continue: 'CONTINUE',
        dialNumber: 'DIAL NUMBER',
        cancelrequest: 'Cancel Request',
        showAll: 'Show All',
        viewStatus: 'VIEW STATUS',
        resetAnotherCards: 'RESET ANOTHER CARD',
        activateAnotherCard: 'ACTIVATE ANOTHER CARD',
        okDone: 'OK, DONE',
        sltcard: 'Select Card',
        accept: 'ACCEPT',
        save: 'SAVE',
        apply: 'APPLY',
        select: 'SELECT',
        selected: 'SELECTED',
        applynow: 'Apply Now',
        iUnderstand: 'I understand',
        changeSelection: 'YES, CHANGE SELECTION',
        startApplication: 'START APPLICATION',
        forgotbvn: 'Forgot BVN?',
        accountUpgradeYes: 'YES, UPGRADE',
        accountUpgradeNo: 'NO',
        submit: 'SUBMIT',
        checkStatus: 'CHECK STATUS',
        backToHomePage: 'BACK TO HOMEPAGE',
        gotoHelpAndServices: 'GO TO HELP AND SERVICES',
        goToProfileUpdate: 'UPDATE MY PROFILE',
        viewUrReq: 'View Your Requests',
        callUsNow: 'CALL US NOW',
        scrollDown: 'Scroll Down',
        viewRequest: 'VIEW YOUR REQUESTS'
      },
      crsMessage: {
        title: 'Sorry!',
        CRSETB:
          'Please update your Country of Tax Residency information to proceed with this request. Click on Service Requests>Personal Details>CRS Declaration to update details.',
        CRSNTB:
          'We are not able to continue with your request. Please contact your Tax Advisor for further information.'
      },
      subCategoryText: {
        feeWaver: 'Fee Waiver',
        cardCancellation: 'Card Cancellation',
        cardBlock: 'Report Lost/Stolen Card',
        cardBlock1: 'Report Lost/Stolen Credit Card',
        cardBlock2: 'Report Lost/Stolen Debit Card',
        cardReplace: 'Replace Card',
        cardReplace1: 'Replace Credit Card',
        cardReplace2: 'Replace Debit Card',
        debitCardBlockAndReplace: 'Debit Card Block and Replace',
        debitCardReplace: 'Debit Card Replace',
        debitCardActivationPinset: 'Debit Card Activation and PIN set',
        debitCardPinRest: 'Debit Card PIN Reset',
        chequeRequest: 'Cheque Book Request',
        cardReplacement: 'Card Replacement',
        cardReplacement1: 'Replace Credit Card',
        cardReplacement2: 'Replace Debit Card',
        cardActivation: 'Debit/ATM Card Activation & PIN Set',
        profileSettings: 'Profile Settings',
        pinChange: 'Debit/ATM Card PIN Change',
        letterRequest: 'Letter Request',
        chequeBookActivation: 'Cheque Book Activation',
        chequeStop: 'Cheque Book Stop/Block',
        chequeConfirmation: 'Confirm a Cheque',
        newChequeBook: 'New Cheque Book Request',
        creditBalanceRefund: 'Credit Balance Refund',
        cardFeewavier: 'Fee Waiver',
        accountOpening: 'Account Opening',
        demandDraft: 'Demand Darft',
        accountClosure: 'Account Closure',
        updateFatcaStatus: 'Update FATCA Status',
        cddUpdate: 'Customer Due Diligence',
        kycDocumentRequest: 'KYC Document request',
        newSignAddition: 'Manage Signatory',
        signChange: 'Signature Update',
        sweepSetup: 'Sweep Setup ',
        upliftFullFd: 'Uplift Full FD',
        dndRequestRemoval: 'DND Request Removal',
        requestStatement: 'Request Statement',
        creditCardActivation: 'Credit Card Activation & PIN Set',
        creditPinChange: 'Credit Card PIN Change',
        fixedDeposit: 'Fixed Deposit',
        sltatm: 'Select ATM language',
        linkaccount: 'Link Another Account',
        debitatmcardrpm: 'Debit/ATM Card Replacement',
        newdebitatmcard: 'New Debit/ATM Card Application',
        refNo: 'Reference No:',
        sltCardtoreplace: 'Selected card to be replaced',
        atmLang: 'ATM Language',
        cardDesign: 'Card Design',
        jointAccount: 'Joint Account',
        productFeatures: 'Product Features',
        featureSubtitle: 'Get even more with your '
      },
      productListDetails: {
        detailLink: 'More details',
        eligibilityDocumentTitle: 'Eligibility & Documents',
        keyFeatures: 'Key Features',
        feesAndChargeDesc:
          'Fees and charges are subject to change. All fees and charges listed are inclusive of 5% Value Added Tax(VAT), where applicable.',
        feesAndChargeNote:
          'Note: Primary credit card Annual Fee from the second year onwards may be waived if retail spends for the preceding 12 months exceeds AED 150,000 or equivalent.For more details on all other applicable fees and charges, please click here.',
        faqTitle: 'FAQs',
        tocTitle: 'Useful Links',
        tableServiceHeader: 'SERVICE',
        tableChargeHeader: 'CHARGE'
      },
      categoryText: {
        creditCard: 'Credit Card',
        debitCard: 'Debit Card',
        personalDetails: 'Personal Details',
        accountManagement: 'Account Management',
        cardManagement: 'Card Management',
        debitatmcardtitle: 'Debit/ATM Card'
      },
      productOpening: {
        selectAccounts: 'Select one or more accounts to open',
        accountInfo1: 'Joint accounts are available upon opening an account',
        accountInfo2: 'These products are available upon opening a current or savings account.',
        currentAccount: 'Current Account',
        currentAccDesc: 'Convenience and simplicity for your banking needs.',
        excelAccount: 'Savings Plus Account',
        excelAccDesc: 'Designed to maximise your interest rates',
        otherProducts: 'Other products we offer',
        fixedDeposit: 'Fixed Deposit',
        fixedDepoDesc: 'Maximise the growth potential of your savings at competitive rates, without taking any risks.',
        select: 'SELECT',
        selected: 'SELECTED',
        learnMore: 'LEARN MORE',
        tooltipInfo1: 'Joint accounts are available upon opening an account.',
        tooltipInfo2: 'These products are available upon opening a current or savings account.',
        proceed: 'PROCEED',
        open1Account: 'Open 1 account',
        open2Account: 'Open 2 accounts',
        cfaf: 'CFAF',
        free: 'FREE',
        initialDeposit: 'Initial deposit',
        keyFeature: 'Key Features',
        service: 'SERVICE',
        charges: 'CHARGES',
        currentAccountContent: {
          noInitialDeposit: 'No Initial deposit',
          cardType: 'Gold ATM/Debit Cards offered at account opening for all clients',
          minBalance: 'No Minimum balance',
          keyFeatures: {
            cfafNon: '',
            minBalance: 'Minimum balance',
            notRequired: 'Not required',
            maintenFee: 'Monthly account maintenance fee',
            firstYear: '2 000 CFAF',
            atmCashGim: 'ATM cash withdrawals (within the GIM UEMOA Network)',
            atmCashOutside: 'ATM Cash withdrawals (Outside of WAEMU zone)',
            electronicTransfer: 'Electronic transfer to another banking institution',
            cfafByRTGS: 'CFAF by RTGS',
            locTransfer: 'Local Transfer Between SCB CI Accounts',
            locTransferOther: 'Local Transfer from SCB CI to other bank',
            newAmount: 'ACH: 250 CFAF<br/>RTGS: 2000 CFAF',
            transferWameu: 'Transfer in another WAEMU country',
            cfafCote: '6 000 CFAF',
            internationalTransfer: 'International Transfer',
            euro: 'EURO : Transfer Commission  :  1.8% min 10 000 CFAF',
            otherCurrency: 'Other currencies : Change Commission : 1% min 10 000 CFAF',
            onlineBA: 'Online Banking access',
            mobileBA: 'Mobile Banking access',
            eStatemtment: 'Monthly eStatement',
            chequeBook: 'Crossed Cheque book issuance'
          }
        },
        fixedDepositContent: {
          term: '3 Month minimum term',
          VAT: 'Withholding & Value Added Tax applies respectively',
          investment: 'Flexibility & Convenience of opening & liquidating investment',
          interestRate: 'Premature liquidation attracts 1.5% off pre-agreed interest  rate on the incurred period',
          keyFeatures: {
            attractive: 'Attractive Term rates',
            initialDeposit: 'Initial deposit',
            initialDepositValue: 'From 2,000,000',
            minAmount: 'Minimum Amount for Fixed Deposits',
            minAmountValue: '2,000,000',
            minTerm: 'Minimum term of term deposit',
            monthsSmall: 'months',
            months: 'Months',
            years: 'Years',
            slab1Rate: '3.5% p.a',
            slab2Rate: '3.5% p.a',
            slab3Rate: '3.8% p.a',
            depositRate: 'Deposit negotiable rate',
            dnRate: 'Above 10,000,000 CFAF Speak to Bank Relationship Manager',
            mip: 'Maturity interest paid',
            mnPaid: 'Principal and interest is credited to linked Current or Savings account',
            partialFull: 'Partial / Full break of term deposit upliftment fee',
            pfBreak: 'Premature liquidation attracts 1.5% off pre-agreed interest rate on the incurred period'
          }
        },
        savingsPlusAccount: {
          minBalance: 'Minimum balance 10,000 CFAF ',
          noInitialDeposit: 'No initial deposit required',
          interestPaid: 'Interest paid monthly and withholding & Value Added Tax applies respectively',
          interestRates: 'Tiered interest rates from 4.0% - 5.0%',
          keyFeatures: {
            attractiveInterest: 'Attractive interest rates from',
            slab1: '0 - 999,999',
            slab1Value: '4.00%',
            slab2: '1,000,000 - 7,499,999',
            slab2Value: '4.75%',
            aboveCFAF: 'CFAF 7,500,000 - 10,000,000',
            slab3Value: '5%',
            interestTermPaid: 'Interest maturity term paid',
            monthly: 'Monthly',
            initialDeposit: 'Initial deposit',
            notRequired: '',
            additionalCharges: 'Fees for additional debit transaction',
            additionalDebitTransactions: 'CFAF 5,000<br/>Cash withdrawals: free<br/>POS transaction: free',
            minBalance: 'Minimum Balance',
            minBalanceAmount: '10,000',
            feesBalanceMin: 'Fall below minimum fee',
            quarterAmount: 'CFAF 2,500/quarter',
            monthlyMaintenanceFee: 'Monthly account maintenance fee',
            noOfTransactions: 'Number of debit transactions allowed',
            months2: '2/month',
            atmDebitInsurance: 'ATM / Debit card issuance ',
            onlineBankaccess: 'Online Banking access',
            mobileBankAccess: 'Mobile Banking access',
            MonthStatement: 'Monthly eStatement',
            atmDebitCash: 'ATM/Debit card cash withdrawal (GIM UEMOA Network)',
            atmCashWAEMU: 'ATM cash withdrawal within the WAEMU zone (Other networks such as Visa)',
            atmCashOutside: 'ATM cash withdrawal (Outside of WAEMU zone)'
          }
        }
      },
      DISCLAIMER: {
        label: 'Approximate time to complete',
        time: '15 minutes',
        information1: 'You will need these documents to complete the application.',
        information2:
          'Your progress will be saved at each stage, so you can leave or resume your application at any time.',
        secureMessage: 'You are entering a secure environment and your data is protected.',
        nationalID: 'National Identity Card / Passport ',
        photo: 'Selfie taken on white background, holding your National Identity Card / Passport',
        address: 'Proof of Residence',
        existingAccount:
          'If you have an existing account with Standard Chartered, please sign up for an account through <a target="_blank" href="https://online.standardchartered.com/nfsafr/ibank/ci/foa/login.htm">our website</a>.',
        salary:
          'If you have an existing account with Standard Chartered, please sign up for an account through our website.',
        uploadSign: 'Upload New Signature (Please sign on a white paper and take a picture)',
        uploadInfo: 'Residence Certificate, Utility Bill or Rent Lease Agreement',
        letgetstarted: "LET'S GET STARTED"
      },
      mostPopularRequests: {
        cardBlock: 'Report Lost/Stolen Card',
        replaceCards: 'Replace Cards',
        replaceCards1: 'Replace Credit Cards',
        replaceCards2: 'Replace Debit Cards',
        debitCardBlockAndReplace: 'Debit Card Block and Replace',
        debitCardReplace: 'Debit Card Replace',
        debitCardActivationPinset: 'Card Activation and PIN set',
        debitCardPinRest: 'Debit Card PIN Reset',
        chequeBookRequest: 'Cheque Book Request',
        profileUpdate:
          'Update My Profile<span id="landing-popular-subtext">Review and update your profile with the latest details.</span>',
        letterRequest: 'Letter Request',
        chequeBookActivation: 'Cheque Book Activation',
        chequeStop: 'Cheque Book Stop/Block',
        chequeConfirmation: 'Confirm a Cheque',
        newChequeBook: 'New Cheque Book Request',
        accountOpening: 'Account Opening',
        jointAccount: 'Joint Account'
      },
      contactLinks: {
        IN: '',
        SG: '',
        HK: '',
        MY: '',
        AE: 'https://www.sc.com/ae/contact-us/'
      },
      contactLinksTxt: {
        default: '24/7 Phone Banking'
      },
      fullName: 'Full Name',
      closeWindowText:
        'If you want to leave this page,<br>kindly select the "X" option available in the browser tab/window.',
      validation: {
        crossSelectionCASAError: 'You cannot select combination of Islamic and Classic account.',
        only: 'Only ',
        allowedApply: 'You can select ',
        zibukaCASAValidation: 'You can apply for only one Current and one Savings account per application',
        allowedApply_1: 'Please select ',
        overallMaxValidation: ' product allowed per application',
        productSelectionValidation:
          ' Bank account Product at a time. Please Visit again to apply for another Bank account product.',
        productSelectionValidation_1:
          ' product under each category. Please visit again to apply for another bank product.',
        productSelectionValidation_2: '',
        categoryRestrictionAsset: {
          title: 'Change selection?',
          message: 'You can only pick one product in this category to apply'
        },
        categoryRestriction: {
          message: 'The selected products combination is not allowed. Please select some other combination to proceed.'
        }
      }
    },
    NG_DEBITCARD_ERROR_MAP: {
      tier1_title: 'Please note',
      tier1_message:
        'To request for Debit/ATM card on an INSTANT ACCOUNT, kindly UPGRADE to Instant Plus or Regular Savings first.'
    },
    CREDITCARD_ERROR_MAP: {
      'CSL-CC-301':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-302':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-303':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-304':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-305':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-306':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-307':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-308':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-312':
        'You have exceeded the PIN try limit. Kindly call our 24-hour Customer Care hotline for further assistance.',
      'CSL-CC-313':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-314':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-315':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-422':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline or walk in to any of our branches for further assistance.',
      'CSL-CC-423':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline or walk in to any of our branches for further assistance.',
      'CSL-CC-409':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-417':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-407':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-416': 'Please enter Standard Chartered Credit Card for activation.',
      'CSL-CC-415':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-405':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-414':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-404':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-413':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-403':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-412':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-402':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-411':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-401':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-410':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-418':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-316':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-OTP-1328':
        'Sorry, due to maximum invalid OTP attempts you will not receive any OTP for transactions for the next 24 hours.',
      'CSL-SEC-519': 'Max retry attempt reached, kindly reset.',
      '1308':
        'You have entered invalid one-time password (OTP). Please check and re-enter your one time password(OTP). (Error Code:1308)',
      '1307': 'Your one-time password (OTP) had expired. Please request for a new OTP. (Error Code:1307)',
      'CSL-OTP-1024': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-OTP-1026': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-OTP-400': 'The mobile must be between 9 and 30 chars long'
    },
    CARDREPLACEMENT: {
      'header.title': 'Request for Replacement Card',
      cardlistHeader1: 'Select cards to replace',
      cardlistHeader2: 'Your card(s) to be replaced',
      cardlistHeader3: 'Your Replacement Cards',
      cardlistHeader4: 'Select debit cards to replace',
      cancelPopup: 'Do you want to cancel your Card Replacement request?',
      countryLinks: {
        IN: 'https://www.sc.com/in/help-centre/service-charges-fees.html',
        SG: 'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf',
        HK: 'https://www.sc.com/global/av/hk-service-charges-en.pdf',
        MY: 'https://www.sc.com/my/help-centre/fees-and-charges.html',
        AE: 'https://www.sc.com/ae/help-centre/service-charges.html',
        BW: 'https://www.sc.com/global/av/bw-imp-info-tariff-guide-may-2017.pdf',
        GH: 'https://www.sc.com/global/av/gh-scb-tariff.pdf',
        KE: 'https://www.sc.com/ke/help-centre/service-charges.html',
        NG: 'https://www.sc.com/global/av/ng-tarrif-guide-new.pdf',
        ZM: 'https://www.sc.com/zm/'
      },
      countryLinksTxt: {
        default: 'fee schedule'
      },
      countryNotes: {
        IN:
          "You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>Cards reported lost or stolen are eligible for replacement within 90 days from reported date.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.",
        SG:
          'This request is for replacement of<ul><li>Damaged cards or</li><li>Cards that have already been reported lost/stolen</li></ul>Credit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/ stolen card, please use the Report Lost/Stolen Card Service Request.<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. If you have previously reported a lost or stolen card, please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any GIRO arrangement to your new credit card. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.',
        HK:
          'You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br><b>If you have NOT reported your card as lost/stolen</b>, you may do so by using Report Lost/Stolen service request.<br>Cards reported lost or stolen are eligible for replacement within 90 days from reported date.<br>Replacement card will be sent to your registered mailing address.<br>If you do not see the card you wish to replace in the list above, please contact  Standard Chartered Credit Card Hotline (852) 2886 4111 for assistance.<br>All supplementary cards (if any) will be replaced once the primary card is replaced.',
        MY:
          'This page is to request for card(s) replacement only.<br>For card replacement, please discard/destroy the existing card before raising this service request.<br>The replacement card will be sent to your registered mailing address within 7 working days.<br>There will not be any fees and charges for card replacement.<br>Please arrange to update your auto-debit transaction(s) once you have received the replacement card.<br>For assistance, kindly contact us at 1300 888 888 or +603-7711 8888.',
        AE:
          "You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.",
        BW:
          "You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.",
        GH:
          "You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.",
        KE:
          "You may use this request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen Credit Card service request.<br>A fee may be applicable depending on card type. Please check Bank's {{inter_link}} for more information.<br>A replacement card will be automatically ordered and sent to your registered delivery address. Please ensure that your delivery address with us is up to date.<br>If you do not see the card you wish to replace in the list above, please contact our client care centre on +254 20 3293900, +254 703 093 900, +254 732 143 900 for further assistance.",
        NG:
          "You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.",
        ZM:
          "You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>A replacement card will be automatically ordered and sent to your branch or registered mailing address on request. Please ensure that your mailing address with us is up to date.<br>A fee may be applicable depending on card type. Please check Bank's {{inter_link}} for more information.<br>If you do not see the card you wish to report in the list above, please call our Client Care Centre on 5247 or 260966751500 for assistance.",
        VN:
          'This request is for replacement of<ul><li>Damaged cards or</li><li>Cards that have already been reported lost/stolen</li></ul>Credit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/ stolen card, please use the Report Lost/Stolen Card Service Request.<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. If you have previously reported a lost or stolen card, please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.',
        BN:
          'This request is for replacement of<ul><li>Damaged cards or</li><li>Cards that have already been reported lost/stolen</li></ul>Credit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/ stolen card, please use the Report Lost/Stolen Card Service Request.<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. If you have previously reported a lost or stolen card, please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any GIRO arrangement to your new credit card. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.',
        BD:
          'This request is for replacement of<ul><li>Damaged cards or</li><li>Cards that have already been reported lost/stolen</li></ul>Credit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/ stolen card, please use the Report Lost/Stolen Card Service Request.<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. If you have previously reported a lost or stolen card, please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any GIRO arrangement to your new credit card. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.',
        LK:
          'This request is for replacement of<ul><li>Damaged cards or</li><li>Cards that have already been reported lost/stolen</li></ul>Credit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/ stolen card, please use the Report Lost/Stolen Card Service Request.<br>We will send the replacement card(s) to your card delivery address in our records. If you have previously reported a lost or stolen card, please note that the replaced card will have a new number and PIN.<br>Card replacement charges will apply as per the tariff.<br>Please note that you will need to update your existing payment arrangements/ standing instructions given to third party (if any), after receiving your new card.<br>Any standing order placed from your Standard Chartered account to the above Credit Card, will be transferred to the new replacement card.',
        NP:
          'This request is for replacement of<ul><li>Damaged cards or</li><li>Cards that have already been reported lost/stolen</li></ul>Credit cards reported lost/stolen are eligible for replacement within 90 days from the date of reporting. To report a lost/ stolen card, please use the Report Lost/Stolen Card Service Request.<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. If you have previously reported a lost or stolen card, please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any GIRO arrangement to your new credit card. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.'
      },
      statusMsg: {
        SG: {
          success:
            "Your request has been submitted. We will be processing your replacement card(s), including any supplementary cards. To check on the status of your request, go to the 'Status’ tab under 'Help & Services' via Online Banking or the SC Mobile App.",
          failure:
            'We have encountered an error while processing your request. Please cancel the request and try again.',
          incomplete: 'We have encountered an error with your card(s). Please cancel the request and try again.'
        },
        MY: {
          success:
            'Your card replacement request is successfully submitted and can be tracked online via Service Request Status Enquiry page.',
          failure:
            'Sorry, we are unable to process your request at the moment. Please try again or contact our Lost or Emergency Service Hotline at 1300 888 888 or +603-7711 8888 for immediate assistance.',
          incomplete:
            'Sorry, we are unable to process your request at the moment. Please try again or contact our Lost or Emergency Service Hotline at 1300 888 888 or +603-7711 8888 for immediate assistance.'
        },
        HK: {
          success:
            'Your replacement request is submitted.<br>Your replacement request status can be tracked online via "Help and Services".',
          failure:
            'We are unable to process your request at the moment. For enquiry, please contact us: Standard Chartered Credit Card 24-hour Customer Service Hotline (852) 2886-4111. Standard Chartered Banking Service Hotline (Including ATM card) (852) 2886-8888.',
          incomplete:
            'Some of your cards below did not get processed. For enquiry, please contact us: Standard Chartered Credit Card 24-hour Customer Service Hotline (852) 2886-4111. Standard Chartered Banking Service Hotline (Including ATM card) (852) 2886-8888.'
        },
        KE: {
          success:
            'Your replacement request is submitted.<br>Your replacement request status can be tracked online via Status Enquiry.',
          failure:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 254 20329 3900 for any assistance.',
          incomplete:
            'Some of your cards below did not get processed. Please try submitting the request again or contact our client care centre on 254 20329 3900 for any assistance.'
        },
        NP: {
          success:
            'Your replacement request is submitted.<br>Your replacement request status can be tracked online via Service Request Status Enquiry.',
          failure:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our 24X7 Client Care Center service for assistance.',
          incomplete:
            'Some of your cards below did not get processed. Please try submitting the request again or contact our 24X7 Client Care Center service for assistance if the issue persists.'
        },
        success:
          'Your replacement request is submitted.<br>Your replacement request status can be tracked online via Service Request Status Enquiry.',
        failure:
          'We are unable to process your request at the moment. Please try submitting the request again or contact our {{contactUsLink}} service for assistance.',
        incomplete:
          'Some of your cards below did not get processed. Please try submitting the request again or contact our {{contactUsLink}} service for assistance if the issue persists.'
      }
    },

    LOANCLOSURE: {
      'header.title': 'Closure of CashOne/Credit Card Instalment Loan',
      reasonCancellation: 'I’m closing my loan because',
      selectreason: {
        header: 'I’m closing my loan because',
        placeholder: 'select reason',
        reasonToBlock: 'Reason to block',
        CCCRSN01: {
          SG: "I've sufficient cash to repay loan",
          default: "I've sufficient cash to repay loan"
        },
        CCCRSN02: {
          SG: "I've taken up another Loan",
          default: "I've taken up another Loan"
        },
        CCCRSN03: {
          SG: 'of fees and charges',
          default: 'of fees and charges'
        },
        CCCRSN04: {
          SG: "I'm unhappy with approved Loan Amount",
          default: "I'm unhappy with approved Loan Amount"
        },
        CCCRSN05: {
          SG: 'of delay in Disbursement',
          default: 'of delay in Disbursement'
        },
        CCCRSN06: {
          SG: "I'm unhappy with Bank Service",
          default: "I'm unhappy with Bank Service"
        },
        CCCRSN07: {
          SG: "I'm migrating to overseas",
          default: "I'm migrating to overseas"
        }
      },
      confirmReason: {
        CCCRSN01: {
          SG: "I've sufficient cash to repay loan",
          default: "I've sufficient cash to repay loan"
        },
        CCCRSN02: {
          SG: "I've taken up another Loan",
          default: "I've taken up another Loan"
        },
        CCCRSN03: {
          SG: 'of fees and charges',
          default: 'Fees and charges'
        },
        CCCRSN04: {
          SG: "I'm unhappy with approved Loan Amount",
          default: "I'm unhappy with approved Loan Amount"
        },
        CCCRSN05: {
          SG: 'of delay in Disbursement',
          default: 'Delay in Disbursement'
        },
        CCCRSN06: {
          SG: "I'm unhappy with Bank Service",
          default: "I'm unhappy with Bank Service"
        },
        CCCRSN07: {
          SG: "I'm migrating to overseas",
          default: "I'm migrating to overseas"
        }
      },
      years: 'Years',
      instalments: 'Instalments',
      detailStatement: 'The detail is valid until',
      cardlistHeader1: 'Select the loan(s) you wish to close',
      cardlistHeader2Mob: 'Selected loan(s) to be closed',
      cardlistHeader2: 'Selected loan(s) to be closed',
      cardlistSubHeader:
        'If you do not see the card you wish to cancel in the list below, please contact our 24/7 Phone Banking immediately.',
      creditCardText: 'Credit Card(s)',
      contactText: 'We will contact you via this number to complete the loan closure.',
      contactNumber: 'Contact Number',
      statusMsg: {
        success:
          'Request submission successful. We will call you back within 3 business days to complete processing of your request.',
        submitted:
          'Your cancellation request has been submitted and your card(s) has been temporarily blocked. We will send a confirmation SMS/Email in 1 working day.',
        failure:
          'We are unable to process your request at this time. Please try submitting the request again or contact 24 hour Phone Banking service for assistance.',
        incomplete:
          'Some of your cancellation request(s) are not successfully submitted. Please try submitting the request(s) again or contact our 24-hour Phone Banking service for assistance if this issue persists.'
      },
      referenceNumber: 'Reference Number',
      reasonForCancellation: 'Reason for cancellation',
      collapsibleHeader: 'More Details',
      loanDuration: 'Loan Duration',
      RMI: 'Remaining Monthly Instalments',
      nextPosting: 'Next Posting:',
      rewardPoints: 'Reward Points',
      expiry: 'Expiry:',
      ezpay: 'EasyPay/Instalment Payment Plan(s)',
      giro: 'Giro Setup',
      tokenCard: 'Token Card',
      priorityPass: 'Priority Pass',
      supplementaryCard: 'Supplementary Card(s)',
      bankAccount: 'Bank Account(s)',
      noCardsHeading: 'No eligible card detected.',
      noCardsMessage:
        'If you do not see the card you wish to cancel in the list, please contact our 24/7 Phone Banking immediately.',
      countryNotes: {
        default:
          '<ol><li>After successful submission of your request, we will call you back with further details to complete processing. This will typically take 2-3 working days. If your payment due date is approaching, do continue to make payment to avoid any fees and charges.</li><li>Please settle the full amount in your final statement which will be sent to you after the loan is closed.</li><li>Please note that closure of this loan does not cancel any credit cards that may be linked to the loan account. To cancel a credit card, please submit a separate Card Cancellation request.</li></ol>'
      },
      cardsTitle: 'Selected loan(s) to be closed',
      systemError: {
        SG:
          "We've encountered an error while processing your request. Please cancel the request and try again.  For assistance, please call our 24-hour Client Contact Centre at 1800 747 7000 or +65 6747 7000 from overseas."
      }
    },

    CARDCANCELLATION: {
      'header.title': 'Card Cancellation',
      ineligibleAlertHeader: 'The card is ineligible because of the following reason(s):',
      reasonCancellation: 'Reason for cancellation',
      contactText: 'We will contact you via this number to complete the card cancellation.',
      contactNumber: 'Contact Number',
      balanceTransferErrorMessage:
        'You have active loans with us. Please ensure your loans are fully settled and closed before cancelling all your cards.',
      balanceTransferButtonLabel: 'OK',
      points: 'pts',
      countryNotes: {
        IN:
          '<ol><li>This request does not cancel the card immediately. You will be liable for transactions made using the card until the card account has been successfully cancelled.</li><li>Cards with an outstanding balance will not be liable for card cancellation.</li><li>A bank personnel may contact you to complete the card cancellation process after the request submission.</li></ol>',
        SG:
          '<ol><li>Your selected card(s) will be temporarily blocked upon submission of the request. Please note that we may need to call you after submission of your request to confirm further details.</li><li>Please note that any supplementary cards will also be cancelled when you cancel the main card.</li><li>If you have any recurring payment arrangements, such as GIRO or standing instructions, please notify the merchant(s) immediately to cancel any further payments to the card.</li><li>If there are any transactions that are not yet posted to your card, they will be reflected in subsequent statements. Please continue to pay your outstanding balances.</li><li>Any existing rewards points and cashback that has not been posted will automatically be forfeited. If you wish to utilise your rewards points, please redeem your points before cancelling the credit card.</li><li>Existing fees and charges, excluding annual fees, are still applicable. Refer to our <a href="https://www.sc.com/sg/terms-and-conditions/" target="_blank"> credit cards terms and conditions</a> for more details.</li></ol>',
        HK:
          '<ol><li>This request does not cancel the card immediately. You will be liable for transactions made using the card until the card account has been successfully cancelled.</li><li>Cards with an outstanding balance will not be liable for card cancellation.</li><li>A bank personnel may contact you to complete the card cancellation process after the request submission.</li></ol>',
        AE:
          '<ol><li>Request for cancelling the card does not immediately cancel the card account. You will be liable for any transactions made using the card till the closure of the account is successful.</li><li>Cancellation process cannot be completed for cards with outstanding balance.</li><li>Post successful submission of the request bank personnel may reach out to you for further processing for the cancellation request.</li></ol>',
        default:
          '<ol><li>This request does not cancel the card immediately. You will be liable for transactions made using the card until the card account has been successfully cancelled.</li><li>Cards with an outstanding balance will not be liable for card cancellation.</li><li>A bank personnel may contact you to complete the card cancellation process after the request submission.</li></ol>'
      },
      confirmationNotes: {
        IN:
          '<ol><li>This request does not cancel the card immediately. You will be liable for transactions made using the card until the card account has been successfully cancelled.</li><li>Cards with an outstanding balance will not be liable for card cancellation.</li><li>A bank personnel may contact you to complete the card cancellation process after the request submission.</li></ol>',
        SG:
          '<ol><li>Your selected card(s) will be temporarily blocked upon submission of the request. Please note that we may need to call you after submission of your request to confirm further details.</li><li>Please note that any supplementary cards will also be cancelled when you cancel the main card.</li><li>If you have any recurring payment arrangements, such as GIRO or standing instructions, please notify the merchant(s) immediately to cancel any further payments to the card.</li><li>If there are any transactions that are not yet posted to your card, they will be reflected in subsequent statements. Please continue to pay your outstanding balances.</li><li>Any existing rewards points and cashback that has not been posted will automatically be forfeited. If wish to utilise your rewards points, please redeem your points before cancelling the credit card.</li><li>Existing fees and charges, excluding annual fees, are still applicable. Refer to our <a href="https://www.sc.com/sg/terms-and-conditions/" target="_blank"> credit cards terms and conditions</a> for more details.</li></ol>',
        HK:
          '<ol><li>This request does not cancel the card immediately. You will be liable for transactions made using the card until the card account has been successfully cancelled.</li><li>Cards with an outstanding balance will not be liable for card cancellation.</li><li>A bank personnel may contact you to complete the card cancellation process after the request submission.</li></ol>',
        AE:
          '<ol><li>Request for cancelling the card does not immediately cancel the card account. You will be liable for any transactions made using the card till the closure of the account is successful.</li><li>Cancellation process cannot be completed for cards with outstanding balance.</li><li>Post successful submission of the request bank personnel may reach out to you for further processing for the cancellation request.</li></ol>',
        default:
          '<ol><li>This request does not cancel the card immediately. You will be liable for transactions made using the card until the card account has been successfully cancelled.</li><li>Cards with an outstanding balance will not be liable for card cancellation.</li><li>A bank personnel may contact you to complete the card cancellation process after the request submission.</li></ol>'
      },
      noCardsHeading: 'No eligible card detected.',
      noCardsMessage:
        'If you do not see the card you wish to cancel in the list, please contact our 24/7 Phone Banking immediately.',

      selectreason: {
        header: "I'm cancelling my card because",
        placeholder: 'select reason',
        reasonToBlock: 'Reason to block',
        CCCRSN01: {
          AE: "I'm not happy with the card offer",
          default: "I've too many cards"
        },
        CCCRSN02: {
          AE: "I'm not happy with the Annual fee charged",
          default: 'I seldom use'
        },
        CCCRSN03: {
          AE: 'I need to apply for different card for different benefit',
          default: "I'm migrating overseas"
        },
        CCCRSN04: {
          AE: "I'm applying for a new Loan and Credit card with other bank",
          default: 'of fees and charges'
        },
        CCCRSN05: {
          AE: 'Other bank cards have better offers',
          default: 'of unattractive benefits'
        },
        CCCRSN06: {
          AE: "I'm leaving the country",
          default: "I'm unhappy with bank service"
        },
        CCCRSN07: {
          AE: 'Other reasons',
          default: 'of other reasons'
        }
      },
      confirmReason: {
        CCCRSN01: {
          AE: "I'm not happy with the card offer",
          default: "I've too many cards"
        },
        CCCRSN02: {
          AE: "I'm not happy with the Annual fee charged",
          default: 'I seldom use'
        },
        CCCRSN03: {
          AE: 'I need to apply for different card for different benefit',
          default: "I'm migrating overseas"
        },
        CCCRSN04: {
          AE: "I'm applying for a new Loan and Credit card with other bank",
          default: 'Fees and Charges'
        },
        CCCRSN05: {
          AE: 'Other bank cards have better offers',
          default: 'Unattractive benefits'
        },
        CCCRSN06: {
          AE: "I'm leaving the country",
          default: "I'm unhappy with bank service"
        },
        CCCRSN07: {
          AE: 'Other reasons',
          default: 'Other reasons'
        }
      },
      cardlistHeader1: 'Select the card(s) you want to cancel',
      cardlistHeader2Mob: 'Selected credit card(s) to be cancelled',
      cardlistHeader2: 'Card(s) to be cancelled',
      cardlistSubHeader:
        'If you do not see the card you wish to cancel in the list below, please contact our 24/7 Phone Banking immediately.',
      creditCardText: 'Credit Card(s)',
      statusMsg: {
        submitted: {
          bankCallBack:
            'Your cancellation request has been submitted. A bank representative will contact you within 3 working days.',
          bankNoCallBack:
            'Your cancellation request has been submitted. You can check the progress of this request via "Status" tab in the "Help & Services" page.'
        },
        failure: {
          default:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance if the issue persists.',
          SG:
            'We have encountered an issue while processing your request. Please re-submit the request again. For assistance, please call our 24-hour Client Contact Centre at 1800 747 7000 or +65 6747 7000 from overseas.'
        },
        incomplete: {
          default:
            'Some cards in your cancellation request cannot be submitted successfully. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance if the issue persists.',
          SG:
            'We have encountered an issue for the card(s) listed below. Please re-submit your request for the unsuccessful cards.  For assistance, please call our 24-hour Client Contact Centre at 1800 747 7000 or +65 6747 7000 from overseas.'
        },
        success: {
          default:
            'Your card cancellation request has been submitted and your card(s) temporarily blocked. As part of processing, please expect a call from us within 3 business days to confirm the details of your request.',
          SG:
            'Your card cancellation request has been submitted and your card(s) are temporarily blocked. As part of processing, please expect a call from us within 3 business days to confirm the details of your request.'
        }
      },
      referenceNumber: 'Reference Number',
      reasonForCancellation: 'Reason for cancellation',
      collapsibleHeader: 'Card Details',
      currentAccount: 'Current Balance',
      cashback: 'Cashback',
      nextPosting: 'Next Posting:',
      rewardPoints: 'Reward Points',
      expiry: 'Expiry:',
      ezpay: 'EasyPay/Instalment Payment Plan(s)',
      giro: 'Giro Setup',
      tokenCard: 'Token Card',
      priorityPass: 'Priority Pass',
      supplementaryCard: 'Supplementary Card(s)',
      bankAccount: 'Bank Account(s)'
    },
    CARDBLOCK: {
      'header.title': 'Report Lost/Stolen Card',
      'header.title1': 'Report Lost/Stolen Credit Card',
      'header.title2': 'Report Lost/Stolen Debit Card',
      cardlistHeader1: 'Select the card(s) you want to block',
      cardlistHeader2: 'Selected card(s) to be blocked',
      cardlistHeader3: 'Your Replacement Cards',
      cardlistSubHeader:
        'If you do not see the card you wish to block in the list below, please contact our 24/7 Phone Banking immediately.',
      'cardlistSubHeader.KE':
        'If you do not see the card you wish to block in the list below, please contact our client care centre on +254 20 3293900',
      cancelPopup: 'Do you want to cancel your Report Lost/Stolen Credit Card request?',
      selectreason: {
        header: "I'm blocking my card because",
        placeholder: 'Select reason',
        reasonToBlock: 'Reason to block',
        reason1: 'I have lost my card',
        reason2: 'my card got stolen',
        reason3: 'my card got captured by the ATM'
      },
      countryLinks: {
        IN: 'https://www.sc.com/in/help-centre/service-charges-fees.html',
        SG: 'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf',
        HK: 'https://www.sc.com/global/av/hk-service-charges-en.pdf',
        MY: 'https://www.sc.com/my/help-centre/fees-and-charges.html',
        AE: 'https://www.sc.com/ae/help-centre/service-charges.html',
        BW: 'https://www.sc.com/global/av/bw-imp-info-tariff-guide-may-2017.pdf',
        GH: 'https://www.sc.com/global/av/gh-scb-tariff.pdf',
        KE: 'https://www.sc.com/ke/help-centre/service-charges.html',
        NG: 'https://www.sc.com/global/av/ng-tarrif-guide-new.pdf',
        ZM: 'https://www.sc.com/zm/'
      },
      countryLinksTxt: {
        default: 'fee schedule'
      },
      countryNotes: {
        IN:
          "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions made using the card prior to the blocking.",
        SG:
          'Upon confirmation, your card(s) will be blocked immediately and you will not be able to use it. This includes any supplementary cards. Please note that a blocked card cannot be reactivated.<br>You will not be liable for any transactions on the card(s) after this report. Any existing card balances will be transferred to the new replacement card(s).<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. Please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any GIRO arrangement to your new credit card. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.',
        HK:
          '<b>For reporting Credit Card as Lost/Stolen</b><ul><li>Upon confirmation, your Credit Card will be blocked immediately.</li><li>You will not be able to use your Credit Card once it is blocked.</li><li>Blocked Credit Card cannot be activated again.</li><li>You will be liable for any transactions made using the Credit Card prior to the blocking; Please call (852) 2886 4111 for Credit Card dispute transaction enquiry.</li><li>All supplementary cards (if any) will be blocked once the primary card is blocked.</li><li>Replacement card will be sent to your registered mailing address.</li><li>If you do not see the card you wish to report in the list above, please contact (852) 2886 4111.</li></ul><br><b>For reporting ATM Card as Lost/Stolen</b><ul><li>Upon confirmation, your ATM Card will be blocked immediately.</li><li>You will not be able to use your ATM Card once it is blocked.</li><li>Blocked card cannot be activated again.</li><li>After reporting your ATM Card as lost or stolen through this service, you can request for replacement card via "Replace ATM Card".</li><li>If you do not see the card you wish to report in the list above, please contact (852) 2886 8888</li></ul>',
        MY:
          'Upon confirmation, your card will be blocked immediately and cannot be used for any transactions i.e. purchase transactions or ATM withdrawals.<br>Blocked card cannot be activated again and the replacement card will be sent to your registered mailing address.<br>The replacement card will be sent to your registered mailing address within 7 working days.<br>There will not be any fees and charges for card replacement.<br>The existing credit/debit balance from your blocked account will be transferred to your new credit card account.<br>Please arrange to update your auto-debit transaction(s) once you have received the replacement card.<br>For assistance, kindly contact our Lost or Emergency Service Hotline at 1800 888 998 or +603-7849 6888.',
        AE:
          "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If you do not see the card you wish to report in the list above, please contact our 24/7 Phone Banking for assistance.",
        BW:
          "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br> Blocked card cannot be activated again.<br> Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If you do not see the card you wish to report in the list above, please contact our 24/7 Phone Banking for assistance.",
        GH:
          "Upon confirmation, your card will be blocked immediately.<br> You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If you do not see the card you wish to report in the list above, please contact our 24/7 Phone Banking for assistance.",
        KE:
          "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked in the event that you locate it after having reported it lost/stolen.<br>A blocked card cannot be activated again.<br>A replacement card will be automatically ordered and sent to your delivery address. Please ensure that your delivery address with us is up to date.<br>A fee may be applicable depending on card type. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel your account.<br>You will be liable for any transactions made using the card prior to blocking.<br>If you do not see the card you wish to report in the list above, please contact our client care centre on +254 20 3293900, +254 703 093 900, +254 732 143 900 for further assistance.",
        NG:
          "Upon confirmation, your card will be blocked immediately.<br> You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If you do not see the card you wish to report in the list above, please contact our 24/7 Phone Banking for assistance.",
        ZM:
          "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked in the event that you locate it after having reported it lost/stolen.<br>Blocked card cannot be activated again.<br>A replacement card will be automatically ordered and sent to your branch or registered mailing address on request. Please ensure that your mailing address with us is up to date.<br>A fee may be applicable depending on card type. Please check Bank's. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If you do not see the card you wish to report in the list above, please call our Client Care Centre on 5247 or 260966751500 for assistance.",
        BD:
          'Upon confirmation, your card(s) will be blocked immediately and you will not be able to use it. This includes any supplementary cards. Please note that a blocked card cannot be reactivated.<br>You will not be liable for any transactions on the card(s) after this report. Any existing card balances will be transferred to the new replacement card(s).<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. Please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any GIRO arrangement to your new credit card. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.',
        LK:
          'Upon confirmation, your card(s) will be blocked immediately and you will not be able to use it. Please note that a blocked card cannot be reactivated.<br>You will not be liable for any transactions on the card(s) after this report. Any existing card balances will be transferred to the new replacement card(s).<br>We will send the replacement card(s) to your card delivery address in our records. Please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing payment arrangements/ standing instructions given to third party (if any), after receiving your new card.<br>Any standing order placed from your Standard Chartered account to the above Credit Card, will be transferred to the new replacement card.',
        BN:
          'Upon confirmation, your card(s) will be blocked immediately and you will not be able to use it. This includes any supplementary cards. Please note that a blocked card cannot be reactivated.<br>You will not be liable for any transactions on the card(s) after this report. Any existing card balances will be transferred to the new replacement card(s).<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. Please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any GIRO arrangement to your new credit card. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.',
        NP:
          'Upon confirmation, your card(s) will be blocked immediately and you will not be able to use it. This includes any supplementary cards. Please note that a blocked card cannot be reactivated.<br>You will not be liable for any transactions on the card(s) after this report. Any existing card balances will be transferred to the new replacement card(s).<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. Please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.<br>We will also transfer any GIRO arrangement to your new credit card. Please note that if your debiting account is not with us, this may take 4 to 6 weeks, so please continue make payment on your card until you receive our confirmation letter on the setup.',
        VN:
          'Upon confirmation, your card(s) will be blocked immediately and you will not be able to use it. This includes any supplementary cards. Please note that a blocked card cannot be reactivated.<br>You will not be liable for any transactions on the card(s) after this report. Any existing card balances will be transferred to the new replacement card(s).<br>We will send the replacement card(s), including any supplementary cards, to your mailing address in our records. Please note that the replaced card will have a new number and PIN.<br>Please note that you will need to update your existing card billing and payment arrangements after receiving your replacement card.'
      },
      statusMsg: {
        SG: {
          success:
            "Your request has been submitted. We have blocked your card(s) and will be processing your replacement card(s). Please note that any supplementary card(s) will also be blocked and replaced. To check on the status of your request, go to the 'Status’ tab under 'Help & Services' via Online Banking or the SC Mobile App.",
          failure:
            'We have encountered an error while processing your request. Please cancel the request and try again.',
          incomplete: 'We have encountered an error with your card(s). Please cancel the request and try again.'
        },
        MY: {
          success:
            'Your card has been successfully blocked and your card replacement will be sent to your registered mailing address. Status of your card replacement can be tracked online via Service Request Status Enquiry page.',
          failure:
            'Sorry, we are unable to process your request at the moment. Please try again or contact our Lost or Emergency Service Hotline at 1800 888 998 or +603-78496888 for immediate assistance.',
          incomplete:
            'Sorry, we are unable to process some of your cards at the moment. Please try again or contact our Lost or Emergency Service Hotline at 1800 888 998 or +603-78496888 for immediate assistance.'
        },
        HK: {
          success:
            'Your card has been blocked and your replacement request is submitted. Credit card replacement request status can be tracked online via "Help and Services".<br>For ATM cards replacements, please select the card to replace from the card list and submit the request.',
          failure:
            'We are unable to process your request at the moment. Please contact us: Standard Chartered Credit Card 24-hour Customer Service Hotline (852) 2886-4111. Standard Chartered Banking Service Hotline (Including ATM card) (852) 2886-8888.',
          incomplete:
            'Some of your cards below did not get processed. Please contact us: Standard Chartered Credit Card 24-hour Customer Service Hotline (852) 2886-4111. Standard Chartered Banking Service Hotline (Including ATM card) (852) 2886-8888.'
        },
        KE: {
          success:
            'Your card has been blocked and your replacement request is submitted. Your replacement card request status can be tracked online via Status Enquiry.',
          failure:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 254 20329 3900 for any assistance.',
          incomplete:
            'Some of your cards below did not get processed. Please try submitting the request again or contact our client care centre on 254 20329 3900 for any assistance.'
        },
        VN: {
          success:
            'Your card has been blocked and your replacement request is submitted. Your replacement card request status can be tracked online via Status Enquiry.',
          failure:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our Client Care Center (24/7) at +84 28 3911 0000 for assistance',
          incomplete:
            'Some of your cards below did not get processed. Please try submitting the request again or contact our client care centre on +84 28 3911 0000 for any assistance.'
        },
        NP: {
          success:
            'Your card has been blocked and your replacement request is submitted. Your replacement request status can be tracked online via Service Request Status Enquiry.',
          failure:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our  24X7 Client Care Center service for assistance.',
          incomplete:
            'Some of your cards below did not get processed. Please try submitting the request again or contact our  24X7 Client Care Center service for assistance if the issue persists.'
        },
        success:
          'Your card has been blocked and your replacement request is submitted. Your replacement request status can be tracked online via Service Request Status Enquiry.',
        failure:
          'We are unable to process your request at the moment. Please try submitting the request again or contact our {{contactUsLink}} service for assistance.',
        incomplete:
          'Some of your cards below did not get processed. Please try submitting the request again or contact our {{contactUsLink}} service for assistance if the issue persists.'
      }
    },
    CHEQUEBOOK: {
      'header.title': 'Cheque Book Request',
      accountsList: 'Account(s)',
      selectAccountList: 'Select Account(s) for Cheque Book',
      deliveryMethodText: 'DELIVERY METHOD',
      deliveryDetailsText: 'Delivery Details',
      deliveryAddressText: 'Delivery Address',
      selectedBranchText: 'SELECTED BRANCH',
      collectFromBranch: 'Collect from Available Branches',
      deliveryToAddress: 'Send to Registered Mailing Address',
      selectedAddressText: 'Selected Address',
      selectBranchHeader: 'Select a Preferred Branch',
      selectBranchText: 'Select Branch',
      'progress.step1': '1 of 2',
      'progress.branchFlow.step1': '1 of 3',
      'progress.step2': '2 of 2',
      'progress.branchFlow.step2': '2 of 3',
      'progress.branchFlow.step3': '3 of 3',
      countryNotes: {
        IN:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>The cheque book will be dispatched to your mailing address as available in our records and will reach you within 7 working days.</li><li>If you have recently changed your address, please get it updated in our records immediately. Address update in our system will be processed within 4 working days of submitting the address change request.</li><li>You can request for one cheque book for your account in a day. For bulk request, kindly submit a written request at your nearest branch.</li></ol>',
        SG:
          '<ol><li>Only eligible accounts for this request are shown.</li><li>Cheque books will be sent to the account\'s mailing address in our records.</li><li>Please ensure your address with us is up to date before submitting this request. If you have submitted an address change, please note that this takes three working days to update in our system.</li><li>Charges may apply. Please see our <a  href="https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf" target="_blank">fee schedule</a> for more details.</li></ol>',
        MY:
          '<ol><li>Only eligible account(s) for this request is shown.</li><li> Upon successful cheque book request submission, the cheque book will be sent to your mailing address within 7 working days. Joint account cheque book will be sent to the primary account holder’s mailing address.</li><li>  Please ensure your mailing address is up to date. Otherwise, you may proceed to update your mailing address and please allow 5 working days before submitting your cheque book request.</li><li>This self service request is not applicable if your mailing address is a P.O.Box address. Please call our Client Care Centre to assist with your cheque book request.</li><li>Charges:<br/>Personal Clients: Stamp Duty : RM7.50 (50 cheque leaves at RM0.15 per leaf)<br/>Ordinary mail charges including GST : RM2.12<br/>Priority Banking Clients: Stamp Duty : RM7.50 (50 cheque leaves at RM0.15 per leaf)<br/>Courier charges including GST : RM5.30</li></ol>',
        HK:
          '<ol><li>Only accounts eligible for this request are shown.</li><li>Cheque book(s) will be sent to your registered mailing address and will reach you within 7 working days.</li></ol>',
        AE:
          '<ol><li>Only accounts eligible for this request are shown.</li><li>Cheque book(s) will be sent to your registered mailing address.</li></ol>',
        KE:
          '<ol><li>Only Accounts that are eligible for a Cheque Book request are displayed.</li><li> Please ensure that your physical/mailing address with us is up to date before submitting this request.</li><li>If you have recently made a request to update your physical/mailing address, please allow 2 working days before submitting your cheque book request.</li><li>You can only request for another cheque book once the previous request has been processed.</li><li> Your new cheque book will be mailed to your physical/mailing address in four (4) working days.</li><li>Cheque book request charges apply as per the <a href="https://www.sc.com/ke/help-centre/service-charges.html">tariff guide.</a></li></ol>',
        UG:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>Please ensure your address with us is up-to-date before submitting this request. Otherwise, you may proceed to update your mailing address and please allow 5 working days before submitting your cheque book request.</li></ol>',
        NG:
          '<ol><li>Only funded and eligible accounts will be displayed for Cheque Book request.</li><li>You are only required to submit one Cheque Book request per account. The system will reject multiple requests provided there is another request from same account that is pending processing.</li><li>The booklets will come in 50 leaves.</li><li>Your account will be debited for the equivalent cheque book fee once the request is submitted successfully. Please refer to our tariff guide for the <a href="https://www.sc.com/global/av/ng-tarrif-guide-new.pdf" target="_blank">applicable fee</a></li><li>Your cheque book will be available for collection at your selected branch within 5 working days.</li><li>You can view the status of your cheque book request in the ‘Status’ section. </li><li>If you require further assistance, kindly contact our Client Contact Centre on +234-1-2704611-4 or send an email to <a href="mailto:ClientCare.NG@sc.com">ClientCare.NG@sc.com</a></li></ol>',
        TZ:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>Please ensure your address with us is up-to-date before submitting this request. Otherwise, you may proceed to update your mailing address and please allow 5 working days before submitting your cheque book request.</li></ol>',
        ZM:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>Please ensure your address with us is up-to-date before submitting this request. Otherwise, you may proceed to update your mailing address and please allow 5 working days before submitting your cheque book request.</li></ol>',
        GH:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>Please ensure your address with us is up-to-date before submitting this request. Otherwise, you may proceed to update your mailing address and please allow 5 working days before submitting your cheque book request.</li></ol>',
        BW:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>Please ensure your address with us is up-to-date before submitting this request. Otherwise, you may proceed to update your mailing address and please allow 5 working days before submitting your cheque book request.</li></ol>',
        ZW:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>Please ensure your address with us is up-to-date before submitting this request. Otherwise, you may proceed to update your mailing address and please allow 5 working days before submitting your cheque book request.</li></ol>',
        default:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>Cheque Book will be sent to your Registered mailing address.</li></ol>'
      },
      statusMsg: {
        branchSelected:
          'Your request has been submitted. <br>Your cheque book will be available for collection at the branch you selected within 5 working days.',
        addressSelected:
          'Your request has been submitted. <br>Your cheque book will be sent to the mailing address in our records.',
        success:
          '{{#unless media.isMobile}}Your request has been submitted. <br>{{/unless}}Your cheque book will be sent to the mailing address in our records.',
        failure:
          'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance. Reference #',
        incomplete:
          'Some of your cards below did not get processed. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance if the issue persists. Reference #',
        HK:
          'Your request has been submitted.<br>Cheque book(s) will be sent to your registered mailing address  and will reach you within 7 working days.'
      },
      referenceNumber: 'Reference Number',
      noAccount:
        'There are no eligible Accounts for which Cheque Book Request can be initiated. Please Contact your Relationship Manager or Contact Call Centre or Branch',
      'selectAccount.title': 'Select Details',
      'confirmAccount.title': 'Confirm Details',
      confirmCancelText: 'Do you want to cancel your Cheque Book request?',
      noAccountWarningText: {
        IN:
          'ERR_CHQ_002 - We are unable to process your request as you do not have any eligible accounts for cheque book. Kindly contact our phone banking team or visit our branches for assistance.',
        SG: 'ERR_CHQ_002 - Sorry, you do not have any accounts that are eligible for this request.',
        HK: 'Sorry, you do not have any accounts that are eligible for this request.',
        KE:
          'We are unable to process your request as you don’t have any eligible accounts. Please contact us on 254 20 3293900 or email us on Ke.service@sc.com .'
      }
    },
    STATUSENQUIRY: {
      'header.title': 'Status',
      'activeSection.title': 'ACTIVE',
      'completedSection.title': 'COMPLETED',
      statusReferenceNo: 'Service. No.',
      statusUpdatedDate: 'Estimated Completion Date:',
      statusCardReplacement: 'Card Replacement Status:',
      statusCardReplacementM: 'Replacement Status:',
      statusUpdateDateMobile: 'Est. Completion:',
      noActiveRequest: 'There are no active requests',
      statusOfRecords: 'This page only shows requests from the past 90 days',
      'statusOfRecords.KE': 'This page only shows request made in the last 90 days',
      'statusOfRecords.IN':
        'If you are unable to view the status of your earlier request, please <a href="/retail/api/security/v1/ssoRequest?RedirPageId=VIEWSTATUS">click here</a>.<br/><br/>This page only shows requests from the past 90 days.',
      clClosure: 'Loan Account(s)',
      labelReceive: 'RECEIVED',
      labelProcessing: 'PROCESSING',
      labelCompleted: 'COMPLETED',
      labelRejected: 'REJECTED',
      labelSuccess: 'SUCCESS',
      labelFailed: 'FAILED',
      labelCancelled: 'CANCELLED',
      labelRetained: 'RETAINED',
      labelNotProcessed: 'NOT PROCESSED',
      labelClosed: 'CLOSED',
      updatedDate: 'Updated on',
      dateSubmitted: 'Date Submitted',
      'account/relationshipNo': 'Account(s)',
      CC: 'Credit Card',
      creditCard: 'Blocked Credit Cards',
      debitCard: 'Blocked Debit Cards',
      ccCancellation: 'Card Account(s)',
      CCFWR: 'Fee Waived',
      CCFWC: 'Fee Charged',
      creditCardReplace: 'Replaced Credit Card',
      debitCardReplace: 'Replaced ATM Card',
      referral: 'Action Required',
      authVerification: 'CUSTOMER CONSENT',
      resume: 'Resume',
      verification: 'Verification',
      activation: 'Activation',
      pending: 'Pending',
      agentTitle: 'Begin Authentication with Agent',
      agentDescription: 'An authentication with our agent is required to complete your account application.',
      accountDetails: 'Account Opening Details',
      debitCardIssuance: 'Applied ATM Card',
      accountDebited: 'Account No/Credit Card No to be debited',
      statementAcc: 'Statement Account',
      PLCLOSUR: 'PLC account to be closed'
    },
    LANDINGPAGE: {
      tabText: {
        createRequest: 'Create Request',
        status: 'Status'
      },
      'header.title': 'Help & Services',
      noResultsFound: 'No results found',
      needHelp: 'I need help with my',
      regardsTo: 'regarding',
      popularServices: 'Most popular service requests',
      popularServicesCI: 'Service Request',
      allServicesCategory: 'Service requests by category',
      'help&usefulLinks': 'Help & Useful Links',
      search: 'Search...'
    },
    STATEMENTREQUEST: {
      'header.title': 'Statement Request',
      'selectAccount.title': 'Select an Account ',
      'account.title.text': 'Select an account to request for a hardcopy statement',
      'date.selection.label': 'Select Source Date',
      'casa.title.text': 'Current/Savings Account',
      'creditcard.title.text': 'Credit Card',
      notes:
        "Fee may be apply depending on the statement requested. Please check Bank's <a>fee schedule</a> for more information.<br> <br>Your statement will be sent to your registered mailing address. Please ensure your address is correct. Contact <a>24/7 Phone Banking</a> if you wish to update your address.",
      'confirm.title.text': 'Confirm Details',
      'account.label': 'Account Number',
      'statement.label': 'Statement Option',
      'statement.date.label': 'Statement Date',
      'statusMsg.success':
        'Your request has been submitted. You can track your statement status online via Service Request Status Enquiry.',
      referenceNumber: 'Reference Number',
      'account.type': 'Account Type',
      'statement.date': 'Statement Date',
      'cc.title.text': 'Credit Card'
    },
    DEBITCARDREPLACEMENT: {
      'header.title': 'Replace Debit/ATM Card',
      'header.title1': 'Apply New Debit/ATM Card',
      replaceCardTitle: 'Replace card with',
      selectLanguageTitle: 'Select language for the ATM',
      accountIncludeTitle: 'Account(s) linked to card',
      primaryAccountTitle: 'Primary Account',
      otherAccountTitle: 'Other Account(s)',
      replacementFeeTitle: 'Replacement Fee',
      replacementFeeSubtitle: 'Account to debit from',
      replaceCardwith: 'Replace card with',
      sltcardType: 'Select Card Type',
      sltdebitType: 'Select debit card type',
      primaryAccountLinked: 'Primary Account Linked to the Card',
      otherAccountLinked: 'Other Account(s) Linked to Card',
      countryLinks: {
        HK: 'https://www.sc.com/hk/help/service-charges/'
      },
      countryLinksTxt: {
        default: 'fee schedule',
        HK:
          "Fee depending on card type may be applicable for replacement. Please check Bank's fee schedule for more information."
      },
      countryNotes: {
        HK:
          'You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost.<br>If you have not reported your card as lost/stolen, you may do so by using "Report Lost/Stolen" service request.<br>{{inter_link}}<br>Replacement card will be sent to your registered mailing address.<br>If you do not see the card you wish to replace in the list above, please contact (852) 2886 8888.'
      },
      statusMsg: {
        successReplacement:
          'Your replacement request is submitted.<br>Your replacement request status can be tracked online via "Help and Services".',
        success:
          'Your application is submitted.<br>Your application status can be tracked online via "Help and Services".'
      }
    },
    CREDITBALANCEREFUND: {
      'header.title': 'Credit Balance Refund',
      'progress.subheader1': 'Select a Credit Card',
      'progress.subheader2': 'Select Receiving Credit Card',
      'progress.subheader3': 'Select Receiving Account',
      'progress.subheader4': "Cashier's Order",
      'progress.subheader5': 'Confirm Details',
      'progress.stepTxt': 'Step',
      'progress.step1': '1 of 3',
      'progress.step2': '2 of 3',
      'progress.step3': '3 of 3',
      'selectCard.text': 'Please select a credit card to do a refund:',
      'refundFrom.text': 'Refund From',
      'refundTo.text': 'Refund To',
      'refundto.text': 'Refund to:',
      //'confirm.text':'Please confirm the Credit Balance Refund details.',
      'minimumPayment.text': 'Min. Payment Due*',
      'excessBalance.text': 'Credit Balance',
      'required.text': '*',
      'statementBalance.text': 'Total Amount Due*',
      'dueDate.text': 'Due on',
      'reasonToRefund.text': 'Reason to Refund',
      'availableBalanceLeft.text': 'Available Credit Balance',
      'enterAmount.text': 'Enter Amount',
      'invalidAmount.text': 'You have entered invalid amount.',
      'invalidAmountAE.text':
        'Enter an amount below or equal to Dhs 10000. For higher value refunds, please contact our Phone Banking service.',
      'invalidAmountBN.text':
        'The maximum Credit Balance Refund is BND 5,000. For refunds above BND 5,000, please contact our Client Care Centre.',
      //'enterAmount.desktop.text':'Amount to Refund',
      'selectReason.placeholder': 'Please Select',
      'selectReason.frontline': {
        reason1: 'Payment to wrong account',
        reason2: 'Excess payment made',
        reason3: 'Duplicate Request by Staff',
        reason4: 'Credit Balance due to CashBack',
        reason5: 'Merchant Reversal/ Refund',
        reason6: 'Posting Error by Staff / Staff Error',
        reason7: 'Others – Please specify'
      },
      'selectReason.selfAssisted': {
        reason1: 'Payment to wrong account',
        reason2: 'Excess payment made',
        reason3: 'Merchant reversal/ Refund'
      },
      'selectReason.backend.selfAssisted': {
        reason1: 'Payment to wrong account',
        reason2: 'Excess payment made',
        reason3: 'Merchant reversal/ Refund'
      },
      'deliveryAddress.text': 'Delivery Address',
      'updateAddress.text': 'Update Address',
      'updateAddress.confirmation.message':
        'Your current progress will be lost. You will need to submit a new request <br/> after updating your details.',
      'updateAddress.confirmation.title': 'Do you want to update your contact details?',
      updateAddressLinks: {
        IN: '',
        SG: 'https://oat.sc.com/retail/api/security/v1/redirect?service=DGL',
        MY: ''
      },
      'deliveryAddress.message.text':
        "We will send the Cashier's Order to your registered mailing address. Please ensure your address is correct before proceeding to the next step.",
      'deliveryAddress.message.text.desktop':
        "We will send the Cashier's Order to your registered mailing address.<br>Please ensure your address is correct before proceeding to the next step.",
      'deliveryAddress.message.text.sg': "We will send the Cashier's Order to your registered mailing address.",
      'deliveryAddress.checkAddress.text': 'Check Address',
      'mailingAddress.text': 'Mailing Address',
      'referenceNumber.text': 'Reference Number',
      'notes.title': 'NOTES',
      'notes.statementBalance': {
        SG: '*Minimum Payment, Full Payment and Statement due date is displayed based on your last statement.',
        default: '*Total Amount Due reflects the total amount as per your last statement.'
      },
      'notes.minimumPayment': {
        SG: ' ',
        default: '*Minimum Payment Due reflects the minimum amount that needs to be paid as per last statememt.'
      },
      'notes.addressChange': 'Please contact {{inter_link}} if there has been an address change in the last 30 days.',
      'notes.fromCard': {
        SG:
          '*Excess Credit refers to the excess balances on each credit card. This is the amount which can be refunded from your credit card.</br>*Please note that Excess Credit displayed has been rounded to the nearest dollar. To refund your exact amount in full, please call our 24-hour Client Contact Centre at +65 6747 7000.',
        AE:
          '*Excess Credit displayed is the excess credit card payment made by you, including the recent unbilled/unstatemented transactions.<br/>*We allow to initiate only one Credit Balance Refund request in last 6 months tenure for each credit card.',
        IN:
          '*Excess Credit displayed has been rounded to the nearest rupee.</br>*Excess Credit displayed is the excess credit card payment made by you, including the recent unbilled/unstatemented transactions.',
        MY:
          '*Excess Credit displayed has been rounded to the nearest ringgit.</br>*Excess Credit displayed is the excess credit card payment made by you, including the recent unbilled/unstatemented transactions.',
        HK:
          '*Credit balance displayed has been rounded to the nearest currency.</br>*Credit balance displayed is the credit balance of your credit card account.',
        default:
          '*Excess Credit displayed has been rounded to the nearest dollar. To view and refund the exact amount including cents, please refer to your card balance in the main page.</br>*Excess Credit displayed is the excess credit card payment made by you, including the recent unbilled/unstatemented transactions.'
      },
      'notes.confirmCashierOrder': "We will send the Cashier's Order to your registered mailing address.",
      'requestCancel.content': 'Do you want to cancel your Credit Balance Refund request?',

      //   'countryLinks':{
      //      'IN':'',
      //      'SG':'',
      //      'MY':''
      //   },
      //   'countryLinksTxt':{
      //      'IN':'fee schedule',
      //      'SG':'fee schedule'
      //   },
      //   'countryNotes':{
      //      'IN':'1. You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>2. Cards reported lost or stolen are eligible for replacement within 90 days from reported date.<br>3. If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>4. Replacement card will be sent to your registered mailing address.<br>5. Fee depending on card type may be applicable for replacement. Please check Bank\'s {{inter_link}} for more information.<br>6. If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.',
      //      'SG':'1. You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>2. Cards reported lost or stolen are eligible for replacement within 90 days from reported date.<br>3. If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>4. Replacement card will be sent to your registered mailing address.<br>5. Fee depending on card type may be applicable for replacement. Please check Bank\'s {{inter_link}} for more information.<br>6. If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.<br>7. If your current card is embedded with token, you will be issued card embedded with token card.<br>8. All supplementary cards (if any) will be replaced once the primary card is replaced.'
      //   },
      'phoneBankingHotline.text': {
        //   'IN':'customer service',
        //   'SG':'customer service',
        //   'MY':'customer service',

        IN: '24/7 Phone Banking',
        SG: '24/7 Phone Banking',
        MY: '24/7 Phone Banking',
        AE: '24/7 Phone Banking',
        HK: '24/7 Phone Banking',
        NP: '24X7 Client Care Center'
      },
      'phoneBankingHotline.link': {
        IN: '',
        SG: '',
        MY: '',
        AE: '',
        HK: ''
      },
      'callCentre.text': {
        IN: 'call centre',
        SG: 'call centre',
        MY: 'call centre',
        AE: 'call centre',
        HK: 'call centre'
      },
      'callCentre.link': {
        IN: '',
        SG: '',
        MY: '',
        AE: '',
        HK: ''
      },
      statusMsg: {
        status: 'Submitted',
        success: 'Your request has been submitted.<br>We will send a confirmation SMS/Email in 1 working day.',
        'success.SG':
          "Your request has been submitted and you will be notified once your refund is processed. To check on the status of your request, go to 'Status' tab under 'Help & Services' via Online Banking or the SC Mobile App.",
        'success.cashierOrder':
          "Your request has been submitted.<br> We will send the Cashier's Order in 5 days to your registered mailing address.",
        'success.cashierOrder.SG':
          "Request submission successful. To check the status, go to the 'Status' tab under Help & Services.<br>If you have requested a cashier's order, it will be sent to your mailing address in our records.",
        'unsupportedCOCountry.header': 'We are unable to process your request.',
        'recentAddressChange.header':
          'We are unable to process your request since you have updated your address recently.',
        'pendingAddressChange.header': 'We are unable to process your request since you have a pending address change.',
        'contactPhoneBankingHotline.content': 'Kindly contact our {{inter_link}} for further assistance.',
        //'updateAddress.header':'We are not able to process your request since you have requested for address change.',
        'updateAddress.header':
          'We are unable to process your request at this point in time as you have opted for an address change.',
        'contactPhoneBankingHotline.updateAddress.content':
          'Kindly contact our {{inter_link}}  to update your address and request for a credit balance refund.',
        noEligibleFromCard: 'You do not have any eligible Credit Card(s) to initiate the request'
      },

      button: {
        cancel: 'Cancel',
        next: 'NEXT',
        confirm: 'Confirm',
        viewStatus: 'View Status',
        close: 'Close',
        back: 'BACK'
      }
    },
    CCFEEWAVIER: {
      submitted: 'Submitted',
      annualFee: 'Annual Fee',
      'selectAccount.title': 'Select Details',
      'header.title': 'Credit Card Fee Waiver',
      'notstaffassistant.header.title': 'Credit Card Late Fee Waiver',
      'selectreason.placeholder': 'Select fee type',
      selectDate: 'Select Fee',
      'selectreason.header': "I'd like to waive my",
      'selectreason.header.mob': 'Type of Fee*',
      'selectreason.header.charger': "I'd like to charge",
      'specifyreason.placeholder': 'specify other fee',
      'cardlist.header': 'Select Credit Card(s)',
      'cardlist.header.mob': 'Select Fee(s) to be Waived',
      'feeselect.header': 'Eligible Card(s)',
      'feeselect.subheader': 'The charged fees reflected below can be offset using your reward points.',
      'feetype.title': 'Fee Category',
      'countryNotes.notes':
        'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline.',
      'cards.title': 'Credit Card(s)',
      'reward.alert': 'Rewards Points available',
      'reward.alert.msg': 'Do you want to use your available rewards points for these fees?',
      'reward.alert.button.yes': 'Yes, use points',
      'reward.alert.button.no': 'No, don’t use points',
      'notes.title': 'NOTES',
      'reward.remain': 'REMAINING REWARD POINTS',
      'reward.point.display.heading': 'Available Rewards Points',
      'reward.point.display.subheading': 'Total points across all cards as on date',
      'creditcard.title': 'Credit Card',
      'reason.feewavier': 'REASON FOR FEEWAIVER',
      'reason.charge': 'REASON FOR CHARGE',
      'reason.override': 'Reason For Over-ride',
      'text.systemError.content':
        'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
      'progress.subheader1': 'Select Details',
      'progress.stepTxt1of3': '1 of 3',
      'progress.stepTxt2of3': '2 of 3',
      'progress.stepTxt3of3': '3 of 3',
      'progress.stepTxt1of2': '1 of 2',
      'progress.stepTxt2of2': '2 of 2',
      'progress.stepTxt': '1 of 3',
      'basic.placeholder': 'Please Select',
      'add.placeholder': 'Please Select',
      ReferNo: 'Reference Number',
      'selectReason.placeholder.reversal': 'Select Reason For Reversal',
      'selectReason.placeholder': 'Select Reason For Charge',
      'selectReason.placeholder.override': 'Select Reason For Over-ride',
      'hotline.contact': 'Kindly contact our 24 hour Phone Banking hotline on 1800 747 7000 for further assistance.',
      'cardlist.groupA': 'GROUP A',
      'cardlist.groupB': 'GROUP B',
      'cardlist.msgLabel': 'You can select only one group ,either GROUP A or GROUP B',
      statusMsg: {
        success: 'Your request has been submitted.<br>You will receive result notification in 1 working day.',
        hksuccessmsg: 'Your request has been submitted.',
        failure:
          'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance. Reference #',
        incomplete:
          'Some of your cards below did not get processed. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance if the issue persists. Reference #'
      },
      referenceNumber: 'Reference Number',
      noAccount:
        'There are no eligible Accounts for which Cheque Book Request can be initiated. Please Contact your Relationship Manager or Contact Call Centre or Branch',
      'confirmAccount.title': 'Confirm Details',
      confirmCancelText: 'Do you want to cancel your Cheque Book request?',
      groupAccNo: 'Group Acc Number: ',
      annualFeeEligibleSel: 'Only one primary and supplementary card can be selected from each group.',
      lateoverFeeEligibleSel: 'Only one primary card can be selected from each group.',
      commonErrtext: 'The client is not eligible for the selected type of fee waiver.',
      noCCards: 'The client does not have any eligible credit cards for this request.',
      noAccountWarningText: {
        IN:
          'We are unable to process your request as you do not have any eligible accounts for cheque book. Kindly contact our phone banking team or visit our branches for assistance.',
        SG:
          'We are unable to process your request as you do not have any eligible accounts for cheque book. Kindly contact our phone banking team hotline at 1800 747 700 or visit our branches for assistance.'
      },

      button: {
        okDone: 'OK, Done',
        back: 'BACK'
      },

      countryLinks: {
        IN: 'https://www.sc.com/in/help-centre/service-charges-fees.html',
        SG: 'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf',
        HK: 'https://www.sc.com/global/av/hk-service-charges-en.pdf',
        MY: 'https://www.sc.com/my/help-centre/fees-and-charges.html',
        AE: 'https://www.sc.com/ae/help-centre/service-charges.html'
      },
      countryLinksTxt: {
        IN: '24/7 Phone Banking hotline',
        SG: '24/7 Phone Banking hotline',
        HK: '2886-4111',
        AE: '24/7 Phone Banking hotline',
        MY: '24/7 Phone Banking hotline',
        NP: '24X7 Client Care Center'
      },
      countryNotes: {
        IN:
          'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline at  {{inter_link}}.<br>Only the eligible credit card will be shown. If you do not see your credit card, please contact our 24-hour Customer Service Hotline at {{inter_link}}',
        SG:
          'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline at  {{inter_link}}.<br>Only the eligible credit card will be shown. If you do not see your credit card, please contact our 24-hour Customer Service Hotline at {{inter_link}}',
        HK:
          'Only the eligible credit card(s) will be shown. If you do not see your credit card, please contact our 24-hour Customer Service Hotline.',
        AE:
          'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline at  {{inter_link}}.<br>Only the eligible credit card will be shown. If you do not see your credit card, please contact our 24-hour Customer Service Hotline at {{inter_link}}',
        MY:
          'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline at  {{inter_link}}.<br>Only the eligible credit card will be shown. If you do not see your credit card, please contact our 24-hour Customer Service Hotline at {{inter_link}}'
      },
      validationCountryNotes: {
        IN: 'Kindly contact our {{inter_link}} for further assistance.',
        SG: 'Kindly contact our {{inter_link}} for further assistance.',
        HK: '',
        MY: 'Kindly contact our {{inter_link}} for further assistance.',
        AE: 'Kindly contact our {{inter_link}} for further assistance.'
      },
      countryNotesTransactionPage: {
        IN: 'Displayed transactions are charges posted on the selected cards only.',
        SG: 'Displayed transactions are charges posted on the selected cards only.',
        HK: 'Displayed transactions are charges posted on the selected cards only.',
        AE: 'Displayed transactions are charges posted on the selected cards only.',
        MY: 'Displayed transactions are charges posted on the selected cards only.'
      },
      cardPreSelectionMsg: 'Please select Primary Card fee',
      OtherChannelError: 'We are unable to process your request ,It is not valid channel',
      errorText: 'For enquiries, please contact our 24-hour Customer Service Hotline at 2886-4111.',
      subNotes:
        'Only waiver requests for transactions post 3rd July’18 can be initiated through the Service Journey module . For prior waiver requests please raise the requests through the CEMS SP SR',
      cardLimitMsg: 'Please select not more than 5 credit cards per request',
      cardLimitMsgNP_BN: 'Please select not more than 4 credit cards per request',
      cardLimitMsgLK: 'Please select not more than 7 credit cards per request'
    },
    TRANSFEROFPAYMENTS: {
      'header.title': 'Transfer of Payment - Credit Cards',
      'selectAccount.title': 'Select a Credit Card(s)',
      selectCard: 'Transfer amount from:',
      selectCardTo: 'Transfer amount to:',
      notes: {
        fromCard:
          '<ol><li>Total Payment Credit reflects the total payment on your card after your last statement.</li><li>Minimum Payment Due reflects the minimum amount that needs to be paid as per your last statement.</li><li>Total Amount Due reflects the total amount as per your last statement.</li><li>Minimum payment due would be retained on your selected card. You also have an option to offset the total amount due towards the available credit reflected and the balance amount would be available for transfer.</li><li>Transferable Credit reflects the amount that you will be allowed to transfer to your credit card(s).</li><li>Transferable credit excludes payments credited in last 3 working days.</li></ol>',
        toCard:
          '<ol><li>Minimum Payment Due reflects the minimum amount that needs to be paid as per your last statement.</li><li>Total Amount Due reflects the total amount as per your last statement.</li></ol>'
      },
      minimunAmtDue: 'Minimum Payment Due',
      totalPaymentCredit: 'Total Payment Credit',
      totalAmtDue: 'Total Amount Due',
      retainTxt: 'Select Amount to retain in this card:',
      transferableCredit: 'Transferable Credit*',
      dueDate: 'Due Date on',
      transferFrom: 'Transfer From',
      transferTo: 'Transfer To',
      'tooltip.fromCard': {
        default: 'There is no sufficient amount in your account to initiate the transfer.'
      },
      statusMsg: {
        success: 'Your request has been submitted.<br>We will send a confirmation SMS/Email in 1 working day.'
      },
      disableTADMsg:
        'You do not have sufficient Transferable Credit available in your credit card to initiate the request. Please select Minimum Payment Due to proceed with the request.',
      noCardTitile: 'No cards detected.',
      noCardMessage:
        'If you do not see the card you wish to make a transfer from, please contact our <a>24/7 Phone Banking</a> immediately.'
    },
    TRACKRESUME: {
      trackResume: 'Resume Application / Check Status',
      iWantTo: 'I want to',
      trackMyApplication: 'Check my Application Status',
      resumeApplication: 'Resume my Application',
      helpUsIdentify: 'Please help us identify you',
      mobileNumberLable: 'Contact Number should not exceed 15 digits (including country code)',
      mobileNumberErrorAE: 'This field is invalid',
      mobileNumberError: 'Mobile Number is required',
      mobileNumber: 'Mobile Number'
    },
    ESCARDCONTROL: {
      cardLimitTitle: {
        atmTransaction: 'ATM Transactions',
        overseasTransaction: 'Overseas Transactions',
        overseasNotificationsContent:
          'Disabling this feature will block all overseas transactions(POS/Ecom/ATM) on your card. You can enable them again anytime by switching it on.',
        tokenizedTransaction: 'Tokenized Transactions',
        cardLimit: 'Card Limit',
        domesticLimit: 'Domestic Limit',
        overseasLimit: 'Overseas Limit',
        dailyLimit: 'Daily Limit',
        perTxnLimit: 'Per Transaction Limit',
        limitCriteriaMsg: '*Limit in multiples of 1000',
        requestFailed: 'Request Failed!',
        dailylimitErrMsg: 'Entered Limit Amount cannot exceed the Credit Limit',
        greaterLimitMsg: 'Per transaction limit cannot be greater than Daily limit',
        multipleMsg: 'Please enter the amount in multiples of 1000',
        requestSubmitted: 'Request Submitted',
        blockSuccessMsg:
          'Your changes are saved successfully. You can always revisit manage card usage menu for any further changes.',
        generalFailMsg: ' Your request could not be processed at the moment.',
        blockedFailureMsg:
          'Due to technical reasons, you request cannot processed right now. Please try again by revisting manage card usage menu under card management.'
      },
      noCards: {
        content2: 'Apply for a credit card now and you will be in control',
        nocardcontent: 'No cards'
      },
      noDebitCards: {
        content2: 'Apply for a Debit card now and you will be in control',
        nocardcontent: 'No cards'
      },
      atmTransactionPage: {
        atmBlockEnableContent:
          'Enabling this feature will unblock all domestic and overseas ATM transactions on your card.',
        atmBlockDisableContent:
          'Disabling this feature will block all domestic and overseas ATM transactions on your card.'
      },
      overseasTransactionPage: {
        overseasNotificationsDisableContent:
          'Disabling this feature will completely block all overseas transactions (POS/Ecom/ATM) on your card.',
        overseasNotificationsEnableContent:
          'Enabling this feature will allow all overseas transactions (POS/Ecom/ATM) on your card up to the limit opted for daily transaction.',
        overseasLimitLabel: 'Set Limit for Overseas Transactions',
        overseasDailyLimitTT:
          'This will be the cumulative daily limit for all overseas transactions. The transactions will be declined if this limit is reached on any given day.',
        requestedInfo: 'Requested limit for Overseas Transaction = Rs.'
      },
      tokenizedTransactionPage: {
        tokenizedNotificationsDisableContent:
          'Disabling this feature will completely block all tokenized transactions (POS/Ecom) on your card.',
        tokenizedNotificationsEnableContent:
          'Enabling this feature will allow all tokenized transactions (POS/Ecom) on your card up to the limit opted for daily and per transaction.',

        tokenizedDailyLimit: 'Set Daily Limit for Tokenized Transactions',
        tokenizedPerTxnLimit: 'Set Per Txn Limit for Tokenized Transactions',
        tokenizedDailyLimitContent:
          'This will be the cumulative daily limit for all tokenized transactions. The transactions will be declined if this limit is reached on any given day.',
        tokenizedPerTxnLimitContent:
          'This will be the cumulative per transaction limit for all tokenized transactions. The transactions will be declined if it exceeds per transaction limit.',
        validInputMsg: 'Please enter a valid input',
        requestedPerTxnInfo: 'Requested limit for Tokenized Transaction: Per Transaction Limit = Rs.',
        requestedDailyInfo: ', Daily Limit = RS.'
      }
    },
    CREDITCARD: {
      cardSetting: {
        terminateRequest: 'Your request is terminated and will be navigated back for card selection',
        settingsSaved: 'Settings saved!',
        journeyHeader: 'Card Settings',
        notSaveConfirm: 'If you go back, your settings will not be saved.',
        settingsTitle: {
          transactionLimit: 'Transaction Limit',
          paymentChannels: 'Payment Channels',
          controlledCatagories: 'Transaction Categories',
          countryLimits: 'Overseas Transactions'
        },
        settingsDesc: {
          tmpBlock: 'Instant lock/unlock on your card',
          transactionLimit: 'Card transaction limit',
          paymentChannels: 'Transaction channel settings',
          controlledCategories: 'Transaction category settings',
          countryLimits: 'Overseas transactions'
        },
        selectPage: {
          pageHeader: 'Select a Credit Card',
          sectionHeaderMob: 'Select a card'
        },
        cardSettingsPage: {
          pageHeader: 'Set Credit Card Settings',
          sectionHeader: 'SET YOUR CREDIT CARD Settings',
          sectionHeaderMob: 'Set your Credit Card Settings',
          termsAndConditions: 'By enabling these features, you accept the ',
          on: 'ON',
          off: 'OFF'
        },
        transactionLimitPage: {
          transactionNotifications: 'Limit Notifications',
          transactionNotificationsContent: 'Be notified every time a single transaction exceeds your limit amount.',
          limitAmountTitle: 'LIMIT AMOUNT',
          blockCheckbox: 'Decline transactions above this limit amount',
          maxLimitAlert: 'Please enter an amount that does not exceed your credit limit _AMOUNT_.',
          minLimitAlert: 'Please enter an amount above the minimum limit of _AMOUNT_.',
          errorNumType: 'Please enter a correct amount.'
        },
        paymentChannelsPage: {
          paymentChannelNotifications: 'Channel Notifications',
          paymentChannelNotificationsContent: 'Receive an SMS every time your card is used via selected channels.',
          blockCheckbox: 'Decline transactions made via these selected channels',
          optionItem1: 'Online payments',
          optionItem2: 'Contactless payments',
          optionItem3: 'Contact payments',
          optionContent1:
            'Online payments are made by submitting your credit card details into a website or app. This will also impact your regular payments such as bills and subscriptions.',
          optionContent2:
            'Contactless payments are made when you tap your card or mobile wallet near a credit card terminal. Sometimes a PIN or signature may be required.',
          optionContent3:
            'Contact payments are made by physically swiping or inserting your card into a credit card terminal. Sometimes a PIN or signature may be required.'
        },
        controlledCategories: {
          controlledCategoriesNotifications: 'Controlled Category Notifications',
          controlledCategoriesNotificationsContent:
            'Receive an SMS every time your card is used for selected purchase categories.',
          blockCheckbox: 'Decline transactions for selected categories',
          optionItem1: 'Clothing & Accessories',
          optionItem2: 'Travel',
          optionItem3: 'Gas & Automotive',
          optionItem4: 'Groceries',
          optionItem5: 'Household goods',
          optionItem6: 'Entertainment'
        },
        countryLimitsPage: {
          countryNotifications: 'Overseas Transaction Notifications',
          countryNotificationsContent:
            'Be notified every time your card is used for a card-present transaction in selected countries.',
          blockCheckbox: 'Decline transactions made in these selected countries.',
          selectedCountry: 'Block Selected Countries',
          selectCountryContent: 'SEARCH',
          addCountryContent: 'Search countries',
          countryLimitExplain: 'Notify me when my card is used in:',
          overseaCardUsageContent:
            'Block card-present transactions made outside of the country where the card was issued. Online transactions will not be affected.',
          countryTooltip:
            ' A card-present transaction is where your card is used at a payment terminal or card reader and includes contactless payments. Payments made through websites or apps are not affected.',
          anyOverseasCountries: 'Any overseas country',
          allOverseasCountriesExcept: 'All overseas countries except...',
          theseSpecificCountries: 'These specific countries:'
        },
        isPrimary: {
          primary: 'PRIMARY',
          supplementary: 'SUPPLEMENTARY'
        },
        TMPBLOCKTXT: 'Temporarily lock this card',
        ESTMPBLOCK: 'Temporarily block this card',
        TMPTOOLTIP:
          'This impacts all transactions on your card except for: recurring bill or subscription payments, ATM withdrawals.',
        ESTMPTOOLTIP:
          'Enabling this feature will temporarily block all domestic and overseas transactons on your card. You can unblock your card anytime by switching it off.',
        DTMPTOOLTIP:
          'Disabling this feature will allow all domestic and overseas transactons on your card. You can block your card anytime by switching it on.',

        NOTICE: {
          TMPBLOCK:
            'You are about to temporarily lock this card. Non-recurring transactions will be declined until the card is unlocked.',
          SETBLOCK: 'This action will result in certain transactions being declined.',
          ERROR: 'An error occured and your settings could not be saved. Please try again.',
          MCORVISA: 'Sorry, Card Settings is currently only available for Visa and MasterCard credit cards.',
          INACTIVE: 'Please activate your card before changing settings.'
        },
        noCards: {
          content2: 'Apply for a credit card now and you will be in control:',
          button: 'APPLY NOW',
          nocardcontent: 'No cards'
        },
        noDebitCards: {
          content2: 'Apply for a Debit card now and you will be in control:',
          button: 'APPLY NOW',
          nocardcontent: 'No cards'
        }
      },
      pinSetup: {
        journeyHeader: 'Credit Card PIN Setup/Change',

        selectPage: {
          pageHeader: 'Select a Credit Card',
          sectionHeader: 'SELECT A CREDIT CARD TO SETUP A PIN',
          sectionHeaderMob: 'Select a Credit Card to setup a PIN',
          nocardHeader: 'No eligible card detected.',
          nocardContent: 'Sorry, you do not have any eligible Credit Card(s) for this request.'
        },
        pinChange: {
          pageHeader: 'Set Credit Card PIN',
          sectionHeader: 'SET YOUR NEW CREDIT CARD PIN',
          sectionHeaderMob: 'Set your new Credit Card PIN',
          newPin: 'ENTER YOUR NEW CARD PIN',
          reEnterPin: 'RE-ENTER YOUR PIN',
          newPinMob: 'Enter New PIN',
          reEnterPinMob: 'Re-Enter PIN',
          pinNotSame: 'Entered PIN numbers are not same',
          pinNotAsGuideline: 'Invalid PIN, please enter PIN as per the guidelines'
        },
        countryNotes: {
          IN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/in/contact-us/#talk-to-us'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          SG:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 5-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To authenticate your PIN change, we will send you an OTP at your registered mobile number. Please ensure you have this ready for reference.</li><li>You should always memorise your PIN. Do not reveal your 5-digit PIN to anyone or record it anywhere.</li><li>Avoid using numbers for your PIN that may be easily guessed, such as your birthday, NRIC, phone number, sequential numbers (eg. 12345) etc.</li></li></ol>",
          HK:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>Do not disclose your PIN to any other person.</li><li>Do not write your PIN on your card or anything you usually keep with or near it.</li><li> Do not use an obvious number such as your HKID number, telephone number, date of birth or other easily accessible personal information as your PIN.</li><li>Do not use the same details that you use to access other services such as email, other Internet sites/ ISPs, Phone Banking TIN.</li><li>Do regularly change your PIN.</li><li>Do change your PIN when there is any suspicion that it has been compromised or impaired.</li><li>For enquiry, please contact us.Standard Chartered ATM Card: (852) 2886-8888, Standard Chartered Credit Card: (852) 2886-4111 and <br> MANHATTAN Card: (852) 2881-0888.</li></ol></li></ol>",
          MY:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/my/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          AE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/ae/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          KE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that is sent to your registered mobile number.</li><li>We recommend that you memorize your 4-digit PIN, do not record it anywhere, divulge or share it with anyone.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or the same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Call us on 254203293900 in case you observe any unauthorized transactions in your account.</li></ol></li></ol>",
          NG:
            '<ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>Do not reveal your 4-digit PIN to anyone. Memorise your PIN and do not record it anywhere.</li><li>Do not use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Contact Centre Team immediately in case of any unauthorized transactions observed in your account.</li></ol>',
          GH:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          BW:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          ZM:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          BN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 5-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 5-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 5-digit PIN to anyone. 5-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 5-digit PIN.</li><li>Avoid using sequential numbers (such as 12345) or same number more than twice (such as 22222) for your 5-digit PIN.</li><li>5-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 5-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a target='_blank' href='https://www.sc.com/bn/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          VN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password(OTP) that will be sent to your regitered mobile number.</li><li>DO NOT reveal your PIN to anyone. The PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 1223) for your PIN.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>For enquiry, please contact our Client Care Center (24/7) at +84 28 3911 0000 or +84 24 3696 0000.</li></ol></li></ol>",
          LK:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your PIN to anyone. PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your PIN.</li><li>PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24 hour hotline on 9411 2480480 immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          NP:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a target='_blank' href='https://www.sc.com/np/contact-us.html'>24X7 Client Care Centre</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          BD:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a target='_blank' href='https://www.sc.com/bd/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>"
        },
        status: {
          refNo: 'REFERENCE NUMBER',
          refNoSmall: 'Reference No.',
          cardDetails: 'CARD DETAILS',
          success: 'Success',
          failed: 'Failed!',
          transactionSuccessMsg: 'You have successfully reset your Credit Card PIN.',
          transactionSuccessFailure: {
            IN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            SG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            MY:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 1 300 888 888/ +603 7711 8888 for any assistance.',
            HK:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            AE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 600 5222 88 for any assistance.',
            KE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 254 20 329 3900 for any assistance.',
            NG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 01 2704611 - 4 for any assistance.',
            GH:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 0302 740100 for any assistance.',
            BW:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on +267 3615800 for any assistance.',
            ZM:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 5247  for any assistance.',
            VN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our Client Care Center (84-8)39110000 hoặc (84-4) 36960000 for assistance.',
            BN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            LK:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            NP:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            BD:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.'
          },
          transactionSuccessInComplete:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.'
        }
      },
      activation: {
        journeyHeader: 'Credit Card Activation/PIN Setup',
        selectPage: {
          pageHeader: 'Select a Credit Card',
          sectionHeader: 'SELECT A CARD YOU WANT TO ACTIVATE',
          sectionHeaderMob: 'Select a Credit Card to setup a PIN',
          nocardHeader: 'No eligible card detected.',
          nocardContent: 'Sorry, you do not have any eligible Credit Card(s) for this request.'
        },
        pinChange: {
          pageHeader: 'Set Credit Card PIN',
          sectionHeader: 'SET YOUR NEW CREDIT CARD PIN',
          sectionHeaderMob: 'Set your new Credit Card PIN',
          newPin: 'ENTER YOUR NEW CARD PIN',
          reEnterPin: 'RE-ENTER YOUR PIN',
          newPinMob: 'Enter New PIN',
          reEnterPinMob: 'Re-Enter PIN',
          pinNotSame: 'Entered PIN numbers are not same',
          pinNotAsGuideline: 'Invalid PIN, please enter PIN as per the guidelines'
        },
        disclaimerNotes: {
          AE:
            'DISCLAIMER : Please ensure you have the plastic with you before you proceed for Activation and Pin Set request',
          VN:
            'DISCLAIMER : Please ensure you have the physical card with you before you proceed for Activation and PIN Set request for this Card.'
        },
        countryNotes: {
          IN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/in/contact-us/#talk-to-us'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          SG:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 5-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To authenticate your PIN change, we will send you an OTP at your registered mobile number. Please ensure you have this ready for reference.</li><li>You should always memorise your PIN. Do not reveal your 5-digit PIN to anyone or record it anywhere.</li><li>Avoid using numbers for your PIN that may be easily guessed, such as your birthday, NRIC, phone number, sequential numbers (eg. 12345) etc.</li></li></ol>",
          HK:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>Do not disclose your PIN to any other person.</li><li> Do not write your PIN on your card or anything you usually keep with or near it.</li><li>Do not use an obvious number such as your HKID number, telephone number, date of birth or other easily accessible personal information as your PIN.</li><li>Do not use the same details that you use to access other services such as email, other Internet sites/ ISPs, Phone Banking TIN.</li><li>Do regularly change your PIN.</li><li>Do change your PIN when there is any suspicion that it has been compromised or impaired.</li><li> For enquiry, please contact us.Standard Chartered ATM Card: (852) 2886-8888, Standard Chartered Credit Card: (852) 2886-4111 and <br> MANHATTAN Card: (852) 2881-0888.</li></ol></li></ol>",
          MY:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/my/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          AE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/ae/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          KE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that is sent to your registered mobile number.</li><li>We recommend that you memorize your 4-digit PIN, do not record it anywhere, divulge or share it with anyone.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or the same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Call us on 254203293900 in case you observe any unauthorized transactions in your account.</li></ol></li></ol>",
          NG:
            '<ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>Do not reveal your 4-digit PIN to anyone. Memorise your PIN and do not record it anywhere.</li><li>Do not use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Contact Centre Team immediately in case of any unauthorized transactions observed in your account.</li></ol>',
          GH:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          BW:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          ZM:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          BD:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a target='_blank' href='https://www.sc.com/bd/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          BN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 5-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 5-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 5-digit PIN to anyone. 5-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 5-digit PIN.</li><li>Avoid using sequential numbers (such as 12345) or same number more than twice (such as 22222) for your 5-digit PIN.</li><li>5-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 5-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a target='_blank' href='https://www.sc.com/bn/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          VN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password(OTP) that will be sent to your registered mobile number.</li><li>DO NOT reveal your PIN to anyone. The PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 1223) for your PIN.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>For enquiry, please contact our Client Care Center (24/7) at +84 28 3911 0000 or +84 24 3696 0000.</li></ol></li></ol>",
          LK:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your PIN to anyone. PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your PIN.</li><li>PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24 hour hotline on 9411 2480480 immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          NP:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a target='_blank' href='https://www.sc.com/np/contact-us.html'>24X7 Client Care Centre</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>"
        },
        status: {
          refNo: 'REFERENCE NUMBER',
          refNoSmall: 'Reference No.',
          cardDetails: 'CARD DETAILS',
          success: 'Success',
          failed: 'Failed!',
          transactionSuccessMsg: 'Your credit card is activated and PIN has been set successfully.',
          transactionSuccessFailure: {
            IN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            SG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            MY:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 1 300 888 888/ +603 7711 8888 for any assistance.',
            HK:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            AE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 600 5222 88 for any assistance.',
            KE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 254 20 329 3900 for any assistance.',
            NG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 01 2704611 - 4 for any assistance.',
            GH:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 0302 740100 for any assistance.',
            BW:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on +267 3615800 for any assistance.',
            ZM:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 5247  for any assistance.',
            VN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our Client Care Center (84-8)39110000 hoặc (84-4) 36960000 for assistance.',
            BN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            NP:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            LK:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            BD:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.'
          },
          transactionSuccessInComplete:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.'
        }
      },
      validation: {
        pinNotSame: {
          IN: 'Please ensure both 6-digit PIN values entered are the same.',
          SG: 'Sorry, the PIN does not match. Please re-enter the correct PIN.',
          MY: 'Please ensure both 6-digit PIN values entered are the same.',
          HK: 'Please ensure both 6-digit PIN values entered are the same.',
          AE: 'Please ensure both 4-digit PIN values entered are the same.',
          KE: 'Please ensure both 4-digit PIN values entered are the same.',
          NG: 'Please ensure both 4-digit PIN values entered are the same.',
          GH: 'Please ensure both 4-digit PIN values entered are the same.',
          BW: 'Please ensure both 4-digit PIN values entered are the same.',
          ZM: 'Please ensure both 4-digit PIN values entered are the same.',
          BN: 'Please ensure both 5-digit PIN values entered are the same.',
          VN: 'Please ensure both 4-digit PIN values entered are the same.',
          LK: 'Please ensure both 4-digit PIN values entered are the same.',
          NP: 'Please ensure both 4-digit PIN values entered are the same.',
          BD: 'Please ensure both 4-digit PIN values entered are the same.'
        },
        pinNotAsGuideline: {
          IN: 'Please enter a valid 6-digit PIN as per the guidelines in the notes section',
          SG: 'Please enter a valid 5-digit PIN as per the guidelines in the notes section',
          MY: 'Please enter a valid 6-digit PIN as per the guidelines in the notes section',
          HK: 'Please enter a valid 6-digit PIN as per the guidelines in the notes section',
          AE: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          KE: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          NG: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          GH: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          BW: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          ZM: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          VN: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          NP: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          LK: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          BD: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          BN: 'Please enter a valid 5-digit PIN as per the guidelines in the notes section'
        },
        enterValidPin: {
          IN: 'Please enter valid PIN',
          SG: 'Sorry, the PIN does not match. Please re-enter the correct PIN.',
          MY: 'Please enter valid PIN',
          HK: 'Please enter valid PIN',
          AE: 'Please enter valid PIN',
          KE: 'Please enter valid PIN',
          NG: 'Please enter valid PIN',
          GH: 'Please enter valid PIN',
          BW: 'Please enter valid PIN',
          ZM: 'Please enter valid PIN',
          VN: 'Please enter valid PIN',
          NP: 'Please enter valid PIN',
          LK: 'Please enter valid PIN',
          BD: 'Please enter valid PIN',
          BN: 'Please enter valid PIN'
        }
      }
    },
    creditCardDesc: {
      '405803801801': 'Standard Chartered Platinum Credit Card',
      '450936033033': 'Standard Chartered Platinum Credit Card',
      '450936035035': 'Standard Chartered Platinum Credit Card',
      '450936036036': 'Standard Chartered Platinum Credit Card',
      '450936054054': 'Standard Chartered Platinum Credit Card',
      '450936062062': 'Standard Chartered Platinum Credit Card',
      '450936068068': 'Standard Chartered Platinum Credit Card',
      '450936069069': 'Standard Chartered Platinum Credit Card',
      '450936086086': 'Standard Chartered Platinum Credit Card',
      '450936100001': 'Standard Chartered Platinum Credit Card',
      '450936101001': 'Standard Chartered Platinum Credit Card',
      '450936110001': 'Standard Chartered Platinum Credit Card',
      '450936120001': 'Standard Chartered Platinum Credit Card',
      '450936124001': 'Standard Chartered Platinum Credit Card',
      '450936140004': 'Standard Chartered Platinum Credit Card',
      '450936180005': 'Standard Chartered Platinum Credit Card',
      '450936230026': 'Standard Chartered Platinum Credit Card',
      '496657038038': 'Standard Chartered Platinum Credit Card',
      '496657039039': 'Standard Chartered Platinum Credit Card',
      '496657055055': 'Standard Chartered Platinum Credit Card',
      '496657061061': 'Standard Chartered Platinum Credit Card',
      '496657070070': 'Standard Chartered Platinum Credit Card',
      '496657071071': 'Standard Chartered Platinum Credit Card',
      '496657087087': 'Standard Chartered Platinum Credit Card',
      '496657100021': 'Standard Chartered Platinum Credit Card',
      '496657120021': 'Standard Chartered Platinum Credit Card',
      '496657140014': 'Standard Chartered Platinum Credit Card',
      '496657151011': 'Standard Chartered Platinum Credit Card',
      '496657170011': 'Standard Chartered Platinum Credit Card',
      '496657174011': 'Standard Chartered Platinum Credit Card',
      '496657190013': 'Standard Chartered Platinum Credit Card',
      '486495044044': 'Standard Chartered Corporate Visa Credit Card',
      '486495045045': 'Standard Chartered Visa Signature Business Card',
      '450936065065': 'Standard Chartered Simply Cash Visa Card',
      '450936064064': 'Standard Chartered Simply Cash Visa Card',
      '541737000131': 'Standard Chartered Platinum Credit Card',
      '541737100101': 'Standard Chartered Platinum Credit Card',
      '541737120102': 'Standard Chartered Platinum Credit Card',
      '541737133133': 'Standard Chartered Platinum Credit Card',
      '541737135135': 'Standard Chartered Platinum Credit Card',
      '541737140104': 'Standard Chartered Platinum Credit Card',
      '541737152152': 'Standard Chartered Platinum Credit Card',
      '541737154154': 'Standard Chartered Platinum Credit Card',
      '541737158158': 'Standard Chartered Platinum Credit Card',
      '541737170170': 'Standard Chartered Platinum Credit Card',
      '541737172172': 'Standard Chartered Platinum Credit Card',
      '541737173173': 'Standard Chartered Platinum Credit Card',
      '552083802802': 'Standard Chartered Platinum Credit Card',
      '552083812812': 'Standard Chartered Platinum Credit Card',
      '540034112112': 'Standard Chartered Titanium Credit Card',
      '540034138138': 'Standard Chartered Titanium Credit Card',
      '540034139139': 'Standard Chartered Titanium Credit Card',
      '540034105105': 'Standard Chartered Titanium Credit Card',
      '540034108108': 'Standard Chartered Titanium Credit Card',
      '540034150108': 'Standard Chartered Titanium Credit Card',
      '540034171171': 'Standard Chartered Titanium Credit Card',
      '540034174174': 'Standard Chartered Titanium Credit Card',
      '540034175175': 'Standard Chartered Titanium Credit Card',
      '540034126126': 'Standard Chartered Titanium Credit Card',
      '540034214214': 'Standard Chartered Titanium Credit Card',
      '553398114114': 'Standard Chartered executive platinum Credit Card',
      '553398123123': 'Standard Chartered executive platinum Credit Card',
      '553398115115': 'Standard Chartered executive Credit Card',
      '553398125125': 'Standard Chartered executive Credit Card',
      '553398120120': 'Standard Chartered corporate executive Credit Card',
      '553398121121': 'Standard Chartered executive platinum Credit Card',
      '540034155155': 'Standard Chartered Click-a-Count Titanium Credit Card',
      '442394830830': 'Standard Chartered Visa Infinite Credit Card',
      '442394831831': 'Standard Chartered Visa Infinite Credit Card',
      '442394832832': 'Standard Chartered Visa Infinite Credit Card',
      '442394833833': 'Standard Chartered Priority Banking Credit Card',
      '442394834834': 'Standard Chartered Priority Banking Credit Card',
      '552343840840': 'Standard Chartered Preferred Banking Credit Card',
      '552343841841': 'Standard Chartered Asia Miles Mastercard',
      '622482866866': 'UnionPay Dual Currency Platinum Card (HKD)',
      '037710788880': 'Standard Chartered WorldMiles Card',
      '037710788881': 'Standard Chartered WorldMiles Card',
      '037710788882': 'Standard Chartered WorldMiles Card',
      '037710788883': 'Standard Chartered WorldMiles Card',
      '037710788884': 'Standard Chartered WorldMiles Card',
      '037710788885': 'Standard Chartered WorldMiles Card',
      '496673403001': 'MANHATTAN Gold VISA',
      '496673432001': 'MANHATTAN Gold VISA',
      '496673800001': 'MANHATTAN Gold VISA',
      '450885394002': 'MANHATTAN id VISA',
      '450885580002': 'MANHATTAN id VISA',
      '450885581002': 'MANHATTAN id VISA',
      '496673253001': 'Orbis MANHATTAN Gold VISA',
      '450885343002': 'Orbis MANHATTAN VISA',
      '450885900002': 'MANHATTAN id VISA',
      '414004188003': 'MANHATTAN id Platinum VISA',
      '414004427003': 'MANHATTAN id Platinum VISA',
      '414004429003': 'MANHATTAN id Platinum VISA',
      '540157261011': 'MANHATTAN Titanium Mastercard',
      '540157749011': 'MANHATTAN Titanium Mastercard',
      '540157791011': 'MANHATTAN Titanium Mastercard',
      '540157796011': 'MANHATTAN Titanium Mastercard',
      '540157280011': 'MANHATTAN Titanium Mastercard',
      '542479342012': 'MANHATTAN id Platinum Mastercard',
      '542479354012': 'MANHATTAN id Platinum Mastercard',
      '542479558012': 'MANHATTAN id Platinum Mastercard',
      '552168500013': 'MANHATTAN id Platinum Mastercard',
      '552168842013': 'MANHATTAN id Platinum Mastercard',
      '542479253012': 'MANHATTAN Platinum Mastercard',
      '542479750012': 'MANHATTAN Platinum Mastercard',
      '552168850013': 'MANHATTAN Platinum Mastercard',
      '419077301301': "Standard Chartered SHOP'n GAIN Credit Card",
      '419077302302': "Standard Chartered SHOP'n GAIN Credit Card",
      '419077303303': "Standard Chartered SHOP'n GAIN Credit Card",
      '419078311311': "Standard Chartered SHOP'n GAIN Platinum Card",
      '419078312312': "Standard Chartered SHOP'n GAIN Platinum Card",
      '419078313313': "Standard Chartered SHOP'n GAIN Platinum Card",
      '548803401401': 'Standard Chartered Platinum Mastercard',
      '548803402402': 'Standard Chartered Platinum Mastercard',
      '548803403403': 'Standard Chartered Platinum Mastercard',
      '548830411411': 'Standard Chartered Platinum Mastercard',
      '548830412412': 'Standard Chartered Platinum Mastercard',
      '548830413413': 'Standard Chartered Platinum Mastercard',
      '822482866866': 'UnionPay Dual Currency Platinum Card (CNY)'
    },
    defaultcreditCardDesc: {
      MaestroCard: 'Standard Chartered Master Credit Card',
      VisaCard: 'Standard Chartered Visa Credit Card',
      AmexCard: 'Standard Chartered Credit Card',
      CUPCard: 'Standard Chartered UnionPay Card',
      DefaultCard: 'Standard Chartered Credit Card'
    },
    debitCardDesc: {
      'PRBN:CPB:YM1': 'Priority Banking UnionPay ATM Card',
      'PRBN:CPB:YM2': 'Priority Banking UnionPay ATM Card',
      'PRBN:CPB:YM3': 'Priority Banking UnionPay ATM Card',
      'PRBN:CPB:YM4': 'Priority Banking UnionPay ATM Card',
      'PRBN:CPB:YM5': 'Priority Banking UnionPay ATM Card',
      'PRBN:CPB:YM6': 'Priority Banking UnionPay ATM Card',
      'PRBN:CPB:YM7': 'Priority Banking UnionPay ATM Card',
      'PRBN:CPB:YM8': 'Priority Banking UnionPay ATM Card',
      'PRBN:CPB:NA': 'Priority Banking UnionPay ATM Card',
      'PRBN:PBI:NA': 'Priority Banking Cirrus ATM Card',
      'PRBN:DPB:NA': 'Priority Banking UnionPay Dual Currency ATM Card',
      'PRBN:CME:TM1': 'Teen Card',
      'PRBN:CME:TM2': 'Teen Card',
      'PRBN:CME:TM3': 'Teen Card',
      'PRBN:CME:TM4': 'Teen Card',
      'PRBN:CME:TM5': 'Teen Card',
      'PRBN:CME:TM6': 'Teen Card',
      'PRBN:CME:TM7': 'Teen Card',
      'PRBN:CME:TM8': 'Teen Card',
      'PRBN:CME:NA': 'Teen Card',
      'PRBN:CMK:KM1': 'Kid Card',
      'PRBN:CMK:KM2': 'Kid Card',
      'PRBN:CMK:KM3': 'Kid Card',
      'PRBN:CMK:KM4': 'Kid Card',
      'PRBN:CMK:KM5': 'Kid Card',
      'PRBN:CMK:KM6': 'Kid Card',
      'PRBN:CMK:KM7': 'Kid Card',
      'PRBN:CMK:KM8': 'Kid Card',
      'PRBN:CMK:NA': 'Kid Card',
      'EXBN:CEX:NA': 'Standard Chartered UnionPay ATM Card (Applicable to Premium Client Only)',
      'EXBN:EXI:NA': 'Standard Chartered Cirrus ATM Card',
      'EXBN:DEX:NA': 'Standard Chartered UnionPay Dual Currency ATM Card',
      'EXBN:CME:TM1': 'Teen Card',
      'EXBN:CME:TM2': 'Teen Card',
      'EXBN:CME:TM3': 'Teen Card',
      'EXBN:CME:TM4': 'Teen Card',
      'EXBN:CME:TM5': 'Teen Card',
      'EXBN:CME:TM6': 'Teen Card',
      'EXBN:CME:TM7': 'Teen Card',
      'EXBN:CME:TM8': 'Teen Card',
      'EXBN:CME:NA': 'Teen Card',
      'EXBN:CMK:KM1': 'Kid Card',
      'EXBN:CMK:KM2': 'Kid Card',
      'EXBN:CMK:KM3': 'Kid Card',
      'EXBN:CMK:KM4': 'Kid Card',
      'EXBN:CMK:KM5': 'Kid Card',
      'EXBN:CMK:KM6': 'Kid Card',
      'EXBN:CMK:KM7': 'Kid Card',
      'EXBN:CMK:KM8': 'Kid Card',
      'EXBN:CMK:NA': 'Kid Card',
      'GMMN:CML:YM1': 'Standard Chartered UnionPay ATM Card',
      'GMMN:CML:YM2': 'Standard Chartered UnionPay ATM Card',
      'GMMN:CML:YM3': 'Standard Chartered UnionPay ATM Card',
      'GMMN:CML:YM4': 'Standard Chartered UnionPay ATM Card',
      'GMMN:CML:YM5': 'Standard Chartered UnionPay ATM Card',
      'GMMN:CML:YM6': 'Standard Chartered UnionPay ATM Card',
      'GMMN:CML:YM7': 'Standard Chartered UnionPay ATM Card',
      'GMMN:CML:YM8': 'Standard Chartered UnionPay ATM Card',
      'GMMN:CML:NA': 'Standard Chartered UnionPay ATM Card',
      'GMMN:MLI:NA': 'Standard Chartered Cirrus ATM Card',
      'GMMN:DML:NA': 'Standard Chartered UnionPay Dual Currency ATM Card',
      'GMMN:CME:TM1': 'Teen Card',
      'GMMN:CME:TM2': 'Teen Card',
      'GMMN:CME:TM3': 'Teen Card',
      'GMMN:CME:TM4': 'Teen Card',
      'GMMN:CME:TM5': 'Teen Card',
      'GMMN:CME:TM6': 'Teen Card',
      'GMMN:CME:TM7': 'Teen Card',
      'GMMN:CME:TM8': 'Teen Card',
      'GMMN:CME:NA': 'Teen Card',
      'GMMN:CMK:KM1': 'Kid Card',
      'GMMN:CMK:KM2': 'Kid Card',
      'GMMN:CMK:KM3': 'Kid Card',
      'GMMN:CMK:KM4': 'Kid Card',
      'GMMN:CMK:KM5': 'Kid Card',
      'GMMN:CMK:KM6': 'Kid Card',
      'GMMN:CMK:KM7': 'Kid Card',
      'GMMN:CMK:KM8': 'Kid Card',
      'GMMN:CMK:NA': 'Kid Card',
      defaultDebit: 'ATM'
    },
    JOINTACCOUNT: {
      moreDetails: 'More Details',
      dateJoined: 'Date Joined',
      fullName: 'Full Name',
      firstName: 'First Name',
      lastName: 'Last Name',
      emailAddress: 'Email Address',
      mobileNumber: 'Mobile Number',
      primaryAccountTitle: 'Primary Account Holders',
      existingAccountTitle: 'Existing Account Holders',
      primaryAccount: 'Primary Account Holder',
      secondaryAccount: 'Secondary Account Holder',
      newSecondaryAccount: 'New Secondary Account Holder',
      pendingAccountTitle: 'New / Pending Account Holders',
      addNewAccountHolder: 'Add New Account Holder',
      error: {
        alphabetsOnly: 'Only Alphabets are valid',
        invalidEmail: 'Invalid Email Address',
        mobileFormat: 'Format should be CCCaaaRRRRRRRR'
      },
      modal: {
        message: {
          reject:
            'Are you sure you want to reject adding Secondary Account Holder into the Join Account? The request application will be cancelled.',
          approve: 'Are you sure you want to provide approval for Secondary Account Holder to join the Join Account.',
          decline: 'Are you sure you want to decline the invitation? The join account application will be cancelled.'
        }
      }
    },
    FDUPLIFTMENT: {
      headerTitle: 'Fixed Deposit/Term Deposit-i Upliftment',
      selectHeading: 'Your FD/TD-i details',
      confirmHeading: 'Confirm Details',
      selectSubHeadingFd: 'Select the FD/TD-i to be uplifted',
      selectSubHeadingCr: 'Select the account to be credited',
      instructionHeadingFd: 'Your FD/TD-i details',
      listHeadingFd: 'Fixed Deposit',
      accToWithdrawLabel: 'FD/TD-i account to be uplifted:',
      accToCreditLabel: 'Account to be credited:',
      noFDAccountHeading: 'No fixed deposit/term deposit-i account detected.',
      noCreditAccountHeading:
        'You do not have any deposit accounts for crediting. Please contact our Client Care Centre or visit our nearest branch.',
      successHeading: 'Submitted!',
      successMsg:
        'Your request has been submitted and will be processed.<br/><br/>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for your understanding.<br/><br/>To check the status, go to the ‘Status’ tab under Help & Services.',
      successMsg2:
        'Your request has been submitted and will be processed.<br/> We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for your understanding.<br/>To check the status, go to the ‘Status’ tab under Help & Services.',
      successRefLabel: 'Reference Number',
      successRefNote: 'Please quote this reference number for all future correspondences related to this request.',
      failureHeading: 'Failed!',
      failureMsg:
        'We are unable to process your request at the moment. Please try submitting the request again or contact 24-hour Phone Banking service for assistance.',
      failureMsg2:
        'We are unable to process your request at the moment. <br>Please try submitting the request again or contact 24-hour Phone Banking service for assistance.',
      btnSubmitText: 'SUBMIT',
      btnStatusText: 'VIEW STATUS',
      systemErrorMsg:
        'We have encountered technical error while processing your request. Please cancel the request and try again later.',
      prematurUpliftMsg:
        'Partial upliftment of Fixed Deposit/Term Deposit-i is enabled for MYR only. Please note Foreign Currency Fixed Deposit cannot be partially uplifted. No interest/profit will be paid if you uplift your MYR Fixed Deposit/Term Deposit-i before the contracted term/maturity date. For Foreign Currency Fixed Deposit, penalty charges apply. Foreign Currency Fixed Deposit is not available under Standard Chartered Saadiq Berhad.',
      notes:
        '<ul><li>Partial upliftment of Fixed Deposit/Term Deposit-i is enabled for MYR only, please note Foreign Currency Fixed Deposit cannot be partially uplifted.</li><li>No interest/profit will be paid if you uplift your MYR Fixed Deposit/Term Deposit-i before the contracted term/maturity date.</li><li>For Foreign Currency Fixed Deposit, penalty charges apply. For more info, please click <a href="https://av.sc.com/my/content/docs/my-scbmb-fees-and-charges-booklet.pdf" target="_blank">here</a>.</li><li>Foreign Currency Fixed Deposit is not available under Standard Chartered Saadiq Berhad.</li></ul>',
      maturityDateLabel: 'Maturity Date',
      depositBalanceLabel: 'Deposit Balance'
    },
    debitCardSettings: {
      panelTitle: {
        placeholder: 'Please Select',
        optIn: 'Opt In',
        optOut: 'Opt Out',
        selectCard: 'Select the Card',
        cardSetting: 'Select Debit Card Settings',
        newLimit: 'New Limit',
        atmPosLimit: 'Preferred Daily Limit for ATM & POS',
        cumulativeLimit: 'Cumulative Contactless Limit',
        atmIbftLimit: 'ATM IBFT Limit',
        mainHeader: 'Card-Not-Present and Overseas Transaction',
        selectTitle: 'Should you wish to Opt in/Opt Out. Please Select',
        cardNotPresentTitle: 'Card Not Present Transactions',
        overseasTransaction: 'Overseas Transactions',
        confirmation: 'Confirmation',
        reviewDetails: 'Please review and confirm your details.',
        requestProcessed: 'Your request is being processed!',
        optOutText: 'I would like to remain opted-out for both Card-Not-Present and Overseas transactions.',
        duplicateMessage:
          'We are unable to process your request at this moment as there is another Debit Card Setting request in progress.',
        statusInfoDesktop1:
          'We will send you notifications when there are updates or if we require more information from you.',
        statusInfoDesktop2:
          'Stay updated on all your service requests on the "Help & Services" page by going to the "Your Requests" section.'
      },
      errorMsg: {
        title: {
          casa: 'You do not have any debit/ATM card to proceed with this request.',
          invalidMobNo: 'Invalid mobile number, Please contact customer care.',
          maxTryMobileNo:
            "We're sorry You have exceeded the maximum tries to enter the correct OTP.You may only retry again after 24 hours.",
          noCardsHeader: 'No card detected.'
        }
      },
      notemessages: {
        MY:
          '<ol><li>Upon confirmation on the above new preferred daily limits, your defaulted debit card daily transaction limit will change from the current setting of RM6,000 for Personal Banking and RM10,000 for Priority Banking card.</li><li>In the event of a replacement card, you are required to complete this submission to expressly state your preferred limits assigned to the replacement card.</li><li>Cumulative contactless is defaulted to RM500 per day. If you do not wish to use this feature, please select RM0.</li><li>Please note that there are risks involved when a card-not-present transaction and/or overseas transactions are performed, including but not limited to your account data being compromised, resulting in the loss of funds in current / savings account and unauthorised retail purchase transactions.</li><li>For ATM iBFT, the defaulted limit is RM10,000.</li><li>For external accountholder, the ATM iBFT limit remains unchanged at RM10,000 in compliance with the Foreign Exchange Administration (FEA) Rules.</li></ol>'
      }
    },
    signatureUpdate: {
      header: {
        title: {
          signatureUpdate: 'Update My Signature',
          viewRequests: 'VIEW YOUR REQUESTS',
          uploadSignature: 'Upload Your Signature',
          reviewSignature: 'Review Your Signature',
          verifySignature: 'Verify Your Signature',
          captureSignature: 'Capture your signature',
          accountTypeLbl: 'Current/Savings Accounts',
          useThisImagebtn: 'USE THIS IMAGE',
          confirmation: 'Confirmation',
          instruction1: 'Sign your signature on white paper.',
          uploadSignLbl: 'UPLOAD A PICTURE OF YOUR SIGNATURE',
          requestProcessed: 'Your request is being processed!',
          refNo: ' Reference Number',
          signatureUpload: 'Signature Uploaded',
          reviewlbl: 'REVIEW SCANNED SIGNATURE',
          uploadSupport: 'Upload supporting documents (Max File Size 5MB)',
          fileUploadLabelDesktop:
            "<span class='drag-drop'>Drag & Drop files here</span><br><span class='or'>or</span><br><span class='choose-files'>Choose from computer</span>",
          fileUploadLabelMobile:
            '<span>Take a Photo/Upload an Image</span><br><span class="choose-files">(Maximum file size 5mb)</span>',
          desktopUploadInstruction:
            'Sign your signature on white paper. Upload a picture of your signature from your computer.(PNG, JPEG format only. Max File Size 5MB)'
        }
      },
      errorMsg: {
        title: {
          casa: 'You do not have any eligible account(s) for this request.',
          cardLimitMsg: 'Please select not more than 30 accounts per request',
          invalidMobNo: 'Invalid mobile number, Please contact customer care.',
          maxTryMobileNo:
            "We're sorry You have exceeded the maximum tries to enter the correct OTP.You may only retry again after 24 hours."
        }
      }
    },
    genericRequest: {
      header: {
        title: {
          'credit-card': 'Credit Card',
          'debit-card': 'Debit Card',
          loan: 'Loan',
          deposit: 'Term Deposit',
          default: 'Account',
          PLCLOSUR: 'Selected PLC account(s) to be closed',
          label1: 'Review your request',
          label2: 'Request Details',
          label3: 'Supporting Documents',
          label4: 'Please describe your request',
          label5: 'What is your request about?',
          label6: 'Upload Supporting Documents',
          label7: 'Type additional details here',
          labelMsgPLCLOSUR: 'Select the PLC account(s) you wish to close',
          CUSTOMERLbl:
            'If you were unable to find a suitable request in the menu, please describe your request to us in the section below.',
          CUSTOMERPlcHld: 'Please describe your request',
          'comment-label': 'Comments',
          'note-label': 'Please refer to the Notes below and provide the necessary information for your request.',
          statusMsg:
            "Your request has been submitted and will be processed.<br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br>To check the status, go to the 'Status' tab under Help & Services.",
          statusMsgCUSTOMER:
            'Thank you. Your request has been submitted and will be processed.<br><br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br><br>You may refer to your Secure Mailbox for status updates or view your submitted request under "Sent Items".',
          statusMsgReferral:
            'We have received your response to our query and will process your request.<br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.',
          referral: {
            scb: 'Standard Chartered:',
            user: 'You:',
            reply: 'Reply Message',
            submit: 'Submit Message'
          }
        },
        panelTitle: {
          'credit-card': 'Select a Credit Card',
          'debit-card': 'Select a Debit Card',
          loan: 'Select a Loan',
          deposit: 'Select a Term Deposit',
          default: 'Select an Account'
        },
        content: {
          loan: 'Which Loan you need help with?',
          casa: 'Which Account you need help with?',
          deposit: 'Which Term Deposit you need help with?',
          default: 'Which Card you need help with?'
        }
      },
      errorMsg: {
        title: {
          casa: 'You do not have any eligible account(s) for this request.',
          loan: 'You do not have any eligible loan(s) for this request.',
          default: 'You do not have any eligible card(s) for this request.',
          PLCLOSUR: 'No PLC account detected. You do not have any eligible PLC account to proceed with this request.'
        },
        content: {
          default: 'We are unable to process your request.',
          duplicateRequest:
            'We are unable to process your request at this moment as there is another request currently in progress.'
        }
      },
      default: 'Generic Request',
      otherRequest: 'Other Request',
      none: 'none',
      GREQSTAC: {
        title: 'Other Request',
        notemessage: {
          upload:
            'In order for your request to be processed, please ensure that you have submitted all relevant details.<br>In light of the current situation, please expect a delay in processing and avoid submitting time-sensitive requests via this platform. Thank you for your patience and understanding.'
        }
      },
      GREQSTCC: {
        title: 'Other Request',
        notemessage: {
          upload:
            'In order for your request to be processed, please ensure that you have submitted all relevant details.<br>In light of the current situation, please expect a delay in processing and avoid submitting time-sensitive requests via this platform. Thank you for your patience and understanding.'
        }
      },
      GREQSTLA: {
        title: 'Other Request',
        notemessage: {
          upload:
            'In order for your request to be processed, please ensure that you have submitted all relevant details.<br>In light of the current situation, please expect a delay in processing and avoid submitting time-sensitive requests via this platform. Thank you for your patience and understanding.'
        }
      },
      GREQSTTD: {
        title: 'Other Request',
        notemessage: {
          upload:
            'In order for your request to be processed, please ensure that you have submitted all relevant details.<br>In light of the current situation, please expect a delay in processing and avoid submitting time-sensitive requests via this platform. Thank you for your patience and understanding.'
        }
      },
      GREQSTMO: {
        title: 'Other Request',
        notemessage: {
          upload:
            'In order for your request to be processed, please ensure that you have submitted all relevant details.<br>In light of the current situation, please expect a delay in processing and avoid submitting time-sensitive requests via this platform. Thank you for your patience and understanding.'
        }
      },
      GREQSTGN: {
        title: 'Other Request',
        notemessage: {
          upload:
            'In order for your request to be processed, please ensure that you have submitted all relevant details.<br>In light of the current situation, please expect a delay in processing and avoid submitting time-sensitive requests via this platform. Thank you for your patience and understanding.'
        }
      }
    },
    certificatesRequest: {
      default: 'Request for Certificates',
      header: {
        panelTitle: {
          select: 'Enter Details',
          confirm: 'Confirmation'
        },
        title: {
          select: 'Select Product',
          year: 'Please provide the details needed in these certificate(s)'
        },
        subTitle: {
          select: 'Which certificate(s) are you looking for?',
          TDS:
            'Financial year starts on 1st April and ends on <span>31st March</span> of the following year.<br>From 2016 onwards, quarterly TDS certificates will be available for selection.',
          PI: 'Financial year starts on 1st April and ends on <span>31st March</span> of the following year.',
          IBC:
            'Financial year starts on 1st April and ends on <span>31st March</span> of the following year.<br>From 2016 onwards, quarterly certificates will be available for selection.'
        }
      },
      pageLabels: {
        submit: 'submit',
        certificate: 'Certificate Selection',
        placeholder: 'Please Select',
        year: 'Financial Year',
        selectYear: 'Select Financial Year',
        quarter: 'Financial Quarter',
        selectQuarter: 'Select the financial quarter you require',
        loanAccount: 'Loan Account',
        selectLoanAccount: 'Select respective loan account',
        serviceNo: 'Service No.',
        statusMsg:
          'Thank you. We will send you a notification when there is an update, and will be in touch if we need more information.<br>You can track the status at any time by going to Services > Status'
      },
      countryNotes: {
        default:
          'More information and supporting evidence provided at this point can increase your chance in getting a permanent refund.',
        TDS:
          'The certificate will be sent to your registered email id within 2 working days.<br>In case you wish to check your email id registered with us, please click on Profiles tab in the left panel.<br>The TDS certificate will be issued only for cases where Tax is deducted from the NRO Savings account / Deposits.<br>The TDS certificate will be issued only for cases where valid PAN available in Bank’s record.',
        PI:
          'The certificate will be sent to your registered email id within 2 working days.<br>In case you wish to check your email id registered with us, please click on Profiles tab in the left panel.<br>Interest certificate will not be issued in case arrear payment is not cleared.<br>For current financial year, certificate window will be opened from 1st May on-wards.',
        IBC:
          'The certificate will be sent to your registered email id within 2 working days.<br>In case you wish to check your email id registered with us, please click on Profiles tab in the left panel.<br>The Interest and Balance Certificate will be issued only for cases where balance as of 31st March and Interest Paid amount for the financial year should be greater than zero.'
      },
      error: {
        noAccounts: 'You do not have any eligible account(s) for this request.',
        noLoans: 'You do not have any eligible loan(s) for this request.',
        noIbc: 'You do not have any eligible account(s) for this request.',
        noCustomers: 'No eligible customer available'
      }
    },
    duplicateStatement: {
      title: {
        common: 'Statement Request',
        NONDLYCC: 'Credit Card redelivery'
      },
      productLabel: {
        account: 'Account',
        cccard: 'Credit Card',
        loan: 'Loan',
        datePlacehld: 'MM/YYYY'
      },
      header: {
        panelTitle: {
          select: 'Enter Details',
          account: 'Account Details',
          confirm: 'Confirm Details',
          mobConfirm: 'Confirmation',
          card: 'Card Details',
          product: 'Enter Details',
          statement: 'Enter Details',
          productNoNCC: 'Select Card'
        },
        title: {
          select: 'Select Product',
          account: 'Account Details',
          confirm: 'Confirm Details',
          statusMsg:
            'Thank you. We will send you a notification when there is an update, and will be in touch if we need more information.<br>You can track the status at any time by going to Services > Status',
          subInprogress: 'Your request is submitted and being processed.'
        },
        subTitle: {
          select: 'Please select the product you require a statement for',
          product: 'Please select the product you require a statement for',
          account: 'Select an account to be debited',
          confirm: 'Confirm Details',
          reviewAndconf: 'Please review and confirm your details',
          productNoNCC: 'SELECT A CARD'
        }
      },
      pageLabels: {
        addressInfo:
          'By clicking "OK", we will charge the paper statement fee to your account. Please select which account for us to debit the charges in the next step.',
        product: 'Product Selection',
        ConfirmProduct: 'Product Selection',
        account: 'Related Account',
        sltedProduct: 'Product Selected',
        dlryAddress: 'Delivery Address',
        startDate: 'Statement Start Date',
        endDate: 'Statement End Date',
        debitedAccount: 'Account to be debited',
        'deliveryMode.text': 'Delivery Mode',
        'deliveryMode.email': 'Email Statement',
        'deliveryMode.address': 'Paper Statement',
        deliveryModeconfirm: 'Delivery Mode',
        confirmAddress:
          'If you do not see your preferred address above please visit your nearest branch for assistance.',
        address: {
          mode: 'Paper Statement',
          text: 'Delivery Address',
          'check.text': 'Check Address',
          'message.text':
            'We will send the statement copy to your registered address. Please ensure your address is correct before proceeding to the next step.',
          'message.text.desktop':
            'We will send the statement copy to your registered address. Please ensure your address is correct before proceeding to the next step.'
        },
        email: {
          mode: 'Email Statement',
          text: 'Email Address',
          'check.text': 'Check Email',
          'message.text':
            'We will send the statement copy to your registered email address. Please ensure your email address is correct before proceeding to the next step.',
          'message.text.desktop':
            'We will send the statement copy to your registered email address. <br> Please ensure your email address is correct before proceeding to the next step.'
        }
      },
      countryNotes: {
        default:
          'More information and supporting evidence provided at this point can increase your chance in getting a permanent refund.',
        account:
          'Only the eligible account for cheque book will be shown. If you do not see you account, <a href="">contact our 24/7 Call Centre</a>.<br>Free may apply depending on the cheque book requested. Please check Bank’s <a>fee schedule</a> for more information.<br>Your Cheque Book will be sent to your registered mailing address. Please ensure your address is correct.',
        statement: 'You may be charged for this request based on terms and conditions.'
      },
      error: {
        default: 'Please enter a valid date',
        startDate: {
          error1: 'Start Date should not be more than 7 years',
          error2: 'Start date should not be greater than today date',
          error3: 'Start date should be less than end date'
        },
        endDate: {
          error1: 'End date should not be less than 7 years',
          error2: 'End date should not be greater than today date',
          error3: 'End date should be greater than start date'
        },
        commonError: {
          invalidMobNo: 'Invalid mobile number, Please contact customer care.',
          maxTryMobileNo:
            "We're sorry You have exceeded the maximum tries to enter the correct OTP.You may only retry again after 24 hours.",
          noEligible: 'No eligible records found',
          statmentInprogress:
            'We are unable to process your request at this moment as there is another statement request currently in progress.',
          endDateError: 'Month should be January or July',
          startDateError: 'Month should be June or December'
        },
        noData: {
          customerNotEligible: 'You are not eligible for this request.',
          customerData: 'No eligible account for statement request.',
          loan: 'You do not have any eligible loans for this request.',
          casa: 'You do not have any eligible accounts for this request.',
          nodebitAcc: 'You do not have eligible accounts to be debited for this request.',
          default: 'You do not have any eligible cards for this request.'
        }
      }
    },
    changeStatDate: {
      currentStmtDate: 'Current Statement Date',
      newStmtDate: 'Enter New Statement Date',
      statusMsg:
        'Your request is submitted. Thank You. We will process your request within 30 days. You will receive a status update notification from us. To check the status , go to the ‘Status’ tab under Help & Services.',
      noteMsg: {
        default:
          'Please enter a date between 2<sup>nd</sup> to 25<sup>th</sup> of the month.<br>The change in date is subject to bank approval. Success or failure of your request will be notified to you via SMS/Email.'
      },
      errorLabel: 'Please choose a different date. Refer the notes for suggestion.',
      eligibleText: 'You are not eligible to change the statement date.',
      everymonthText: 'of every month'
    },
    dollarReinstatement: {
      header: {
        title: {
          rewardPoints: 'Reinstate My Expired Rewards Points',
          confirm: 'Confirmation',
          confirm1: 'Confirm Details',
          select: 'Select Product'
        }
      },
      content: {
        cardSelectLabel: 'Select a Card',
        pointsLabel: 'Points',
        expiryDateLabel: 'expired on ',
        reviewLabel: 'Please review and confirm your request',
        reinstatementPlaceholder: 'Please Select',
        acknowledgeBelowLabel:
          " I confirm that the information provided is accurate and acknowledge that my request is subjected to the Bank's approval.",
        acknowledgeAboveLabel:
          " I confirm that the information provided is accurate and acknowledge that my request is subjected to the Bank's approval. I acknowledge that the Bank may approve up to a maximum of 500,000 Rewards Points only.",
        productSelected: 'Product Selected',
        rewardPoints: 'Rewards Points',
        expiredDate: 'Expired date',
        alertLabel:
          'We will send the notification to your registered email address. Please check and ensure your email address is updated before submitting the request.',
        referenceNo: 'Reference No.',
        quoteLabel: 'Please quote this reference number for all future correspondences related to this request.',
        status: 'Your request has been submitted and will be processed',
        statusMsg:
          "We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br><br>To check the status, go to the 'Status' tab under Help & Services.",
        statusMsg1:
          "Your request has been submitted and will be processed.<br><br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br><br>To check the status, go to the 'Status' tab under Help & Services.",
        countryNotes: {
          default:
            "Upon successful completion, you may find the updated Points expiry date in your next credit card statement.<br>Refer to our <a href='https://av.sc.com/sg/content/docs/scb-cc-tc.pdf'>Credit Card Terms</a> for more information."
        }
      },
      errorMsg: {
        noCards: 'You do not have any card(s) for this request.',
        noRewards: 'Your card do not any eligible reward(s)',
        noEligibleCards: 'You do not have any eligible cards for this request.'
      }
    },
    posLimit: {
      default: 'Change Daily Limit for Debit/ ATM/ Combo Card',
      header: {
        panelTitle: {
          select: 'Select Product',
          account: 'Account Details',
          confirm: 'Confirm Details',
          mobConfirm: 'Confirmation'
        },
        title: {
          select: 'Request to update daily transaction limit for your card(s)',
          confirm: 'Please review and confirm your details below'
        },
        subTitle: {
          select: 'Select a card type below:',
          account: 'Select the card you wish to update the limit for'
        }
      },
      pageLabels: {
        debitCard: 'Debit / ATM Card(s)',
        comboCard: 'Credit Card(s) with NETS/ATM link',
        all: 'All Cards',
        product: 'Product Selected',
        account: 'Card',
        posLimit: 'POS Limit',
        atmLimit: 'ATM Limit',
        dailyPOSLimit: 'Select Daily POS Limit',
        subInprogress: 'Your request is submitted',
        limitNotes: 'Explore our full range of banking products - Notes TBD',
        mobStatusMsg:
          "Your request has been submitted and will be processed.<br><br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br><br>To check the status, go to the 'Status' tab under Help & Services.",
        desktopStatusMsg:
          "Your request has been submitted and will be processed.<br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br>To check the status, go to the 'Status' tab under Help & Services."
      },
      countryNotes: {
        default:
          'As we are currently experiencing a high volume of requests, we apologise if you experience any processing delay.We will attend to your request as soon as possible. Thank you for understanding.<br>Please note that your new daily limit will be effective only after you receive a confirmation from us.<br>By submitting this request, I agree to the <a target="_blank" href="https://av.sc.com/sg/content/docs/scb-customer-terms-eff30Jun2019.pdf">terms and conditions</a>'
      },
      errorMsg: {
        noEligibleCards: 'You do not have eligible card(s) for this request.',
        invalidMobNo: 'Invalid mobile number, Please contact customer care.',
        maxTryMobileNo:
          "We're sorry You have exceeded the maximum tries to enter the correct OTP.You may only retry again after 24 hours."
      }
    }
  },

  rdcComponent: {
    selectAll: 'Select All',
    deselectAll: 'Deselect All'
  },

  rdcPinreset: {
    pinLabel: 'Enter New PIN',
    rePinLabel: 'Re-Enter PIN',
    error: {
      invalid: 'Enter a valid 4-digit PIN',
      mismatch: 'PIN and Re-Enter PIN mismatch'
    }
  },

  emailVerify: {
    emailLabel: 'Email Address',
    reEmailLabel: 'Re-confirm Email address',
    error: {
      invalid: 'Enter a valid Email',
      mismatch: 'Email and Re-type your Email Address mismatch'
    }
  },

  textVerify: {
    reConfirmLabel: 'Re-type ',
    error: {
      invalid: 'Enter valid ',
      mismatch: 'Otp and Re-Type Otp mismatch'
    }
  },

  multiNationality: {
    addNationality: '+ ADD NATIONALITY',
    fieldLabel1: 'Second Nationality',
    fieldLabel2: 'Third Nationality',
    error: 'Additional nationality cannot be same as previous nationality selected'
  },

  appSummary: {
    currentAccount: 'Current Account',
    excelAccount: 'Savings Plus Account',
    applyingFor: 'You are applying for',
    applicationId: 'Application ID',
    applicationSaved: 'Application Saved',
    refNo: 'Ref. No.'
  },

  errors: {
    unknownError: 'An Unknown error occurred. Please try again.',
    serviceUnavailable: 'The internet banking service is currently unavailable. Please try again later.'
  },
  generalDeclaration: {
    title: 'General Declaration',
    ecocashTitle: 'Ecocash Banking Services Terms and Conditions',

    declaration:
      "<div class='modal-terms-condition'><h3 class='general-info-head'>By accepting this application :</h3><ol><li>You represent and warrant that all information (including any documents) you have given to us in connection with the application is correct, complete and not misleading. (If this is not the case you may be personally liable.);</li><li>You authorise us to verify any of the information you have given to us or your credit standing from anyone we may consider appropriate (such as an authority or credit reference agency);</li><li>You acknowledge that we may decline your application without giving you any reason for doing so. If this happens, no contractual relationship arises between us and you;</li><li>You confirm and agree that we may give any information in connection with this application (including your personal information) to any service provider (whether located in or outside of Côte d'Ivoire ) for the purposes of providing any service to you in connection with this application (including data processing);</li><li>You declare that you have read and understood our [Client Terms /Product Terms and conditions/Online terms –and the applicable documents referred to in Part A of our Client  Terms [please check Part A of the client terms and confirm if the reference is correct] forming our banking agreement which are available . If it is an in-page text within the application itself, probably there is a hyperlinked sentence which takes you there within the app?] You acknowledge that you are bound by any variation we make to these documents, in accordance with our banking agreement. In particular, you understand that by entering into our banking agreement you give indemnities, authorisations, consents and waivers and agree to limitations on our liability;</li><li>You consent to us contacting you at the addresses, e-mail addresses  and phone numbers you have provided to us, to give you information on other products and services that we, or our strategic partners, may offer; where applicable, you agree that we will send electronic statement for your bank accounts on monthly basis by email to the email addresses  provided by you.</li><li>You consent to us and to each of our subsidiaries and affiliates (including each branch or representative office) (“Standard Chartered Group”) its officers, employees, agents and advisers disclosing information relating to you (including details of our banking agreement, the accounts, the products or any arrangement with us) to our head office and any other member of the Standard Chartered Group in any jurisdiction (“Permitted Parties”); your employer professional advisers, service providers (whether located in or outside of  Côte d'Ivoire) for the purposes of providing any service to you in connection with this application (including data processing), or independent contractors to, or agents of, the Permitted Parties, such as debt collection agencies, data processing firms and correspondents who are under a duty of confidentiality to the permitted parties, any actual or potential participant or sub-participant in relation to any of our obligations under our banking agreement between us, or assignee, novatee or transferee (or any officer, employee, agent or adviser of any of them), any credit reference agency, rating agency, business alliance partner, insurer or insurance broker of, or direct or indirect provider of credit protection to, or any Permitted Parties; any court, tribunal or authority (including an authority investigating an offence) with jurisdiction over the Permitted Parties; a merchant or member of VISA International or Mastercard International where the disclosure is in connection with the use a card; any authorized person or any security provider; anyone we consider necessary in order to provide you with the services in connection with an account;</li><li>You acknowledge that the bank will register you for a prescribed set of SMS alerts, to be sent to the number registered with the bank</li><li><p>For the purposes of your application of a credit card or personal loan / finance application – if any -(including personal instalment loan, personal revolving loan and personal line of credit/ overdraft) or Home Loan / Home Finance application or Auto Loan / Auto Finance application you confirm that:  </p> <ol type='a'><li>None of your existing credit cards and/or unsecured loan / finance have been cancelled due to payment defaults,</li><li>You do not have any payments overdue by more than one month on any loans / finances or  credit cards you have with other financial institutions,</li><li>You are not and have never been bankrupt and you have no intention to petition or are currently petitioning for bankruptcy;]</li></ol></li><li>You acknowledge that insurance plans that accompany certain products are underwritten by third parties insurers. Such insurers are not Standard Chartered Group associates or subsidiaries or related corporations. Such insurers are solely responsible for all coverage and compensation under the plans. We collect your information and send them to such insurers for processing and review. Collection of information does not necessarily mean that your insurance application will be approved; and</li><li>You understand and agree that the bank has the right (upon giving you notice) to amend or withdraw any rewards that may accompany the bundled products that you have applied for. In particular if you do not use any of the bundled products that you have applied for, the Bank may upon giving you notice withdraw the rewards that accompany the bundled products,</li><li><span>Specific for Joint Accounts: </span><ol type='a'><li>By accepting this declaration, you accept and agree the primary accountholder’s absolute discretion in running the account in any manner he/she sees fit. Such absolute discretion includes, without limitation, applying for any product and in any limit (subject to the bank approval). For further information, please see the documents that form part of our agreement.</li><li>All statements and notices, including legal ones, will be sent to the primary accountholder and the bank is under no obligation to inform each and every one of the joint accountholders with any matter. The primary accountholder and the invitee(s) might be held liable if the primary accountholder does not act promptly when he/ she receives any information that might require an action from his/ her end;  </li><li>If the account is current account, the primary accountholder and the invitee(s)  hereby understand that the account might be associated with the issuance of a checkbook [cheque book]  and  the primary accountholder and the invitee(s) are aware of the risks associated therewith, including, without limitation, the legal and regulatory consequences if a cheque is bounced;</li><li>The primary accountholders and the invitee(s) hereby agree and understand that their obligations and liabilities towards the bank are joint and several with any and all of the joint accountholders; and</li><li>If you are the primary accountholder, you hereby give us the permission to share some or all of your information to the invitee(s). The information that the bank might share, by any mean, includes, without limitation, your name, date of the invitation request, the date the account was  opened, how many people are already joint accountholders and their names, joint account number, current balance and currency, email and mobile number of each of the accountholders, whether there are any liabilities on the account or you personally. For the avoidance of doubt, you to acknowledge and understand that the bank have the right to share the information as mentioned above at any time and by any mean, up until you cancel the invitation or the invitation is rejected by the invitee;</li><li>If you are the joint accountholder (recipient (s) /invitee(s)), you hereby give the bank the permission to share some or all of your information to other current or future invitee(s) (which might be sent by any member of the account parties, including the primary accountholder) []. The information that the bank might share, by any mean, includes, without limitation, your name, date of the invitation request, the date the account was  opened, how many people are already joint accountholders and their names,  joint account number, current balance and currency, email and mobile number of each of the accountholders, whether there are any liabilities on the account or you personally. For the avoidance of doubt, you acknowledge and understand that the bank has the right to share the information as mentioned above at any time and by any mean, up until you cancel the invitation or the invitation is rejected by the invitee;</li></ol></li><li>Subject to applicable local laws, I hereby consent for Standard Chartered PLC or any of its affiliates (collectively “the Bank”) to share my information with domestic and overseas regulators or tax authorities where necessary to establish my tax liability in any jurisdiction.</li><li>Where required by domestic or overseas regulators or tax authorities, I consent and agree that the Bank may withhold from my account(s) such amounts as may be required according to applicable laws, regulations and directives.</li><li>I undertake to notify the Bank within 30 calendar days if there is a change in any information which I have provided to the Bank.</li></ol></div>",

    ECOCASH:
      "<div class='modal-terms-condition general-declaration'><ol><li>I hereby certify that all the information provided is correct and authorize Standard Chartered Bank Limited Zimbabwe (“The Bank”) to use the information contained herein to process and register the mobile line and the bank account in the Ecocash Banking Services Platform.</li><li>I hereby  indemnify Standard Chartered Bank Limited Zimbabwe (“The Bank”) against any losses, claims, damages, whether direct, special or consequential, howsoever and when so ever arising as a result of a failure of mobile equipment, Ecocash Banking Services being offline or unavailable for any reason, the mobile phone number provided being incorrect, account number provided  being incorrect, unlawful or unauthorised access to my mobile phone by another person(s), delays in Ecocash Banking Services or direct or indirect losses which the Bank could not reasonably have foreseen.</li><li>The Ecocash Pin number used to access any other Ecocash Services shall be the same used to access Ecocash Banking Services and I agree that the Bank shall not be liable under any circumstances whatsoever should I disclose the PIN Number to a third party.</li><li>The above terms and conditions shall be read together with any other Ts & Cs as they appear on the Ecocash User Registration Form and Bank Account Opening form and any other Ecocash Services guidelines as advised by Ecocash &/or the Bank from time to time as well as the Bank’s relevant product and client terms which may be found at www.sc.com/zw.</li><li>The Bank reserves the right, from time to time, to review and or amend the terms and conditions applicable to the use of Ecocash Services and shall advise Ecocash registered Users of those changes accordingly.</li></ol></div>"
  },
  ngBvnFlow: {
    forgotBvnMessageTitle: 'How to get your<br/>Bank verification Number.',
    forgotBvnMessageContent:
      'To get your BVN in an SMS, simply dial *565*0# from the mobile number registered to your BVN.<br/><br/>Please note that regular network SMS charges would apply.',
    accountUpgradeHeader: 'Do you want to upgrade your instant account?',
    upgradeDetailsheader: 'Upgrade to Instant Plus:',
    upgradeDocDetailsHeader: 'What you need to upgrade:',
    noBVN: {
      message:
        "<p class='title highlight'>Proceed without BVN?</p><p class='message'>Your account will not be activated until your BVN is provided.</p>"
    },
    liveSelfieInfo: {
      title: 'What is a Live Selfie?',
      message:
        'A Live Selfie is essentially a photo that captures a few seconds of the moment to create a moving image.<br/><br/>This helps to prevent imposters from opening a bank account online with your still photo.'
    },
    receiptPageInfo: {
      title: 'Funding your<br/>account is easy!',
      message:
        'You can do it directly in your Standard chartered mobile banking app.<br/><br/>When you next log into your online banking account, we will provide options to instantly fund your account fuss free in your app.'
    },
    etbAccountOpeningFailure: {
      message: 'Your account is eligible for Upgrade Option. Please click on Upgrade account from your Home Screen.',
      buttonText: 'Take me to Home Screen'
    }
  },
  productSummary: {
    assetAccountSelection: {
      assetAccountHeader: 'One moment please',
      assetAccountText_1: 'You will need a current account to begin banking with us.',
      assetAccountText_2: "Let's set you up with one now.",
      assetAccountButton: 'SELECT A CURRENT ACCOUNT'
    },
    startApplication: {
      header: 'Great! Let’s get you started with the application.',
      assetOnboardingHeader: 'Your application will take about 15 minutes to complete.',
      bureauConsent: {
        header: 'Bureau Consent',
        labelWithCC:
          'I authorise the Bank to access, obtain and verify my personal information from Government database and Credit Reference Bureaus for purposes of banks product offering.',
        labelDefault:
          'I authorise the Bank to access, obtain and verify my personal information from Government database for purposes of banks product offering.'
      },
      applicationSummary: {
        applicationSummaryHeader: 'Your Application Summary',
        eligibilityDocumentHeader: 'Eligibility and documents',
        eligibilityHeader: 'Eligibility',
        documentHeader: 'Documents required',
        applyingForProduct: 'You are applying for these bank products:',
        basicInfoTitle: '1. Basic info',
        basicInfoDescription: 'Provide your contact details and ID documents.',
        moreInfoTitle: '2. More about you',
        moreInfoDescription:
          'Provide additional information about your address, employment status, product preferences.',
        supportingTitle: '3. Supporting documents',
        supportingDescription: 'Provide your contact details and ID documents',
        reviewTitle: '4. Application review',
        reviewDescription: 'Review your application details.',
        progressInfoPrefix: 'Additional requirements may apply. ',
        progressInfo:
          'Your progress will be automatically saved in your app. You may resume your application within 30 days.',
        keepTheseReadyTitle: 'Keep these ready',
        productHardBundleNote: 'A no fee bank account to credit your salary'
      },
      pricing: {
        details: 'Details',
        charges: 'Charges',
        annualFee: 'Annual fee for new credit card clients',
        finalCharge: 'Finance charges',
        continue: 'Continue',
        headerInfo:
          'Fees and charges are subject to change. All fees and charges listed are inclusive of 5% Value Added Tax (VAT), where applicable.',
        footerInfo:
          'For all fees and charges, please visit: <u><a href="javascript:;" onclick="window.open(\'https://www.sc.com/ae/help-centre/service-charges/\',\'_system\')">https://www.sc.com/ae/help-centre/service-charges/</a></u>',
        footerMultipleInfo:
          'If you have applied for multiple credit cards in this application, the credit card with the higher annual fee will be waived for the first year and the other card(s) will be charged from the first year onwards. If all the cards applied for have the same annual fee, one card annual fee will be waived for the first year and the other card(s) will be charged from the first year onwards.'
      },
      infoBoxText:
        'Your details will be automatically saved in the app after every step. You may save your application and continue later, anytime within 30 days. After 30 days, your partially completed application will expire. We will send you an email and SMS with a link to resume your application.',
      infoBoxTitle: 'Autosave feature'
    },
    productList: {
      cartHeader: 'You are applying for these banking product(s)',
      noProductsMsg: 'Hey there! You already have all the credit cards we have on offer.',
      productsInfo:
        'Now you can apply multiple credit cards in single GO. Please view our other credit card offerings for your personal needs',
      productAlreadyExist: 'Oh! You already have this card. Do you want to explore other card offerings?',
      restrictCCMessage:
        'You need to have an active current account to apply for this product. Please explore account category to apply for one now',
      newLoan: 'Apply for a new personal loan',
      transferLoan: 'Transfer loan from other bank',
      newCredit: 'Apply for a new credit card',
      transferCredit: 'Transfer credit card balance from other bank',
      categoryDisableDescription: 'These products will be available for you to open after your account is active',
      categoryDisableTitle: 'Oops!',
      categoryNoProductsTitle: 'Sorry!',
      bundlingInfo: 'You will need a current account to begin banking with us. We are setting you up with one now.',
      categoryNoProductsDescription:
        'You can only have one credit card.<br> You may increase your limit or perform a balance transfer in Help & Services.',
      icdd_disclosure: {
        actionSheetLabel: 'Confirmation on your PEP / SANC / ADV awareness',
        mainRadioLable: 'Are you aware of PEP / Sanctions / Adverse Media?',
        PEPRadioLable: 'Are you aware of PEP?',
        sanctionRadioLable: 'Are you aware of Sanctions?',
        adverseRadioLable: 'Are you aware of Adverse Media?'
      }
    },
    bureauTitle: 'Bureau Consent',
    bureauDescription:
      'You authorise the bank to verify your information and conduct checks from third party agencies, including National Registries and Credit Reference bureaus.',
    notEligible:
      'Thank you for your interest in this product. We are currently unable to process your application through the app.',
    notEligibleInfoTitle: 'What can I do now?',
    notEligibleInfo1: 'A Bank representative will contact you shortly for your options.',
    notEligibleInfo2:
      'If you have any queries, you may contact our 24-Hour Phone Banking team on (+971) 600 5222 88 or visit your nearest branch.',
    isCDDRiskAvailable: {
      desc: 'We are unable to open an account for you.',
      maxAttemptReachedMsg: 'Sorry, You have exceeded the maximum number of attempts.',
      info2: 'You can also visit any of our branches where we will be happy to assist you.',
      info1_CI: 'Please contact the Customer Contact Centre on +225 2030 3281.',
      info1_KE: 'Please contact the Customer Contact Centre on +254 203 293900 or +254 703 093900.',
      info1_GH: 'Please contact the Customer Contact Centre on +233 302740100.',
      info1_UG: 'Please contact the Customer Contact Centre on +256 200524100 or +256 313294100.',
      info1_TZ: 'Please contact the Customer Contact Centre on +255 222164999 , +255 784109999 or +255 768986999.',
      info1_BW: 'Please contact the Customer Contact Centre on +267 361 5800.',
      info1_ZM: 'Please contact the Customer Contact Centre on +260 966751500.',
      info1_ZW: 'Please contact the Customer Contact Centre on +263 242 254281 - 3.',
      info1_NG: 'Please contact the Customer Contact Centre on +234 1270 4611 - 4.',
      default: 'Please contact the Customer Contact Centre'
    },
    button: {
      backToCatelogue: 'BACK TO PRODUCT CATELOGUE',
      backToHomePage: 'BACK TO HOMEPAGE',
      authoriseContinue: 'AUTHORISE & CONTINUE',
      resumeApplication: 'Resume Application'
    },
    appDedupeMessage: 'You have an existing application in progress, please continue with the same application.',
    icmDedupeMessage:
      "<div class='fallback-heading'>We have identified you as an existing client.</div><br/><div class='fallback-message'>Sorry, we have identified you have an existing active relationship with our bank and therefore cannot proceed further with this application.<br /><br/></div><div class='fallback-link-style'>What can you do now?</div><br/><div class='section-2'><ul><li>Please login to Online Banking to apply for new product</li> <li>If you do not have an existing Online Banking please register for new one.</li> </ul></div>",
    etbHardHoldMessage:
      "<div class='fallback-heading'>Sorry, we are unable to offer you selected product at this moment.</div><br/><div class='fallback-link-style'>What can you do now?</div><br/><div class='fallback-message'>Our bank representative will contact you within 24 hours to navigate you through your next steps.</div>",
    etbCustomerMessage:
      'Sorry, we cannot proceed with your application as you currently hold a Standard Chartered credit card.',
    appNTBApproved: 'Uh-oh! A credit card application submitted with this mobile number has already been approved.',
    relPartyDedupeMessage:
      'Sorry, we are unable to process your credit card application through the app at the moment. Please contact our Phone Banking on (+971) 600 52222 88 or visit your nearest branch for assistance.',
    appSubmitDedupeMessage:
      'Sorry, it looks like you have another credit card application in progress with the Bank. Please try again after receiving the status of your current application.',
    icmMobMismatchMessage:
      "<div class='fallback-heading'>Sorry, we are unable to offer you selected product at this moment.</div><br/><div class='fallback-link-style'>What can you do now?</div><br/><div class='fallback-message'>Our bank representative will contact you within 24 hours to navigate you through your next steps.</div>",
    onBoardingRiskMessage:
      "<div class='fallback-heading'>Sorry, we are unable to offer you selected product at this moment.</div><br/><div class='fallback-link-style'>What can you do now?</div><br/><div class='fallback-message'>Our bank representative will contact you within 24 hours to navigate you through your next steps.</div>",
    privateBankingFlagMessage:
      "<div class='fallback-heading'>Sorry, we are unable to offer you selected product at this moment.</div><br/><div class='fallback-link-style'>What can you do now?</div><br/><div class='fallback-message'>Our bank representative will contact you within 24 hours to navigate you through your next steps.</div>",
    isETB: "<div class='fallback-heading'>You are an existing customer. Please login and apply</div><br/>",
    isETBCSLDedupeMatch:
      "<div class='fallback-heading'>You are an existing customer. Please login and apply</div><br/>",
    assetOnboardingisETB:
      "<div class='fallback-heading'>We recognize that you are banking with us, simply log in to continue your application.</div>",
    isPurposeOfAccBusiness:
      "<div class='fallback-heading'>The product you have selected is for personal use only. To open an account for Business Purposes, kindly visit your nearest SCB Branch.</div><br/>",
    sanctionCountry:
      "<div class='fallback-heading'>We regret to advise that your application has been declined since it does not meet a set of banking conditions.</div><br/>",
    isNonResident:
      "<div class='fallback-heading'>Please contact our Nearest Branch as we are unable to proceed with your application on this Channel.</div><br/>",
    purposeOfAccAlertMsg:
      "<div class='fallback-heading'>Sorry, we currently do not allow opening of business accounts in this channel. Please visit any of our branches to open a Business Account.</div><br/>",
    etbResumeDedupeMessage:
      "<div class='fallback-message'>Oh wait! You're already our client, simply log in to resume your application.<br /><br/></div>",
    mbnkResumeDedupeMessage:
      "<div class='fallback-message'>Uh-oh! We noticed that there is a work in progress application initiated through SCMobile App. To complete the application, visit our SC Mobile app> Resume / Track Application > Resume my Application.</div><br/>",
    ibnkResumeDedupeMessage:
      "<div class='fallback-message'>Uh-oh! We noticed that there is a work in progress application initiated through SC.COM website. We have sent you a mail along with application resume link to your mail ID. Please open the application through email link</div>",
    staffMbnkResumeDedupeMessage:
      "<div class='fallback-message'>Please note that there is a work in progress application. You can only initiate a new application after 2 hours of the initial request.</div><br/>",
    staffIbnkResumeDedupeMessage:
      "<div class='fallback-message'>Please note that there is a work in progress application. You can only initiate a new application after 2 hours of the initial request.</div><br/>",
    staffAbortResumeDedupeMessage:
      "<div class='fallback-message'>Please note that there is a work in progress application. You can only initiate a new application after 2 hours of the initial request.</div><br/>",
    incomeAlertSingle:
      'Uh-oh!  Your monthly gross income does not meet the minimum criteria for the product you selected.',
    incomeAlertSingleCC:
      'Uh-oh!  Your monthly gross income does not meet the minimum criteria for the credit card you selected.',
    incomeAlertMultiple:
      'Uh-oh!  Your monthly gross income does not meet the minimum criteria of one of the products you selected.',
    incomeAlertMultipleCC:
      'Uh-oh!  Your monthly gross income does not meet the minimum criteria of one of the credit cards you selected.'
  },
  applyProducts: {
    productChangeTitle: 'Do you want to change your product selection?',
    changeMsg: 'Current application will be saved and you will be directed back to the product catalogue.',
    incorrectVerificationCode: 'Authorisation code is incorrect, please enter it again',
    maxLimitReached: 'Authorisation code is incorrect and you have reached the limit to retry',
    eligibleLimitPageHeader:
      "<span class='eligibility-title'>Congratulations!</span> <br/><span class='eligibility-content'>Here's what you are eligible for.</span>",
    verificationCodeRequired: 'Authorisation Code is required',
    verificationCodeInfo:
      'If you are unable to access your office email at the moment, you may skip this step and proceed with your application. You can complete this email verification within 30 days.',
    verificationCodeHeader: 'Verify your office email',
    verificationCodeTitleInfo: "We've sent a 6-digit authorisation code to ",
    info: ' Please enter the code below.',
    skipBtn: 'Skip',
    verifyBtn: 'Verify',
    tryAgain: 'Try Again',
    docExpireTitle: 'Your ID document requires to be refreshed',
    docExpireMessage: 'Please go to your Profile Update menu and upload your current ID document',
    infoBoxText:
      'Now you can apply multiple credit cards in single GO. Please view our other credit card offerings for your personal needs',
    merchantInfo: 'Choose a Mobile Number to validate',
    merchantInfoForRadio: 'Choose a number you wish to register with us.</br>We will send you an SMS OTP to verify.',
    maxRetryLimitReached:
      'Oh wait! Promo code used is invalid. You have exceeded the maximum number of attempts. Do you want to continue without a promo code?',
    continue: 'Continue',
    continueToLogin: 'CONTINUE TO LOGIN',
    stopMyJourney: 'Cancel',
    promoRetryMsg:
      '<div>Invalid promo code</div><div>Do you want to try again or skip and continue without a promo code?</div>',
    applicationResult: {
      declineTitle: 'Sorry, looks like we need more information.',
      pcoDeclineInfo:
        'You may contact our client care centre at +971 3293900 or visit any of our branches for more information.',
      declineBundledTitle: 'Looks like our offer did not match your expectation:(',
      declineBundledInfo:
        "Contact our 24-hour banking line at <br><u><a href='tel:+254302740100'>+254 302 740100</a></u> or visit one of <u>our branches</u> if you want a higher credit limit.",
      referredTitle: 'Application referred.',
      referredInfo:
        'Thank you for your application. One of our relationship staff will contact you within 2 days to discuss your credit card application.<br><br>You may contact our client care centre at <br><u>+254 3293900</u> or visit any of <u>our branches</u> for more information.',
      step1: 'Provide Additional Details',
      step2: 'Customise Banking Preferences',
      step3: 'Submit Application'
    },
    fundAccount: {
      inSufficientFund: {
        title: 'Insufficient Funds to Open Account',
        content_1: 'A minimum deposit of ',
        content_2: ' is required to open this account.',
        fundAccount_1: ' For funding, Select >>Transfers >> Between Own Accounts'
      }
    },
    insurance_sanlam:
      '<h2 class="title">Benefits and Exclusions</h2><div class="learn-more"><p class="header">Unsecured Personal Loans / Mortgage Protection</p><ol><li><span class="sub-header">Death Benefit</span> – In the unfortunate event of death through illness or an accident, the death benefit will be paid. The death benefit payable is the amount outstanding on the personal/mortgage at the time of your death. The amount payable does not include any arrears that may have accumulated as result of non-payment of the loan. The policy will also pay the Last Expense Benefit where this benefit was selected under the options. This benefit will be paid to the bank.</li><li><span class="sub-header">Disability Benefit</span> – If you become permanently and totally incapacitated because of injury or illness and are prevented from following your own or any similar occupation, for more than six (6) consecutive calendar months from the date of such injury or illness, the benefit will be treated in the same manner as No.1 above. However, there will be a 6 month waiting period from the commencement date during which only permanent and total disability claims resulting from accidents and non natural illness will be paid. This benefit will be paid to the bank.</li><li><span class="sub-header">Retrenchment Benefit</span> – The benefit shall mean the insured member suffering a loss of employment as a result of implementation of a staff reduction program, adverse business conditions, introduction of new technology or the re-organisation of the business by the employer which results in the insured not earning any income for a continued unemployment period of at least 30 days. Sanlam shall pay to the bank the monthly instalment due from the date of retrenchment under the credit life agreement for a maximum of 9 months and this payment shall exclude arrear instalments and arrear finance charges; if any. The retrenchment cover is payable only once in the lifetime of the facility. No benefit is payable after re-employment of the life assured.</li><li><span class="sub-header">Last Expense</span> – This benefit is payable within 48 hours of the notification of death to assist in meeting funeral expenses. It is important to nominate a beneficiary(ies) for the purposes of handling the claim under this benefit category. It is recommended that you nominate the beneficiaries who are above 18 years. For joint life (applicable only to mortgage protection), the cover ends on the death of the first life. This benefit is payable to the next of kin.</li></ol></div>',
    insurance_prudential:
      '<h2 class="title">Benefits and Exclusions</h2><div class="learn-more"><p class="header">Unsecured Personal Loans and Mortgage Protection Loans</p><p class="header-content">You will be covered for the following benefits, subject to the benefits option you have selected, for the term of the policy (maximum up to age 64 years last birthday):</p><ol><li><span class="sub-header">Death Benefit</span> – In the unfortunate event of your death, the death benefit will be paid to the bank. The death benefit payable is the amount outstanding on your unsecured personal loan or mortgage loan at the time of your death. The amount payable does not include any arrears that may have accumulated as a result of non-payment of the loan.</li><li><span class="sub-header">Disability Benefit</span> – If you become permanently and totally incapacitated because of injury or illness and are prevented from following your own or any similar occupation, for more than six (6) consecutive calendar months from the date of such injury or illness, the benefit will be treated in the same manner as No.1 above. However, there will be a 6 month waiting period from the commencement date of the policy during which only permanent and total disability claims resulting from an accident will be paid. This benefit is paid to the bank.</li><li><span class="sub-header">Retrenchment Benefit</span> – The benefit shall become payable in the event of you being retrenched or made redundant by your employer and remain without employment for a period exceeding 30 continuous days from the date of retrenchment or redundancy. Prudential will pay to the bank the monthly installment due from the date of retrenchment or redundancy under the credit life agreement till the date of re-employment or for a maximum of 9 months, whichever is earlier. There shall be a thirty (30) days waiting period from the commencement date of the policy during which this benefit is not payable. This benefit is only payable once during the lifetime of the policy.</li><li><span class="sub-header">Last Expense Benefit</span> –  In the unfortunate event of your death, Prudential will pay an amount equal to 10% of the initial loan amount to your nominated beneficiary. This benefit, where selected, is paid in addition to the death benefit. This benefit is payable within 48 hours of the notification and provision of necessary documentation to assist in meeting funeral expenses. It is important to nominate a beneficiary(s) for the purpose of handling the claim under this benefit category. It is recommended that you nominate beneficiaries who are above 18 years. For joint life (applicable only to Mortgage Loans) the cover ends on the death of the first life.</li></ol></div>',
    insurance_jubilee:
      '<h2 class="title">Benefits and Exclusions</h2><div class="learn-more"><p class="header">Benefits - Unsecured Personal Loans/ Mortgage loans</p><ol><li><span class="sub-header">Death Benefit</span> – Benefit is payable in case of death. The Benefit (payable to the bank) is the amount of loan outstanding at the time of death excluding any arrears as a result of nonpayment of loan.</li><li><span class="sub-header">Disability Benefit</span> – This Benefit is payable to the bank in case of total and permanent disability due to accident or illness. It is the amount of loan outstanding at the time of death excluding any arrears as a result of nonpayment of loan. Disability is deemed to exist while in the opinion of the Jubilee, you are totally disabled or incapacitated by reason of injury or illness from following your usual occupation or any other occupation to which you may reasonably be suited by training, education or experience and the disability has persisted for at least 6 consecutive calendar months from the date of such injury or illness.</li><li><span class="sub-header">Retrenchment Benefit</span> – This benefit shall mean the insured member suffering a loss of employment as a result of implementation of a staff reduction program, adverse business conditions, introduction of new technology or the re-organization of the business by the employer which results in the insured not earn any income for a continued unemployment period of at least 30 days. The benefit amount is monthly loan installment payable to the bank for a period of 9 months or up to date of reemployment whichever is earlier. The payment shall exclude any installment arrears or charges. It is payable once in a life time of the life assured.</li><li><span class="sub-header">Funeral Expense benefit</span> – This benefit is payable to the nominated beneficiary within 48 hours of notification of death. In case of joint life assured, the benefit is payable on first death only.</li></ol></div>',
    applicationResultTitle: 'Continue your account application:',
    applicationResultAccName: 'Hifadhi current account',
    monthRange: 'Enter a valid Number between 0-11',
    yearRange: 'Enter a valid number between 0-40',
    quitBtn: 'QUIT',
    nonResident: 'Sorry! You are a invalid Resident',
    employerSearchMsg: 'Type your company name and wait for a while to search',
    ineligibleCustomerTitle: 'Sorry, looks like we will have to call you back.',
    ineligibleCustomerDesc:
      'Our relationship manager will contact <br> you within 24 hours to advice you about <br> your eligibility and recommend other <br> suitable options for you. <br><br> Meanwhile, you may continue to apply for <br> the selected bank account(s) instead.',
    customLoaderMsg: 'Calculating your eligibility...',
    ineligibleCustomerDesc_etb: 'Would you like to browse other products to apply instead?',
    ineligibleCustomerButton_etb: 'BROWSE OTHER PRODUCTS',
    editMailingAddressTitle: 'Do you want to edit your mailing address?',
    editMailingAddressMessage:
      'You will leave this application and your progress will be lost. You can restart the application after updating your address.',
    editMailingAddressButton: 'YES, UPDATE ADDRESS',
    editDaonDetailsTitle: 'Do you want to edit ID details?',
    editDaonDetailsMessage:
      'Your application will be manually verified before your account gets activated, which may take more time.',
    editDaonDetailsButton: 'YES, CONTINUE TO EDIT',
    aipCashOneStatus: 'Congratulations!',
    aipCashOneMsg: "Based on your declared income, Here's what we offer!",
    eligibilLimit: {
      errorInput: 'Invalid amount Entered',
      errorInputEmpty: 'Field cannot be blank',
      errorInputMaximum: 'Value cannot exceed the maximum approved amount',
      errorInputMinimum: 'Please enter value more than',
      errorTenure: 'Invalid Tenure Entered',
      errorTenureEmpty: 'Field cannot be blank',
      errorTenureMaximum:
        'The value entered is not within our valid tenor period. Please try our sliders to pick desired tenor',
      errorTenureMinimum:
        'The value entered is not within our valid tenor period. Please try our sliders to pick desired tenor',
      errorNotNumber: 'Please enter a numeric value',
      reviewPageInsuranceLabel: 'Insurance Premium',
      reviewPageLoanAmtLabel: 'Applied Loan Amount',
      recalculateTitle: "You've made some changes above!",
      recalculateContent: 'Please allow recalculation'
    }
  },
  hrPortal:{
    loanApp: 'Loan Applications',
    raiseReq: 'Raise Request',
    insights: 'Insights',
    profileSettings: 'Profile Settings',
    welcome: 'Welcome',
    custCare: '+254 329 3900',
    loanApplicantsTitle: "Loan Applicants",
    pendingApplication: "Pending applicants",
    approvedApplication: "Approved applicants",
    declinedApplication: "Declined applicants",
    fullName: "Full Name",
    AppRefNo: "Application Reference Number",
    empId: "Employee ID",
    appSubmited: "Application Submitted",
    action: "Action",
    approvalDate: "Approval Date",
    reviewBy: "Reviewed By",
    noOfDays: "days ago",
    verifyBtn: "Verify",
    reVerifyBtn: "Reverify",
    refered: "(Refered)",
    logout : "Log Out",
  },
  monthYearVerify: {
    monthRange: 'Enter a valid values between 40 years and 0 months'
  },
  preEtb: {
    resumeApplication: 'Resume application',
    statusTracking: 'Check Application Status',
    mobileNumber: 'Please provide your mobile number',
    footNote: 'We will be sending you an OTP via SMS for verification.',
    button: {
      resumeNow: 'RESUME APPLICATION',
      checkStatus: 'CHECK STATUS'
    }
  },
  TRANSACTIONDISPUTE: {
    noCardsHeader: 'You do not have eligible cards for this request.',
    noCardsInfo:
      'If you do not see the card you wish to block in the list below, please contact our <u><a>24/7 Phone Banking</a></u> immediately.',
    noTransactions: 'You do not have transactions that are eligible for dispute.',
    reversalTransaction:
      'Please note there is a credit for the same amount in your card.<br/> Would you like to proceed with this dispute?',
    limitInfo: 'You may select up to 10 transactions per request',
    reasonRequired: 'Please select a dispute reason to proceed',
    serviceNo: 'Service No.'
  },
  tinSelect: {
    selectErrorMessage: 'Select atleast {{minlength}} and up to {{maxlength}} {{label}}',
    selectPlaceHolder: 'Please Select',
    tinPlaceholder: 'Tax Identification Number (TIN)',
    checkboxLabel: "I don't have a TIN",
    radioGroupLabel: 'Reason for not Providing TIN',
    specificReasonLabel: 'Please explain why you are unable to obtain the TIN',
    specicReasonBanner:
      'Please note that you may be contacted to provide additional information regarding your TIN declaration before account can be opened'
  }
};
