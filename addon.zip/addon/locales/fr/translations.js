export default {
  FERE: {
    action: {
      modal: {
        message: 'Veuillez confirmer de quitter le formulaire sans le soumettre ?',
        resetMessage: 'Êtes-vous sûr de vouloir rétablir la modification?'
      },
      button: {
        confirm: 'CONFIRMER',
        cancel: 'ANNULER',
        YES: 'OUI',
        NO: 'NON',
        edit: 'Modifier',
        reset: 'RÉINITIALISER',
        save: 'ENREGISTRER',
        close: 'CLOSE'
      }
    },
    validation: {
      error: {
        labelNameError: 'devrait être inférieur au solde du comptee',
        message: ' est requis',
        dateExpired: 'La date est expirée',
        dateInvalid: 'Veuillez saisir une date valide',
        dateFuture: "La date future n'est pas disponible",
        invalidCard: 'Numéro de carte invalide',
        dateInputError: {
          label: 'Ce champ',
          beforeError: '{{label}} doit être antérieure à {{date}}',
          afterError: '{{label}} doit être postérieure à {{date}}'
        }
      }
    },
    page: {
      receipt: {
        title: 'N° de Référence',
        description: 'Veuillez indiquer ce numéro de référence pour toutes les correspondances liées à cette demande.',
        'button.blocked': 'SUIVANT',
        failed: 'Échoué'
      },
      jumpTolabel: 'Aller à la section souhaitée',
      step: 'de',
      top: 'Haut',
      loading: 'Chargement en cours...'
    }
  },
  ServiceRequest: {
    COMMON: {
      addOtherNationality: '+ AJOUTER UNE AUTRE NATIONALITÉ',
      recordNotExist: "'L'enregistrement n'existe pas",
      loadingIndicatorText: 'Chargement...',
      'notes.title': 'REMARQUES',
      'creditcard.title': 'Carte de crédit',
      'debitcards.title': 'Carte de Débit',
      'nocard.header': 'Aucune carte détectée.',
      'nocard.content': "Vous n'avez aucune carte éligible à une mise à jour.",
      'errorcard.header': 'Impossible de récupérer les détails de la carte.',
      'errorcard.content':
        "Veuillez contacter l'équipe des services bancaires téléphonique 24/7 pour une assistance immédiate.",
      'debit.header': 'No debit cards detected.',
      'debit.content': 'You do not have any eligible ATM/Debit Card(s) to be updated.',
      'credit.header': 'No credit cards detected.',
      'credit.content': 'You do not have any eligible Credit Card(s) to be updated.',
      backToHelpAndServicesText: "Êtes-vous sûr de vouloir retourner l'aide et les services?",
      backToiBankText: 'Are you sure you want to return to account overview/homepage?',
      backToiBankBefAckText: 'Are you sure you want to return to account overview/homepage and cancel your request?',
      backToMobileBankText: 'Are you sure you want to return to account overview/homepage?',
      backToMobileBankBefAckText:
        'Are you sure you want to return to account overview/homepage and cancel your request?',
      genericError: {
        MY:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our client care center on 1 300 888 888/ +603 7711 8888 for any assistance',
        AE:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our <a href="javascript:;" onclick="window.open(\'https://www.sc.com/ae/contact-us/\',\'_system\')">24/7 Phone Banking</a> for immediate assistance.',
        KE:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our client care center on 254203293900 for any assistance',
        GH:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
        ZM:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
        BW:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
        NG:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
        IN:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
        default:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.'
      },
      validation: {
        allowedApply_1: 'Veuillez sélectionner ',
        productSelectionValidation:
          ' produit de compte bancaire à la fois. Veuillez visiter à nouveau pour demander un autre produit de compte bancaire.'
      },
      maintanence: {
        title:
          'Nous effectuons actuellement des travaux de maintenance afin d’améliorer la qualité de nos services bancaires mobiles.',
        message:
          'Notre application sera de nouveau fonctionnelle sous peu. Nous nous excusons pour les désagréments causés.',
        button: 'OK'
      },
      systemError:
        'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
      'systemError.AE':
        'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our <a href="javascript:;" onclick="window.open(\'https://www.sc.com/ae/contact-us/\',\'_system\')">24/7 Phone Banking</a> for immediate assistance.',
      breadcrumbHome: 'You are in Home',
      pageTitles: {
        openNewAccount: 'Ouvrir un  Nouveau Compte',
        profileUpdate: 'Mise à Jour du Profil',
        letterRequests: 'Demande de Confirmation',
        chequeBookActivation: 'Activation de carnet de chèque',
        chequeBookStop: 'Opposition Carnet de Chèques',
        confirmCheque: 'Confirmer un chèque',
        newChequeBookRequest: 'Nouvelle demande de chéquier',
        accountClosure: 'Clôture de Compte',
        manageSignatory: 'Ajout de Signataire',
        signataireUpdate: 'Mise à Jour de la Signature',
        sweepTransfer: 'Instruction de Nivellement de Comptes',
        requestStatement: 'Demande de Relevé de Compte',
        fixedDeposit: 'Dépôt à Terme',
        demanDraft: 'Traite bancaire',
        upliftFixed: 'Clôture de Dépôt à Terme',
        debitCardActivationPinset: 'Activer la Carte de Débit et Création de Code PIN',
        debitCardBlockAndReplace: 'Bloquer et Remplacer la Carte de Débit',
        debitCardReplace: 'Remplacer la Carte de Débit',
        debitCardPinRest: 'Réinitialiser le Code PIN',
        communProcess: 'Préférences de communication',
        jointAccountManagement: 'Joint Account Management',
        accountInformation: 'Information du compte',
        visaTransfer: 'Approvisionner mon compte'
      },
      progress: {
        success: 'Réussie',
        failure: 'Échoué',
        steptxt: 'Étapes',
        step12: 'Étapes Un de deux',
        step22: 'Étapes Deux des deux'
      },
      text: {
        selectAll: 'Select All',
        deselectAll: 'Deselect All',
        new: 'New'
      },
      button: {
        cancel: 'ANNULER',
        next: 'NEXT',
        ok: 'OK',
        confirm: 'CONFIRM',
        yes: 'Oui',
        no: 'No',
        done: 'DONE',
        back: 'Retour',
        loadMore: 'LOAD MORE',
        sNext: 'Next',
        sPrev: 'Prev',
        proceed: 'Procéder',
        close: 'CLOSE',
        cancelrequest: 'Cancel Request',
        showAll: 'Show All',
        viewStatus: 'VIEW STATUS',
        accept: 'ACCEPTER',
        iUnderstand: 'JE COMPRENDS'
      },
      subCategoryText: {
        feeWaver: 'Fee Waver',
        cardCancellation: 'Card Cancellation',
        cardBlock: 'Report Lost/Stolen Credit Card',
        debitCardBlockAndReplace: 'Bloquer et remplacer la carte de débit',
        debitCardReplace: 'Remplacer la carte de débit',
        debitCardActivationPinset: 'Activation de la carte de débit et du code PIN',
        debitCardPinRest: 'Réinitialisation du code PIN de la carte de débit',
        chequeRequest: 'Demande de chèque',
        cardReplacement: 'Card Replacement',
        cardActivation: 'Card Activation',
        profileSettings: 'Profile Settings',
        pinChange: 'PIN Setup/Change',
        letterRequest: 'Demande de lettre',
        chequeBookActivation: 'Activation du carnet de chèque',
        chequeStop: 'Arrêt / Blocage du carnet de chèque',
        chequeConfirmation: 'Confirmer un chèque',
        newChequeBook: 'Nouvelle demande de chéquier',
        accountOpening: 'Ouverture de compte',
        demandDraft: 'Demand Darft',
        accountClosure: 'Fermeture du Compte',
        updateFatcaStatus: 'Update FATCA Status',
        cddUpdate: 'Customer Due Diligence',
        kycDocumentRequest: 'KYC Document request',
        newSignAddition: 'Gérer le signataire',
        signChange: 'Mise à jour Signature',
        sweepSetup: 'Sweep Setup ',
        upliftFullFd: 'Uplift Full FD',
        dndRequestRemoval: 'DND Request Removal',
        requestStatement: 'Request Statement',
        fixedDeposit: 'Dépôt fixe',
        jointAccount: 'Joint Account'
      },
      categoryText: {
        creditCard: 'Credit Card',
        debitCard: 'Carte de Débit',
        personalDetails: 'Détails personnels',
        accountManagement: 'Gestion de compte',
        cardManagement: 'Card Management'
      },
      productOpening: {
        selectAccounts: 'Sélectionner un ou plusieurs compte(s) à ouvrir',
        accountInfo1: 'Joint accounts are available upon opening an account.',
        accountInfo2: 'These products are available upon opening a current or savings account.',
        currentAccount: 'Compte Courant',
        currentAccDesc: 'Commodité et simplicité pour vos besoins bancaires',
        currentAccDesc1: 'Guichet automatique gratuit retraits.',
        currentAccDesc2: 'Redevance mensuelle: 12 000 francs CFA (annulé pour la première année)',
        excelAccount: "Compte d'Epargne Plus",
        excelAccDesc: 'Conçu pour maximiser vos intérêts.',
        excelAccDesc1: 'Guichet automatique gratuit retraits.',
        excelAccDesc2: 'Redevance mensuelle: 12 000 francs CFA (annulé pour la première année)',
        otherProducts: 'Autres Produits Offerts',
        fixedDeposit: 'Dépôt à Terme',
        fixedDepoDesc:
          'Placez votre épargne à des taux compétitifs et  sur une plus longue durée sans prendre de risques.',
        select: 'AJOUTER',
        selected: 'AJOUTE',
        learnMore: 'En savoir plus',
        tooltipInfo1: "Les comptes conjoints sont disponibles lors de l'ouverture d'un compte",
        tooltipInfo2: "Ces produits sont disponibles à l'ouverture d'un compte courant ou d'épargne.",
        proceed: 'Continuer',
        open1Account: 'Ouvrir 1 compte',
        open2Account: 'Ouvrir 2 comptes',
        cfaf: 'FCFA',
        free: 'Gratuit',
        initialDeposit: 'Dépôt Initial',
        keyFeature: 'Caractéristiques principales',
        service: 'SERVICE',
        charges: 'FRAIS',
        currentAccountContent: {
          noInitialDeposit: 'Dépôt Initial non requis ',
          cardType: "Carte de débit VISA Gold offerte à tous les clients à l'ouverture du compte",
          minBalance: 'Solde Minimum  non requis',
          maintenFee:
            "Pas de frais de tenue de compte mensuel pour une durée de 12 mois à partir de la date d'ouverture de compte",
          keyFeatures: {
            cfafNon: '(non requis)',
            minBalance: 'Solde Minimum ',
            notRequired: '(non requis)',
            maintenFee: 'Frais de tenue de compte mensuel',
            firstYear: '2 000 FCFA',
            cardIssuance:
              "Frais d'émission de la carte de débit VISA Gold - Retrait d'espèces, Piaments au terminal et en ligne",
            atmCashGim: "Retrait d'espèces  (dans le réseau GIM UEMOA)",
            atmCahsWaemu: "Retrait d'espèces aux guichets automatiques dans la zone UEMOA) (Autres réseaux tels Visa)",
            atmCashOutside: "Retrait d'espèces aux guichets automatiques (en dehors de la zone UEMOA)",
            electronicTransfer: 'Virement électronique vers une autre banque',
            cfafByRTGS: 'FCFA par RTGS',
            locTransfer: 'Virement de compte à compte',
            locTransferOther: 'Virement local autre banque',
            newAmount: 'ACH: 250 FCFA<br/>RTGS: 2000 FCFA',
            transferWameu: "Virement vers un autre pays de l'UEMOA",
            cfafCote: '6 000 FCFA',
            cfafOutside: '6 000 FCFA en dehors de la CI',
            internationalTransfer: 'Transfert International ',
            euro: 'EURO : Commission de transfert : 1,8% min 10 000 FCFA',
            otherCurrency: 'Autres devises : Commission de change : 1% min 10 000 FCFA',
            onlineBA: "Accès à l'Internet Banking",
            mobileBA: "Accès à l'application mobile SC Mobile",
            eStatemtment: 'Relevé Electronique mensuel',
            chequeBook: 'Demande de chéquier barré',
            mtn: "Achat de recharges téléphoniques d'unités MTN",
            mtTn:
              'Transfert de fonds du compte bancaire vers le porte-monnaie électronique Mobile Money (Push and Pull)'
          }
        },
        fixedDepositContent: {
          term: '3 Mois (Durée minimum)',
          VAT: 'Intérêts soumis à la taxe sur les revenus (IRC)',
          investment:
            'Flexibilité et convivialité dans la gestion du Dépôt à terme. Intérêts sur investissements élevés.',
          interestRate:
            'La liquidation anticipée du Dépôt à terme entraîne une réduction de 1.5% sur le taux  initialement convenu sur la durée courue.',
          keyFeatures: {
            attractive: "Taux d'intérêts attractifs",
            minAmount: 'Montant Minimum du dépôt à terme',
            minAmountValue: '2 000 000',
            minTerm: 'Durée Minimum du dépôt à terme',
            initialDeposit: 'Dépôt',
            initialDepositValue: 'A partir de 2 000 000',
            monthsSmall: 'mois',
            months: 'Mois',
            years: 'Années',
            slab1Rate: '3,5% p.a',
            slab2Rate: '3,5% p.a',
            slab3Rate: '3,8% p.a',
            depositRate: 'Taux de Dépôt à terme négociable ',
            dnRate: 'Au-delà de 10 000 000 FCFA consulter votre chargé de compte',
            mip: 'Paiements des intérêts à maturité',
            mnPaid: "Principal et intérêts crédités  au compte courant ou compte d'épargne à l'échéance du dépôt",
            partialFull: 'Liquidation partielle ou totale du dépôt à terme',
            pfBreak:
              'La liquidation anticipée du Dépôt à terme entraîne une réduction de 1,5% sur le taux  initialement convenu sur la durée courue.'
          }
        },
        savingsPlusAccount: {
          minBalance: 'Solde minimum de 10 000 FCFA',
          noInitialDeposit: 'Dépôt Initial non requis',
          interestPaid: 'Intérêts payés mensuellement et soumis à la taxe sur les revenus (IRC)',
          interestRates: 'Taux d’intérêts par paliers allant de 4% à 5%',
          keyFeatures: {
            attractiveInterest: "Taux d'intérêts attractifs comme suit",
            slab1: '0 - 999 999',
            slab1Value: '4,00%',
            slab2: '1 000 000 - 7 499 999',
            slab2Value: '4,75%',
            aboveCFAF: '7 500 000 - 10 000 000 FCFA',
            slab3Value: '5%',
            interestTermPaid: 'Fréquence de paiement des intérêts',
            monthly: 'Mensuel',
            initialDeposit: 'Dépôt Initial',
            notRequired: '(non requis)',
            additionalCharges: 'Frais pour transactions additionnelles',
            additionalDebitTransactions:
              '5000 FCFA par opérations de débit<br/>Retrais d’espéces: Gratuit<br/>Paiements au TPE: Gratuit',
            minBalance: 'Solde Minimum',
            minBalanceAmount: '10 000',
            feesBalanceMin: 'Frais pour solde inférieur au minimum',
            quarterAmount: '2500 FCFA/Trimestre',
            monthlyMaintenanceFee: 'Frais de tenue de compte mensuel',
            visaCardFee: 'Emission de la carte de débit VISA Gold',
            noOfTransactions: 'Nombre d’opérations de débit autorisées',
            months2: '2 par mois',
            atmDebitInsurance: 'Emission de la carte de débit VISA Gold',
            onlineBankaccess: "Accès à l'Internet Banking",
            mobileBankAccess: "Accès à l'application mobile SC Mobile",
            MonthStatement: 'Relevé Electronique',
            atmDebitCash: "Retrait d'espèces  (dans le réseau GIM UEMOA)",
            atmCashWAEMU: "Retrait d'espèces aux guichets automatiques dans la zone UEMOA) (Autres réseaux tels Visa)",
            atmCashOutside: "Retrait d'espèces aux guichets automatiques (en dehors de la zone UEMOA)"
          }
        }
      },
      DISCLAIMER: {
        label: 'Temps approximatif',
        time: '15 minutes',
        information1: 'Avant de commencer, assurez-vous d’avoir les documents suivants à votre disposition:',
        information2:
          'Vos données seront sauvegardées à chaque étape. Vous pouvez donc quitter l’application et reprendre votre demande plus tard sans aucun problème.',
        secureMessage: 'Vous entrez dans un environement sécurisé. Vos données sont protégées par McAfee',
        nationalID: 'Une Carte Nationale D’identité',
        photo: 'Un Selfie, en tenant votre pièce d’identité (Montrant le visage entier)',
        address: 'Un justificatif d’adresse',
        salary: 'Bulletin de salaire',
        uploadSign: 'Insérer une signature (Veuillez signer sur un papier blanc et prendre une photo',
        uploadInfo: 'Certificat de Résidence, Justificatif de domicile, Contrat de Bail',
        existingAccount:
          'If you have an existing account with Standard Chartered, please sign up for an account through our website.',
        letgetstarted: 'Top Départ'
      },
      mostPopularRequests: {
        cardBlock: 'Report Lost/Stolen Credit Card',
        replaceCards: 'Replace Cards',
        debitCardBlockAndReplace: 'Bloquer et remplacer la carte de débit',
        debitCardReplace: 'Remplacer la carte de débit',
        debitCardActivationPinset: 'Activation de la carte de débit et du code PIN',
        debitCardPinRest: 'Réinitialisation du code PIN de la carte de débit',
        chequeBookRequest: 'Cheque Book Request',
        profileUpdate:
          'Mettre à jour mon profil<span id="landing-popular-subtext">Consultez et mettez à jour votre profil avec les derniers détails.</span>',
        letterRequest: 'Demande de lettre',
        chequeBookActivation: 'Activation du carnet de chèque',
        chequeStop: 'Arrêt / Blocage du carnet de chèque',
        chequeConfirmation: 'Confirmer un chèque',
        newChequeBook: 'Nouvelle demande de carnet de chèque',
        accountOpening: 'Ouverture de compte',
        jointAccount: 'Joint Account'
      }
    },
    COMMONERROR: {
      'CSL-1406': 'Date/Time format is invalid',
      'CSL-1344': 'Invalid Transaction Reference Number',
      'CSL-1328': 'Max retry limit reached',
      'CSL-1320': 'Pin Reset Failed',
      'CSL-1318': 'Key not found',
      'CSL-1303': 'Random challenge expired',
      'CSL-1302': 'Random challenge expired',
      'CSL-1304': 'Invalid random challenge',
      'CSL-1252': 'Pin block generation failed',
      'CSL-1225': 'Query failed',
      'CSL-1200': 'Invalid parameters',
      'CSL-1212': 'Encryption/Decryption error',
      'CSL-1211': 'Database/SQL error',
      'CSL-1034': 'Pin Reset Request Timed out',
      'CSL-1032': 'Pin Reset Request failed',
      'CSL-1702': 'EN - This is 1702'
    },
    CARDREPLACEMENT: {
      'header.title': 'Request for Replacement Card',
      cardlistHeader1: 'Select cards to replace',
      cardlistHeader2: 'Your card(s) to be replaced',
      cardlistHeader3: 'Your Replacement Cards',
      cancelPopup: 'Do you want to cancel your Card Replacement request?',
      countryLinks: {
        IN: 'https://www.sc.com/in/help-centre/service-charges-fees.html',
        SG: 'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf',
        HK: 'https://www.sc.com/global/av/hk-service-charges-en.pdf',
        MY: 'https://www.sc.com/my/help-centre/fees-and-charges.html',
        AE: 'https://www.sc.com/ae/help-centre/service-charges.html'
      },
      countryLinksTxt: {
        IN: 'fee schedule',
        SG: 'fee schedule',
        HK: 'fee schedule',
        MY: 'fee schedule',
        AE: 'fee schedule'
      },
      countryNotes: {
        IN:
          "You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>Cards reported lost or stolen are eligible for replacement within 90 days from reported date.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.",
        SG:
          "You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>Cards reported lost or stolen are eligible for replacement within 90 days from reported date.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.<br>If your current card is embedded with token, you will be issued card embedded with token card.<br>All supplementary cards (if any) will be replaced once the primary card is replaced.",
        HK:
          'You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>Cards reported lost or stolen are eligible for replacement within 90 days from reported date.<br>Replacement card will be sent to your registered mailing address. If the selected card for replacement has an outstanding balance, minimum payment must be settled in order to receive the replacement card.<br>If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.<br>All supplementary cards (if any) will be replaced once the primary card is replaced.',
        MY:
          "You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>Cards reported lost or stolen are eligible for replacement within 90 days from reported date.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance.",
        AE:
          "You may use this form to request for replacement for cards that are damaged, or cards that you have already reported as lost or stolen.<br>If you have NOT reported your card as lost/stolen, you may do so by using Report Lost/Stolen service request.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>If you do not see the card you wish to replace in the list above, please contact our 24/7 Phone Banking for assistance."
      },
      statusMsg: {
        success:
          'Your replacement request is submitted.<br>Your replacement request status can be tracked online via Service Request Status Enquiry. Reference # {{refNo}}.',
        failure:
          'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance. Reference # {{refNo}}.',
        incomplete:
          'Some of your cards below did not get processed. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance if the issue persists. Reference # {{refNo}}.'
      }
    },
    CARDBLOCK: {
      'header.title': 'Report Lost/Stolen Credit Card',
      cardlistHeader1: 'Select the card(s) you want to block',
      cardlistHeader2: 'Selected card(s) to be blocked',
      cardlistHeader3: 'Your Replacement Cards',
      cardlistSubHeader:
        'If you do not see the card you wish to block in the list below, please contact our 24/7 Phone Banking immediately.',
      cancelPopup: 'Do you want to cancel your Report Lost/Stolen Credit Card request?',
      selectreason: {
        header: "I'm blocking my card because",
        placeholder: 'Select reason',
        reasonToBlock: 'Reason to Block',
        reason1: 'I have lost my card',
        reason2: 'My card got stolen',
        reason3: 'My card got captured by ATM'
      },
      countryLinks: {
        IN: 'https://www.sc.com/in/help-centre/service-charges-fees.html',
        SG: 'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf',
        HK: 'https://www.sc.com/global/av/hk-service-charges-en.pdf',
        MY: 'https://www.sc.com/my/help-centre/fees-and-charges.html',
        AE: 'https://www.sc.com/ae/help-centre/service-charges.html'
      },
      countryLinksTxt: {
        IN: 'fee schedule',
        SG: 'fee schedule',
        HK: 'fee schedule',
        MY: 'fee schedule',
        AE: 'fee schedule'
      },
      countryNotes: {
        IN:
          "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions made using the card prior to the blocking.",
        SG:
          "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If your current card is embedded with token, you will be issued card embedded with token card.<br>All supplementary cards (if any) will be blocked once the primary card is blocked.",
        HK:
          'Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address. If the selected card for replacement has an outstanding balance, minimum payment must be settled in order to receive the replacement card.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>All supplementary cards (if any) will be blocked once the primary card is blocked.<br>If you do not see the card you wish to report in the list above, please contact our 24/7 Phone Banking for assistance.',
        MY:
          "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If you do not see the card you wish to report in the list above, please contact our 24/7 Phone Banking for assistance.",
        AE:
          "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If you do not see the card you wish to report in the list above, please contact our 24/7 Phone Banking for assistance."
      },
      statusMsg: {
        success:
          'Your card has been blocked and your replacement request is submitted. Your replacement request status can be tracked online via Service Request Status Enquiry. Reference # {{refNo}}.',
        failure:
          'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance. Reference # {{refNo}}.',
        incomplete:
          'Some of your cards below did not get processed. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance if the issue persists. Reference # {{refNo}}.'
      }
    },
    CHEQUEBOOK: {
      'header.title': 'Cheque Book Request',
      accountsList: 'Compte(s)',
      selectAccountList: 'Select Account(s) for Cheque Book',
      countryNotes: {
        IN:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>The cheque book will be dispatched to your mailing address as available in our records and will reach you within 7 working days.</li><li>If you have recently changed your address, please get it updated in our records immediately. Address update in our system will be processed within 4 working days of submitting the address change request.</li><li>You can request for one cheque book for your account in a day. For bulk request, kindly submit a written request at your nearest branch.</li></ol>',
        SG:
          '<ol><li>Only eligible accounts for this request are shown.</li><li>Cheque books will be sent to the account\'s mailing address in our records.</li><li>Please ensure your address with us is up to date before submitting this request. If you have submitted an address change, please note that this takes three working days to update in our system.</li><li>Charges may apply. Please see our <a  href="https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf" target="_blank">fee schedule</a> for more details.</li></ol>',
        MY:
          '<ol><li>Only eligible accounts for this request are shown.</li><li>Cheque books will be sent to the mailing address in our records. Joint account cheque books will be sent to the primary account holder\'s mailing address.</li><li>Please ensure your address with us is up-to-date before submitting this request. If you have submitted an address change,please note that this takes five working days to update in our system.</li><li>Charges may apply. Please see our <a  href="https://www.sc.com/global/av/my-fees-and-charges-27-apr-2017.pdf" target="_blank">fee schedule</a> for more details.</li><li>If you mailing address is a PO Box address,please do not proceed and call our Contact Center for placing this request.</li></ol>',
        HK:
          '<ol><li>Only accounts eligible for this request are shown.</li><li>Cheque book(s) will be sent to your registered mailing address and will reach you within 4 working days.</li></ol>',
        AE:
          '<ol><li>Only accounts eligible for this request are shown.</li><li>Cheque book(s) will be sent to your registered mailing address.</li></ol>',
        default:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>Cheque Book will be sent to your Registered mailing address.</li></ol>'
      },
      statusMsg: {
        success:
          '{{#unless media.isMobile}}Your request has been submitted. <br>{{/unless}}Your cheque book will be sent to the mailing address in our records.',
        failure:
          'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance. Reference #',
        incomplete:
          'Some of your cards below did not get processed. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance if the issue persists. Reference #'
      },
      referenceNumber: 'Reference Number',
      noAccount:
        'There are no eligible Accounts for which Cheque Book Request can be initiated. Please Contact your Relationship Manager or Contact Call Centre or Branch',
      'selectAccount.title': 'Select Details',
      'confirmAccount.title': 'Confirm Details',
      confirmCancelText: 'Do you want to cancel your Cheque Book request?',
      noAccountWarningText: {
        IN:
          'We are unable to process your request as you do not have any eligible accounts for cheque book. Kindly contact our phone banking team or visit our branches for assistance.',
        SG: 'ERR_CHQ_002 - Sorry, you do not have any accounts that are eligible for this request.',
        HK: 'ER_CHQ_002  Sorry, you do not have any accounts that are eligible for this request.'
      }
    },
    STATUSENQUIRY: {
      'header.title': 'Statut',
      'activeSection.title': 'ACTIF',
      'completedSection.title': 'TERMINÉ',
      statusReferenceNo: 'Numéro de dossier ',
      statusUpdatedDate: 'Estimated Completion Date:',
      statusCardReplacement: 'Card Replacement Status:',
      statusCardReplacementM: 'Replacement Status:',
      statusUpdateDateMobile: 'Est. Completion:',
      noActiveRequest: "Il n'y a pas de demandes actives",
      statusOfRecords: 'Cette page affiche uniquement les demandes des 90 derniers jours',
      labelReceive: 'Reçu',
      labelProcessing: 'Traitement en cours',
      labelCompleted: 'Effectué',
      labelRejected: 'REJETÉ',
      labelSuccess: 'SUCCÈS',
      labelFailed: 'ÉCHOUÉ',
      updatedDate: 'Mis à jour le',
      dateSubmitted: 'Date de soumission',
      'account/relationshipNo': 'Compte(s)',
      creditCard: 'Cartes de crédit bloquées',
      debitCard: 'Cartes de débit bloquées',
      referral: 'Action requise',
      resume: 'Reprendre',
      verification: 'Verification',
      activation: 'Activation',
      pending: 'En attente',
      agentTitle: 'Commencez la vérification avec notre agent',
      agentDescription:
        'Une authentification par notre agent est requise pour  finaliser votre demande d’ouverture de compte ',
      accountDetails: 'Détails d’ouverture du compte',
      accountActivation: 'Account Activation'
    },
    LANDINGPAGE: {
      tabText: {
        createRequest: 'Faire une demande',
        status: 'Statut'
      },
      'header.title': 'Aide & Services',
      noResultsFound: 'No results found',
      needHelp: "Besoin d'assistance",
      regardsTo: 'En ce qui concerne',
      popularServices: 'Most popular service requests',
      popularServicesCI: 'Demande de Service',
      allServicesCategory: 'Rubriques',
      'help&usefulLinks': 'Aide et Liens Utiles',
      search: 'Chercher...'
    },
    STATEMENTREQUEST: {
      'header.title': 'Statement Request',
      'selectAccount.title': 'Select an Account ',
      'account.title.text': 'Select an account to request for a hardcopy statement',
      'date.selection.label': 'Select Source Date',
      'casa.title.text': 'Current/Savings Account',
      'creditcard.title.text': 'Credit Card',
      notes:
        "Fee may be apply depending on the statement requested. Please check Bank's <a>fee schedule</a> for more information.<br> <br>Your statement will be sent to your registered mailing address. Please ensure your address is correct. Contact <a>24/7 Phone Banking</a> if you wish to update your address.",
      'confirm.title.text': 'Confirm Details',
      'account.label': 'Account Number',
      'statement.label': 'Statement Option',
      'statement.date.label': 'Statement Date',
      'statusMsg.success':
        'Your request has been submitted. You can track your statement status online via Service Request Status Enquiry.',
      referenceNumber: 'Reference Number',
      'account.type': 'Account Type',
      'statement.date': 'Statement Date',
      'cc.title.text': 'Credit Card'
    },
    TRACKRESUME: {
      trackResume: 'Suivre/proursuivre votre demande',
      iWantTo: 'Je souhaite',
      trackMyApplication: 'Vérifier  l’état de ma demande',
      resumeApplication: 'Poursuivre ma demande d’ouverture de compte',
      helpUsIdentify: 'Aidez-nous à vous identifier',
      mobileNumberLable: 'Le numéro de contact ne doit pas dépasser 15 chiffres (y compris le code du pays)',
      mobileNumberError: 'Téléphone Mobile est requis',
      mobileNumber: 'Téléphone Mobile'
    },
    CREDITCARD: {
      cardSetting: {
        journeyHeader: 'Paramètres de carte de crédit',

        selectPage: {
          pageHeader: 'Sélectionnez une carte de crédit',
          sectionHeader: 'SÉLECTIONNER UNE CARTE DE CRÉDIT POUR RÉGLER LES PARAMÈTRES',
          sectionHeaderMob: 'Sélectionnez une carte de crédit pour définir les paramètres'
        },
        isPrimary: {
          primary: 'Carte principale',
          supplementary: 'Carte subsidiaire'
        }
      },
      pinSetup: {
        journeyHeader: 'Credit Card PIN Setup/Change',

        selectPage: {
          pageHeader: 'Select a Credit Card',
          sectionHeader: 'SELECT A CREDIT CARD TO SETUP A PIN'
        },
        pinChange: {
          pageHeader: 'Set Credit Card PIN',
          sectionHeader: 'SET YOUR NEW CREDIT CARD PIN',
          newPin: 'Enter your new credit card pin',
          reEnterPin: 'Re-enter your pin',
          newPinMob: 'Enter New PIN',
          reEnterPinMob: 'Re-Enter PIN',
          pinNotSame: 'Entered PIN numbers are not same',
          enterValidPin: 'Please enter valid PIN',
          pinNotAsGuideline: 'Invalid PIN, please enter PIN as per the guidelines'
        },
        countryNotes: {
          IN:
            "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions made using the card prior to the blocking.",
          SG:
            "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If your current card is embedded with token, you will be issued card embedded with token card.<br>All supplementary cards (if any) will be blocked once the primary card is blocked.",
          HK:
            'Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Blocking the card does not cancel the account. You will be liable for any transactions made using the card prior to the blocking. Please call Standard Chartered Credit Card Hotline (852) 2886 4111 for dispute transaction inquiry.<br>All supplementary cards (if any) will be blocked once the primary card is blocked.<br>If you do not see the card you wish to report in the list above, please contact Standard Chartered Credit Card Hotline (852) 2886 4111 for assistance.',
          MY:
            "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If you do not see the card you wish to report in the list above, please contact our 24/7 Phone Banking for assistance.",
          AE:
            "Upon confirmation, your card will be blocked immediately.<br>You will not be able to use your card once it is blocked.<br>Blocked card cannot be activated again.<br>Replacement card will be sent to your registered mailing address.<br>Fee depending on card type may be applicable for replacement. Please check Bank's {{inter_link}} for more information.<br>Blocking the card does not cancel the account. You will be liable for any transactions  made using the card prior to the blocking.<br>If you do not see the card you wish to report in the list above, please contact our 24/7 Phone Banking for assistance."
        },
        status: {
          refNo: 'REFERENCE NUMBER',
          refNoSmall: 'Reference No.',
          cardDetails: 'CARD DETAILS',
          success: 'Success',
          transactionSuccessMsg: 'You have successfully reset your Credit Card PIN.',
          transactionSuccessFailure:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
          transactionSuccessInComplete:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.'
        }
      }
    },
    JOINTACCOUNT: {
      moreDetails: 'More Details',
      dateJoined: 'Date Joined',
      fullName: 'Full Name',
      firstName: 'Prénom',
      lastName: 'Nom',
      emailAddress: 'Adresse Email',
      mobileNumber: 'Téléphone Mobile',
      primaryAccountTitle: 'Primary Account Holders',
      existingAccountTitle: 'Existing Account Holders',
      primaryAccount: 'Primary Account Holder',
      secondaryAccount: 'Secondary Account Holder',
      newSecondaryAccount: 'New Secondary Account Holder',
      pendingAccountTitle: 'New / Pending Account Holders',
      addNewAccountHolder: 'Add New Account Holder',
      error: {
        alphabetsOnly: 'Seuls les alphabets sont valides',
        invalidEmail: "L'adresse électronique invalide",
        mobileFormat: 'Le format devrait être CCCaaaRRRRRRRR'
      },
      modal: {
        message: {
          reject:
            'Are you sure you want to reject adding Secondary Account Holder into the Join Account? The request application will be cancelled.',
          approve: 'Are you sure you want to provide approval for Secondary Account Holder to join the Join Account.',
          decline: 'Are you sure you want to decline the invitation? The join account application will be cancelled.'
        }
      }
    }
  },
  rdcComponent: {
    selectAll: 'Tout Sélectionner',
    deselectAll: 'Tout Déselectionner'
  },
  rdcPinreset: {
    pinLabel: 'Entrez un nouveau code PIN',
    rePinLabel: 'Ré-entrer le code PIN',
    error: {
      invalid: 'Entrez un code PIN valide à 4 chiffres',
      mismatch: 'Le code PIN et le code PIN ré-entrer incompatibles'
    }
  },
  emailVerify: {
    emailLabel: 'Adresse e-mail',
    reEmailLabel: 'Ressaisir votre adresse Email',
    error: {
      invalid: 'Entrez un Email valide',
      mismatch: 'Email et ressaisir votre adresse Email sont Incompatibilite'
    }
  },
  multiNationality: {
    addNationality: '+ Ajouter d’autres nationalités',
    fieldLabel1: 'Deuxième nationalité',
    fieldLabel2: 'Troisième nationalité',
    error: 'Les autres nationalités ne peuvent être similaires aux nationalités précédemment sélectionnées'
  },
  appSummary: {
    currentAccount: 'Compte Courant',
    excelAccount: "Compte d'Epargne Plus",
    applyingFor: 'Vous faites une demande pour',
    applicationId: 'Application ID',
    applicationSaved: 'Demande sauvegardée',
    refNo: 'N° de Référence.'
  },
  errors: {
    unknownError: "Une erreur inconnue s'est produite. Essayez s'il vous plaît de nouveau.",
    serviceUnavailable: 'Ce service est actuellement indisponible, veuillez réessayer plus tard.'
  },
  generalDeclaration: {
    title: 'Déclaration générale',
    declaration:
      "<div class='modal-terms-condition'><h3>En acceptant cette demande :</h3><ol><li>vous déclarez et garantissez que tous les renseignements (y compris les documents) que vous nous avez fournis dans le cadre de la demande sont exacts, complets et non-fallacieux. (Si ce n'est pas le cas, vous pourriez en être tenu personnellement responsable);</li><li>vous nous autorisez à vérifier tous les renseignements que vous nous avez donnés ou votre solvabilité auprès de toute personne que nous jugerons appropriée (soit une autorité ou une agence de référence de crédit);</li><li>vous reconnaissez que nous pouvons rejeter votre demande sans avoir à nous justifier. Si cela se produit, aucune relation contractuelle n'est créée entre vous et nous;</li><li>vous confirmez et acceptez que nous pouvons fournir toute information relative à la présente demande (y compris vos renseignements personnels) à tout prestataire de services (qu'il soit situé en Côte d'Ivoire ou à l'extérieur de la Côte d'Ivoire) dans le but de vous fournir tout service en rapport avec cette demande (y compris le traitement de données);</li><li>vous déclarez avoir lu et compris nos Conditions générales applicables à la Clientèle, aux produits, les Conditions en ligne - ainsi que les documents applicables mentionnés dans la section A de nos Conditions générales  applicables à la Clientèle  ainsi que les Conditions générales contenues dans notre application mobile constituant notre Accord bancaire.. Vous reconnaissez que vous êtes lié par toute modification que nous apporterons à ces documents, conformément à notre convention bancaire. En particulier, vous comprenez qu'en signant notre convention bancaire, vous nous accordez des indemnités, des autorisations, des consentements et des renonciations et acceptez  que notre responsabilité soit restreinte dans certains cas.;</li><li><p>    vous consentez à ce que nous vous contactions aux adresses, adresses électroniques et numéros de téléphone que vous nous avez communiqués, pour vous fournir des informations sur d'autres produits et services offerts par nous, ou par nos partenaires stratégiques;  </p>  <p>    Le cas échéant, vous convenez que nous vous enverrons des relevés électroniques pour vos comptes bancaires mensuellement par courriel aux adresses que vous nous avez communiquées.  </p></li><li>vous consentez à ce que nous et chacune de nos filiales et sociétés affiliées (y compris chaque succursale ou bureau de représentation) ('Standard Chartered Group'), ses dirigeants, employés, agents et conseillers divulguent des renseignements vous concernant (y compris au sujet de notre convention bancaire, des comptes, des produits ou de tout autre arrangement avec nous) à notre siège social et à tout autre membre du Groupe Standard Chartered dans toute juridiction ('Parties autorisées'); aux  conseillers professionnels de votre employeur, aux prestataires de services (qu'ils soient situés en Côte d'Ivoire ou à l'extérieur de la Côte d'Ivoire) afin de vous fournir tout service en rapport avec votre  demande (y compris le traitement de données), ou aux  entrepreneurs indépendants ou les représentants des Parties autorisées, notamment les agences de recouvrement de créances, les sociétés de traitement de données et les correspondants qui sont soumis à une obligation de confidentialité envers les Parties autorisées, tout participant ou sous-participant réel ou potentiel à l'une de nos obligations en vertu de la convention bancaire entre nous, ou tout cessionnaire ou ayant-droit (ou tout dirigeant, employé, représentant ou conseiller de l'un d'entre eux), toute agence de référence de crédit, agence de notation, partenaire d'alliance commerciale, assureur ou courtier d'assurance, ou fournisseur direct ou indirect de protection de crédit, ou toute Partie autorisée; tout tribunal ou autorité (y compris toute autorité chargée d'enquêter sur une infraction) ayant compétence sur les Parties autorisées; un marchand ou un membre de VISA International ou de Mastercard International lorsque la divulgation est liée à l'utilisation d'une carte; toute personne autorisée ou tout fournisseur de services sécurité; toute personne que nous jugerons aptes à vous fournir les services liés à un compte;</li><li>vous acceptez  d’être inscrits à un ensemble de services d'alertes par SMS, qui seront envoyés au numéro que vous aurez communiqué à la Banque.</li><li><p>    pour les besoins de votre demande de carte de crédit, de prêt personnel ou demande de financement - le cas échéant - (y compris tout prêt à tempérament personnel, prêt personnel renouvelable et marge de crédit personnelle ou découvert) ou demande de prêt logement, demande de financement immobilier ou demande de prêt automobile / demande de financement automobile, vous confirmez que :  </p>  <ol type='a'>    <li>aucune de vos cartes de crédit existantes et/ou prêt/financement non garanti n'a été annulé en raison d'un défaut de paiement,</li><li>vous n'avez aucun retard de paiement de plus d'un mois sur les prêts, financements ou cartes de crédit dont vous disposez avec d'autres institutions financières,</li><li>vous n'êtes pas et n'avez jamais été en faillite et vous n'avez pas l'intention de faire, ou n'êtes pas actuellement engagé dans une procédure  de  faillite.    </li>  </ol></li><li>vous reconnaissez que les polices d'assurance qui accompagnent certains produits sont souscrits  auprès d’ assureurs tiers. Ces assureurs ne sont ni des associés ou des filiales du Groupe Standard Chartered, ni des sociétés apparentées audit groupe. Ces assureurs sont les seuls responsables de l'ensemble de la couverture et de l'indemnisation au titre de ces régimes. Nous recueillons vos renseignements et les envoyons à ces assureurs pour traitement. La collecte de renseignements ne signifie pas nécessairement que votre demande de souscription à une assurance sera approuvée.</li><li>vous comprenez et convenez que la banque a le droit (sur préavis) de modifier ou de retirer les récompenses susceptibles d'accompagner les produits groupés que vous avez demandés. En particulier, si vous n'utilisez aucun des produits groupés que vous avez demandés, la Banque peut, sur préavis, retirer les récompenses qui accompagnent ces produits.</li><li><span>Uniquement pour les comptes conjoints : </span>  <ol type='a'>    <li>en acceptant la présente déclaration, vous acceptez et convenez que le principal titulaire du compte peut, à sa discrétion absolue, gérer le compte de la manière qu'il juge appropriée. Cette discrétion absolue comprend, sans restriction, la demande de n'importe quel produit et dans toute limite (sous réserve de l'approbation de la banque). Pour des informations additionnelles, veuillez vous référer aux documents constituant notre accord.</li><li>tous les relevés et avis, y compris les avis juridiques, seront envoyés au principal titulaire du compte, et la banque n'est pas tenue d'en informer chacun des cotitulaires. Le principal titulaire du compte et les invités pourraient être tenus responsables si le principal titulaire du compte n'agit pas promptement lorsqu'il reçoit des informations qui pourraient nécessiter une action de sa part; </li><li>si le compte est un compte courant, le principal titulaire du compte et les invités comprennent par les présentes que ce compte pourrait être associé à l'émission d'un chéquier, et le principal titulaire du compte et les invités sont conscients des risques qui y sont associés, notamment les conséquences juridiques et réglementaires applicables en cas d'émission de chèque sans provision;</li><li>Le principal titulaire du compte et les invités conviennent et comprennent par les présentes que leurs obligations et responsabilités envers la banque sont conjointes et impliquent tous les cotitulaires du compte; et</li><li>Si vous êtes le principal titulaire du compte, vous nous autorisez par les présentes à communiquer une partie ou la totalité de vos renseignements aux invités. Les informations que la banque pourrait partager, par quelque moyen que ce soit, sont, entre autres, votre nom, la date de la demande d'invitation, la date d'ouverture du compte, le nombre de personnes déjà co-titulaires et leurs noms, le numéro du compte conjoint, le solde courant et la devise, l'adresse électronique et le numéro de téléphone portable de chacun des titulaires de compte, s'il y ait des dettes sur le compte ou sur vous personnellement. Pour éviter tout équivoque, vous reconnaissez et comprenez que la banque a le droit de partager les informations mentionnées ci-dessus à tout moment et par tout moyen, jusqu'à ce que vous annuliez l'invitation ou qu'elle soit rejetée par l'invité;</li><li>Si vous êtes le cotitulaire du compte (bénéficiaire/invité), vous autorisez la banque à partager une partie ou l'ensemble de vos renseignements avec d'autres invités actuels ou futurs (qui pourraient être envoyés par n'importe quel membre des parties au compte, y compris le principal titulaire du compte) []. Les informations que la banque pourrait partager, par quelque moyen que ce soit, sont, entre autres, votre nom, la date de la demande d'invitation, la date d'ouverture du compte, le nombre de personnes déjà co-titulaires et leurs noms, le numéro du compte conjoint, le solde courant et la devise, l'adresse électronique et le numéro de téléphone portable de chacun des titulaires de compte, s'il y ait des dettes sur le compte ou sur vous personnellement. Pour éviter tout équivoque, vous reconnaissez et comprenez que la banque a le droit de partager les informations mentionnées ci-dessus à tout moment et par tout moyen, jusqu'à ce que vous annuliez l'invitation ou qu'elle soit rejetée par l'invité;    </li>  </ol></li><li>Sous réserve des lois locales en vigueur, vous consentez par les présentes à ce que Standard Chartered ou l'une de ses sociétés affiliées (collectivement appelées la Banque) partage vos renseignements avec les organismes de réglementation ou les autorités fiscales nationales et étrangères, au besoin, afin d'établir votre assujettissement à l'impôt dans toute juridiction.</li><li>A la demande des autorités de réglementation ou des autorités fiscales nationales ou étrangères,  vous  consentez  et  acceptez que la Banque puisse retenir sur votre (vos) compte(s) les montants requis conformément aux lois, règlements et directives en vigueur.</li><li>Vous  vous   engagez à aviser la Banque dans un délai de 30 jours francs en cas de modification dans les renseignements que vous avez   fournis à la Banque.</li></ol></div>"
  },
  productSummary: {
    button: {
      backToHomePage: "Retour à la page d'accueil"
    },
    isNonResident:
      "<div class='fallback-heading'>Merci de contacter l’agence la plus proche car nous ne sommes pas en mesure de traiter votre dossier via le canal digital.</div><br/>",
    sanctionCountry:
      "<div class='fallback-heading'>Nous sommes désolés que votre dossier ait été rejeté car il ne respecte pas nos critères de banque établis.</div><br/>",
    isETB:
      "<div class='fallback-heading'>Vous êtes déjà client. Veuillez-vous connecter avec vos identifiants.</div><br/>",
    isETBCSLDedupeMatch:
      "<div class='fallback-heading'>Vous êtes déjà client. Veuillez-vous connecter avec vos identifiants.</div><br/>",
    isPurposeOfAccBusiness:
      "<div class='fallback-heading'>Le produit que vous avez sélectionné est réservé uniquement  pour votre usage personnel. Pour l’ouverture d’un compte à  but  commercial  ou pour des professions libérales, prière de contacter notre  agence principale sise au Plateau.</div><br/>"
  }
};
