/* eslint-disable no-useless-escape */

export default {
  FERE: {
    action: {
      modal: {
        message: 'Quý khách xác nhận muốn hủy mẫu đơn và không tiếp tục?',
        resetMessage: 'Quý khách xác nhận muốn hủy thay đổi?',
        quitApp: {
          title: 'Hủy đăng ký?',
          messageEmailSms: 'Đường dẫn đến bước đăng ký tiếp theo của Quý khách sẽ được gửi qua email và tin nhắn SMS.',
          messageProgressLost: 'Thông tin đã nhập của Quý khách sẽ bị hủy.'
        }
      },
      button: {
        confirm: 'XÁC NHẬN',
        cancel: 'HỦY',
        YES: 'ĐỒNG Ý',
        NO: 'KHÔNG',
        edit: 'Chỉnh sửa',
        reset: 'NHẬP LẠI',
        save: 'LƯU',
        close: 'ĐÓNG'
      }
    },
    validation: {
      error: {
        labelNameError: 'phải nhỏ hơn số dư tài khoản',
        message: ' (Bắt buộc)',
        prefixMessage: ' Vui lòng nhập ',
        dateExpired: 'Ngày đã quá hạn',
        dateInvalid: 'Ngày không hợp lệ/Định dạng ngày không đúng',
        dateFuture: 'Ngày trong tương lai không hợp lệ',
        invalidCard: 'Số thẻ không hợp lệ.',
        invalidEmiratesId: 'Your Emirates ID Number is invalid',
        invalidResidentialCountry: 'Vui lòng chọn quốc gia cư trú hợp lệ',
        invalidGender: 'Please select a valid title, this does not match your earlier selected gender.'
      }
    },
    page: {
      receipt: {
        title: 'Số tham chiếu',
        description: 'Vui lòng lưu mã tham chiếu này để xử lý các yêu cầu trong tương lai.',
        'button.blocked': 'TIẾP TỤC',
        failed: 'Không thành công!'
      },
      jumpTolabel: 'Đi đến mục',
      step: 'of',
      top: 'TOP',
      loading: 'Đang truy xuất...',
      fileUploadInfoText: 'Định dạng tệp phải là JPG, PNG hoặc PDF. Dung lượng của tệp không vượt quá 10MB.',
      of: 'trên'
    }
  },
  modalMessages: {
    commonError: 'Yêu cầu của Quý khách không xử lý được lúc này. Vui lòng thử lại sau.',
    idleSessionTitle: 'Phiên giao dịch của Quý Khách sắp kết thúc',
    idleSessionMessage: 'Chọn OK để tiếp tục. Chọn ĐĂNG XUẤT để quay trở lại trang đăng nhập'
  },
  rdcOtp: {
    resendOtpEnableTime: '30',
    heading: 'Tin nhắn OTP đã được gửi đến số điện thoại đăng ký của Quý khách',
    title: 'Nhập OTP',
    resendRetryText:
      'Vui lòng ấn vào “Yêu cầu OTP mới” để nhận lại OTP nếu Quý khách không nhận được OTP trong 30 giây.',
    resendExceedLimitText: 'Nếu Quý khách vẫn chưa nhận được mã OTP, vui lòng thử lại lần nữa.',
    button: {
      resend: 'Yêu cầu OTP mới',
      back: 'Quay lại',
      next: 'Trang sau',
      submit: 'GỬI'
    },
    messages: {
      your_account_locked:
        'Giao dịch đã bị hủy do Quý khách đã nhập sai OTP quá số lần cho phép. Quý khách có thể  thử lại lần nữa sau 24h tới.',
      otp_is_invalid: 'Quý khách đã nhập sai OTP. Vui lòng kiểm tra và nhập lại.',
      otp_is_expired: 'Mã OTP đã quá hạn. Vui lòng yêu cầu mã OTP mới.'
    },
    requestCountdown: 'Yêu cầu mã OTP mới sau <span> {{remainingTime}} </span> giây'
  },
  ServiceRequest: {
    COMMON: {
      loadingIndicatorText: 'Đang truy xuất...',
      'notes.title': 'Lưu ý',
      'creditcard.title': 'THẺ TÍN DỤNG',
      'debitcards.title': 'THẺ GHI NỢ',
      'productlist.title': 'Select one or more accounts to open',
      'nocard.header': 'Không tìm thấy thẻ hợp lệ nào',
      'nocard.content': 'Rất tiếc Quý khách không có Thẻ hợp lệ nào cho yêu cầu này.',
      'errorcard.header': 'Không thể truy xuất thông tin thẻ.',
      'errorcard.content.VN': 'Vui lòng liên hệ Trung tâm Tư vấn Khách hàng 24/7 để nhận hỗ trợ.',
      'debit.header': 'Không tìm thấy thẻ Ghi nợ hợp lệ nào.',
      'debit.content': 'Rất tiếc Quý khách không có thẻ Ghi nợ/ATM hợp lệ nào cho yêu cầu này.',
      'credit.header': 'No credit cards detected.',
      'credit.content': 'Quý khách không có Thẻ Tín dụng hợp lệ nào để cập nhật.',
      backToHelpAndServicesText: 'Quý khách muốn quay lại trang Hỗ trợ & Dịch vụ?',
      backToiBankText: 'Quý khách muốn quay trở lại trang chủ?',
      backToiBankBefAckText: 'Quý khách muốn quay trở lại trang chủ và huỷ yêu cầu?',
      backToMobileBankText: 'Quý khách muốn quay trở lại trang chủ?',
      backToMobileBankBefAckText: 'Quý khách muốn quay trở lại trang chủ và huỷ yêu cầu?',
      genericError: {
        VN:
          'Hệ thống đang gặp sự cố trong lúc tiến hành yêu cầu của Quý khách. Vui lòng hủy yêu cầu này và thử lại sau. Nếu tiếp tục gặp lỗi trong những lần sau, vui lòng liên hê với Trung tâm Tư vấn Khách hàng (24/7) qua số +84 28 3911 0000 hoặc +84 24 3696 0000 để được hỗ trợ ngay.',
        default:
          'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.'
      },
      popup: {
        title: 'Do you want to update your contact details?',
        message:
          'Your current progress will be lost. You will need to submit a new request after updating your details.'
      },
      recordNotExist: 'Record does not exist',
      systemError:
        'Hệ thống đang gặp sự cố trong lúc tiến hành yêu cầu của Quý khách. Vui lòng hủy yêu cầu này và thử lại sau. Nếu tiếp tục gặp lỗi trong những lần sau, vui lòng liên hê với Trung tâm Tư vấn Khách hàng (24/7) qua số +84 28 3911 0000 hoặc +84 24 3696 0000 để được hỗ trợ ngay.',
      'systemError.title': 'Lỗi Hệ thống',
      termsAndConditions:
        '<ol><li>Các điều khoản và điều kiện (“Điều khoản”) áp dụng cho dịch vụ Tùy chỉnh tính năng Thẻ được cung cấp bởi Ngân hàng TNHH Một Thành Viên Standard Chartered Việt Nam (“Ngân hàng” hoặc “chúng tôi” hoặc “Standard Chartered”).</li><li>Dịch vụ Tùy chỉnh tính năng Thẻ là một phần của dịch vụ <i>Ngân hàng điện tử</i> do Ngân hàng cung cấp, và do đó:<ol><li>Các điều khoản sẽ bổ sung và được đọc cùng với Điều khoản và Điều kiện Chung, thông báo bảo mật được đăng tải trên website của chúng tôi hay bất cứ tài liệu nào khác tạo thành thoả thuận ngân hàng (và mọi tham chiếu đến Điều khoản và Điều kiện Chung sẽ bao gồm cả tham chiếu tới các Điều khoản này).</li><li>Ý nghĩa của các từ khóa được in <i>như thế này</i> được giải thích trong Điều khoản và Điều kiện Chung trừ khi được định nghĩa trong các Điều khoản này. Điều khoản và Điều kiện Chung có thể được tham khảo trên trang web chính thức của Ngân hàng.</li><li>Trong trường hợp xảy ra bất kỳ mâu thuẫn nào, các Điều khoản này sẽ được ưu tiên áp dụng so với Điều khoản và Điều kiện Chung trong phạm vi các mâu thuẫn đó.</li></ol></li><li>Dịch vụ Tùy chỉnh tính năng Thẻ cho phép Quý khách hoặc <i>một người được ủy quyền hợp lệ</i> sử dụng các tùy chỉnh sau trên Thẻ tín dụng của Quý khách:<ol><li>Khóa/Chặn thẻ tạm thời</li><li>Gửi thông báo hoặc từ chối các giao dịch qua Thẻ ở nước ngoài</li><li>Tùy chỉnh hạn mức giao dịch</li><li>Quản lý các kênh giao dịch/ thanh toán</li><li>Thông báo về các loại giao dịch</li></ol></li><li style="list-style-type:none;">Lưu ý những điểm sau đây:<ol><li>Mục a (Khóa/chặn Thẻ tạm thời) không áp dụng/không có hiệu lực cho các các giao dịch định kỳ;</li><li>Mục b (Gửi thông báo hoặc từ chối các giao dịch qua Thẻ ở nước ngoài) chỉ áp dụng/có hiệu lực với các giao dịch thẻ trực tiếp tại nước ngoài. Khi sử dụng tính năng này, Quý khách vẫn có thể sử dụng Thẻ cho các <i>giao dịch trực tuyến</i> ở bất cứ đâu dù đó là giao dịch nội địa hay quốc tế;</li><li>Hạn mức được thiết lập ở mục c (Tùy chỉnh hạn mức giao dịch) được dựa trên đơn vị tiền tệ của quốc gia nơi thẻ được phát hành; lưu ý rằng các giao dịch nước ngoài hoặc các giao dịch không thuộc giao dịch nội địa vẫn áp dụng cùng tỷ giá hối đoái với tỷ giá dùng cho việc chuyển đổi tiền tệ trên thẻ;</li><li>Quý khách có thể thiết lập một hay kết hợp nhiều loại kênh giao dịch/kênh thanh toán trong mục d (Quản lý các kênh giao dịch/ thanh toán);</li><li>Mục e (Thông báo về các loại giao dịch) khi được kích hoạt sẽ cung cấp các thông báo tới Quý khách khi có các giao dịch với các loại nhà cung cấp như Quý khách đã chọn, nhưng không chặn các giao dịch nói trên.</li></ol></li><li style="list-style-type:none;">Xin lưu ý rằng <i>Dịch vụ Tùy chỉnh tính năng Thẻ</i> (Bao gồm tất cả các tùy chỉnh từ a đến e như trên) không áp dụng hoặc có hiệu lực với các loại giao dịch trên thẻ sau:<ol><li>Các giao dịch mà Quý khách, người dùng hợp lệ hoặc thương nhân sử dụng một đơn vị chuyển mạch thẻ khác ngoài Visa hay Mastercard;</li><li>Các giao dịch được thực hiện tại các máy ATM của Standard Chartered;</li><li>Các giao dịch chuyển tiền sử dụng <i>Ngân hàng trực tuyến</i> hoặc <i>Ngân hàng di dộng</i> từ thẻ của Quý khách sang các tài khoản ngân hàng khác tại Standard Chartered;</li><li>Các giao dịch qua thẻ tại điểm bán của nhà cung cấp nơi sử dụng mạng lưới thanh toán riêng (thông qua tổ chức thanh toán thẻ, bao gồm giải pháp dành cho điểm chấp nhận thẻ của First Data hoặc sử dụng đầu số thẻ thông qua một thỏa thuận tài trợ), tại quốc gia nơi thẻ của Quý khách được phát hành; và</li><li>Bất kỳ loại giao dịch nào khác mà chúng tôi sẽ thông báo cho Quý khách</li></ol></li></ol><ol start="4"><li>Bằng việc sử dụng Dịch vụ Tùy chỉnh tính năng Thẻ, Quý khách chấp nhận và đồng ý rằng:<ol><li>Chúng tôi có thể sẽ gửi các thông báo điện tử bao gồm điện thư, thư điện tử, chức năng nhận thông báo, hoặc tin nhắn điện thoại trong trường hợp một giao dịch qua thẻ kích hoạt các tính năng mà bạn đã thiết lập thông qua <i>Dịch vụ Tùy chỉnh tính năng thẻ</i>; Trong trường hợp bạn đã đăng ký để sử dụng Dịch vụ Hộp thư Thông báo, chúng tôi có thể sẽ gửi cho bạn những thông báo nói trên thông qua dịch vụ <i>Hộp thư Thông báo của SC</i> (sử dụng Chức năng nhận thông báo) như một kênh giao tiếp chính trong các phương thức điện tử hay bất kỳ hình thức nào khác mà chúng tôi lưa chọn;</li><li>Quý khách chấp thuận việc sử dụng và tiết lộ thông tin Thẻ (Bao gồm cả số thẻ) và những tùy chỉnh cụ thể do Quý khách thiết lập thông qua <i>Dịch vụ Tùy chỉnh tính năng Thẻ</i> tới các hiệp hội Thẻ liên quan nhằm hỗ trợ Ngân Hàng cung cấp <i>Dịch vụ Tùy chỉnh tính năng Thẻ</i>;</li><li>Các tùy chỉnh cụ thể đã được thiết lập thông qua <i>Dịch vụ Tùy chỉnh tính năng Thẻ</i> không vượt quá bất cứ hạn mức nào được quy định bởi các hiệp hội Thẻ có liên quan hoặc bởi Ngân Hàng và thẻ của Quý khách vẫn chịu sự điều chỉnh của các hạn mức nói trên.</li><li><i>Dịch vụ Tùy chỉnh tính năng thẻ</i> là công cụ giúp Quý khách có thể kiểm soát hoàn toàn việc sử dụng thẻ của mình và chống lại nguy cơ gian lận. Quý khách hiểu rằng có khả năng những thông tin về loại nhà cung cấp hoặc về loại kênh thanh toán/ giao dịch có thể đã/sẽ được cung cấp/ lựa chọn bởi các nhà cung cấp hoặc nơi cung cấp máy thanh toán thẻ không chính xác và không tuân theo với các yêu cầu hoặc luật lệ, và dẫn đến các tùy chỉnh không như ý hoặc không hiệu quả khi Quý khách thiết lập các tùy chỉnh mục 3d (Quản lý loại kênh giao dịch/ thanh toán) hoặc 3e (Thông báo về loại nhà cung cấp) thông qua <i>dịch vụ Tùy chỉnh tính năng Thẻ</i>.</li></ol></li><li>Quý khách có thể truy cập <i>dịch vụ Tùy chỉnh tính năng Thẻ</i> để thay đổi hoặc đặt lại các tùy chỉnh vào bất kỳ lúc nào. Để thay đổi bất kỳ tùy chỉnh nào, Quý khách cần đăng nhập vào <i>Ứng dụng Ngân hàng di động hoặc Ngân hàng trực tuyến</i> và thực hiện các bước xác thực bảo mật.</li><li>Nếu Quý khách thông báo cho chúng tôi về vấn đề bảo mật của thiết bị điện tử hoặc mã bảo mật đã bị tiết lộ hoặc thiết bị điện tử dùng để truy cập vào bất kỳ dịch vụ ngân hàng trực tuyến bị mất, chúng tôi có thể yêu cầu Quý khách thay đổi <i>mã bảo mật</i>, hoặc ngừng sử dụng <i>Dịch vụ Tùy chỉnh tính năng Thẻ</i>.</li><li>Quý khách có trách nhiệm với:<ol><li>Mã bảo mật sử dụng để truy cập <i>Dịch vụ Tùy chỉnh tính năng Thẻ; và</i></li><li>Sự bảo mật của thiết bị di động của Quý khách.</li></ol></li><li>Ngoài các miễn trách và trách nhiệm pháp lý của Quý khách được quy định trong <i>Điều khoản và Điều kiện Chung</i>:<ol><li>Do có rất nhiều vấn đề mang tính kỹ thuật, chúng tôi không thể cam đoan hay đảm bảo rằng <i>Dịch vụ Tùy chỉnh tính năng Thẻ</i> sẽ có thể được truy cập mọi lúc, hoặc thực hiện đúng chức năng với bất kỳ thiết bị điện tử, phần mềm, hạ tầng hay một số các dịch vụ Ngân hàng điện tử khác mà chúng tôi cung cấp;</li><li>Chúng tôi sẽ không chịu trách nhiệm cho bất kỳ mất mát hay tổn thất nào mà Quý khách hay những người được ủy quyền có liên quan đến việc sử dụng <i>Dịch vụ tùy chỉnh tính năng Thẻ</i> bắt nguồn từ bất kỳ sự không chính xác nào trong mã loại nhà cung cấp hoặc loại kênh thanh toán/ giao dịch được cung cấp hoặc lựa chọn bởi các nhà cung cấp hoặc nơi cung cấp phương thức thanh toán thẻ không tuân theo với các yêu cầu tuân thủ hay các luật lệ của Payment Card Industry (PCI) hoặc từ các hiệp hội thẻ có liên quan;</li><li>Trừ khi do lỗi trực tiếp của chúng tôi, chúng tôi sẽ không chịu trách nhiệm cho bất kỳ mất mát hay tổn thất nào mà Quý khách hay những người được ủy quyền có liên quan đến việc sử dụng sai hoặc cố ý sử dụng sai <i>Dịch vụ tùy chỉnh tính năng Thẻ</i>, hoặc các yêu cầu không phù hợp của Quý khách, hoặc bất kỳ giao dịch không được ủy quyền nào do lỗi trực tiếp của Quý khách có thông qua hoặc liên quan tới <i>Dịch vụ tùy chỉnh tính năng Thẻ</i>;</li><li>Quý khách sẽ phải bồi thường cho chúng tôi khỏi mọi mất mát hoặc thiệt hại trực tiếp mà chúng tôi có thể phải chịu liên quan tới việc Quý khách sử dụng không đúng cách <i>Dịch vụ tùy chỉnh tính năng Thẻ</i> do lỗi trực tiếp của Quý khách trong phạm vi pháp luật cho phép;</li><li>Quý khách tự chịu trách nhiệm bảo mật thiết bị di động và thông tin của Quý khách; và</li><li>Quý khách chấp nhận rằng bất kỳ tùy chỉnh nào đã thiết lập cho Thẻ thông qua Dịch vụ tùy chỉnh tính năng Thẻ sẽ không tự động áp dụng cho bất kỳ Thẻ thay thế hay Thẻ mới nào mà Quý khách có. Khi Quý khách được cấp một Thẻ thay thế hoặc Thẻ mới với số thẻ khác, Quý khách sẽ được yêu cầu thiết lập lại các tùy chỉnh để có thể sử dụng Dịch vụ tùy chỉnh tính năng Thẻ cho thẻ thay thế hoặc thẻ mới đó.</li></ol></li></ol><br><b>Định nghĩa từ</b><br/><br/>Chức năng Thông báo đẩy (Push notification) là dịch vụ do Apple và Google cung cấp cho hệ điều hành di động tương ứng của họ, tức là iOS và Android để các ứng dụng của iOS và Android có thể gửi cho người dùng (người đã cài đặt ứng dụng điện thoại) thông báo.<br/><br/>Tổ chức thanh toán thẻ là ngân hàng hoặc tổ chức tài chính xử lý thanh toán thẻ thay mặt cho điểm bán hàng. Tổ chức thanh toán thẻ cho phép điểm bán hàng chấp nhận thanh toán thẻ tín dụng hoặc ghi nợ của ngân hàng phát hành trong cùng một hiệp hội thẻ.<br/><br/>Hiệu lực từ 03/02/2020',
      'termsAndConditions.title': 'Điều khoản & Điều kiện',
      breadcrumbHome: 'Trang chủ',
      refNumber: 'SỐ THAM CHIẾU',
      cardTypenocardsTit: 'Không tìm thấy thẻ hợp lệ',
      cardTypenocardsDesc:
        'The selected account(s) to be linked does not have any eligible card for replacement. Kindly select other account(s) to proceed or contact our <a href="javascript:;">24/7 Phone Banking</a> for assistance.',
      cardTypeErrornocardsTit: 'Unable to retrieve data.',
      cardTypeErrornocardsDesc:
        'We are unable to retrieve your account details at this moment.<br>Kindly select other account(s) or try again later.',
      pageTitles: {
        applyProduct: {
          default: 'Open a New Account'
        },
        openNewAccount: 'Open a New Account',
        profileUpdate: 'Update Profile',
        letterRequests: 'Letter Request',
        chequeBookActivation: 'Cheque Book Activation',
        chequeBookStop: 'Cheque Book Stop/Block',
        confirmCheque: 'Confirm a Cheque',
        newChequeBookRequest: 'New Cheque Book Request',
        accountClosure: 'Account Closure',
        manageSignatory: 'Manage Signatory',
        signataireUpdate: 'Signature Update',
        sweepTransfer: 'Sweep Transfer',
        requestStatement: 'Request Statement',
        fixedDeposit: 'Fixed Deposit',
        demanDraft: 'Demand Draft/Manager Cheque',
        upliftFixed: 'Uplift Fixed Deposit',
        debitCardActivationPinset: 'Debit Card Activation and PIN set',
        debitCardBlockAndReplace: 'Debit Card Block and Replace',
        debitCardReplace: 'Debit Card Replace',
        debitCardPinRest: 'Debit Card PIN Reset',
        communProcess: 'Communication Preferences',
        jointAccountManagement: 'Joint Account Management',
        accountInformation: 'Account Information',
        visaTransfer: 'Fund My Account'
      },
      progress: {
        title1: 'Enter Details',
        title2: 'Xác nhận thông tin',
        title3: 'Chọn thông tin',
        title4: 'Select Your ATM Card Design',
        steptxt: 'Step',
        step1: '1/2',
        step2: '2/2',
        step12: 'Step 1 of 2',
        step22: 'Step 2 of 2',
        step13: '1 of 3',
        step23: '2 of 3',
        step33: '3 of 3',
        step14: '1 of 4',
        step24: '2 of 4',
        step34: '3 of 4',
        step44: '4 of 4',
        success: 'Thành công',
        submit: 'ĐÃ GỬI',
        failure: 'THẤT BẠI',
        incomplete: 'Incomplete',
        syserror: 'Lỗi Hệ thống',
        submitted: 'ĐÃ GỬI',
        plsselect: 'Please Select',
        stepOf: 'trên'
      },
      text: {
        selectAll: 'Chọn tất cả',
        deselectAll: 'Huỷ tất cả lựa chọn',
        english: 'English',
        chinese: 'Chinese',
        new: 'MỚI'
      },
      button: {
        cancel: 'HỦY',
        agree: 'AGREE',
        next: 'TIẾP',
        ok: 'OK',
        confirm: 'Xác nhận',
        yes: 'CÓ',
        no: 'KHÔNG',
        done: 'DONE',
        back: 'TRỞ VỀ',
        loadMore: 'TẢI THÊM',
        sNext: 'Trang sau',
        sPrev: 'Trang trước',
        proceed: 'Tiếp tục',
        close: 'Đóng',
        cancelrequest: 'HUỶ YÊU CẦU',
        showAll: 'Show All',
        viewStatus: 'Xem trạng thái',
        resetAnotherCards: 'ĐỔI MÃ PIN THẺ KHÁC',
        activateAnotherCard: 'Kích hoạt một thẻ khác',
        okDone: 'OK',
        sltcard: 'Select Card',
        accept: 'ACCEPT',
        save: 'LƯU',
        apply: 'APPLY',
        select: 'SELECT',
        selected: 'SELECTED',
        applynow: 'Apply Now',
        iUnderstand: 'I understand',
        startApplication: 'START APPLICATION',
        viewUrReq: 'XEM TRẠNG THÁI'
      },
      subCategoryText: {
        feeWaver: 'Fee Waiver',
        cardCancellation: 'Card Cancellation',
        cardBlock: 'Báo mất/Mất trộm thẻ',
        cardBlock1: 'Báo mất/Mất trộm thẻ Tín dụng',
        cardBlock2: 'Báo mất/Mất trộm Thẻ Ghi nợ',
        cardReplace: 'Thay Thẻ mới',
        cardReplace1: 'Thay thẻ tín dụng mới',
        cardReplace2: 'Replace Debit Card',
        debitCardBlockAndReplace: 'Debit Card Block and Replace',
        debitCardReplace: 'Debit Card Replace',
        debitCardActivationPinset: 'Debit Card Activation and PIN set',
        debitCardPinRest: 'Debit Card PIN Reset',
        chequeRequest: 'Cheque Book Request',
        cardReplacement: 'Card Replacement',
        cardReplacement1: 'Thay thẻ tín dụng mới',
        cardReplacement2: 'Replace Debit Card',
        cardActivation: 'Kích hoạt Thẻ Ghi nợ/ATM và Thiết lập mã PIN',
        profileSettings: 'Profile Settings',
        pinChange: 'Đổi mã PIN Thẻ Ghi nợ/ATM',
        letterRequest: 'Letter Request',
        chequeBookActivation: 'Cheque Book Activation',
        chequeStop: 'Cheque Book Stop/Block',
        chequeConfirmation: 'Confirm a Cheque',
        newChequeBook: 'New Cheque Book Request',
        creditBalanceRefund: 'Yêu cầu hoàn số dư từ Thẻ Tín Dụng',
        cardFeewavier: 'Fee Waiver',
        accountOpening: 'Account Opening',
        demandDraft: 'Demand Darft',
        accountClosure: 'Account Closure',
        updateFatcaStatus: 'Update FATCA Status',
        cddUpdate: 'Customer Due Diligence',
        kycDocumentRequest: 'KYC Document request',
        newSignAddition: 'Manage Signatory',
        signChange: 'Signature Update',
        sweepSetup: 'Sweep Setup ',
        upliftFullFd: 'Uplift Full FD',
        dndRequestRemoval: 'DND Request Removal',
        requestStatement: 'Request Statement',
        creditCardActivation: 'Kích hoạt Thẻ Tín dụng và Thiết lập mã PIN',
        creditPinChange: 'Thay đổi mã PIN Thẻ Tín dụng',
        fixedDeposit: 'Fixed Deposit',
        sltatm: 'Select ATM language',
        linkaccount: 'Link Another Account',
        debitatmcardrpm: 'Debit/ATM Card Replacement',
        newdebitatmcard: 'New Debit/ATM Card Application',
        refNo: 'SỐ THAM CHIẾU',
        sltCardtoreplace: 'Selected card to be replaced',
        atmLang: 'ATM Language',
        cardDesign: 'Card Design',
        jointAccount: 'Joint Account',
        productFeatures: 'Product Features',
        featureSubtitle: 'Get even more with your '
      },
      productListDetails: {
        detailLink: 'More details',
        eligibilityDocumentTitle: 'Eligibility & Documents',
        keyFeatures: 'Key Features',
        feesAndChargeDesc:
          'Fees and charges are subject to change. All fees and charges listed are inclusive of 5% Value Added Tax(VAT), where applicable.',
        feesAndChargeNote:
          'Note: Primary credit card Annual Fee from the second year onwards may be waived if retail spends for the preceding 12 months exceeds AED 150,000 or equivalent.For more details on all other applicable fees and charges, please click here.',
        faqTitle: 'FAQs',
        tocTitle: 'Useful Links',
        tableServiceHeader: 'SERVICE',
        tableChargeHeader: 'CHARGE'
      },
      categoryText: {
        creditCard: 'THẺ GHI NỢ',
        debitCard: 'Debit Card',
        personalDetails: 'Thông tin Cá nhân',
        accountManagement: 'Quản lý tài khoản',
        cardManagement: 'Quản lý thẻ',
        debitatmcardtitle: 'Debit/ATM Card'
      },
      mostPopularRequests: {
        cardBlock: 'Báo mất/mất trộm Thẻ',
        replaceCards: 'Replace Cards',
        replaceCards1: 'Replace Credit Cards',
        replaceCards2: 'Replace Debit Cards',
        debitCardBlockAndReplace: 'Debit Card Block and Replace',
        debitCardReplace: 'Debit Card Replace',
        debitCardActivationPinset: 'Card Activation and PIN set',
        debitCardPinRest: 'Debit Card PIN Reset',
        chequeBookRequest: 'Cheque Book Request',
        profileUpdate:
          'Update My Profile<span id="landing-popular-subtext">Review and update your profile with the latest details.</span>',
        letterRequest: 'Letter Request',
        chequeBookActivation: 'Cheque Book Activation',
        chequeStop: 'Cheque Book Stop/Block',
        chequeConfirmation: 'Confirm a Cheque',
        newChequeBook: 'New Cheque Book Request',
        accountOpening: 'Account Opening',
        jointAccount: 'Joint Account'
      },
      contactLinks: {
        VN: ' '
      },
      contactLinksTxt: {
        default: '24/7 Phone Banking'
      },
      fullName: 'Full Name',
      closeWindowText:
        'If you want to leave this page,<br>kindly select the "X" option available in the browser tab/window.',
      validation: {
        only: 'Only ',
        overallMaxValidation: ' product allowed per application',
        productSelectionValidation_1: ' credit card allowed in this application',
        productSelectionValidation_2: '',
        allowedApply: 'Only '
      }
    },
    CREDITCARD_ERROR_MAP: {
      'CSL-CC-301':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-302':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-303':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-304':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-305':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-306':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-307':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-308':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-312':
        'You have exceeded the PIN try limit. Kindly call our 24-hour Customer Care hotline for further assistance.',
      'CSL-CC-313':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-314':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-315':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-422':
        'Số điện thoại của Quý khách chưa được cập nhật với Ngân hàng. Vui lòng liên hệ Trung tâm Tư vấn Khách hàng +84 28 3911 0000 hoặc Chi nhánh gần nhất để được hỗ trợ',
      'CSL-CC-423':
        'Số điện thoại của Quý khách chưa được cập nhật với Ngân hàng. Vui lòng liên hệ Trung tâm Tư vấn Khách hàng +84 28 3911 0000 hoặc Chi nhánh gần nhất để được hỗ trợ',
      'CSL-CC-409':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-417':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-407':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-416': 'Please enter Standard Chartered Credit Card for activation.',
      'CSL-CC-415':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-405':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-414':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-404':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-413':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-403':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-412':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-402':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-411':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-401':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-410':
        'This service is currently not available. Please try again later. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-418':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-CC-316':
        'We are unable to process your request. Kindly call our 24-hour Customer Care Hotline for further assistance.',
      'CSL-OTP-1328':
        'Rất tiếc, Quý khách sẽ không nhận được thêm OTP nào trong vòng 24h kế tiếp với lý do đã bị quá số lần thử lại OPT',
      'CSL-SEC-519': 'Max retry attempt reached, kindly reset.',
      '1308':
        'You have entered invalid one-time password (OTP). Please check and re-enter your one time password(OTP). (Error Code:1308)',
      '1307': 'Mã OTP đã quá hạn. Vui lòng yêu cầu mã OTP mới. (Error Code:1307)',
      'CSL-OTP-1024': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-OTP-1026': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.'
    },
    CARDREPLACEMENT: {
      'header.title': 'Request for Replacement Card',
      cardlistHeader1: 'Chọn những thẻ để thay mới',
      cardlistHeader2: 'THẺ ĐÃ CHỌN ĐỂ THAY MỚI',
      cardlistHeader3: 'Your Replacement Cards',
      cardlistHeader4: 'Select debit cards to replace',
      cancelPopup: 'Do you want to cancel your Card Replacement request?',
      countryLinks: {
        VN: 'https://www.sc.com/vn'
      },
      countryLinksTxt: {
        default: 'fee schedule'
      },
      countryNotes: {
        VN:
          'Với xác nhận trên, (các) Thẻ của Quý khách sẽ bị khóa ngay lập tức và không thể sử dụng được nữa. Vui lòng lưu ý rằng, thẻ đã bị khóa sẽ không thể kích hoạt lại.<br>Quý khách sẽ không phải chịu trách nhiệm cho bất cứ giao dịch nào phát sinh từ (những) thẻ này kể từ sau thông báo này được gửi thành công. Số dư hiện tại của thẻ đã bị khóa sẽ được chuyển sang thẻ thay thế mới.<br>Ngân hàng sẽ gửi thẻ thay thế mới đến địa chỉ của Quý khách mà Ngân hàng đang ghi nhận trên hệ thống. Vui lòng lưu ý rằng thẻ thay thế mới sẽ có số thẻ mới và Quý khách sẽ phải tạo lại mã PIN trên Ngân hàng Trực tuyến. Việc thay thẻ mới sẽ được áp dụng theo thẻ biểu phí hiện tại.<br/><br>Quý khách vui lòng cập nhật lại tất cả các hóa đơn hoặc yêu cầu thanh toán có sử dụng số thẻ cũ bằng số thẻ mới sau khi nhận được thẻ thay thế.'
      },
      statusMsg: {
        success:
          'Yêu cầu thay thẻ mới của Quý khách đã được gửi đi. Quý khách có thể theo dõi yêu cầu này trong thanh “Trạng thái” dưới mục Hỗ trợ và Dịch vụ.',
        failure:
          'Lỗi xảy ra khi xử lý yêu cầu của Quý khách. Vui lòng gửi lại yêu cầu mới. Nếu tiếp tục gặp lỗi trong những lần sau, vui lòng liên hệ với Trung tâm Tư vấn Khách hàng (24/7) qua số +84 28 3911 0000 hoặc +84 24 3696 0000 để được hỗ trợ ngay.',
        incomplete:
          'Lỗi xảy ra khi xử lý một số thẻ của Quý khách. Vui lòng gửi lại yêu cầu mới cho những thẻ này. Nếu tiếp tục gặp lỗi trong những lần sau, vui lòng liên hệ với Trung tâm Tư vấn Khách hàng (24/7) qua số +84 28 3911 0000 hoặc +84 24 3696 0000 để được hỗ trợ ngay.'
      }
    },
    CARDBLOCK: {
      'header.title': 'Báo mất/Mất trộm thẻ',
      'header.title1': 'Báo mất/Mất trộm thẻ Tín dụng',
      'header.title2': 'Báo mất/Mất trộm Thẻ Ghi nợ',
      cardlistHeader1: 'CHỌN THẺ ĐỂ KHOÁ',
      cardlistHeader2: 'Thẻ đã được chọn để khoá',
      cardlistHeader3: 'Your Replacement Cards',
      cardlistSubHeader:
        'Nếu không thấy thẻ mà Quý khách muốn khoá trong danh sách dưới đây, vui lòng liên hệ Trung tâm Tư vấn Khách hàng (24/7) ngay lập tức.',
      'cardlistSubHeader.KE':
        'If you do not see the card you wish to block in the list below, please contact our client care centre on +254 20 3293900',
      cancelPopup: 'Do you want to cancel your Report Lost/Stolen Credit Card request?',
      selectreason: {
        header: 'Tôi muốn khoá thẻ của tôi vì',
        placeholder: 'Chọn lý do',
        reasonToBlock: 'NGUYÊN NHÂN KHOÁ THẺ',
        reason1: 'Tôi đánh mất thẻ',
        reason2: 'Thẻ của tôi bị lấy cắp',
        reason3: 'Thẻ của tôi bị kẹt trong máy ATM'
      },
      countryLinks: {
        VN: 'https://www.sc.com/vn'
      },
      countryLinksTxt: {
        default: 'fee schedule'
      },
      countryNotes: {
        VN:
          'Với xác nhận trên, (các) Thẻ của Quý khách sẽ bị khóa ngay lập tức và không thể sử dụng được nữa. Vui lòng lưu ý rằng, thẻ đã bị khóa sẽ không thể kích hoạt lại.<br>Quý khách sẽ không phải chịu trách nhiệm cho bất cứ giao dịch nào phát sinh từ (những) thẻ này kể từ sau thông báo này được gửi thành công. Số dư hiện tại của thẻ đã bị khóa sẽ được chuyển sang thẻ thay thế mới.<br>Ngân hàng sẽ gửi thẻ thay thế mới đến địa chỉ của Quý khách mà Ngân hàng đang ghi nhận trên hệ thống. Vui lòng lưu ý rằng thẻ thay thế mới sẽ có số thẻ mới và Quý khách sẽ phải tạo lại mã PIN trên Ngân hàng Trực tuyến. Việc thay thẻ mới sẽ được áp dụng theo thẻ biểu phí hiện tại.<br/>- Đối với thẻ tín dụng, nhấp vào <u><a href="https://www.sc.com/global/av/vn-credit-card-fees-charges-vn.pdf" target="_blank">đây</a></u> để biết thêm chi tiết.<br/>- Đối với thẻ ghi nợ dành cho Khách hàng cá nhân, nhấp vào <u><a href="https://www.sc.com/global/av/vn-individual-banking-tariff-vn.pdf" target="_blank">đây</a></u> để biết thêm chi tiết.<br/>- Đối với thẻ ghi nợ dành cho khách hàng ưu tiên, nhấp vào <u><a href="https://www.sc.com/global/av/vn-priority-banking-tariff-vn.pdf" target="_blank">đây</a></u> để biết thêm chi tiết.<br>Quý khách vui lòng cập nhật lại tất cả các hóa đơn hoặc yêu cầu thanh toán có sử dụng số thẻ cũ bằng số thẻ mới sau khi nhận được thẻ thay thế.'
      },
      statusMsg: {
        success:
          'Thẻ của Quý khách đã bị khoá và yêu cầu thay mới đã được gửi đi. Quý khách có thể theo dõi yêu cầu này trong thanh “Trạng thái” dưới mục Hỗ trợ và Dịch vụ.',
        failure:
          'Lỗi xảy ra khi xử lý yêu cầu của Quý khách. Vui lòng gửi lại yêu cầu mới. Nếu tiếp tục gặp lỗi trong những lần sau, vui lòng liên hệ với Trung tâm Tư vấn Khách hàng (24/7) qua số +84 28 3911 0000 hoặc +84 24 3696 0000  để được hỗ trợ ngay.',
        incomplete:
          'Lỗi xảy ra khi xử lý một số thẻ của Quý khách. Vui lòng gửi lại yêu cầu mới cho những thẻ này. Nếu tiếp tục gặp lỗi trong những lần sau, vui lòng liên hệ với Trung tâm Tư vấn Khách hàng (24/7) qua số +84 28 3911 0000 hoặc +84 24 3696 0000 để được hỗ trợ ngay.'
      }
    },
    STATUSENQUIRY: {
      'header.title': 'TRẠNG THÁI',
      'activeSection.title': 'Đang chờ xử lý',
      'completedSection.title': 'HOÀN TẤT',
      statusReferenceNo: 'Số Tham chiếu',
      statusUpdatedDate: 'Estimated Completion Date:',
      statusCardReplacement: 'Trạng thái yêu cầu thay thẻ:',
      statusCardReplacementM: 'Replacement Status:',
      statusUpdateDateMobile: 'Est. Completion:',
      noActiveRequest: 'Không có yêu cầu nào',
      statusOfRecords: 'Trang này chỉ hiển thị các yêu cầu trong vòng 90 ngày trở lại đây',
      'statusOfRecords.KE': 'This page only shows request made in the last 90 days',
      'statusOfRecords.IN':
        'If you are unable to view the status of your earlier request, please <a href="/retail/api/security/v1/ssoRequest?RedirPageId=VIEWSTATUS">click here</a>.<br/><br/>This page only shows requests from the past 90 days.',
      clClosure: 'Loan Account(s)',
      labelReceive: 'ĐÃ NHẬN',
      labelProcessing: 'ĐANG XỬ LÝ',
      labelCompleted: 'HOÀN TẤT',
      labelRejected: 'TỪ CHỐI',
      labelSuccess: 'THÀNH CÔNG',
      labelFailed: 'THẤT BẠI',
      labelCancelled: 'CANCELLED',
      labelRetained: 'RETAINED',
      labelNotProcessed: 'NOT PROCESSED',
      labelClosed: 'CLOSED',
      updatedDate: 'Được cập nhật vào',
      dateSubmitted: 'Ngày gửi',
      'account/relationshipNo': 'Sản phẩm',
      creditCard: 'Thẻ Tín dụng bị khoá',
      debitCard: 'Thẻ Ghi nợ bị khóa',
      ccCancellation: 'Card Account(s)',
      CCFWR: 'Fee Waived',
      CCFWC: 'Fee Charged',
      creditCardReplace: 'Thẻ Tín dụng bị thay thế',
      debitCardReplace: 'Replaced ATM Card',
      referral: 'Action Required',
      resume: 'Resume',
      verification: 'Verification',
      activation: 'Activation',
      pending: 'Pending',
      agentTitle: 'Begin Authentication with Agent',
      agentDescription: 'An authentication with our agent is required to complete your account application.',
      accountDetails: 'Account Opening Details',
      debitCardIssuance: 'Applied ATM Card'
    },
    LANDINGPAGE: {
      tabText: {
        createRequest: 'YÊU CẦU DỊCH VỤ',
        status: 'TRẠNG THÁI'
      },
      'header.title': 'Hỗ trợ và Dịch vụ',
      noResultsFound: 'No results found',
      needHelp: 'Tôi cần hỗ trợ cho mục',
      regardsTo: 'về việc',
      popularServices: 'Các dịch vụ thông dụng',
      popularServicesCI: 'Service Request',
      allServicesCategory: 'Dịch vụ theo danh mục',
      'help&usefulLinks': 'Hỗ trợ & Các đường dẫn hữu ích',
      search: 'Tìm kiếm...'
    },
    CREDITCARD: {
      cardSetting: {
        terminateRequest: 'Yêu cầu của bạn đã chấm dứt và sẽ được chuyển trở lại để chọn thẻ.',
        settingsSaved: 'Tùy chỉnh đã được lưu!',
        journeyHeader: 'Tùy chỉnh Tính năng Thẻ',
        notSaveConfirm: 'Nếu quay lại, các tùy chỉnh vừa thực hiện sẽ không được lưu.',
        settingsTitle: {
          transactionLimit: 'Hạn mức mỗi giao dịch',
          paymentChannels: 'Kênh thanh toán',
          controlledCatagories: 'Nhóm danh mục giao dịch',
          countryLimits: 'Giao dịch ở nước ngoài'
        },
        settingsDesc: {
          tmpBlock: 'Khóa/Mở Khóa thẻ tức thời',
          transactionLimit: 'Hạn mức mỗi giao dịch',
          paymentChannels: 'Kênh thanh toán',
          controlledCategories: 'Nhóm danh mục giao dịch',
          countryLimits: 'Giao dịch ở nước ngoài'
        },
        selectPage: {
          pageHeader: 'Chọn Thẻ Tín dụng',
          sectionHeaderMob: 'Chọn một thẻ'
        },
        cardSettingsPage: {
          pageHeader: 'Thiếp lập Thẻ Tín dụng',
          sectionHeader: 'Thiếp lập Thẻ Tín dụng của Quý khách',
          sectionHeaderMob: 'Thiết lập Thẻ Tín dụng của Quý khách',
          termsAndConditions: 'Bằng việc kích hoạt những tính năng này, Quý khách đã đồng ý với các ',
          on: 'BẬT',
          off: 'TẮT'
        },
        transactionLimitPage: {
          transactionNotifications: 'Thông báo vượt hạn mức giao dịch',
          transactionNotificationsContent: 'Được thông báo mỗi khi có giao dịch vượt hạn mức',
          limitAmountTitle: 'HẠN MỨC MỖI GIAO DỊCH',
          blockCheckbox: 'Từ chối các giao dịch vượt hạn mức này',
          maxLimitAlert: 'Vui lòng nhập một số tiền không vượt quá hạn mức tín dụng của Quý khách _AMOUNT_.',
          minLimitAlert: 'Vui lòng nhập một số tiền lớn hơn hoặc bằng _AMOUNT_.',
          errorNumType: 'Vui lòng nhập số tiền hợp lệ.'
        },
        paymentChannelsPage: {
          paymentChannelNotifications: 'Thông báo về kênh thanh toán',
          paymentChannelNotificationsContent:
            'Nhận thông báo mỗi khi thẻ của Quý khách được dùng thông qua kênh thanh toán sau.',
          blockCheckbox: 'Từ chối các giao dịch được thực hiện thông qua các kênh thanh toán được chọn',
          optionItem1: 'Thanh toán trực tuyến',
          optionItem2: 'Thanh toán không tiếp xúc',
          optionItem3: 'Thanh toán tiếp xúc',
          optionContent1:
            'Thanh toán trực tuyến được thực hiện bằng việc nhập thông tin thẻ tín dụng vào một trang web hoặc ứng dụng. Điều này cũng ảnh hưởng tới các thanh toán thường kỳ như thanh toán hóa đơn hay đăng ký thuê bao.',
          optionContent2:
            'Thanh toán không tiếp xúc là khi Quý khách sử dụng thẻ hoặc ví điện tử bằng cách đặt chúng gần một thiết bị thanh toán thẻ tín dụng. Đôi khi Quý khách sẽ được yêu cầu cung cấp mã PIN hoặc chữ ký.',
          optionContent3:
            'Thanh toán tiếp xúc được thực hiện bằng việc quẹt hoặc đưa thẻ vào một thiết bị thanh toán thẻ tín dụng. Đôi khi Quý khách sẽ được yêu cầu cung cấp mã PIN hoặc chữ ký.'
        },
        controlledCategories: {
          controlledCategoriesNotifications: 'Thông báo Nhóm danh mục giao dịch',
          controlledCategoriesNotificationsContent:
            'Nhận thông báo mỗi khi thẻ của Quý khách có giao dịch trong Nhóm danh mục giao dịch đã chọn.',
          blockCheckbox: 'Từ chối các giao dịch được thực hiện với loại giao dịch được chọn',
          optionItem1: 'Quần áo & Phụ Kiện',
          optionItem2: 'Du lịch',
          optionItem3: 'Nhiên liệu & Xe cộ',
          optionItem4: 'Tạp hóa',
          optionItem5: 'Đồ gia dụng',
          optionItem6: 'Giải trí'
        },
        countryLimitsPage: {
          countryNotifications: 'Thông báo về giao dịch ở nước ngoài',
          countryNotificationsContent:
            'Nhận thông báo mỗi khi có một giao dịch quẹt thẻ tại các quốc gia đã được chọn.',
          blockCheckbox: 'Từ chối các giao dịch được thực hiện tại các quốc gia đã được chọn.',
          selectedCountry: 'Chặn các nước sau',
          selectCountryContent: 'TÌM KIẾM',
          addCountryContent: 'Tìm kiếm quốc gia',
          countryLimitExplain: 'Thông báo cho tôi khi thẻ của tôi được sử dụng:',
          overseaCardUsageContent:
            'Chặn giao dịch thẻ vật lý ở ngoài quốc gia mà thẻ được phát hành. Giao dịch trực tuyến sẽ không bị ảnh hưởng.',
          countryTooltip:
            'Giao dịch dùng thẻ vật lý là khi mà thẻ được sử dụng tại một thiết bị thanh toán hoặc máy đọc thẻ, bao gồm cả hình thức thanh toán không tiếp xúc. Các thanh toán qua trang web hay app sẽ không bị ảnh hưởng.',
          anyOverseasCountries: 'Tại nước ngoài',
          allOverseasCountriesExcept: 'Tại nước ngoài, ngoại trừ...',
          theseSpecificCountries: 'Các quốc gia cụ thể sau đây:'
        },
        isPrimary: {
          primary: 'THẺ CHÍNH',
          supplementary: 'THẺ PHỤ'
        },
        TMPBLOCKTXT: 'Tạm thời khóa thẻ này',
        TMPTOOLTIP:
          'Tùy chỉnh này áp dụng cho tất cả các giao dịch không định kỳ. Các giao dịch định kỳ như thanh toán hóa đơn, đăng ký thuê bao, rút tiền từ ATM sẽ không bị ảnh hưởng.',
        NOTICE: {
          TMPBLOCK:
            'Quý khách đang thực hiện khóa tạm thời thẻ này. Các giao dịch không định kỳ sẽ bị từ chối cho đến khi thẻ được mở lại.',
          SETBLOCK: 'Thao tác này sẽ khiến một số giao dịch nhất định bị từ chối.',
          ERROR: 'Đã xảy ra lỗi và thiếp lập của Quý khách đã không được lưu lại. Vui lòng thử lại sau.',
          MCORVISA: 'Xin lỗi, hiện tại tính năng Tùy chỉnh Tính năng Thẻ chỉ hiện có cho thẻ tín dụng của MasterCard.',
          INACTIVE: 'Vui lòng kích hoạt thẻ của Quý khách trước khi thay đổi các tùy chỉnh.'
        },
        noCards: {
          content2:
            'Quý khách không có Thẻ tín dụng nào để cài đặt Tùy chỉnh tính năng Thẻ.<br><br>Đăng ký mở thẻ tín dụng ngay để có thể sử dụng:',
          button: 'ĐĂNG KÝ NGAY',
          nocardcontent: 'Không tìm thấy thẻ'
        }
      },
      pinSetup: {
        journeyHeader: 'Thiết lập/Đổi mã PIN Thẻ Tín dụng',

        selectPage: {
          pageHeader: 'Chọn một Thẻ Tín dụng',
          sectionHeader: 'CHỌN THẺ TÍN DỤNG ĐỂ THIẾT LẬP MÃ PIN',
          sectionHeaderMob: 'Chọn thẻ tín dụng để thiết lập mã PIN',
          nocardHeader: 'Không tìm thấy thẻ hợp lệ',
          nocardContent: 'Rất tiếc Quý khách không có Thẻ Tín dụng hợp lệ nào cho yêu cầu này.'
        },
        pinChange: {
          pageHeader: 'Tạo mã PIN Thẻ  Tín dụng',
          sectionHeader: 'TẠO MÃ PIN MỚI',
          sectionHeaderMob: 'Tạo mã PIN mới',
          newPin: 'NHẬP MÃ PIN MỚI CỦA QUÝ KHÁCH',
          reEnterPin: 'NHẬP LẠI MÃ PIN MỚI CỦA QUÝ KHÁCH',
          newPinMob: 'Nhập mã PIN mới của quý khách',
          reEnterPinMob: 'Nhập lại mã PIN mới của quý khách',
          pinNotSame: 'Entered PIN numbers are not same',
          pinNotAsGuideline: 'Invalid PIN, please enter PIN as per the guidelines'
        },
        countryNotes: {
          VN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'><ol><li>Nhập mã OTP (mật khẩu dùng 1 lần) sẽ được gửi đến số điện thoại đăng ký của Quý khách để thay đổi mã PIN gồm 4 ký tự.</li><li>KHÔNG tiết lộ mã PIN cho bất cứ ai. Mã PIN cần được ghi nhớ và không lưu lại dưới bất kỳ hình thức nào.</li><li>KHÔNG đặt mã PIN là các chuỗi số dễ đoán như ngày sinh, ngày kỷ niệm, số CMND, số điện thoại.</li><li>Không nên đặt mã PIN là các chuỗi số liên tục hoặc có các ký tự trùng lặp (như 1234 hoặc 1223).</li><li>Thay đổi mã PIN của Quý khách thường xuyên và thay đổi ngay lập tức nếu Quý khách nghi ngờ rằng mã PIN đã bị lộ.</li><li>Khi cần hỗ trợ, vui lòng liên hệ với Trung tâm Tư vấn Khách hàng (24/7) theo số +84 28 3911 0000 hoặc +84 24 3696 0000.</li></ol></li></ol>"
        },
        status: {
          refNo: 'SỐ THAM CHIẾU',
          refNoSmall: 'Số tham chiếu',
          cardDetails: 'Thông tin thẻ',
          success: 'Thành công!',
          failed: 'Không thành công!',
          transactionSuccessMsg: 'Quý khách đã đổi mã PIN Thẻ Tín dụng thành công',
          transactionSuccessFailure: {
            VN:
              'Yêu cầu của Quý khách không thể thực hiện được. Vui lòng thử lại hoặc liên hệ với Trung tâm Tư vấn Khách hàng (24/7) theo số +84 28 3911 0000 hoặc +84 24 3696 0000 để được hỗ trợ'
          },
          transactionSuccessInComplete:
            'Yêu cầu của Quý khách không thể thực hiện được. Vui lòng thử lại hoặc liên hệ với Trung tâm Tư vấn Khách hàng (24/7) theo số +84 28 3911 0000 hoặc +84 24 3696 0000 để được hỗ trợ'
        }
      },
      activation: {
        journeyHeader: 'Kích hoạt Thẻ Tín dụng/Thiết lập mã PIN',
        selectPage: {
          pageHeader: 'Chọn một Thẻ Tín dụng',
          sectionHeader: 'CHỌN MỘT THẺ TÍN DỤNG ĐỂ KÍCH HOẠT',
          sectionHeaderMob: 'Chọn một thẻ tín dụng để kích hoạt',
          nocardHeader: 'Không tìm thấy thẻ hợp lệ',
          nocardContent: 'Rất tiếc Quý khách không có Thẻ Tín dụng hợp lệ nào cho yêu cầu này.'
        },
        pinChange: {
          pageHeader: 'Tạo mã PIN Thẻ  Tín dụng',
          sectionHeader: 'TẠO MÃ PIN MỚI',
          sectionHeaderMob: 'Tạo mã PIN mới',
          newPin: 'NHẬP MÃ PIN MỚI CỦA QUÝ KHÁCH',
          reEnterPin: 'NHẬP LẠI MÃ PIN MỚI CỦA QUÝ KHÁCH',
          newPinMob: 'Nhập mã PIN mới của quý khách',
          reEnterPinMob: 'Nhập lại mã PIN mới của quý khách',
          pinNotSame: 'Entered PIN numbers are not same',
          pinNotAsGuideline: 'Invalid PIN, please enter PIN as per the guidelines'
        },
        disclaimerNotes: {
          VN:
            'MIỄN TRỪ TRÁCH NHIỆM: Vui lòng đảm bảo rằng Quý khách đã nhận được Thẻ nhựa trước khi tiến hành kích hoạt Thẻ và thiết lập mã PIN'
        },
        countryNotes: {
          VN:
            "<ol style='list-style-type: none;'><li>Nhập mã OTP (mật khẩu dùng 1 lần) sẽ được gửi đến số điện thoại đăng ký của Quý khách để thay đổi mã PIN gồm 4 ký tự.</li><li>KHÔNG tiết lộ mã PIN cho bất cứ ai. Mã PIN cần được ghi nhớ và không lưu lại dưới bất kỳ hình thức nào.</li><li>KHÔNG đặt mã PIN là các chuỗi số dễ đoán như ngày sinh, ngày kỷ niệm, số CMND, số điện thoại, v.v.</li><li>Không nên đặt mã PIN là các chuỗi số liên tục hoặc có các ký tự trùng lặp (như 1234 hoặc 1223).</li><li>Thay đổi mã PIN của Quý khách thường xuyên và thay đổi ngay lập tức nếu Quý khách nghi ngờ rằng mã PIN đã bị lộ.</li><li>Khi cần hỗ trợ, vui lòng liên hệ với Trung tâm Tư vấn Khách hàng (24/7) theo số +84 28 3911 0000 hoặc +84 24 3696 0000.</li></ol>"
        },
        status: {
          refNo: 'SỐ THAM CHIẾU',
          refNoSmall: 'Số tham chiếu',
          cardDetails: 'Thông tin Thẻ Tín dụng',
          success: 'Thành công!',
          failed: 'Không thành công!',
          transactionSuccessMsg: 'Thẻ Tín dụng của Quý khách đã được kích hoạt',
          transactionSuccessFailure: {
            VN:
              'Yêu cầu của Quý khách không thể thực hiện được. Vui lòng thử lại hoặc liên hệ với Trung tâm Tư vấn Khách hàng (24/7) theo số +84 28 3911 0000 hoặc +84 24 3696 0000 để được hỗ trợ'
          },
          transactionSuccessInComplete:
            'Yêu cầu của Quý khách không thể thực hiện được. Vui lòng thử lại hoặc liên hệ với Trung tâm Tư vấn Khách hàng (24/7) theo số +84 28 3911 0000 hoặc +84 24 3696 0000 để được hỗ trợ'
        }
      },
      validation: {
        pinNotSame: {
          VN: 'Vui lòng nhập lại mã PIN 4 số trùng với mã PIN mới khởi tạo'
        },
        pinNotAsGuideline: {
          VN: 'Vui lòng nhập mã PIN 4 số hợp lệ như được hướng dẫn trong phần Lưu ý bên dưới'
        },
        enterValidPin: {
          VN: 'Vui lòng nhập mã PIN hợp lệ'
        }
      }
    },
    genericRequest: {
      header: {
        title: {
          'credit-card': 'Credit Card',
          'debit-card': 'Debit Card',
          loan: 'Loan',
          deposit: 'Term Deposit',
          default: 'Account',
          CCLOANCL: 'Selected PLC account(s) to be closed',
          label1: 'Review your request',
          label2: 'Request Details',
          label3: 'Supporting Documents',
          label4: 'Please describe your request',
          label5: 'What is your request about?',
          label6: 'Upload Supporting Documents',
          label7: 'Type additional details here',
          CUSTOMERLbl:
            'If you were unable to find a suitable request in the menu, please describe your request to us in the section below.',
          CUSTOMERPlcHld: 'Please describe your request',
          'comment-label': 'Comments',
          'note-label': 'Please refer to the Notes below and provide the necessary information for your request.',
          statusMsg:
            "Your request has been submitted and will be processed.<br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br>To check the status, go to the 'Status' tab under Help & Services.",
          statusMsgCUSTOMER:
            'Thank you. Your request has been submitted and will be processed.<br><br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.<br><br>You may refer to your Secure Mailbox for status updates or view your submitted request under "Sent Items".',
          statusMsgReferral:
            'We have received your response to our query and will process your request.<br>We are currently experiencing a high volume of requests, and we apologise if you experience any processing delay. We will attend to your request as soon as possible. Thank you for understanding.',
          referral: {
            scb: 'Standard Chartered:',
            user: 'You:',
            reply: 'Reply Message',
            submit: 'Submit Message'
          }
        },
        panelTitle: {
          'credit-card': 'Select a Credit Card',
          'debit-card': 'Select a Debit Card',
          loan: 'Select a Loan',
          deposit: 'Select a Term Deposit',
          default: 'Select an Account'
        },
        content: {
          loan: 'Which Loan you need help with?',
          casa: 'Which Account you need help with?',
          deposit: 'Which Term Deposit you need help with?',
          default: 'Which Card you need help with?'
        }
      },
      errorMsg: {
        title: {
          casa: 'You do not have any eligible account(s) for this request.',
          loan: 'You do not have any eligible loan(s) for this request.',
          default: 'Quý khách không có thẻ đủ điều kiện để thực hiện yêu cầu này.'
        },
        content: {
          default: 'We are unable to process your request.'
        }
      },
      default: 'Generic Request',
      otherRequest: 'Other Request',
      none: 'none',
      LMTCONFL: {
        title: "Credit Card's limit confirmation letter",
        notemessage: {
          select:
            'Quý Khách vui lòng cho chúng tôi biết phạm vi ngày Quý khách muốn chúng tôi phát hành thư xác nhận.<br> Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản thẻ tín dụng, Quý khách vui lòng đảm bảo tài khoản còn đủ hạn mức cho việc thu phí.Vui lòng tham khảo bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/global/av/vn-credit-card-fees-charges-vn.pdf\',\'_system\')">đây</a> để xem phí và lệ phí thẻ tín dụng Standard Chartered.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư đã đăng ký sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách và sẽ thông báo Quý khách qua SMS hoặc Email.'
        }
      },
      BALCONVN: {
        title: "Credit Card's balance confirmation letter",
        notemessage: {
          select:
            'Quý Khách vui lòng cho chúng tôi biết phạm vi ngày Quý khách muốn chúng tôi phát hành thư xác nhận.<br> Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản thẻ tín dụng, Quý khách vui lòng đảm bảo tài khoản còn đủ hạn mức cho việc thu phí.Vui lòng tham khảo bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/global/av/vn-credit-card-fees-charges-vn.pdf\',\'_system\')">đây</a> để xem phí và lệ phí thẻ tín dụng Standard Chartered.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư đã đăng ký sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách và sẽ thông báo Quý khách qua SMS hoặc Email.'
        }
      },
      INTCONFL: {
        title: "Credit Card's Interest confirmation letter",
        notemessage: {
          select:
            'Quý Khách vui lòng cho chúng tôi biết phạm vi ngày Quý khách muốn chúng tôi phát hành thư xác nhận.<br> Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản thẻ tín dụng, Quý khách vui lòng đảm bảo tài khoản còn đủ hạn mức cho việc thu phí.Vui lòng tham khảo bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/global/av/vn-credit-card-fees-charges-vn.pdf\',\'_system\')">đây</a> để xem phí và lệ phí thẻ tín dụng Standard Chartered.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư đã đăng ký sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách và sẽ thông báo Quý khách qua SMS hoặc Email.'
        }
      },
      LOGCONFL: {
        title: "Credit Card's Loan Group confirmation letter",
        notemessage: {
          select:
            'Quý Khách vui lòng cho chúng tôi biết phạm vi ngày Quý khách muốn chúng tôi phát hành thư xác nhận.<br> Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản thẻ tín dụng, Quý khách vui lòng đảm bảo tài khoản còn đủ hạn mức cho việc thu phí.Vui lòng tham khảo bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/global/av/vn-credit-card-fees-charges-vn.pdf\',\'_system\')">đây</a> để xem phí và lệ phí thẻ tín dụng Standard Chartered.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư đã đăng ký sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách và sẽ thông báo Quý khách qua SMS hoặc Email.'
        }
      },
      PAYHISTL: {
        title: "Credit Card's payment history letter",
        notemessage: {
          select:
            'Quý Khách vui lòng cho chúng tôi biết phạm vi ngày Quý khách muốn chúng tôi phát hành thư xác nhận.<br> Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản thẻ tín dụng, Quý khách vui lòng đảm bảo tài khoản còn đủ hạn mức cho việc thu phí.Vui lòng tham khảo bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/global/av/vn-credit-card-fees-charges-vn.pdf\',\'_system\')">đây</a> để xem phí và lệ phí thẻ tín dụng Standard Chartered.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư đã đăng ký sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách và sẽ thông báo Quý khách qua SMS hoặc Email.'
        }
      },
      RESCAUPD: {
        title: 'Resident Card Update',
        notemessage: {
          upload:
            'Vui lòng tải lên Tài liệu thường trú (cả hai mặt).<b>Tài liệu thường trú hợp lệ là:</b>VISA / thẻ thường trú / thẻ tạm trú cho thấy Quý khách được phép ở lại Việt Nam trong ít nhất 12 tháng trở lên và vẫn còn hiệu lực ít nhất 3 tháng kể từ bây giờ.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách và sẽ thông báo Quý khách qua SMS hoặc Email.'
        }
      },
      BANKCERT: {
        title: 'Thư xác nhận thông tin dư nợ quá hạn',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      SLSPURAG: {
        title: 'Hợp đồng mua bán với chủ đầu tư',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      CICCONFM: {
        title: 'Thư xác nhận nhóm nợ',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      CONFISUE: {
        title: 'Thư xác nhận về bất động sản thế chấp',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      COOFMAFA: {
        title: 'Hợp đồng thế chấp / Hợp đồng tín dụng',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      EXTLOAGR: {
        title: 'Trích lục hợp đồng',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      LATPAYHL: {
        title: 'Thư xác nhận lịch sử chậm trả',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      LINCONFL: {
        title: 'Thư xác nhận thông tin khoản vay',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      LREPHIST: {
        title: 'Bảng lịch sử trả nợ khoản vay',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      LREPSCHE: {
        title: 'Bảng thanh toán khoản vay hàng tháng',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      LSETTLEL: {
        title: 'Thư xác nhận tất toán khoản vay',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      PRPCONFL: {
        title: 'Thư xác nhận tất toán khoản vay',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      MAGRFAGR: {
        title: 'Hợp đồng thế chấp / Hợp đồng tín dụng',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      },
      CERTCPTD: {
        title: 'Sao y/ Chứng thực về bất động sản thế chấp',
        notemessage: {
          select:
            'Phí & lệ phí (nếu có) sẽ được ghi nợ vào tài khoản giao dịch, Quý khách vui lòng đảm bảo tài khoản còn đủ số dư cho việc thu phí. Nếu không yêu cầu của quý khách sẽ bị từ chối. Vui lòng bấm vào <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/loans/\',\'_system\')">đây</a> để xem chi tiết phí/ lệ phí.<br>Yêu cầu của Quý khách sẽ được xử lý và gửi đến địa chỉ gửi thư/ Email đã đăng ký hoặc Chi Nhánh chỉ định sau 5 ngày làm việc. Vui lòng đảm bảo địa chỉ gửi thư hợp lệ trước khi gửi yêu cầu này.<br>Quý khách có thể kiểm tra tiến trình yêu cầu của mình trong mục Trạng thái. Trong quá trình xử lý yêu cầu, chúng tôi có thể liên lạc với Quý khách.<br>Vui lòng cung cấp thông tin chủ tài sản/địa chỉ tài sản. Hợp đồng thế chấp” / Hợp đồng tín dung. Hợp đồng mua bán với chủ đầu tư. Hợp đồng thế chấp / Hợp đồng tín dụng. Sao y/ Chứng thực về bất động sản thế chấp. Thư xác nhận về bất động sản thế chap.'
        }
      }
    },
    duplicateStatement: {
      title: {
        common: 'Yêu cầu Bảng sao kê'
      },
      productLabel: {
        account: 'Tài khoản',
        cccard: 'Thẻ tín dụng',
        loan: 'Khoản vay',
        datePlacehld: 'Tháng tháng/ Năm năm'
      },
      header: {
        panelTitle: {
          select: 'Nhập thông tin',
          account: 'Tài khoản',
          confirm: 'Xác nhận thông tin',
          mobConfirm: 'Xác nhận',
          product: 'Nhập thông tin',
          statement: 'Nhập thông tin'
        },
        title: {
          select: 'Sản phẩm',
          account: 'Tài khoản',
          confirm: 'Xác nhận thông tin',
          statusMsg:
            'Yêu cầu Bảng sao kê của Quý khách đã được gửi đi thành công.<br>Quý khách có thể theo dõi trạng thái của Yêu cầu bằng cách vào mục Hỗ trợ & Dịch vụ > thanh Trạng thái.',
          subInprogress: 'Cảm ơn'
        },
        subTitle: {
          select: 'Vui lòng chọn 1 Tài khoản/ Thẻ Quý khách yêu cầu Bảng sao kê',
          product: 'Vui lòng chọn 1 Tài khoản/ Thẻ Quý khách yêu cầu Bảng sao kê',
          account: 'Vui lòng chọn 1 tài khoản cho việc thu phí phát hành.',
          confirm: 'Xác nhận thông tin'
        }
      },
      pageLabels: {
        addressInfo:
          'By clicking "OK", we will charge the paper statement fee to your account. Please select which account for us to debit the charges in the next step.',
        product: 'Sản phẩm',
        ConfirmProduct: 'Sản phẩm',
        account: 'TÀI KHOẢN/ THẺ',
        startDate: 'SAO KÊ TỪ THÁNG',
        endDate: 'SAO KÊ ĐẾN THÁNG',
        debitedAccount: 'TÀI KHOẢN THU PHÍ',
        'deliveryMode.text': 'PHƯƠNG THỨC GỬI',
        'deliveryMode.email': 'Sao kê điện tử (Email)',
        'deliveryMode.address': 'Sao kê giấy',
        deliveryModeconfirm: 'PHƯƠNG THỨC GỬI',
        address: {
          mode: 'Sao kê giấy',
          text: 'Địa chỉ thư tín',
          'check.text': 'Xem địa chỉ',
          'message.text':
            'Chúng tôi sẽ gửi bản sao kê đến địa chỉ đã đăng ký của Quý khách. Quý khách vui lòng đảm bảo địa chỉ là chính xác trước khi tiến hành bước tiếp theo.',
          'message.text.desktop':
            'Chúng tôi sẽ gửi bản sao kê đến địa chỉ đã đăng ký của Quý khách. Quý khách vui lòng đảm bảo địa chỉ là chính xác trước khi tiến hành bước tiếp theo.'
        },
        email: {
          mode: 'Sao kê điện tử',
          text: 'Địa chỉ email',
          'check.text': 'Xem Email',
          'message.text':
            'Chúng tôi sẽ gửi bản sao kê đến địa chỉ email đã đăng ký của Quý khách. Quý khách vui lòng đảm bảo địa chỉ email là chính xác trước khi tiến hành bước tiếp theo.',
          'message.text.desktop':
            'Chúng tôi sẽ gửi bản sao kê đến địa chỉ email đã đăng ký của Quý khách. <br> Quý khách vui lòng đảm bảo địa chỉ email là chính xác trước khi tiến hành bước tiếp theo.'
        }
      },
      countryNotes: {
        default:
          '<div><b>Bảng Sao Kê Tài khoản:</b></div><ul><li>Đối với danh sách các giao dịch trong vòng 1 năm gần nhất, Quý khách có thể tải ngay từ mục Tài khoản > Lịch sử giao dịch.</li><li>Yêu cầu cấp lại bảng sao kê tại mục này theo <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/interest-rates/\',\'_system\')">Biểu phí</a> hiện hành. Quý khách vui lòng đảm bảo đủ số dư trong tài khoản cho việc thu phí.</li><li>Sao kê điện tử sẽ được thực hiện trong vòng 3 ngày làm việc. Sao kê giấy sẽ được thực hiện trong vòng 5 ngày làm việc.</li></ul><br><div><b>Bảng Sao Kê Thẻ Tín Dụng:</b></div><ul><li>Tính năng này phục vụ yêu cầu gửi lại Sao kê điện tử cho Thẻ Tín Dụng trong thời gian 1 năm kể từ hôm nay.</li><li>Trong trường hợp yêu cầu Sao kê điện tử cho Thẻ Tín Dụng cũ hơn 1 năm hoặc yêu cầu Sao kê Giấy có xác nhận của Ngân hàng, Quý khách vui lòng liên hệ Trung Tâm Tư Vấn Khách Hàng (24/7) số +842839110000.</li><li>Yêu cầu sẽ được xử lý trong vòng 1 ngày làm việc.</li></ul><br>Nếu Ngày bắt đầu Sao kê trước Ngày mở tài khoản, ngân hàng sẽ truy xuất thông tin từ Ngày mở tài khoản.<br>Bảng Sao kê sẽ được gửi đến email hoặc địa chỉ bưu điện Quý khách đã đăng ký. Quý khách vui lòng đảm bảo email/ địa chỉ đăng ký đã được cập nhật trước khi gửi yêu cầu.',
        account:
          '<div><b>Bảng Sao Kê Tài khoản:</b></div><ul><li>Đối với danh sách các giao dịch trong vòng 1 năm gần nhất, Quý khách có thể tải ngay từ mục Tài khoản > Lịch sử giao dịch.</li><li>Yêu cầu cấp lại bảng sao kê tại mục này theo <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/interest-rates/\',\'_system\')">Biểu phí</a> hiện hành. Quý khách vui lòng đảm bảo đủ số dư trong tài khoản cho việc thu phí.</li><li>Sao kê điện tử sẽ được thực hiện trong vòng 3 ngày làm việc. Sao kê giấy sẽ được thực hiện trong vòng 5 ngày làm việc.</li></ul><br><div><b>Bảng Sao Kê Thẻ Tín Dụng:</b></div><ul><li>Tính năng này phục vụ yêu cầu gửi lại Sao kê điện tử cho Thẻ Tín Dụng trong thời gian 1 năm kể từ hôm nay.</li><li>Trong trường hợp yêu cầu Sao kê điện tử cho Thẻ Tín Dụng cũ hơn 1 năm hoặc yêu cầu Sao kê Giấy có xác nhận của Ngân hàng, Quý khách vui lòng liên hệ Trung Tâm Tư Vấn Khách Hàng (24/7) số +842839110000.</li><li>Yêu cầu sẽ được xử lý trong vòng 1 ngày làm việc.</li></ul><br>Nếu Ngày bắt đầu Sao kê trước Ngày mở tài khoản, ngân hàng sẽ truy xuất thông tin từ Ngày mở tài khoản.<br>Bảng Sao kê sẽ được gửi đến email hoặc địa chỉ bưu điện Quý khách đã đăng ký. Quý khách vui lòng đảm bảo email/ địa chỉ đăng ký đã được cập nhật trước khi gửi yêu cầu.',
        statement:
          '<div><b>Bảng Sao Kê Tài khoản:</b></div><ul><li>Đối với danh sách các giao dịch trong vòng 1 năm gần nhất, Quý khách có thể tải ngay từ mục Tài khoản > Lịch sử giao dịch.</li><li>Yêu cầu cấp lại bảng sao kê tại mục này theo <a href="javascript:;" onclick="window.open(\'https://www.sc.com/vn/interest-rates/\',\'_system\')">Biểu phí</a> hiện hành. Quý khách vui lòng đảm bảo đủ số dư trong tài khoản cho việc thu phí.</li><li>Sao kê điện tử sẽ được thực hiện trong vòng 3 ngày làm việc. Sao kê giấy sẽ được thực hiện trong vòng 5 ngày làm việc.</li></ul><br><div><b>Bảng Sao Kê Thẻ Tín Dụng:</b></div><ul><li>Tính năng này phục vụ yêu cầu gửi lại Sao kê điện tử cho Thẻ Tín Dụng trong thời gian 1 năm kể từ hôm nay.</li><li>Trong trường hợp yêu cầu Sao kê điện tử cho Thẻ Tín Dụng cũ hơn 1 năm hoặc yêu cầu Sao kê Giấy có xác nhận của Ngân hàng, Quý khách vui lòng liên hệ Trung Tâm Tư Vấn Khách Hàng (24/7) số +842839110000.</li><li>Yêu cầu sẽ được xử lý trong vòng 1 ngày làm việc.</li></ul><br>Nếu Ngày bắt đầu Sao kê trước Ngày mở tài khoản, ngân hàng sẽ truy xuất thông tin từ Ngày mở tài khoản.<br>Bảng Sao kê sẽ được gửi đến email hoặc địa chỉ bưu điện Quý khách đã đăng ký. Quý khách vui lòng đảm bảo email/ địa chỉ đăng ký đã được cập nhật trước khi gửi yêu cầu.'
      },
      error: {
        default: 'Vui lòng nhập tháng hợp lệ',
        startDate: {
          error1: 'Start Date should not be more than 7 years',
          error2: 'Tháng bắt đầu / kết thúc phải trước tháng của ngày hôm nay.',
          error3: 'Ngày bắt đầu nên trước ngày kết thúc'
        },
        endDate: {
          error1: 'End date should not be less than 7 years',
          error2: 'Tháng bắt đầu / kết thúc phải trước tháng của ngày hôm nay.',
          error3: 'Tháng kết thúc phải bằng hoặc lớn hơn Tháng bắt đầu'
        },
        creditCard: {
          startDate: {
            error1: 'Thời gian yêu cầu tối đa là 1 năm gần nhất.'
          },
          endDate: {
            error1: 'Thời gian yêu cầu tối đa là 1 năm gần nhất.'
          }
        },
        casa: {
          startDate: {
            error1: 'Thời gian yêu cầu tối đa là 5 năm gần nhất.'
          },
          endDate: {
            error1: 'Thời gian yêu cầu tối đa là 5 năm gần nhất.'
          }
        },
        commonError: {
          noEligible: 'Rất tiếc, Quý khách không có tài khoản/ thẻ đủ điều kiện để thực hiện yêu cầu này.',
          statmentInprogress:
            'Chúng tôi không thể xử lý yêu cầu của Quý khách tại thời điểm này vì có một yêu cầu Bảng sao kê khác đang được tiến hành.'
        },
        noData: {
          customerNotEligible: 'Xin lỗi, Quý khách hiện không có tài khoản đủ điều kiện cho dịch vụ này.',
          customerData: 'No eligible account for statement request.',
          loan: 'You do not have any eligible loans for this request.',
          casa: 'You do not have any eligible accounts for this request.',
          nodebitAcc: 'Quý khách không có tài khoản thực hiện thu phí cho yêu cầu này',
          default: 'You do not have any eligible cards for this request.'
        },
        casaError: {
          msg: "You may obtain past 12 months' statements from Online Banking."
        }
      }
    }
  },
  errors: {
    unknownError: 'An Unknown error occurred. Please try again.',
    serviceUnavailable: 'The internet banking service is currently unavailable. Please try again later.'
  },
  CARDCANCELLATION: {
    noCardsHeading: 'Không tìm thấy thẻ hợp lệ'
  },
  TRANSACTIONDISPUTE: {
    noCardsHeader: 'Rất tiếc, Quý khách không có Thẻ đủ điều kiện để thực hiện yêu cầu này.',
    limitInfo: 'Quý khách có thể chọn tối đa 10 giao dịch cho mỗi yêu cầu',
    noTransactions: 'Rất tiếc, Quý khách không có Giao dịch đủ điều kiện để thực hiện yêu cầu này.',
    reversalTransaction:
      'Xin lưu ý rằng có một khoản ghi có với cùng số tiền trong thẻ của Quý khách. Quý khách có muốn tiến hành khiếu nại này?',
    serviceNo: 'Số tham chiếu',
    reasonRequired: 'Vui lòng chọn một lý do khiếu nại'
  }
};
