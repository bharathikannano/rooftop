﻿// Simplified language

export default {
  FERE: {
    action: {
      modal: {
        message: 'Please confirm leave the form without submitting?',
        resetMessage: 'Are you sure you want to revert the change?'
      },
      button: {
        confirm: 'CONFIRM',
        cancel: 'CANCEL',
        YES: 'YES',
        NO: 'NO',
        edit: 'Edit'
      }
    },
    'validation.error.message': ' is required',
    page: {
      receipt: {
        title: 'Reference Number',
        description: 'Please quote this reference number for all future correspondences related to this request.',
        'button.blocked': 'Sorry, We are unable to proceed!'
      }
    }
  },
  ServiceRequest: {
    COMMON: {
      loadingIndicatorText: '加载中...',
      'notes.title': '注意事项',
      'creditcard.title': '信用卡',
      'debitcards.title': '提款卡',
      'nocard.header': '未能侦测任何适用的卡',
      'nocard.content': '阁下并无适用的卡',
      'errorcard.header': 'Unable to retrieve card details.',
      'errorcard.content': 'Please contact 24/7 Phone Banking team for immediate assistance.',
      'debit.header': '未能侦测任何适用的卡',
      'debit.content': '阁下并无适用的卡',
      'credit.header': '未能侦测任何适用的卡',
      'credit.content': '阁下并无适用的卡',
      backToHelpAndServicesText: '您确定要退回帮助和服务吗？',
      backToiBankText: '您确定要返回帐户概览/主页吗？',
      backToiBankBefAckText: '是否确认回到主页并取消申请?',
      backToMobileBankText: '您确定要返回帐户概览/主页吗？',
      backToMobileBankBefAckText: '是否确认回到主页并取消申请?',
      genericError: {
        HK: '我们暂时未能处理阁下的申请。请致电本行：渣打电话理财客户服务热线 (包括提款卡) (852) 2886 8888',
        HKCB:
          '我们暂时未能处理阁下的申请。请致电本行：渣打信用卡24小时客户服务热线 (852) 2886 4111；渣打电话理财客户服务热线 (包括提款卡) (852) 2886 8888 参考编号：',
        HKCR: '我们暂时未能处理阁下的申请。请致电本行：渣打信用卡24小时客户服务热线 (852) 2886 4111'
      },
      systemError: '抱歉，我们未能处理阁下之支票簿申请。如有查询请致电28868868。',
      'systemError.HK': '抱歉，我们未能处理阁下之支票簿申请。如有查询请致电28868868。',
      'systemError.title': '系统错误',
      termsAndConditions:
        '1.此条款和条件XXXXXXXXXXXXXX。<br>2.到了五角大楼可挖掘的洛克菲勒连裤袜法赫卡里。<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3<br>3.手动哈是来可几来恢复和 i 哦请问 i 那次哦会成为情侣可大可久了就去看了我3',
      'termsAndConditions.title': '条款 & 条件',
      breadcrumbHome: '你正在首页',
      refNumber: '参考编号。',
      cardTypenocardsTit: 'No eligible card detected.',
      cardTypenocardsDesc:
        'The selected account(s) to be linked does not have any eligible card for replacement. Kindly select other account(s) to proceed or contact our <a href="javascript:;">24/7 Phone Banking</a> for assistance.',
      cardTypeErrornocardsTit: '未能显示资料',
      cardTypeErrornocardsDesc: '我们暂时未能显示阁下户口资料<br>请选择其他户口或稍后再试',
      progress: {
        title1: '输入数据',
        title2: '确认数据',
        title3: '请选择',
        title4: '选择提款卡设计',
        steptxt: '步骤',
        step1: '步驟一/ 共二步',
        step2: '步驟二/ 共二步',
        step12: '步骤1/2',
        step22: '步骤2/2',
        step13: '步骤1/3',
        step23: '步骤2/3',
        step33: '步骤3/3',
        step14: '1 之 4',
        step24: '2 之 4',
        step34: '3 之 4',
        step44: '4 之 4',
        success: '成功',
        submit: '已递交',
        failure: '失敗',
        incomplete: '部分失败',
        syserror: '系统错误',
        submitted: '已递交',
        plsselect: '请选择'
      },
      text: {
        selectAll: '选择全部',
        deselectAll: '取消选择全部',
        english: '英文',
        chinese: '中文',
        new: 'New'
      },
      button: {
        cancel: '取消',
        next: '下一步',
        ok: '好',
        confirm: '确认',
        yes: '是',
        no: '否',
        done: '完成',
        back: '上一步',
        loadMore: '查看更多',
        sNext: '下一步',
        sPrev: '返回',
        proceed: '继续',
        close: '关闭',
        cancelrequest: '取消申请',
        showAll: '展示全部',
        viewStatus: '查看状态',
        sltcard: '选择卡',
        save: '保存',
        activateAnotherCard: '为另一张提款卡设定密码'
      },
      subCategoryText: {
        feeWaver: '费用豁免',
        cardCancellation: '取消信用卡 ',
        cardBlock: '报失卡',
        cardBlock1: '报失卡',
        cardBlock2: '报失卡',
        cardReplace: '申请补发卡',
        cardReplace1: '补发信用卡',
        cardReplace2: '重新发行借记卡',
        chequeRequest: '支票簿',
        cardReplacement: '换卡换卡',
        cardReplacement1: '换卡换卡',
        cardReplacement2: '换卡换卡',
        cardActivation: '启用信用卡',
        profileSettings: '更新个人资料',
        pinChange: '设立/更改密码',
        sltatm: '选择提款机语言',
        linkaccount: '重新选择提款卡包括的户口',
        refNo: '参考编号',
        sltCardtoreplace: '选择要补发的卡',
        atmLang: '柜员机语言',
        cardDesign: '提款卡设计'
      },
      categoryText: {
        creditCard: '信用卡',
        personalDetails: '个人资料',
        accountManagement: '户口',
        cardManagement: '信用卡/提款卡管理'
      },
      mostPopularRequests: {
        cardBlock: '报失卡',
        replaceCards: '补发卡',
        replaceCards1: '补发卡',
        replaceCards2: '补发卡',
        chequeBookRequest: '支票簿',
        profileUpdate: '更新个人资料<span id="landing-popular-subtext">查阅并更新个人资料.</span>'
      },
      contactLinks: {
        HK: ''
      },
      contactLinksTxt: {
        default: '24/7电话银行'
      }
    },
    COMMONERROR: {
      'CSL-1406': 'Date/Time format is invalid',
      'CSL-1344': 'Invalid Transaction Reference Number',
      'CSL-1328': 'Max retry limit reached',
      'CSL-1320': 'Pin Reset Failed',
      'CSL-1318': 'Key not found',
      'CSL-1303': 'Random challenge expired',
      'CSL-1302': 'Random challenge expired',
      'CSL-1304': 'Invalid random challenge',
      'CSL-1252': 'Pin block generation failed',
      'CSL-1225': 'Query failed',
      'CSL-1200': 'Invalid parameters',
      'CSL-1212': 'Encryption/Decryption error',
      'CSL-1211': 'Database/SQL error',
      'CSL-1034': 'Pin Reset Request Timed out',
      'CSL-1032': 'Pin Reset Request failed',
      'CSL-1702': 'EN - This is 1702'
    },
    CARDREPLACEMENT: {
      'header.title': '申请补发卡',
      'header.title1': '申请补发卡',
      'header.title2': '申请补发卡',
      cardlistHeader1: '选择要补发的卡',
      cardlistHeader2: '将被补发的卡',
      cardlistHeader3: '阁下的补发卡',
      cardlistHeader4: 'Select debit cards to replace',
      cancelPopup: '是否取消阁下的补发卡申请',
      countryLinks: {
        HK: 'https://www.sc.com/global/av/hk-service-charges-en.pdf'
      },
      countryLinksTxt: {
        default: '费用表'
      },
      countryNotes: {
        HK:
          '阁下可以透过此表格递交指示为已损坏或已报失之信用卡申请补发新卡<br>如阁下遗失信用卡而尚未报失，请递交报失信用卡指示<br>为已报失之信用卡申请补新卡的限期为九十天<br>补发卡将会送到阁下已注册之通讯地址<br>如阁下需要停用之信用卡未被列出，请即联络渣打信用卡24小时客户服务热线(852) 2886 4111<br>当主卡被停用，所有该主卡之附属卡将同时被停用'
      },
      statusMsg: {
        success: '阁下的补发卡申请已被递交。补发卡申请状况可在支援与服务查阅。',
        failure:
          '我们暂时未能处理阁下的申请。如有查询，请致电本行：渣打信用卡24小时客户服务热线 (852) 2886 4111；渣打电话理财客户服务热线 (包括提款卡) (852) 2886 8888',
        incomplete:
          '我们暂时未能处理阁下的申请。如有查询，请致电本行：渣打信用卡24小时客户服务热线 (852) 2886 4111；渣打电话理财客户服务热线 (包括提款卡) (852) 2886 8888'
      }
    },
    CARDBLOCK: {
      'header.title': '申请补发卡',
      cardlistHeader1: '选择要补发的卡',
      cardlistHeader2: '将被补发的卡',
      cardlistHeader3: '阁下的补发卡',
      cardlistSubHeader: '如阁下需要报失之信用卡未被列出，请即联络本行之 24 小时客户服务热线。',
      cancelPopup: '是否取消报失卡申请',
      selectreason: {
        header: '我想报失卡因为',
        placeholder: '选择原因',
        reasonToBlock: '原因',
        reason1: '我遗失了卡',
        reason2: '我的卡被盗',
        reason3: '我的卡被扣置在自动柜员机'
      },
      countryLinks: {
        HK: 'https://www.sc.com/global/av/hk-service-charges-en.pdf'
      },
      countryLinksTxt: {
        default: '费用表'
      },
      countryNotes: {
        HK:
          '<b>有关报失信用卡</b><ul><li>一经确认，阁下的信用卡会被立即停用</li><li>已被停用的信用卡将不能被使用</li><li>已被停用的信用卡不能被再次启用</li><li>阁下仍需为信用卡停用前的交易负责；阁下可致电 (852) 2886 4111提出争议账项查询</li><li>当主卡被停用，所有该主卡之附属卡将同时被停用</li><li>补发之新卡将会送到阁下已注册之通讯地址</li><li>如阁下需要报失的信用卡未被列出，请致电 (852) 2886 4111</li></ul><br><b>有关报失提款卡</b><ul><li>一经确认，阁下的提款卡会被立即停用</li><li>已被停用的提款卡将不能被使用</li><li>已被停用的提款卡不能被再次启用</li><li>经此报失提款卡后，阁下可以透过递交「补发提款卡」申请，以申请补发新提款卡</li><li>如阁下需要报失的提款卡未被列出，请致电(852) 2886 8888</li></ul>'
      },
      statusMsg: {
        success:
          '我们暂时未能处理阁下的申请。如有查询，请致电本行：渣打信用卡24小时客户服务热线 (852) 2886 4111；渣打电话理财客户服务热线 (包括提款卡) (852) 2886 8888',
        failure:
          '我们暂时未能处理阁下的申请。请致电本行：渣打信用卡24小时客户服务热线 (852) 2886 4111；渣打电话理财客户服务热线 (包括提款卡) (852) 2886 8888 参考编号：',
        incomplete:
          '部份卡未被成功处理。请致电本行：渣打信用卡24小时客户服务热线 (852) 2886 4111；渣打电话理财客户服务热线 (包括提款卡) (852) 2886 8888'
      }
    },
    CHEQUEBOOK: {
      'header.title': '支票簿',
      accountsList: '户口',
      selectAccountList: '选择要申请支票簿的户口',
      countryNotes: {
        IN:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>The cheque book will be dispatched to your mailing address as available in our records and will reach you within 7 working days.</li><li>If you have recently changed your address, please get it updated in our records immediately. Address update in our system will be processed within 4 working days of submitting the address change request.</li><li>You can request for one cheque book for your account in a day. For bulk request, kindly submit a written request at your nearest branch.</li></ol>',
        SG:
          '<ol><li>Only eligible accounts for this request are shown.</li><li>Cheque books will be sent to the account\'s mailing address in our records.</li><li>Please ensure your address with us is up to date before submitting this request. If you have submitted an address change, please note that this takes three working days to update in our system.</li><li>Charges may apply. Please see our <a  href="https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf" target="_blank">fee schedule</a> for more details.</li></ol>',
        MY:
          '<ol><li>Only eligible accounts for this request are shown.</li><li>Cheque books will be sent to the mailing address in our records. Joint account cheque books will be sent to the primary account holder\'s mailing address.</li><li>Please ensure your address with us is up-to-date before submitting this request. If you have submitted an address change,please note that this takes five working days to update in our system.</li><li>Charges may apply. Please see our <a  href="https://www.sc.com/global/av/my-fees-and-charges-27-apr-2017.pdf" target="_blank">fee schedule</a> for more details.</li><li>If you mailing address is a PO Box address,please do not proceed and call our Contact Center for placing this request.</li></ol>',
        HK: '<ol><li>只会显示适用之户口</li><li>支票簿将会在七个工作天内邮寄至阁下的通讯地址。</li></ol>',
        AE:
          '<ol><li>Only accounts eligible for this request are shown.</li><li>Cheque book(s) will be sent to your registered mailing address.</li></ol>',
        default:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>Cheque Book will be sent to your Registered mailing address.</li></ol>'
      },
      statusMsg: {
        success: '您的请求已提交.<br>您的支票簿將發送到我們的記錄中的郵寄地址.',
        failure: '我们目前无法处理您的请求。请再次尝试提交请求，或联系我们的24小时电话银行服务以获得帮助。参考＃',
        incomplete:
          '以下某些卡未被处理。如果问题仍然存在，请尝试再次提交请求或联系我们的24小时电话银行服务以获得帮助。参考＃',
        HK: '阁下的申请已被递交<br>支票簿将会被送到阁下的通讯地址。'
      },
      referenceNumber: '参考编号',
      noAccount: '没有可以启动支票簿请求的符合条件的帐户。请联系您的关系经理或联系呼叫中心或分行',
      'selectAccount.title': '选择',
      'confirmAccount.title': '确认资料',
      confirmCancelText: '要取消您的支票簿请求吗？',
      noAccountWarningText: {
        IN:
          'We are unable to process your request as you do not have any eligible accounts for cheque book. Kindly contact our phone banking team or visit our branches for assistance.',
        SG: 'ERR_CHQ_002 - Sorry, you do not have any accounts that are eligible for this request.',
        HK: '抱歉，阁下并无适用之户口作支票簿申请'
      }
    },
    STATUSENQUIRY: {
      'header.title': '状态',
      'activeSection.title': '处理中',
      'completedSection.title': '已完成',
      statusReferenceNo: '编号',
      statusUpdatedDate: '预计完成日期:',
      statusCardReplacement: '补发卡状态:',
      statusCardReplacementM: '补发卡状态:',
      statusUpdateDateMobile: '预计完成日期:',
      noActiveRequest: '无任何处理中的申请',
      statusOfRecords: '只显示过去九十日之纪录',
      labelReceive: '已接收',
      labelProcessing: '处理中',
      labelCompleted: '已完成',
      labelRejected: '拒絕',
      labelSuccess: '成功',
      labelFailed: '失敗',
      updatedDate: '更新自',
      dateSubmitted: '递交日期',
      'account/relationshipNo': '户口号码',
      creditCard: '已报失的信用卡',
      debitCard: '已报失的提款卡',
      ccCancellation: 'Card Account(s)',
      creditCardReplace: '补发信用卡',
      debitCardReplace: '补发提款卡',
      debitCardIssuance: '申请提款卡'
    },
    LANDINGPAGE: {
      tabText: {
        createRequest: '申请',
        status: '状态'
      },
      'header.title': '支援及服务',
      noResultsFound: '没有结果',
      needHelp: '我需要为',
      regardsTo: '申请',
      popularServices: '常用服务申请',
      popularServicesCI: '服务申请',
      allServicesCategory: '所有服务',
      'help&usefulLinks': '常用连结',
      search: '搜寻...'
    },
    STATEMENTREQUEST: {
      'header.title': 'Statement Request',
      'selectAccount.title': 'Select an Account ',
      'account.title.text': 'Select an account to request for a hardcopy statement',
      'date.selection.label': 'Select Source Date',
      'casa.title.text': 'Current/Savings Account',
      'creditcard.title.text': 'Credit Card',
      notes:
        "Fee may be apply depending on the statement requested. Please check Bank's <a>fee schedule</a> for more information.<br> <br>Your statement will be sent to your registered mailing address. Please ensure your address is correct. Contact <a>24/7 Phone Banking</a> if you wish to update your address.",
      'confirm.title.text': 'Confirm Details',
      'account.label': 'Account Number',
      'statement.label': 'Statement Option',
      'statement.date.label': 'Statement Date',
      'statusMsg.success':
        'Your request has been submitted. You can track your statement status online via Service Request Status Enquiry.',
      referenceNumber: 'Reference Number',
      'account.type': 'Account Type',
      'statement.date': 'Statement Date',
      'cc.title.text': 'Credit Card'
    },
    DEBITCARDREPLACEMENT: {
      'header.title': '补发提款卡',
      'header.title1': '新提款卡申请',
      replaceCardTitle: '补发',
      selectLanguageTitle: 'Select language for the ATM',
      accountIncludeTitle: '提款卡包括以下户口种类',
      primaryAccountTitle: '主要户口',
      otherAccountTitle: '其他戶口',
      replacementFeeTitle: '补发卡费用',
      replacementFeeSubtitle: '扣除费用自',
      replaceCardwith: '补发',
      sltcardType: '选择提款卡种类',
      sltdebitType: '选择提款卡种类',
      primaryAccountLinked: '基本户口号码',
      otherAccountLinked: '其他户口号码',
      countryLinks: {
        HK: 'https://www.sc.com/hk/zh/help-centre/service-charges.html'
      },
      countryLinksTxt: {
        default: '费用表',
        HK:
          '本行有权自行决定是否签发新卡并按照本行不时厘定之收费，由客户户口扣除相应补发新卡之款项。客户请参阅「服务收费－银行服务收费一覧表」 以了解有关服务之最新收费'
      },
      countryNotes: {
        HK:
          '阁下可以透过此表格申请补发已损坏或已报失的提款卡<br>如阁下遗失提款卡而未报失，请选择「报失卡申请」<br>{{inter_link}}<br>补发卡将会送到阁下已注册之通讯地址<br>如阁下想补发的提款卡未被列出，请致电本行(852) 2886 8888'
      },
      statusMsg: {
        successReplacement: '阁下的补发卡申请已被递交。补发信用卡状况可在「支援与服务」查阅。',
        success: '阁下的申请已被递交。提款卡申请状况可在「支援与服务」查阅。'
      }
    },
    CCFEEWAVIER: {
      submitted: '成功提交',
      annualFee: '信用卡年费',
      'selectAccount.title': '请选择',
      'header.title': '信用卡费用豁免',
      'selectreason.placeholder': '选择费用类型',
      selectDate: '选择费用',
      'selectreason.header': '我想申请年费豁免',
      'selectreason.header.mob': '费用类型*',
      'selectreason.header.charger': "I'd like to charge",
      'specifyreason.placeholder': 'specify other fee',
      'cardlist.header': '请选择信用卡',
      'cardlist.header.mob': '选择申请豁免的费用',
      'feeselect.header': 'Eligible Card(s)',
      'feeselect.subheader': 'The charged fees reflected below can be offset using your reward points.',
      'feetype.title': '费用类别',
      'countryNotes.notes':
        'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline.',
      'cards.title': '信用卡',
      'reward.alert': 'Rewards Points available',
      'reward.alert.msg': 'Do you want to use your available rewards points for these fees?',
      'reward.alert.button.yes': 'Yes, use points',
      'reward.alert.button.no': 'No, don’t use points',
      'notes.title': '备注',
      'reward.remain': 'REMAINING REWARD POINTS',
      'reward.point.display.heading': 'Available Rewards Points',
      'reward.point.display.subheading': 'Total points across all cards as on date',
      'creditcard.title': '信用卡',
      'reason.feewavier': 'REASON FOR FEEWAVIER',
      'reason.charge': 'REASON FOR CHARGE',
      'reason.override': 'Reason For Over-ride',
      'text.systemError.content':
        'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
      'progress.subheader1': '请选择',
      'progress.stepTxt1of3': '1 of 3',
      'progress.stepTxt2of3': '2 of 3',
      'progress.stepTxt3of3': '3 of 3',
      'progress.stepTxt1of2': '1 of 2',
      'progress.stepTxt2of2': '2 of 2',
      'progress.stepTxt': '1 of 3',
      'basic.placeholder': '请选择',
      'add.placeholder': 'Please Select',
      ReferNo: '参考号码',
      'selectReason.placeholder.reversal': 'Select Reason For Reversal',
      'selectReason.placeholder': 'Select Reason For Charge',
      'selectReason.placeholder.override': 'Select Reason For Over-ride',
      'hotline.contact': 'Kindly contact our 24 hour Phone Banking hotline on 1800 747 7000 for further assistance.',

      statusMsg: {
        success: '已成功提交申请，<br>您将在3个工作天内收到申请结果通知。',
        hksuccessmsg: '已成功提交申请，<br>您将在3个工作天内收到申请结果通知。',
        failure:
          'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance. Reference #',
        incomplete:
          'Some of your cards below did not get processed. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance if the issue persists. Reference #'
      },
      referenceNumber: '参考号码',
      noAccount:
        'There are no eligible Accounts for which Cheque Book Request can be initiated. Please Contact your Relationship Manager or Contact Call Centre or Branch',
      'confirmAccount.title': '确认资料',
      confirmCancelText: 'Do you want to cancel your Cheque Book request?',
      noAccountWarningText: {
        IN:
          'We are unable to process your request as you do not have any eligible accounts for cheque book. Kindly contact our phone banking team or visit our branches for assistance.',
        SG:
          'We are unable to process your request as you do not have any eligible accounts for cheque book. Kindly contact our phone banking team hotline at 1800 747 700 or visit our branches for assistance.'
      },

      button: {
        okDone: 'OK, Done',
        back: '返回'
      },

      countryLinks: {
        IN: 'https://www.sc.com/in/help-centre/service-charges-fees.html',
        // 'SG': 'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf',
        SG: 'https://www.sc.com/sg/help/contact-us.html'
      },
      countryLinksTxt: {
        IN: '24/7 Phone Banking hotline',
        SG: '24/7 Phone Banking hotline',
        HK: '2886-4111'
      },
      countryNotes: {
        IN:
          'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline at  {{inter_link}}.<br>Only the eligible credit card will be shown. If you do not see your credit card, please contact our 24-hour Customer Service Hotline at {{inter_link}}',
        SG:
          'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline at  {{inter_link}}.<br>Only the eligible credit card will be shown. If you do not see your credit card, please contact our 24-hour Customer Service Hotline at {{inter_link}}',
        HK: '系统只会显示合资格的信用卡。 如未能显示您的有关信用卡，请致电我们的24小时客户服务热线。'
      },
      validationCountryNotes: {
        IN: 'Kindly contact our {{inter_link}} for further assistance.',
        SG: 'Kindly contact our {{inter_link}} for further assistance.',
        HK: ''
      },
      countryNotesTransactionPage: {
        IN: 'Only cards eligible for fee waiver will be shown.',
        SG: 'Only cards eligible for fee waiver will be shown.',
        HK: '只有符合减免费用的卡才会显示。'
      },
      OtherChannelError: 'We are unable to process your request ,It is not valid channel',
      errorText: '如有查詢，請聯絡我們的24小時客戶服務熱線 {{inter_link}}。',
      cardLimitMsg: '每次申请只可选择不多于5张信用卡'
    },
    CREDITCARD: {
      cardSetting: {
        journeyHeader: '信用卡设置',
        notSaveConfirm: 'If you go back, your settings will not be saved.',
        settingsTitle: {
          transactionLimit: '交易限额',
          paymentChannels: '付款频道',
          controlledCatagories: '受控类别',
          countryLimits: '国家限制'
        },
        selectPage: {
          pageHeader: '选择一张信用卡',
          sectionHeader: '选择一张信用卡并设置',
          sectionHeaderMob: '选择一张信用卡并设置'
        },
        cardSettingsPage: {
          pageHeader: '设置信用卡设置',
          sectionHeader: '设置您的信用卡设置',
          sectionHeaderMob: '设置您的信用卡设置',
          termsAndConditions: '通過啟用此功能，您接受 '
        },
        paymentChannelsPage: {
          paymentChannelNotifications: '付款渠道通知',
          paymentChannelNotificationsContent: '在通过以下付款渠道进行交易时收到通知。',
          blockCheckbox: '阻止通过这些付款渠道进行的交易',
          optionItem1: '在线电子商务',
          optionItem2: '非接触式',
          optionItem3: '物理销售点',
          optionContent1: '在线支付是您在网站或应用程序中输入您的卡详细信息的地方。',
          optionContent2: '联系付款是指您必须在支付终端上实体刷卡或插入您的卡。',
          optionContent3:
            '通过在支付终端附近挥动卡片或使用移动设备数字钱包进行付款（例如Apple Pay，Android Pay，Google Pay，Samsung Pay等），您可以在非接触式付款中使用您的卡。'
        },
        isPrimary: {
          primary: '主卡',
          supplementary: '附属卡'
        },
        transactionLimitPage: {
          transactionNotifications: '交易通知',
          transactionNotificationsContent: '每笔交易超过限额时将被通知。',
          limitAmountTitle: '限额',
          blockCheckbox: '阻止高于规定限制的交易',
          maxLimitAlert: '请输入低于_AMOUNT_的金额。',
          minLimitAlert: '请输入高于_AMOUNT_的金额。',
          errorNumType: '请输入正确的金额。'
        },
        controlledCategories: {
          controlledCategoryNotifications: '受控类别通知',
          controlledCategoryNotificationsContent: '在进行属于以下类别的交易时收到通知。',
          blockCheckbox: '阻止属于这些类别的交易',
          optionItem1: '成人娱乐',
          optionItem2: '赌博场所',
          optionItem3: '在线游戏网站',
          optionItem4: '酒吧和夜总会'
        },
        countryLimitsPage: {
          countryNotifications: '国家通知',
          countryNotificationsContent: '在下列任何一个国家/地区进行交易时都会收到通知。',
          blockCheckbox: '阻止在这些国家进行的交易',
          overseaCardUsage: '阻止海外卡的使用',
          selectedCountry: '阻止选定的国家',
          selectCountryContent: '选择国家',
          addCountryContent: '+ 添加国家/地区',
          countryLimitExplain: '通过阻止特定国家，您将无法再使用您的卡在这些国家进行交易。',
          overseaCardUsageContent: '阻止在发卡所在的国家以外进行的交易。 网上交易不会受到影响。'
        },
        TMPBLOCKTXT: '暂停此卡',
        NOTICE: {
          TMPBLOCK: '您将暂停此卡。 此卡的交易在重新启用之前将被阻止。',
          ERROR: '发生错误，您的设置无法保存。请再试一次。'
        },
        noCards: {
          content2: '立即申请信用卡进行配置。',
          label1: '临时锁卡',
          label2: '交易限制',
          label3: '付款渠道',
          label4: '受控类别',
          label5: '国家使用限制',
          button: '现在申请'
        }
      },
      pinSetup: {
        journeyHeader: 'Credit Card PIN Setup/Change',

        selectPage: {
          pageHeader: 'Select a Credit Card',
          sectionHeader: 'SELECT A CREDIT CARD TO SETUP A PIN',
          sectionHeaderMob: 'Select a Credit Card to setup a PIN',
          nocardHeader: 'No eligible card detected.',
          nocardContent: 'Sorry, you do not have any eligible Credit Card(s) for this request.'
        },
        pinChange: {
          pageHeader: 'Set Credit Card PIN',
          sectionHeader: 'SET YOUR NEW CREDIT CARD PIN',
          sectionHeaderMob: 'Set your new Credit Card PIN',
          newPin: '输入提款卡新密码',
          reEnterPin: '再次输入提款卡新密码',
          newPinMob: 'Enter New PIN',
          reEnterPinMob: 'Re-Enter PIN',
          pinNotSame: 'Entered PIN numbers are not same',
          pinNotAsGuideline: 'Invalid PIN, please enter PIN as per the guidelines'
        },
        countryNotes: {
          IN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/in/contact-us/#talk-to-us'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          SG:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 5-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To authenticate your PIN change, we will send you an OTP at your registered mobile number. Please ensure you have this ready for reference.</li><li>You should always memorise your PIN. Do not reveal your 5-digit PIN to anyone or record it anywhere.</li><li>Avoid using numbers for your PIN that may be easily guessed, such as your birthday, NRIC, phone number, sequential numbers (eg. 12345) etc.</li></li></ol>",
          HK:
            '<ol><li>切勿将密码告知他人。</li><li>切勿将密码写在您的卡上或任何接近卡之物件。</li><li>切勿使用香港身份证号码、电话号码、出生日期或其他个人资料作为您的密码。</li><li>切勿使用与您用于连接其他服务相同的资料，例如电邮、其他互联网网站/ISP或电话银行TIN(电话理财交易密码)。</li><li>应定期更新您的密码。</li><li>应在怀疑已被盗用或受损时更改您的密码。</li><li>如有查询，请致电我们。渣打提款卡：(852) 2886-8888 渣打信用卡：(852) 2886-4111 MANHATTAN 信用卡： (852) 2881-0888</li></ol>',
          MY:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/my/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          AE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/ae/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          KE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that is sent to your registered mobile number.</li><li>We recommend that you memorize your 4-digit PIN, do not record it anywhere, divulge or share it with anyone.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or the same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Call us on 254203293900 in case you observe any unauthorized transactions in your account.</li></ol></li></ol>",
          NG:
            '<ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>Do not reveal your 4-digit PIN to anyone. Memorise your PIN and do not record it anywhere.</li><li>Do not use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Contact Centre Team immediately in case of any unauthorized transactions observed in your account.</li></ol>',
          GH:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          BW:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          ZM:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>"
        },
        status: {
          refNo: 'REFERENCE NUMBER',
          refNoSmall: '参考编号',
          cardDetails: '卡资料',
          success: 'Success',
          failed: 'Failed!',
          transactionSuccessMsg: 'You have successfully reset your Credit Card PIN.',
          transactionSuccessFailure: {
            IN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            SG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            MY:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 1 300 888 888/ +603 7711 8888 for any assistance.',
            HK:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            AE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 600 5222 88 for any assistance.',
            KE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 254 20 329 3900 for any assistance.',
            NG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 01 2704611 - 4 for any assistance.',
            GH:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 0302 740100 for any assistance.',
            BW:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on +267 3615800 for any assistance.',
            ZM:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 5247  for any assistance.'
          },
          transactionSuccessInComplete:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.'
        }
      },
      activation: {
        journeyHeader: 'Credit Card Activation/PIN Setup',
        selectPage: {
          pageHeader: 'Select a Credit Card',
          sectionHeader: 'SELECT A CARD YOU WANT TO ACTIVATE',
          sectionHeaderMob: 'Select a Credit Card to setup a PIN',
          nocardHeader: 'No eligible card detected.',
          nocardContent: 'Sorry, you do not have any eligible Credit Card(s) for this request.'
        },
        pinChange: {
          pageHeader: 'Set Credit Card PIN',
          sectionHeader: 'SET YOUR NEW CREDIT CARD PIN',
          sectionHeaderMob: 'Set your new Credit Card PIN',
          newPin: '输入提款卡新密码',
          reEnterPin: '再次输入提款卡新密码',
          newPinMob: 'Enter New PIN',
          reEnterPinMob: 'Re-Enter PIN',
          pinNotSame: 'Entered PIN numbers are not same',
          pinNotAsGuideline: 'Invalid PIN, please enter PIN as per the guidelines'
        },
        disclaimerNotes: {
          AE:
            'DISCLAIMER : Please ensure you have the plastic with you before you proceed for Activation and Pin Set request'
        },
        countryNotes: {
          IN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/in/contact-us/#talk-to-us'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          SG:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 5-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To authenticate your PIN change, we will send you an OTP at your registered mobile number. Please ensure you have this ready for reference.</li><li>You should always memorise your PIN. Do not reveal your 5-digit PIN to anyone or record it anywhere.</li><li>Avoid using numbers for your PIN that may be easily guessed, such as your birthday, NRIC, phone number, sequential numbers (eg. 12345) etc.</li></li></ol>",
          HK:
            '<ol><li>切勿将密码告知他人。</li><li>切勿将密码写在您的卡上或任何接近卡之物件。</li><li>切勿使用香港身份证号码、电话号码、出生日期或其他个人资料作为您的密码。</li><li>切勿使用与您用于连接其他服务相同的资料，例如电邮、其他互联网网站/ISP或电话银行TIN(电话理财交易密码)。</li><li>应定期更新您的密码。</li><li>应在怀疑已被盗用或受损时更改您的密码。</li><li>如有查询，请致电我们。渣打提款卡：(852) 2886-8888 渣打信用卡：(852) 2886-4111 MANHATTAN 信用卡： (852) 2881-0888</li></ol>',
          MY:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/my/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          AE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/ae/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          KE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that is sent to your registered mobile number.</li><li>We recommend that you memorize your 4-digit PIN, do not record it anywhere, divulge or share it with anyone.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or the same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Call us on 254203293900 in case you observe any unauthorized transactions in your account.</li></ol></li></ol>",
          NG:
            '<ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>Do not reveal your 4-digit PIN to anyone. Memorise your PIN and do not record it anywhere.</li><li>Do not use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Contact Centre Team immediately in case of any unauthorized transactions observed in your account.</li></ol>',
          GH:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          BW:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          ZM:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>"
        },
        status: {
          refNo: 'REFERENCE NUMBER',
          refNoSmall: '参考编号',
          cardDetails: '卡资料',
          success: 'Success',
          failed: 'Failed!',
          transactionSuccessMsg: 'Your credit card is activated and PIN has been set successfully.',
          transactionSuccessFailure: {
            IN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            SG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            MY:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 1 300 888 888/ +603 7711 8888 for any assistance.',
            HK:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            AE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 600 5222 88 for any assistance.',
            KE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 254 20 329 3900 for any assistance.',
            NG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 01 2704611 - 4 for any assistance.',
            GH:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 0302 740100 for any assistance.',
            BW:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on +267 3615800 for any assistance.',
            ZM:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 5247  for any assistance.'
          },
          transactionSuccessInComplete:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.'
        }
      },
      validation: {
        pinNotSame: {
          IN: 'Please ensure both 6-digit PIN values entered are the same.',
          SG: 'Sorry, the PIN does not match. Please re-enter the correct PIN.',
          MY: 'Please ensure both 6-digit PIN values entered are the same.',
          HK: 'Please ensure both 6-digit PIN values entered are the same.',
          AE: 'Please ensure both 4-digit PIN values entered are the same.',
          KE: 'Please ensure both 4-digit PIN values entered are the same.',
          NG: 'Please ensure both 4-digit PIN values entered are the same.',
          GH: 'Please ensure both 4-digit PIN values entered are the same.',
          BW: 'Please ensure both 4-digit PIN values entered are the same.',
          ZM: 'Please ensure both 4-digit PIN values entered are the same.'
        },
        pinNotAsGuideline: {
          IN: 'Please enter a valid 6-digit PIN as per the guidelines in the notes section',
          SG: 'Please enter a valid 5-digit PIN as per the guidelines in the notes section',
          MY: 'Please enter a valid 6-digit PIN as per the guidelines in the notes section',
          HK: 'Please enter a valid 6-digit PIN as per the guidelines in the notes section',
          AE: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          KE: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          NG: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          GH: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          BW: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          ZM: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section'
        },
        enterValidPin: {
          IN: 'Please enter valid PIN',
          SG: 'Sorry, the PIN does not match. Please re-enter the correct PIN.',
          MY: 'Please enter valid PIN',
          HK: 'Please enter valid PIN',
          AE: 'Please enter valid PIN',
          KE: 'Please enter valid PIN',
          NG: 'Please enter valid PIN',
          GH: 'Please enter valid PIN',
          BW: 'Please enter valid PIN',
          ZM: 'Please enter valid PIN'
        }
      }
    },

    creditCardDesc: {
      '405803801801': '渣打白金信用卡',
      '450936033033': '渣打白金信用卡',
      '450936035035': '渣打白金信用卡',
      '450936036036': '渣打白金信用卡',
      '450936054054': '渣打白金信用卡',
      '450936062062': '渣打白金信用卡',
      '450936068068': '渣打白金信用卡',
      '450936069069': '渣打白金信用卡',
      '450936086086': '渣打白金信用卡',
      '450936100001': '渣打白金信用卡',
      '450936101001': '渣打白金信用卡',
      '450936110001': '渣打白金信用卡',
      '450936120001': '渣打白金信用卡',
      '450936124001': '渣打白金信用卡',
      '450936140004': '渣打白金信用卡',
      '450936180005': '渣打白金信用卡',
      '450936230026': '渣打白金信用卡',
      '496657038038': '渣打白金信用卡',
      '496657039039': '渣打白金信用卡',
      '496657055055': '渣打白金信用卡',
      '496657061061': '渣打白金信用卡',
      '496657070070': '渣打白金信用卡',
      '496657071071': '渣打白金信用卡',
      '496657087087': '渣打白金信用卡',
      '496657100021': '渣打白金信用卡',
      '496657120021': '渣打白金信用卡',
      '496657140014': '渣打白金信用卡',
      '496657151011': '渣打白金信用卡',
      '496657170011': '渣打白金信用卡',
      '496657174011': '渣打白金信用卡',
      '496657190013': '渣打白金信用卡',
      '486495044044': '渣打corporate VISA 信用卡',
      '486495045045': '渣打Visa Signature商务卡',
      '450936065065': '渣打Simply Cash Visa卡',
      '450936064064': '渣打Simply Cash Visa卡',
      '541737000131': '渣打白金信用卡',
      '541737100101': '渣打白金信用卡',
      '541737120102': '渣打白金信用卡',
      '541737133133': '渣打白金信用卡',
      '541737135135': '渣打白金信用卡',
      '541737140104': '渣打白金信用卡',
      '541737152152': '渣打白金信用卡',
      '541737154154': '渣打白金信用卡',
      '541737158158': '渣打白金信用卡',
      '541737170170': '渣打白金信用卡',
      '541737172172': '渣打白金信用卡',
      '541737173173': '渣打白金信用卡',
      '552083802802': '渣打白金信用卡',
      '552083812812': '渣打白金信用卡',
      '540034112112': '渣打Titanium信用卡',
      '540034138138': '渣打Titanium信用卡',
      '540034139139': '渣打Titanium信用卡',
      '540034105105': '渣打Titanium信用卡',
      '540034108108': '渣打Titanium信用卡',
      '540034150108': '渣打Titanium信用卡',
      '540034171171': '渣打Titanium信用卡',
      '540034174174': '渣打Titanium信用卡',
      '540034175175': '渣打Titanium信用卡',
      '540034126126': '渣打Titanium信用卡',
      '540034214214': '渣打Titanium信用卡',
      '553398114114': '渣打行政人员白金信用卡',
      '553398123123': '渣打行政人员白金信用卡',
      '553398115115': '渣打行政人员信用卡',
      '553398125125': '渣打行政人员信用卡',
      '553398120120': '渣打corporate executive白金信用卡',
      '553398121121': '渣打行政人员白金信用卡',
      '540034155155': '渣打Click-a-Count Titanium信用卡',
      '442394830830': '渣打Visa Infinite信用卡',
      '442394831831': '渣打Visa Infinite信用卡',
      '442394832832': '渣打Visa Infinite信用卡',
      '442394833833': '渣打「优先理财」信用卡',
      '442394834834': '渣打「优先理财」信用卡',
      '552343840840': '渣打Preferred Banking信用卡',
      '552343841841': '渣打亚洲万里通万事达卡',
      '622482866866': '渣打银联双币白金信用卡(港币)',
      '037710788880': '渣打WorldMiles卡',
      '037710788881': '渣打WorldMiles卡',
      '037710788882': '渣打WorldMiles卡',
      '037710788883': '渣打WorldMiles卡',
      '037710788884': '渣打WorldMiles卡',
      '037710788885': '渣打WorldMiles卡',
      '496673403001': 'MANHATTAN Gold VISA',
      '496673432001': 'MANHATTAN Gold VISA',
      '496673800001': 'MANHATTAN Gold VISA',
      '450885394002': 'MANHATTAN id VISA',
      '450885580002': 'MANHATTAN id VISA',
      '450885581002': 'MANHATTAN id VISA',
      '496673253001': '奥比斯MANHATTAN Gold VISA',
      '450885343002': '奥比斯MANHATTAN Gold VISA',
      '450885900002': 'MANHATTAN id VISA',
      '414004188003': 'MANHATTAN id VISA 白金卡',
      '414004427003': 'MANHATTAN id VISA 白金卡',
      '414004429003': 'MANHATTAN id VISA 白金卡',
      '540157261011': 'MANHATTAN Titanium Mastercard',
      '540157749011': 'MANHATTAN Titanium Mastercard',
      '540157791011': 'MANHATTAN Titanium Mastercard',
      '540157796011': 'MANHATTAN Titanium Mastercard',
      '540157280011': 'MANHATTAN Titanium Mastercard',
      '542479342012': 'MANHATTAN id  万事达白金卡',
      '542479354012': 'MANHATTAN id  万事达白金卡',
      '542479558012': 'MANHATTAN id  万事达白金卡',
      '552168500013': 'MANHATTAN id  万事达白金卡',
      '552168842013': 'MANHATTAN id  万事达白金卡',
      '542479253012': 'MANHATTAN Platinum Mastercard',
      '542479750012': 'MANHATTAN Platinum Mastercard',
      '552168850013': 'MANHATTAN Platinum Mastercard',
      '419077301301': '渣打倍多纷信用卡',
      '419077302302': '渣打倍多纷信用卡',
      '419077303303': '渣打倍多纷信用卡',
      '419078311311': '渣打倍多纷白金信用卡',
      '419078312312': '渣打倍多纷白金信用卡',
      '419078313313': '渣打倍多纷白金信用卡',
      '548803401401': '渣打白金万事达卡',
      '548803402402': '渣打白金万事达卡',
      '548803403403': '渣打白金万事达卡',
      '548830411411': '渣打白金万事达卡',
      '548830412412': '渣打白金万事达卡',
      '548830413413': '渣打白金万事达卡',
      '822482866866': '渣打银联双币白金信用卡(人民币)'
    },
    defaultcreditCardDesc: {
      MaestroCard: '渣打主信用卡',
      VisaCard: '渣打银行信用卡',
      AmexCard: '渣打银行信用卡',
      CUPCard: '渣打银联卡',
      DefaultCard: '渣打银行信用卡'
    },
    debitCardDesc: {
      'PRBN:CPB:YM1': '「优先理财」银联卡',
      'PRBN:CPB:YM2': '「优先理财」银联卡',
      'PRBN:CPB:YM3': '「优先理财」银联卡',
      'PRBN:CPB:YM4': '「优先理财」银联卡',
      'PRBN:CPB:YM5': '「优先理财」银联卡',
      'PRBN:CPB:YM6': '「优先理财」银联卡',
      'PRBN:CPB:YM7': '「优先理财」银联卡',
      'PRBN:CPB:YM8': '「优先理财」银联卡',
      'PRBN:CPB:NA': '「优先理财」银联卡',
      'PRBN:PBI:NA': '「优先理财」顺利卡',
      'PRBN:DPB:NA': '「渣打理财」银联双币卡',
      'PRBN:CME:TM1': '青少年ATM卡',
      'PRBN:CME:TM2': '青少年ATM卡',
      'PRBN:CME:TM3': '青少年ATM卡',
      'PRBN:CME:TM4': '青少年ATM卡',
      'PRBN:CME:TM5': '青少年ATM卡',
      'PRBN:CME:TM6': '青少年ATM卡',
      'PRBN:CME:TM7': '青少年ATM卡',
      'PRBN:CME:TM8': '青少年ATM卡',
      'PRBN:CME:NA': '青少年ATM卡',
      'PRBN:CMK:KM1': '存款卡',
      'PRBN:CMK:KM2': '存款卡',
      'PRBN:CMK:KM3': '存款卡',
      'PRBN:CMK:KM4': '存款卡',
      'PRBN:CMK:KM5': '存款卡',
      'PRBN:CMK:KM6': '存款卡',
      'PRBN:CMK:KM7': '存款卡',
      'PRBN:CMK:KM8': '存款卡',
      'PRBN:CMK:NA': '存款卡',
      'EXBN:CEX:NA': '「渣打银联」提款卡（只适用于Premium理财客户）',
      'EXBN:EXI:NA': '「渣打顺利」提款卡',
      'EXBN:DEX:NA': '「渣打银联」双币提款卡',
      'EXBN:CME:TM1': '青少年ATM卡',
      'EXBN:CME:TM2': '青少年ATM卡',
      'EXBN:CME:TM3': '青少年ATM卡',
      'EXBN:CME:TM4': '青少年ATM卡',
      'EXBN:CME:TM5': '青少年ATM卡',
      'EXBN:CME:TM6': '青少年ATM卡',
      'EXBN:CME:TM7': '青少年ATM卡',
      'EXBN:CME:TM8': '青少年ATM卡',
      'EXBN:CME:NA': '青少年ATM卡',
      'EXBN:CMK:KM1': '存款卡',
      'EXBN:CMK:KM2': '存款卡',
      'EXBN:CMK:KM3': '存款卡',
      'EXBN:CMK:KM4': '存款卡',
      'EXBN:CMK:KM5': '存款卡',
      'EXBN:CMK:KM6': '存款卡',
      'EXBN:CMK:KM7': '存款卡',
      'EXBN:CMK:KM8': '存款卡',
      'EXBN:CMK:NA': '存款卡',
      'GMMN:CML:YM1': '「渣打银联」提款卡',
      'GMMN:CML:YM2': '「渣打银联」提款卡',
      'GMMN:CML:YM3': '「渣打银联」提款卡',
      'GMMN:CML:YM4': '「渣打银联」提款卡',
      'GMMN:CML:YM5': '「渣打银联」提款卡',
      'GMMN:CML:YM6': '「渣打银联」提款卡',
      'GMMN:CML:YM7': '「渣打银联」提款卡',
      'GMMN:CML:YM8': '「渣打银联」提款卡',
      'GMMN:CML:NA': '「渣打银联」提款卡',
      'GMMN:MLI:NA': '「渣打顺利」提款卡',
      'GMMN:DML:NA': '「渣打银联」双币提款卡',
      'GMMN:CME:TM1': '青少年ATM卡',
      'GMMN:CME:TM2': '青少年ATM卡',
      'GMMN:CME:TM3': '青少年ATM卡',
      'GMMN:CME:TM4': '青少年ATM卡',
      'GMMN:CME:TM5': '青少年ATM卡',
      'GMMN:CME:TM6': '青少年ATM卡',
      'GMMN:CME:TM7': '青少年ATM卡',
      'GMMN:CME:TM8': '青少年ATM卡',
      'GMMN:CME:NA': '青少年ATM卡',
      'GMMN:CMK:KM1': '存款卡',
      'GMMN:CMK:KM2': '存款卡',
      'GMMN:CMK:KM3': '存款卡',
      'GMMN:CMK:KM4': '存款卡',
      'GMMN:CMK:KM5': '存款卡',
      'GMMN:CMK:KM6': '存款卡',
      'GMMN:CMK:KM7': '存款卡',
      'GMMN:CMK:KM8': '存款卡',
      'GMMN:CMK:NA': '存款卡',
      defaultDebit: 'ATM'
    },
    CREDITBALANCEREFUND: {
      'header.title': '信用卡盈余转账',
      'progress.subheader1': '选择信用卡',
      'progress.subheader2': '选择收款的信用卡',
      'progress.subheader3': '选择收款户口',
      'progress.subheader5': '确认详情',
      'progress.stepTxt': 'Step',
      'progress.step1': '步骤1/共3步',
      'progress.step2': '步骤2/共3步',
      'progress.step3': '步骤3/共3步',
      'selectCard.text': '请选择信用卡以进行转账:',
      'refundFrom.text': '转账自',
      'refundTo.text': '转账至',
      'refundto.text': '转账至:',
      'minimumPayment.text': '最低还款额*',
      'excessBalance.text': '信用卡户口盈余',
      'required.text': '*',
      'statementBalance.text': '月结单结余*',
      'dueDate.text': '到期日',
      'reasonToRefund.text': '申请转账原因',
      'availableBalanceLeft.text': '适用的信用卡户口盈余',
      'enterAmount.text': '输入金额',
      'invalidAmount.text': '你输入的数目不正确.',
      'selectReason.placeholder': '请选择',
      'selectReason.frontline': {
        reason1: '收款的户口不正确',
        reason2: '作出了多于所需要的缴费',
        reason3: '重复的缴款指示',
        reason4: '信用卡现金回赠',
        reason5: '商户退回款项',
        reason6: '错误的入账'
      },
      'selectReason.selfAssisted': {
        reason1: '收款的户口不正确',
        reason2: '作出了多于所需要的缴费',
        reason3: '商戶退回款項'
      },
      'selectReason.backend.selfAssisted': {
        reason1: 'Payment to wrong account',
        reason2: 'Excess payment made',
        reason3: 'Merchant reversal/ Refund'
      },
      'referenceNumber.text': '参考编号',
      'notes.title': '注意事项',
      'notes.statementBalance': {
        default: '*月结单结余为最新一期月结单的结余.'
      },
      'notes.minimumPayment': {
        default: '*最低还款额为最新一期月结单的最低还款额.'
      },

      'notes.fromCard': {
        default: '*信用卡户口盈余凑整至最接近之港币等值显示.</br>*信用卡户口盈余为信用卡账户上的信贷结余.'
      },
      'requestCancel.content': 'Do you want to cancel your Credit Balance Refund request?',

      'phoneBankingHotline.text': {
        HK: '24/7 Phone Banking',
        default: '24/7 Phone Banking'
      },
      'phoneBankingHotline.content': {
        HK: '',
        default: ''
      },
      'callCentre.text': {
        HK: 'call centre',
        default: ''
      },
      'callCentre.link': {
        HK: '',
        default: ''
      },
      statusMsg: {
        status: '已递交',
        success: '阁下的申请已被递交。<br>阁下将会收到电邮及短讯通知。',
        'unsupportedCOCountry.header': 'We are unable to process your request.',
        'contactPhoneBankingHotline.content': 'Kindly contact our {{inter_link}} for further assistance.'
      },

      button: {
        cancel: '取消',
        next: '下一步',
        confirm: '确认',
        viewStatus: '查看状态',
        close: '关闭',
        back: '上一步'
      }
    }
  }
};
