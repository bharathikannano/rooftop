// Traditional language

export default {
  FERE: {
    action: {
      modal: {
        message: 'Please confirm leave the form without submitting?',
        resetMessage: 'Are you sure you want to revert the change?'
      },
      button: {
        confirm: 'CONFIRM',
        cancel: 'CANCEL',
        YES: 'YES',
        NO: 'NO',
        edit: 'Edit'
      }
    },
    'validation.error.message': ' is required',
    page: {
      receipt: {
        title: 'Reference Number',
        description: 'Please quote this reference number for all future correspondences related to this request.',
        'button.blocked': 'Sorry, We are unable to proceed!'
      }
    }
  },
  ServiceRequest: {
    COMMON: {
      loadingIndicatorText: '加載中...',
      'notes.title': '注意事項',
      'creditcard.title': '信用卡',
      'debitcards.title': '提款卡',
      'nocard.header': '未能偵測任何適用的卡',
      'nocard.content': '閣下並無適用的卡',
      'errorcard.header': 'Unable to retrieve card details.',
      'errorcard.content': 'Please contact 24/7 Phone Banking team for immediate assistance.',
      'debit.header': '未能偵測任何適用的卡',
      'debit.content': ' 閣下並無適用的卡',
      'credit.header': '未能偵測任何適用的卡',
      'credit.content': '閣下並無適用的卡',
      backToHelpAndServicesText: '您確定要退回幫助和服務嗎？',
      backToiBankText: '您確定要返回帳戶概覽/主頁嗎？',
      backToiBankBefAckText: '是否確認回到主頁並取消申請?',
      backToMobileBankText: '您確定要返回帳戶概覽/主頁嗎？',
      backToMobileBankBefAckText: '是否確認回到主頁並取消申請?',
      genericError: {
        HK: '我們暫時未能處理閣下的申請。請致電本行：渣打電話理財客戶服務熱線 (包括提款卡) (852) 2886 8888',
        HKCB:
          '我們暫時未能處理閣下的申請。請致電本行：渣打信用卡24小時客戶服務熱線 (852) 2886 4111；渣打電話理財客戶服務熱線 (包括提款卡) (852) 2886 8888',
        HKCR: '我們暫時未能處理閣下的申請。請致電本行：渣打信用卡24小時客戶服務熱線 (852) 2886 4111'
      },
      systemError: '抱歉，我們未能處理閣下之支票簿申請。如有查詢請致電28868868。',
      'systemError.HK': '抱歉，我們未能處理閣下之支票簿申請。如有查詢請致電28868868。',
      'systemError.title': '系統錯誤',
      termsAndConditions: '1.條款.<br>2.條件',
      'termsAndConditions.title': '條款 & 條件',
      breadcrumbHome: '你正在首頁',
      refNumber: '參考編號。',
      cardTypenocardsTit: 'No eligible card detected.',
      cardTypenocardsDesc:
        'The selected account(s) to be linked does not have any eligible card for replacement. Kindly select other account(s) to proceed or contact our <a href="javascript:;">24/7 Phone Banking</a> for assistance.',
      cardTypeErrornocardsTit: '未能顯示資料',
      cardTypeErrornocardsDesc: '我們暫時未能顯示閣下戶口資料<br>請選擇其他戶口或稍後再試.',
      progress: {
        title1: '輸入資料',
        title2: '確認資料',
        title3: '請選擇',
        title4: '選擇提款卡設計',
        steptxt: '步驟',
        step1: '步驟一/ 共二步',
        step2: '步驟二/ 共二步',
        step12: '步驟1/2',
        step22: '步驟2/2',
        step13: '步驟1/3',
        step23: '步驟2/3',
        step33: '步驟3/3',
        step14: '1 之 4',
        step24: '2 之 4',
        step34: '3 之 4',
        step44: '4 之 4',
        success: '成功',
        submit: '已遞交',
        failure: '失敗',
        incomplete: '部分失敗',
        syserror: '系統錯誤',
        submitted: '已遞交',
        plsselect: '請選擇'
      },
      text: {
        selectAll: '選擇全部',
        deselectAll: '取消選擇全部',
        english: '英文',
        chinese: '中文',
        new: 'New'
      },
      button: {
        cancel: '取消',
        next: '下一步',
        ok: '好',
        confirm: '確認',
        yes: '是',
        no: '否',
        done: '完成',
        back: '上一步',
        loadMore: '查看更多',
        sNext: '下一步',
        sPrev: '返回',
        proceed: '繼續',
        close: '關閉',
        cancelrequest: '取消申請',
        showAll: '展示全部',
        viewStatus: '查看狀態',
        sltcard: '選擇卡',
        save: '保存',
        activateAnotherCard: '為另一張提款卡設定密碼'
      },
      subCategoryText: {
        feeWaver: '費用豁免',
        cardCancellation: '取消信用卡',
        cardBlock: '報失卡',
        cardBlock1: '報失卡',
        cardBlock2: '報失卡',
        cardReplace: '申請補發卡',
        cardReplace1: '補發信用卡',
        cardReplace2: '重新發行借記卡',
        chequeRequest: '支票簿',
        cardReplacement: '換卡換卡',
        cardReplacement1: '換卡換卡',
        cardReplacement2: '換卡換卡',
        cardActivation: '啟用信用卡',
        profileSettings: '更新個人資料',
        pinChange: '設立/更改密碼',
        sltatm: '選擇提款機語言',
        linkaccount: '重新選擇提款卡包括的戶口',
        refNo: '參考編號',
        sltCardtoreplace: '選擇要補發的卡',
        atmLang: '櫃員機語言',
        cardDesign: '提款卡設計'
      },
      categoryText: {
        creditCard: '信用卡',
        personalDetails: '個人資料',
        accountManagement: '戶口',
        cardManagement: '信用卡/提款卡管理'
      },
      mostPopularRequests: {
        cardBlock: '報失卡',
        replaceCards: '補發卡',
        replaceCards1: '補發卡',
        replaceCards2: '補發卡',
        chequeBookRequest: '支票簿',
        profileUpdate: '更新個人資料<span id="landing-popular-subtext">查閱並更新個人資料.</span>'
      },
      contactLinks: {
        HK: ''
      },
      contactLinksTxt: {
        default: '24/7電話銀行'
      }
    },
    COMMONERROR: {
      'CSL-1406': 'Date/Time format is invalid',
      'CSL-1344': 'Invalid Transaction Reference Number',
      'CSL-1328': 'Max retry limit reached',
      'CSL-1320': 'Pin Reset Failed',
      'CSL-1318': 'Key not found',
      'CSL-1303': 'Random challenge expired',
      'CSL-1302': 'Random challenge expired',
      'CSL-1304': 'Invalid random challenge',
      'CSL-1252': 'Pin block generation failed',
      'CSL-1225': 'Query failed',
      'CSL-1200': 'Invalid parameters',
      'CSL-1212': 'Encryption/Decryption error',
      'CSL-1211': 'Database/SQL error',
      'CSL-1034': 'Pin Reset Request Timed out',
      'CSL-1032': 'Pin Reset Request failed',
      'CSL-1702': 'EN - This is 1702'
    },
    CARDREPLACEMENT: {
      'header.title': '申請補發卡',
      'header.title1': '申請補發卡',
      'header.title2': '申請補發卡',
      cardlistHeader1: '選擇要補發的卡',
      cardlistHeader2: '將被補發的卡',
      cardlistHeader3: '閣下的補發卡',
      cardlistHeader4: 'Select debit cards to replace',
      cancelPopup: '是否取消閣下的補發卡申請',
      countryLinks: {
        HK: 'https://www.sc.com/global/av/hk-service-charges-en.pdf'
      },
      countryLinksTxt: {
        default: '費用表'
      },
      countryNotes: {
        HK:
          '閣下可以透過此表格遞交指示為已損壞或已報失之信用卡申請補發新卡<br>如閣下遺失信用卡而尚未報失，請遞交報失信用卡指示<br>為已報失之信用卡申請補新卡的限期為九十天<br>補發卡將會送到閣下已註冊之通訊地址<br>如閣下需要停用之信用卡未被列出，請即聯絡渣打信用卡24小時客戶服務熱線 (852) 2886 4111<br>當主卡被停用，所有該主卡之附屬卡將同時被停用'
      },
      statusMsg: {
        success: '閣下的補發卡申請已被遞交。補發卡申請狀況可在「支援與服務」查閱。',
        failure:
          '我們暫時未能處理閣下的申請。如有查詢，請致電本行：渣打信用卡24小時客戶服務熱線 (852) 2886 4111；渣打電話理財客戶服務熱線 (包括提款卡) (852) 2886 8888',
        incomplete:
          '我們暫時未能處理閣下的申請。如有查詢，請致電本行：渣打信用卡24小時客戶服務熱線 (852) 2886 4111；渣打電話理財客戶服務熱線 (包括提款卡) (852) 2886 8888'
      }
    },
    CARDBLOCK: {
      'header.title': '申請補發卡',
      cardlistHeader1: '選擇要補發的卡',
      cardlistHeader2: '將被補發的卡',
      cardlistHeader3: '閣下的補發卡',
      cardlistSubHeader: '如閣下需要報失之信用卡未被列出，請即聯絡本行之 24 小時客戶服務熱線。',
      cancelPopup: '是否取消報失卡申請',
      selectreason: {
        header: '我想報失卡因為',
        placeholder: '選擇原因',
        reasonToBlock: '原因',
        reason1: '我遺失了卡',
        reason2: '我的卡被盜',
        reason3: '我的卡被扣置在自動櫃員機'
      },
      countryLinks: {
        HK: 'https://www.sc.com/global/av/hk-service-charges-en.pdf'
      },
      countryLinksTxt: {
        default: '費用表'
      },
      countryNotes: {
        HK:
          '<b>有關報失信用卡</b><ul><li>一經確認，閣下的信用卡會被立即停用</li><li>已被停用的信用卡將不能被使用</li><li>已被停用的信用卡不能被再次啟用</li><li>閣下仍需為信用卡停用前的交易負責；閣下可致電 (852) 2886 4111提出爭議賬項查詢</li><li>當主卡被停用，所有該主卡之附屬卡將同時被停用</li><li>補發之新卡將會送到閣下已註冊之通訊地址</li><li>如閣下需要報失的信用卡未被列出，請致電 (852) 2886 4111</li></ul><br><b>有關報失提款卡</b><ul><li>一經確認，閣下的提款卡會被立即停用</li><li>已被停用的提款卡將不能被使用</li><li>已被停用的提款卡不能被再次啟用</li><li>經此報失提款卡後，閣下可以透過遞交「補發提款卡」申請，以申請補發新提款卡</li><li>如閣下需要報失的提款卡未被列出，請致電 (852) 2886 8888</li></ul>'
      },
      statusMsg: {
        success:
          '我們暫時未能處理閣下的申請。如有查詢，請致電本行：渣打信用卡24小時客戶服務熱線 (852) 2886 4111；渣打電話理財客戶服務熱線 (包括提款卡) (852) 2886 8888',
        failure:
          '我們暫時未能處理閣下的申請。請致電本行：渣打信用卡24小時客戶服務熱線 (852) 2886 4111；渣打電話理財客戶服務熱線 (包括提款卡) (852) 2886 8888',
        incomplete:
          '部份卡未被成功處理。請致電本行：渣打信用卡24小時客戶服務熱線 (852) 2886 4111；渣打電話理財客戶服務熱線 (包括提款卡) (852) 2886 8888'
      }
    },
    CHEQUEBOOK: {
      'header.title': '支票簿',
      accountsList: '戶口',
      selectAccountList: '選擇要申請支票簿的戶口',
      countryNotes: {
        IN:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>The cheque book will be dispatched to your mailing address as available in our records and will reach you within 7 working days.</li><li>If you have recently changed your address, please get it updated in our records immediately. Address update in our system will be processed within 4 working days of submitting the address change request.</li><li>You can request for one cheque book for your account in a day. For bulk request, kindly submit a written request at your nearest branch.</li></ol>',
        SG:
          '<ol><li>Only eligible accounts for this request are shown.</li><li>Cheque books will be sent to the account\'s mailing address in our records.</li><li>Please ensure your address with us is up to date before submitting this request. If you have submitted an address change, please note that this takes three working days to update in our system.</li><li>Charges may apply. Please see our <a  href="https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf" target="_blank">fee schedule</a> for more details.</li></ol>',
        MY:
          '<ol><li>Only eligible accounts for this request are shown.</li><li>Cheque books will be sent to the mailing address in our records. Joint account cheque books will be sent to the primary account holder\'s mailing address.</li><li>Please ensure your address with us is up-to-date before submitting this request. If you have submitted an address change,please note that this takes five working days to update in our system.</li><li>Charges may apply. Please see our <a  href="https://www.sc.com/global/av/my-fees-and-charges-27-apr-2017.pdf" target="_blank">fee schedule</a> for more details.</li><li>If you mailing address is a PO Box address,please do not proceed and call our Contact Center for placing this request.</li></ol>',
        HK: '<ol><li>只會顯示適用之戶口</li><li>支票簿將會在七個工作天內郵寄至閣下的通訊地址。</li></ol>',
        AE:
          '<ol><li>Only accounts eligible for this request are shown.</li><li>Cheque book(s) will be sent to your registered mailing address.</li></ol>',
        default:
          '<ol><li>Accounts that are eligible for a Cheque Book are being displayed.</li><li>Cheque Book will be sent to your Registered mailing address.</li></ol>'
      },
      statusMsg: {
        success: '您的請求已提交.<br>您的支票簿將發送到我們的記錄中的郵寄地址',
        failure: '我們目前無法處理您的請求。請再次嘗試提交請求，或聯繫我們的24小時電話銀行服務以獲得幫助。參考＃',
        incomplete:
          '以下某些卡未被處理。如果問題仍然存在，請嘗試再次提交請求或聯繫我們的24小時電話銀行服務以獲得幫助。參考＃',
        HK: '閣下的申請已被遞交<br>支票簿將會被送到閣下的通訊地址。'
      },
      referenceNumber: '參考編號',
      noAccount: '沒有可以啟動支票簿請求的符合條件的帳戶。請聯繫您的關係經理或聯繫呼叫中心或分行',
      'selectAccount.title': '選擇',
      'confirmAccount.title': '確認資料',
      confirmCancelText: '要取消您的支票簿請求嗎?',
      noAccountWarningText: {
        IN:
          '我們無法處理您的請求，因為您沒有任何合格的支票簿帳戶。請聯繫我們的電話銀行團隊或訪問我們的分支機構尋求幫助.',
        SG: 'ERR_CHQ_002 - Sorry, you do not have any accounts that are eligible for this request.',
        HK: '抱歉，閣下並無適用之戶口作支票簿申請'
      }
    },
    STATUSENQUIRY: {
      'header.title': '狀態',
      'activeSection.title': '處理中',
      'completedSection.title': '已完成',
      statusReferenceNo: '編號',
      statusUpdatedDate: '預計完成日期:',
      statusCardReplacement: '補發卡狀態:',
      statusCardReplacementM: '補發卡狀態:',
      statusUpdateDateMobile: '預計完成日期:',
      noActiveRequest: '無任何處理中的申請',
      statusOfRecords: '只顯示過去九十日之紀錄',
      labelReceive: '已接收',
      labelProcessing: '處理中',
      labelCompleted: '已完成',
      labelRejected: '拒絕',
      labelSuccess: '成功',
      labelFailed: '失敗',
      updatedDate: '更新自',
      dateSubmitted: '遞交日期',
      'account/relationshipNo': '戶口號碼',
      creditCard: '已報失的信用卡',
      debitCard: '已報失的提款卡',
      ccCancellation: 'Card Account(s)',
      creditCardReplace: '補發信用卡',
      debitCardReplace: '補發提款卡',
      debitCardIssuance: '申請提款卡'
    },
    LANDINGPAGE: {
      tabText: {
        createRequest: '申請',
        status: '狀態'
      },
      'header.title': '支援與服務',
      noResultsFound: '沒有結果',
      needHelp: '我需要為',
      regardsTo: '申請',
      popularServices: '常用服務申請',
      popularServicesCI: '服務申請',
      allServicesCategory: '所有服務',
      'help&usefulLinks': '常用連結',
      search: '搜尋...'
    },
    STATEMENTREQUEST: {
      'header.title': 'Statement Request',
      'selectAccount.title': 'Select an Account ',
      'account.title.text': 'Select an account to request for a hardcopy statement',
      'date.selection.label': 'Select Source Date',
      'casa.title.text': 'Current/Savings Account',
      'creditcard.title.text': 'Credit Card',
      notes:
        "Fee may be apply depending on the statement requested. Please check Bank's <a>fee schedule</a> for more information.<br> <br>Your statement will be sent to your registered mailing address. Please ensure your address is correct. Contact <a>24/7 Phone Banking</a> if you wish to update your address.",
      'confirm.title.text': 'Confirm Details',
      'account.label': 'Account Number',
      'statement.label': 'Statement Option',
      'statement.date.label': 'Statement Date',
      'statusMsg.success':
        'Your request has been submitted. You can track your statement status online via Service Request Status Enquiry.',
      referenceNumber: 'Reference Number',
      'account.type': 'Account Type',
      'statement.date': 'Statement Date',
      'cc.title.text': 'Credit Card'
    },
    DEBITCARDREPLACEMENT: {
      'header.title': '補發提款卡',
      'header.title1': '新提款卡申請',
      replaceCardTitle: '補發',
      selectLanguageTitle: 'Select language for the ATM',
      accountIncludeTitle: '提款卡包括以下戶口種類',
      primaryAccountTitle: '主要戶口',
      otherAccountTitle: '其他戶口',
      replacementFeeTitle: '補發卡費用',
      replacementFeeSubtitle: '扣除費用自',
      replaceCardwith: '補發',
      sltcardType: '選擇提款卡種類',
      sltdebitType: '選擇提款卡種類',
      primaryAccountLinked: '基本戶口號碼',
      otherAccountLinked: '其他戶口號碼',
      countryLinks: {
        HK: 'https://www.sc.com/hk/zh/help-centre/service-charges.html'
      },
      countryLinksTxt: {
        default: '費用表',
        HK:
          '本行有權自行決定是否簽發新卡並按照本行不時釐定之收費，由客戶戶口扣除相應補發新卡之款項。客戶請參閱「服務收費－銀行服務收費一覧表」 以了解有關服務之最新收費'
      },
      countryNotes: {
        HK:
          '閣下可以透過此表格申請補發已損壞或已報失的提款卡<br>如閣下遺失提款卡而未報失，請選擇「報失卡申請」<br>{{inter_link}}<br>補發卡將會送到閣下已註冊之通訊地址<br>如閣下想補發的提款卡未被列出，請致電本行(852) 2886 8888'
      },
      statusMsg: {
        successReplacement: '閣下的補發卡申請已被遞交。補發信用卡狀況可在「支援與服務」查閱。',
        success: '閣下的申請已被遞交。提款卡申請狀況可在「支援與服務」查閱。'
      }
    },
    CCFEEWAVIER: {
      annualFee: '信用卡年費',
      'selectAccount.title': '請選擇',
      'header.title': '信用卡費用豁免',
      'selectreason.placeholder': '選擇收費類型',
      selectDate: '選擇費用',
      'selectreason.header': '我想申請年費豁免',
      'selectreason.header.mob': '費用類型',
      'selectreason.header.charger': "I'd like to charge",
      'specifyreason.placeholder': 'specify other fee',
      'cardlist.header': '請選擇信用卡',
      'cardlist.header.mob': '選擇申請豁免的費用',
      'feeselect.header': 'Eligible Card(s)',
      'feeselect.subheader': 'The charged fees reflected below can be offset using your reward points.',
      'feetype.title': '費用類別',
      'countryNotes.notes':
        'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline.',
      'cards.title': '信用卡',
      'reward.alert': 'Rewards Points available',
      'reward.alert.msg': 'Do you want to use your available rewards points for these fees?',
      'reward.alert.button.yes': 'Yes, use points',
      'reward.alert.button.no': 'No, don’t use points',
      'notes.title': '備註',
      'reward.remain': 'REMAINING REWARD POINTS',
      'reward.point.display.heading': 'Available Rewards Points',
      'reward.point.display.subheading': 'Total points across all cards as on date',
      'creditcard.title': '信用卡',
      'reason.feewavier': 'REASON FOR FEEWAVIER',
      'reason.charge': 'REASON FOR CHARGE',
      'reason.override': 'Reason For Over-ride',
      'text.systemError.content':
        'We have encountered technical error while processing your request. Please cancel the request and try again. If the issue persists, please contact our 24/7 Phone Banking for immediate assistance.',
      'progress.subheader1': '請選擇',
      'progress.stepTxt1of3': '1 of 3',
      'progress.stepTxt2of3': '2 of 3',
      'progress.stepTxt3of3': '3 of 3',
      'progress.stepTxt1of2': '1 of 2',
      'progress.stepTxt2of2': '2 of 2',
      'progress.stepTxt': '1 of 3',
      'basic.placeholder': '請選擇',
      'add.placeholder': 'Please Select',
      ReferNo: '參考號碼',
      'selectReason.placeholder.reversal': 'Select Reason For Reversal',
      'selectReason.placeholder': 'Select Reason For Charge',
      'selectReason.placeholder.override': 'Select Reason For Over-ride',
      'hotline.contact': 'Kindly contact our 24 hour Phone Banking hotline on 1800 747 7000 for further assistance.',
      submitted: '成功提交',
      statusMsg: {
        success: '已成功提交申請。<br>您將在3個工作天內收到申請結果通知。',
        hksuccessmsg: '已成功提交申請。<br>您將在3個工作天內收到申請結果通知。',
        failure:
          'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance. Reference #',
        incomplete:
          'Some of your cards below did not get processed. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance if the issue persists. Reference #'
      },
      referenceNumber: '參考號碼',
      noAccount:
        'There are no eligible Accounts for which Cheque Book Request can be initiated. Please Contact your Relationship Manager or Contact Call Centre or Branch',
      'confirmAccount.title': '確認資料',
      confirmCancelText: 'Do you want to cancel your Cheque Book request?',
      noAccountWarningText: {
        IN:
          'We are unable to process your request as you do not have any eligible accounts for cheque book. Kindly contact our phone banking team or visit our branches for assistance.',
        SG:
          'We are unable to process your request as you do not have any eligible accounts for cheque book. Kindly contact our phone banking team hotline at 1800 747 700 or visit our branches for assistance.'
      },

      button: {
        okDone: 'OK, Done',
        back: '返回'
      },

      countryLinks: {
        IN: 'https://www.sc.com/in/help-centre/service-charges-fees.html',
        // 'SG': 'https://av.sc.com/sg/content/docs/sg-scb-pricing-guide.pdf',
        SG: 'https://www.sc.com/sg/help/contact-us.html'
      },
      countryLinksTxt: {
        IN: '24/7 Phone Banking hotline',
        SG: '24/7 Phone Banking hotline',
        HK: '2886-4111'
      },
      countryNotes: {
        IN:
          'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline at  {{inter_link}}.<br>Only the eligible credit card will be shown. If you do not see your credit card, please contact our 24-hour Customer Service Hotline at {{inter_link}}',
        SG:
          'For fee waiver requests on another fee type, please contact our 24-hour Customer Service Hotline at  {{inter_link}}.<br>Only the eligible credit card will be shown. If you do not see your credit card, please contact our 24-hour Customer Service Hotline at {{inter_link}}',
        HK: '系統只會顯示合資格的信用卡。 如未能顯示您的有關信用卡，請致電我們的24小時客戶服務熱線。'
      },
      validationCountryNotes: {
        IN: 'Kindly contact our {{inter_link}} for further assistance.',
        SG: 'Kindly contact our {{inter_link}} for further assistance.',
        HK: ''
      },
      countryNotesTransactionPage: {
        IN: 'Only cards eligible for fee waiver will be shown.',
        SG: 'Only cards eligible for fee waiver will be shown.',
        HK: '只有符合減免費用的卡才會顯示。'
      },
      OtherChannelError: 'We are unable to process your request ,It is not valid channel',
      errorText: '如有查詢，請聯絡我們的24小時客戶服務熱線 {{inter_link}}。',
      cardLimitMsg: '每次申請只可選擇不多於5張信用卡'
    },
    CREDITCARD: {
      cardSetting: {
        journeyHeader: '信用卡設置',
        notSaveConfirm: 'If you go back, your settings will not be saved.',
        settingsTitle: {
          transactionLimit: '交易限額',
          paymentChannels: '付款頻道',
          controlledCatagories: '受控類別',
          countryLimits: '國家限制'
        },
        selectPage: {
          pageHeader: '選擇一張信用卡',
          sectionHeader: '選擇一張信用卡並設置',
          sectionHeaderMob: '選擇一張信用卡並設置'
        },
        cardSettingsPage: {
          pageHeader: '設置信用卡設置',
          sectionHeader: '設置您的信用卡設置',
          sectionHeaderMob: '設置您的信用卡設置',
          termsAndConditions: '通過啟用此功能，您接受 '
        },
        isPrimary: {
          primary: '主卡',
          supplementary: '附屬卡'
        },
        transactionLimitPage: {
          transactionNotifications: '交易通知',
          transactionNotificationsContent: '每筆交易超過限額時將被通知。',
          limitAmountTitle: '限額',
          blockCheckbox: '阻止高於規定限制的交易',
          maxLimitAlert: '請輸入低於_AMOUNT_的金額。',
          minLimitAlert: '請輸入高於_AMOUNT_的金額。',
          errorNumType: '請輸入正確的金額。'
        },
        paymentChannelsPage: {
          paymentChannelNotifications: '付款渠道通知',
          paymentChannelNotificationsContent: '在通過以下付款渠道進行交易時收到通知。',
          blockCheckbox: '阻止通過這些付款渠道進行的交易',
          optionItem1: '在線電子商務',
          optionItem2: '非接觸式',
          optionItem3: '物理銷售點',
          optionContent1: '在線支付是您在網站或應用程序中輸入您的卡詳細信息的地方。',
          optionContent2: '聯繫付款是指您必須在支付終端上實體刷卡或插入您的卡。',
          optionContent3:
            '通過在支付終端附近揮動卡片或使用移動設備數字錢包進行付款（例如Apple Pay，Android Pay，Google Pay，Samsung Pay等），您可以在非接觸式付款中使用您的卡。'
        },
        controlledCategories: {
          controlledCategoryNotifications: '受控類別通知',
          controlledCategoryNotificationsContent: '在進行屬於以下類別的交易時收到通知。',
          blockCheckbox: '阻止屬於這些類別的交易',
          optionItem1: '成人娛樂',
          optionItem2: '賭博場所',
          optionItem3: '在線遊戲網站',
          optionItem4: '酒吧和夜總會'
        },
        countryLimitsPage: {
          countryNotifications: '國家通知',
          countryNotificationsContent: '在下列任何一個國家/地區進行交易時都會收到通知。',
          blockCheckbox: '阻止在這些國家進行的交易',
          overseaCardUsage: '阻止海外卡的使用',
          selectedCountry: '阻止選定的國家',
          selectCountryContent: '選擇國家',
          addCountryContent: '+ 添加國家/地區',
          countryLimitExplain: '通過阻止特定國家，您將無法再使用您的卡在這些國家進行交易。',
          overseaCardUsageContent: '阻止在發卡所在的國家以外進行的交易。 網上交易不會受到影響。'
        },
        TMPBLOCKTXT: '暫停此卡',
        NOTICE: {
          TMPBLOCK: '您將暫停此卡。此卡的交易在重新啟用之前將被阻止。',
          ERROR: '發生錯誤，您的設置無法保存。請再試一次。'
        },
        noCards: {
          content2: '立即申請信用卡進行配置。',
          label1: '臨時鎖卡',
          label2: '交易限制',
          label3: '付款渠道',
          label4: '受控類別',
          label5: '國家使用限制',
          button: '現在申請'
        }
      },
      pinSetup: {
        journeyHeader: 'Credit Card PIN Setup/Change',

        selectPage: {
          pageHeader: 'Select a Credit Card',
          sectionHeader: 'SELECT A CREDIT CARD TO SETUP A PIN',
          sectionHeaderMob: 'Select a Credit Card to setup a PIN',
          nocardHeader: 'No eligible card detected.',
          nocardContent: 'Sorry, you do not have any eligible Credit Card(s) for this request.'
        },
        pinChange: {
          pageHeader: 'Set Credit Card PIN',
          sectionHeader: 'SET YOUR NEW CREDIT CARD PIN',
          sectionHeaderMob: 'Set your new Credit Card PIN',
          newPin: '輸入提款卡新密碼',
          reEnterPin: '再次輸入提款卡新密碼',
          newPinMob: 'Enter New PIN',
          reEnterPinMob: 'Re-Enter PIN',
          pinNotSame: 'Entered PIN numbers are not same',
          pinNotAsGuideline: 'Invalid PIN, please enter PIN as per the guidelines'
        },
        countryNotes: {
          IN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/in/contact-us/#talk-to-us'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          SG:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 5-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To authenticate your PIN change, we will send you an OTP at your registered mobile number. Please ensure you have this ready for reference.</li><li>You should always memorise your PIN. Do not reveal your 5-digit PIN to anyone or record it anywhere.</li><li>Avoid using numbers for your PIN that may be easily guessed, such as your birthday, NRIC, phone number, sequential numbers (eg. 12345) etc.</li></li></ol>",
          HK:
            '<ol><li>切勿將密碼告知他人。</li><li>切勿將密碼寫在您的卡上或任何接近卡之物件。</li><li>切勿使用香港身份証號碼、電話號碼、出生日期或其他個人資料作為您的密碼。</li><li>切勿使用與您用於連接其他服務相同的資料，例如電郵、其他互聯網網站/ISP或電話銀行TIN(電話理財交易密碼)。</li><li>應定期更新您的密碼。</li><li>應在懷疑已被盜用或受損時更改您的密碼。</li><li>如有查詢，請致電我們。渣打提款卡：(852) 2886-8888 渣打信用卡：(852) 2886-4111 MANHATTAN 信用卡：(852) 2881-0888</li></ol>',
          MY:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/my/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          AE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/ae/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          KE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that is sent to your registered mobile number.</li><li>We recommend that you memorize your 4-digit PIN, do not record it anywhere, divulge or share it with anyone.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or the same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Call us on 254203293900 in case you observe any unauthorized transactions in your account.</li></ol></li></ol>",
          NG:
            '<ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>Do not reveal your 4-digit PIN to anyone. Memorise your PIN and do not record it anywhere.</li><li>Do not use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Contact Centre Team immediately in case of any unauthorized transactions observed in your account.</li></ol>',
          GH:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          BW:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          ZM:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>"
        },
        status: {
          refNo: 'REFERENCE NUMBER',
          refNoSmall: '參考編號',
          cardDetails: '卡資料',
          success: 'Success',
          failed: 'Failed!',
          transactionSuccessMsg: 'You have successfully reset your Credit Card PIN.',
          transactionSuccessFailure: {
            IN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            SG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            MY:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 1 300 888 888/ +603 7711 8888 for any assistance.',
            HK:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            AE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 600 5222 88 for any assistance.',
            KE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 254 20 329 3900 for any assistance.',
            NG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 01 2704611 - 4 for any assistance.',
            GH:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 0302 740100 for any assistance.',
            BW:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on +267 3615800 for any assistance.',
            ZM:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 5247  for any assistance.'
          },
          transactionSuccessInComplete:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.'
        }
      },
      activation: {
        journeyHeader: 'Credit Card Activation/PIN Setup',
        selectPage: {
          pageHeader: 'Select a Credit Card',
          sectionHeader: 'SELECT A CARD YOU WANT TO ACTIVATE',
          sectionHeaderMob: 'Select a Credit Card to setup a PIN',
          nocardHeader: 'No eligible card detected.',
          nocardContent: 'Sorry, you do not have any eligible Credit Card(s) for this request.'
        },
        pinChange: {
          pageHeader: 'Set Credit Card PIN',
          sectionHeader: 'SET YOUR NEW CREDIT CARD PIN',
          sectionHeaderMob: 'Set your new Credit Card PIN',
          newPin: '輸入提款卡新密碼',
          reEnterPin: '再次輸入提款卡新密碼',
          newPinMob: 'Enter New PIN',
          reEnterPinMob: 'Re-Enter PIN',
          pinNotSame: 'Entered PIN numbers are not same',
          pinNotAsGuideline: 'Invalid PIN, please enter PIN as per the guidelines'
        },
        disclaimerNotes: {
          AE:
            'DISCLAIMER : Please ensure you have the plastic with you before you proceed for Activation and Pin Set request'
        },
        countryNotes: {
          IN:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/in/contact-us/#talk-to-us'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          SG:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 5-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To authenticate your PIN change, we will send you an OTP at your registered mobile number. Please ensure you have this ready for reference.</li><li>You should always memorise your PIN. Do not reveal your 5-digit PIN to anyone or record it anywhere.</li><li>Avoid using numbers for your PIN that may be easily guessed, such as your birthday, NRIC, phone number, sequential numbers (eg. 12345) etc.</li></li></ol>",
          HK:
            '<ol><li>切勿將密碼告知他人。</li><li>切勿將密碼寫在您的卡上或任何接近卡之物件。</li><li>切勿使用香港身份証號碼、電話號碼、出生日期或其他個人資料作為您的密碼。</li><li>切勿使用與您用於連接其他服務相同的資料，例如電郵、其他互聯網網站/ISP或電話銀行TIN(電話理財交易密碼)。</li><li>應定期更新您的密碼。</li><li>應在懷疑已被盜用或受損時更改您的密碼。</li><li>如有查詢，請致電我們。渣打提款卡：(852) 2886-8888 渣打信用卡：(852) 2886-4111 MANHATTAN 信用卡：(852) 2881-0888</li></ol>',
          MY:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 6-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 6-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 6-digit PIN to anyone. 6-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 6-digit PIN.</li><li>Avoid using sequential numbers (such as 123456) or same number more than twice (such as 222222) for your 6-digit PIN.</li><li>6-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 6-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/my/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          AE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our <a href='https://www.sc.com/ae/contact-us/'>24/7 Phone Banking</a> team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          KE:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that is sent to your registered mobile number.</li><li>We recommend that you memorize your 4-digit PIN, do not record it anywhere, divulge or share it with anyone.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or the same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Call us on 254203293900 in case you observe any unauthorized transactions in your account.</li></ol></li></ol>",
          NG:
            '<ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>Do not reveal your 4-digit PIN to anyone. Memorise your PIN and do not record it anywhere.</li><li>Do not use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>Change your 4-digit PIN regularly and immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Contact Centre Team immediately in case of any unauthorized transactions observed in your account.</li></ol>',
          GH:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          BW:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>",
          ZM:
            "<ol style='list-style-type: none;'><li style='list-style:none !important;'>Please take note that 4-digit PIN creation/reset can only be performed on activated cards.</li><li style='list-style:none !important;'><ol><li>To change your 4-digit PIN, you will be required to enter the one-time password (OTP) that was sent to your registered mobile number.</li><li>DO NOT reveal your 4-digit PIN to anyone. 4-digit PIN must be memorized and not be recorded anywhere.</li><li>DO NOT use easily recognized numbers such as your birthday, anniversary, National ID, telephone number etc. as your 4-digit PIN.</li><li>Avoid using sequential numbers (such as 1234) or same number more than twice (such as 2222) for your 4-digit PIN.</li><li>4-Digit PIN must be kept confidential at all times and not be divulged to anyone.</li><li>Change your 4-digit PIN regularly and do so immediately if you suspect it has been compromised.</li><li>Contact our 24/7 Phone Banking team immediately in case of any unauthorized transactions observed in your account.</li></ol></li></ol>"
        },
        status: {
          refNo: 'REFERENCE NUMBER',
          refNoSmall: '參考編號',
          cardDetails: '卡資料',
          success: 'Success',
          failed: 'Failed!',
          transactionSuccessMsg: 'Your credit card is activated and PIN has been set successfully.',
          transactionSuccessFailure: {
            IN:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            SG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            MY:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 1 300 888 888/ +603 7711 8888 for any assistance.',
            HK:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.',
            AE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 600 5222 88 for any assistance.',
            KE:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 254 20 329 3900 for any assistance.',
            NG:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 01 2704611 - 4 for any assistance.',
            GH:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 0302 740100 for any assistance.',
            BW:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on +267 3615800 for any assistance.',
            ZM:
              'We are unable to process your request at the moment. Please try submitting the request again or contact our client care centre on 5247  for any assistance.'
          },
          transactionSuccessInComplete:
            'We are unable to process your request at the moment. Please try submitting the request again or contact our 24-hour Phone Banking service for assistance.'
        }
      },
      validation: {
        pinNotSame: {
          IN: 'Please ensure both 6-digit PIN values entered are the same.',
          SG: 'Sorry, the PIN does not match. Please re-enter the correct PIN.',
          MY: 'Please ensure both 6-digit PIN values entered are the same.',
          HK: 'Please ensure both 6-digit PIN values entered are the same.',
          AE: 'Please ensure both 4-digit PIN values entered are the same.',
          KE: 'Please ensure both 4-digit PIN values entered are the same.',
          NG: 'Please ensure both 4-digit PIN values entered are the same.',
          GH: 'Please ensure both 4-digit PIN values entered are the same.',
          BW: 'Please ensure both 4-digit PIN values entered are the same.',
          ZM: 'Please ensure both 4-digit PIN values entered are the same.'
        },
        pinNotAsGuideline: {
          IN: 'Please enter a valid 6-digit PIN as per the guidelines in the notes section',
          SG: 'Please enter a valid 5-digit PIN as per the guidelines in the notes section',
          MY: 'Please enter a valid 6-digit PIN as per the guidelines in the notes section',
          HK: 'Please enter a valid 6-digit PIN as per the guidelines in the notes section',
          AE: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          KE: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          NG: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          GH: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          BW: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section',
          ZM: 'Please enter a valid 4-digit PIN as per the guidelines in the notes section'
        },
        enterValidPin: {
          IN: 'Please enter valid PIN',
          SG: 'Sorry, the PIN does not match. Please re-enter the correct PIN.',
          MY: 'Please enter valid PIN',
          HK: 'Please enter valid PIN',
          AE: 'Please enter valid PIN',
          KE: 'Please enter valid PIN',
          NG: 'Please enter valid PIN',
          GH: 'Please enter valid PIN',
          BW: 'Please enter valid PIN',
          ZM: 'Please enter valid PIN'
        }
      }
    },
    CREDITCARD_ERROR_MAP: {
      'CSL-CC-301':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-302':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-303':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-304':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-305':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-306':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-307':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-308':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-312':
        'You have exceeded the PIN try limit. Kindly call our 24-hour Customer Care hotline at +65 6747 7000 for further assistance.',
      'CSL-CC-313':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-314':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-315':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-422':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline at +65 6747 7000 or walk in to any of our branches for further assistance.',
      'CSL-CC-423':
        'We detected that your mobile number has not been updated with the Bank. Kindly call our 24-hour Customer Care Hotline at +65 6747 7000 or walk in to any of our branches for further assistance.',
      'CSL-CC-409':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-417':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-407':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-416': 'Please enter Standard Chartered Credit Card for activation.',
      'CSL-CC-415':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-405':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-414':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-404':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-413':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-403':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-412':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-402':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-411':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-401':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-410':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-418':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-316':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-OTP-1328':
        'Sorry, due to maximum invalid OTP attempts you will not receive any OTP for transactions for the next 24 hours.',
      'CSL-SEC-519': 'Max retry attempt reached, kindly reset.',
      '1308':
        'You have entered invalid one-time password (OTP). Please check and re-enter your one time password(OTP). (Error Code:1308)',
      '1307': 'Your one-time password (OTP) had expired. Please request for a new OTP. (Error Code:1307)',
      'CSL-OTP-1024': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-OTP-1026': 'We are unable to deliver one-time password (OTP) to your mobile, Kindly try after some time.',
      'CSL-CC-324':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-325':
        "We've encountered an error with your request. Please resubmit a new request. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000 for immediate assistance.",
      'CSL-CC-424':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-425':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-426':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-427':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-428':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-429':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.',
      'CSL-CC-430':
        'Your credit card is activated and PIN has been set successfully. For ATM Transactions, it will be ready to use after 1 working day.'
    },
    creditCardDesc: {
      '405803801801': '渣打白金信用卡',
      '450936033033': '渣打白金信用卡',
      '450936035035': '渣打白金信用卡',
      '450936036036': '渣打白金信用卡',
      '450936054054': '渣打白金信用卡',
      '450936062062': '渣打白金信用卡',
      '450936068068': '渣打白金信用卡',
      '450936069069': '渣打白金信用卡',
      '450936086086': '渣打白金信用卡',
      '450936100001': '渣打白金信用卡',
      '450936101001': '渣打白金信用卡',
      '450936110001': '渣打白金信用卡',
      '450936120001': '渣打白金信用卡',
      '450936124001': '渣打白金信用卡',
      '450936140004': '渣打白金信用卡',
      '450936180005': '渣打白金信用卡',
      '450936230026': '渣打白金信用卡',
      '496657038038': '渣打白金信用卡',
      '496657039039': '渣打白金信用卡',
      '496657055055': '渣打白金信用卡',
      '496657061061': '渣打白金信用卡',
      '496657070070': '渣打白金信用卡',
      '496657071071': '渣打白金信用卡',
      '496657087087': '渣打白金信用卡',
      '496657100021': '渣打白金信用卡',
      '496657120021': '渣打白金信用卡',
      '496657140014': '渣打白金信用卡',
      '496657151011': '渣打白金信用卡',
      '496657170011': '渣打白金信用卡',
      '496657174011': '渣打白金信用卡',
      '496657190013': '渣打白金信用卡',
      '486495044044': '渣打corporate VISA 信用卡',
      '486495045045': '渣打Visa Signature商務卡',
      '450936065065': '渣打Simply Cash Visa卡',
      '450936064064': '渣打Simply Cash Visa卡',
      '541737000131': '渣打白金信用卡',
      '541737100101': '渣打白金信用卡',
      '541737120102': '渣打白金信用卡',
      '541737133133': '渣打白金信用卡',
      '541737135135': '渣打白金信用卡',
      '541737140104': '渣打白金信用卡',
      '541737152152': '渣打白金信用卡',
      '541737154154': '渣打白金信用卡',
      '541737158158': '渣打白金信用卡',
      '541737170170': '渣打白金信用卡',
      '541737172172': '渣打白金信用卡',
      '541737173173': '渣打白金信用卡',
      '552083802802': '渣打白金信用卡',
      '552083812812': '渣打白金信用卡',
      '540034112112': '渣打Titanium信用卡',
      '540034138138': '渣打Titanium信用卡',
      '540034139139': '渣打Titanium信用卡',
      '540034105105': '渣打Titanium信用卡',
      '540034108108': '渣打Titanium信用卡',
      '540034150108': '渣打Titanium信用卡',
      '540034171171': '渣打Titanium信用卡',
      '540034174174': '渣打Titanium信用卡',
      '540034175175': '渣打Titanium信用卡',
      '540034126126': '渣打Titanium信用卡',
      '540034214214': '渣打Titanium信用卡',
      '553398114114': '渣打行政人員白金信用卡',
      '553398123123': '渣打行政人員白金信用卡',
      '553398115115': '渣打行政人員信用卡',
      '553398125125': '渣打行政人員信用卡',
      '553398120120': '渣打corporate executive白金信用卡',
      '553398121121': '渣打行政人員白金信用卡',
      '540034155155': '渣打Click-a-Count Titanium信用卡',
      '442394830830': '渣打Visa Infinite信用卡',
      '442394831831': '渣打Visa Infinite信用卡',
      '442394832832': '渣打Visa Infinite信用卡',
      '442394833833': '渣打「優先理財」信用卡',
      '442394834834': '渣打「優先理財」信用卡',
      '552343840840': '渣打Preferred Banking信用卡',
      '552343841841': '渣打亞洲萬里通萬事達卡',
      '622482866866': '渣打銀聯雙幣白金信用卡(港幣)',
      '037710788880': '渣打WorldMiles卡',
      '037710788881': '渣打WorldMiles卡',
      '037710788882': '渣打WorldMiles卡',
      '037710788883': '渣打WorldMiles卡',
      '037710788884': '渣打WorldMiles卡',
      '037710788885': '渣打WorldMiles卡',
      '496673403001': 'MANHATTAN Gold VISA',
      '496673432001': 'MANHATTAN Gold VISA',
      '496673800001': 'MANHATTAN Gold VISA',
      '450885394002': 'MANHATTAN id VISA',
      '450885580002': 'MANHATTAN id VISA',
      '450885581002': 'MANHATTAN id VISA',
      '496673253001': '奧比斯MANHATTAN Gold VISA',
      '450885343002': '奧比斯MANHATTAN VISA',
      '450885900002': 'MANHATTAN id VISA',
      '414004188003': 'MANHATTAN id VISA 白金卡',
      '414004427003': 'MANHATTAN id VISA 白金卡',
      '414004429003': 'MANHATTAN id VISA 白金卡',
      '540157261011': 'MANHATTAN Titanium Mastercard',
      '540157749011': 'MANHATTAN Titanium Mastercard',
      '540157791011': 'MANHATTAN Titanium Mastercard',
      '540157796011': 'MANHATTAN Titanium Mastercard',
      '540157280011': 'MANHATTAN Titanium Mastercard',
      '542479342012': 'MANHATTAN id  萬事達白金卡',
      '542479354012': 'MANHATTAN id  萬事達白金卡',
      '542479558012': 'MANHATTAN id  萬事達白金卡',
      '552168500013': 'MANHATTAN id  萬事達白金卡',
      '552168842013': 'MANHATTAN id  萬事達白金卡',
      '542479253012': 'MANHATTAN Platinum Mastercard',
      '542479750012': 'MANHATTAN Platinum Mastercard',
      '552168850013': 'MANHATTAN Platinum Mastercard',
      '419077301301': '渣打倍多紛信用卡',
      '419077302302': '渣打倍多紛信用卡',
      '419077303303': '渣打倍多紛信用卡',
      '419078311311': '渣打倍多紛白金信用卡',
      '419078312312': '渣打倍多紛白金信用卡',
      '419078313313': '渣打倍多紛白金信用卡',
      '548803401401': '渣打白金萬事達卡',
      '548803402402': '渣打白金萬事達卡',
      '548803403403': '渣打白金萬事達卡',
      '548830411411': '渣打白金萬事達卡',
      '548830412412': '渣打白金萬事達卡',
      '548830413413': '渣打白金萬事達卡',
      '822482866866': '渣打銀聯雙幣白金信用卡(人民幣)'
    },
    defaultcreditCardDesc: {
      MaestroCard: '渣打主信用卡',
      VisaCard: '渣打銀行信用卡',
      AmexCard: '渣打銀行信用卡',
      CUPCard: '渣打銀聯卡',
      DefaultCard: '渣打銀行信用卡'
    },
    debitCardDesc: {
      'PRBN:CPB:YM1': '「優先理財」銀聯卡',
      'PRBN:CPB:YM2': '「優先理財」銀聯卡',
      'PRBN:CPB:YM3': '「優先理財」銀聯卡',
      'PRBN:CPB:YM4': '「優先理財」銀聯卡',
      'PRBN:CPB:YM5': '「優先理財」銀聯卡',
      'PRBN:CPB:YM6': '「優先理財」銀聯卡',
      'PRBN:CPB:YM7': '「優先理財」銀聯卡',
      'PRBN:CPB:YM8': '「優先理財」銀聯卡',
      'PRBN:CPB:NA': '「優先理財」銀聯卡',
      'PRBN:PBI:NA': '「優先理財」順利卡',
      'PRBN:DPB:NA': '「渣打理財」銀聯雙幣卡',
      'PRBN:CME:TM1': '青少年ATM卡',
      'PRBN:CME:TM2': '青少年ATM卡',
      'PRBN:CME:TM3': '青少年ATM卡',
      'PRBN:CME:TM4': '青少年ATM卡',
      'PRBN:CME:TM5': '青少年ATM卡',
      'PRBN:CME:TM6': '青少年ATM卡',
      'PRBN:CME:TM7': '青少年ATM卡',
      'PRBN:CME:TM8': '青少年ATM卡',
      'PRBN:CME:NA': '青少年ATM卡',
      'PRBN:CMK:KM1': '存款卡',
      'PRBN:CMK:KM2': '存款卡',
      'PRBN:CMK:KM3': '存款卡',
      'PRBN:CMK:KM4': '存款卡',
      'PRBN:CMK:KM5': '存款卡',
      'PRBN:CMK:KM6': '存款卡',
      'PRBN:CMK:KM7': '存款卡',
      'PRBN:CMK:KM8': '存款卡',
      'PRBN:CMK:NA': '存款卡',
      'EXBN:CEX:NA': '「渣打銀聯」提款卡 （只適用於Premium理財客戶）',
      'EXBN:EXI:NA': '「渣打順利」提款卡',
      'EXBN:DEX:NA': '「渣打銀聯」雙幣提款卡',
      'EXBN:CME:TM1': '青少年ATM卡',
      'EXBN:CME:TM2': '青少年ATM卡',
      'EXBN:CME:TM3': '青少年ATM卡',
      'EXBN:CME:TM4': '青少年ATM卡',
      'EXBN:CME:TM5': '青少年ATM卡',
      'EXBN:CME:TM6': '青少年ATM卡',
      'EXBN:CME:TM7': '青少年ATM卡',
      'EXBN:CME:TM8': '青少年ATM卡',
      'EXBN:CME:NA': '青少年ATM卡',
      'EXBN:CMK:KM1': '存款卡',
      'EXBN:CMK:KM2': '存款卡',
      'EXBN:CMK:KM3': '存款卡',
      'EXBN:CMK:KM4': '存款卡',
      'EXBN:CMK:KM5': '存款卡',
      'EXBN:CMK:KM6': '存款卡',
      'EXBN:CMK:KM7': '存款卡',
      'EXBN:CMK:KM8': '存款卡',
      'EXBN:CMK:NA': '存款卡',
      'GMMN:CML:YM1': '「渣打銀聯」提款卡',
      'GMMN:CML:YM2': '「渣打銀聯」提款卡',
      'GMMN:CML:YM3': '「渣打銀聯」提款卡',
      'GMMN:CML:YM4': '「渣打銀聯」提款卡',
      'GMMN:CML:YM5': '「渣打銀聯」提款卡',
      'GMMN:CML:YM6': '「渣打銀聯」提款卡',
      'GMMN:CML:YM7': '「渣打銀聯」提款卡',
      'GMMN:CML:YM8': '「渣打銀聯」提款卡',
      'GMMN:CML:NA': '「渣打銀聯」提款卡',
      'GMMN:MLI:NA': '「渣打順利」提款卡',
      'GMMN:DML:NA': '「渣打銀聯」雙幣提款卡',
      'GMMN:CME:TM1': '青少年ATM卡',
      'GMMN:CME:TM2': '青少年ATM卡',
      'GMMN:CME:TM3': '青少年ATM卡',
      'GMMN:CME:TM4': '青少年ATM卡',
      'GMMN:CME:TM5': '青少年ATM卡',
      'GMMN:CME:TM6': '青少年ATM卡',
      'GMMN:CME:TM7': '青少年ATM卡',
      'GMMN:CME:TM8': '青少年ATM卡',
      'GMMN:CME:NA': '青少年ATM卡',
      'GMMN:CMK:KM1': '存款卡',
      'GMMN:CMK:KM2': '存款卡',
      'GMMN:CMK:KM3': '存款卡',
      'GMMN:CMK:KM4': '存款卡',
      'GMMN:CMK:KM5': '存款卡',
      'GMMN:CMK:KM6': '存款卡',
      'GMMN:CMK:KM7': '存款卡',
      'GMMN:CMK:KM8': '存款卡',
      'GMMN:CMK:NA': '存款卡',
      defaultDebit: 'ATM'
    },
    CREDITBALANCEREFUND: {
      'header.title': '信用卡盈餘轉賬',
      'progress.subheader1': '選擇信用卡',
      'progress.subheader2': '選擇收款的信用卡',
      'progress.subheader3': '選擇收款戶口',
      'progress.subheader5': '確認詳情',
      'progress.stepTxt': 'Step',
      'progress.step1': '步驟1/共3步',
      'progress.step2': '步驟2/共3步',
      'progress.step3': '步驟3/共3步',
      'selectCard.text': '請選擇信用卡以進行轉賬:',
      'refundFrom.text': '轉賬自',
      'refundTo.text': '轉賬至',
      'refundto.text': '轉賬至:',
      'minimumPayment.text': '最低還款額*',
      'excessBalance.text': '信用卡戶口盈餘',
      'required.text': '*',
      'statementBalance.text': '月結單結餘*',
      'dueDate.text': '到期日',
      'reasonToRefund.text': '申請轉賬原因',
      'availableBalanceLeft.text': '適用的信用卡戶口盈餘',
      'enterAmount.text': '輸入金額',
      'invalidAmount.text': '你輸入的數目不正確.',
      'selectReason.placeholder': '請選擇',
      'selectReason.frontline': {
        reason1: '收款的戶口不正確',
        reason2: '作出了多於所需要的繳費',
        reason3: '重複的繳款指示',
        reason4: '信用卡現金回贈',
        reason5: '商戶退回款項',
        reason6: '錯誤的入賬',
        reason7: '其他'
      },
      'selectReason.selfAssisted': {
        reason1: '收款的戶口不正確',
        reason2: '作出了多於所需要的繳費',
        reason3: '商戶退回款項'
      },
      'selectReason.backend.selfAssisted': {
        reason1: 'Payment to wrong account',
        reason2: 'Excess payment made',
        reason3: 'Merchant reversal/ Refund'
      },
      'referenceNumber.text': '參考編號',
      'notes.title': '注意事項',
      'notes.statementBalance': {
        default: '*月結單結餘為最新一期月結單的結餘.'
      },
      'notes.minimumPayment': {
        default: '*最低還款額為最新一期月結單的最低還款額.'
      },

      'notes.fromCard': {
        default: '*信用卡戶口盈餘湊整至最接近之港幣等值顯示.</br>*信用卡戶口盈餘為信用卡賬戶上的信貸結餘.'
      },
      'requestCancel.content': 'Do you want to cancel your Credit Balance Refund request?',

      'phoneBankingHotline.text': {
        HK: '24/7 Phone Banking',
        default: '24/7 Phone Banking'
      },
      'phoneBankingHotline.content': {
        HK: '',
        default: ''
      },
      'callCentre.text': {
        HK: 'call centre',
        default: ''
      },
      'callCentre.link': {
        HK: '',
        default: ''
      },
      statusMsg: {
        status: '已遞交',
        success: '閣下的申請已被遞交。<br>閣下將會收到電郵及短訊通知。',
        'unsupportedCOCountry.header': 'We are unable to process your request.',
        'contactPhoneBankingHotline.content': 'Kindly contact our {{inter_link}} for further assistance.'
      },

      button: {
        cancel: '取消',
        next: '下一步',
        confirm: '確認',
        viewStatus: '查看狀態',
        close: '關閉',
        back: '上一步'
      }
    }
  }
};
