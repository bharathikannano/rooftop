import Mixin from '@ember/object/mixin';
import Ember from 'ember';
import { inject as service } from '@ember/service';
import { Promise as EmberPromise } from 'rsvp';

export default Mixin.create({
  axwayConfig: service(),

  checkMaintenance() {
    return new EmberPromise(resolve => {
      const countries = ['ke', 'ug', 'tz', 'gh', 'bw', 'zm', 'zw', 'ng', 'ci']; //Checking only for SIMBA countries.
      if (countries.indexOf(this.get('axwayConfig.country').toLowerCase()) !== -1) {
        this.getCheckMaintenanceData()
          .then(isUnderMaintanence => {
            resolve(isUnderMaintanence);
          })
          .catch(err => {
            Ember.Logger.log('Error while fetching Maintenance Data' + err);
            resolve(false);
          });
      } else {
        resolve(false);
      }
    });
  },

  getCheckMaintenanceData() {
    // Get maintanence data..
    return new EmberPromise(resolve => {
      let path = 'https://av.sc.com/configuration/maintenance';
      let host = window.location.host.indexOf('sit') != -1 || window.location.host.indexOf('uat') != -1 ? '-test' : '';
      let country = this.get('axwayConfig.country').toLowerCase();
      let response = fetch(path + '-' + country + host + '.json');
      response
        .then(response => response.json())
        .then(response => {
          let isUnderMaintanence = response.maintanence;
          resolve(isUnderMaintanence);
        })
        .catch(() => {
          resolve(false);
        });
    });
    // Maintanence Code End..
  }
});
