/* eslint-disable no-redeclare */
/* global cordova */
import Mixin from '@ember/object/mixin';
import { Promise as EmberPromise } from 'rsvp';

export default Mixin.create({
  init() {
    this._super();
  },

  isCordovaAvailable() {
    return typeof cordova !== 'undefined';
  },

  _exec(functionName, args = []) {
    return new EmberPromise((resolve, reject) => {
      if (this.isCordovaAvailable()) {
        cordova.exec(success => resolve(success), error => reject(error), this.pluginName, functionName, args);
      } else {
        resolve();
      }
    });
  }
});
