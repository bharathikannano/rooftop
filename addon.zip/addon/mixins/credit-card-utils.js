import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';
import { isEmpty, typeOf, isBlank } from '@ember/utils';

export default Mixin.create({
  rdcLoadingIndicator: service(),
  error: service('card-error-handler'),
  rdcModalManager: service(),
  isNumber(input) {
    // allow enter, backspace, tab, delete, numbers, keypad numbers, home, end only.
    return (
      input === 13 ||
      input === 8 ||
      input === 9 ||
      input === 46 ||
      (input >= 35 && input <= 40) ||
      (input >= 48 && input <= 57) ||
      (input >= 96 && input <= 105)
    );
  },
  isSequenceOrContinuousSameNumber(number) {
    let bool = false;
    let sequencePattern = '0123456789012345789';
    let sameNumPattern = /^([0-9])\1*$/g;
    let containSpecialCharacter = /[^0-9]+/;
    if (sequencePattern.indexOf(number) != -1) {
      bool = true;
    }
    if (number.length > 1 && (sameNumPattern.exec(number) != null || containSpecialCharacter.exec(number) != null)) {
      bool = true;
    }
    return bool;
  },
  closePopupActionForOtp(errorContent) {
    let popupConfig = {
      level: 'warning',
      message: errorContent,
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    };
    let self = this;
    this.get('rdcModalManager')
      .showDialogModal(popupConfig)
      .then(() => {
        if (isEmpty(self.transitionTo)) {
          self.transitionToRoute('serviceRequest.new-request');
        } else {
          self.transitionTo('serviceRequest.new-request');
        }
      })
      .catch(() => {});
  },
  errorHandler(error) {
    if (!isEmpty(error) && !isBlank(error)) {
      if (typeOf(error) == 'string') {
        this.closePopupActionForOtp(error);
      } else if (error['name'] != 'OTPCancelledError') {
        this.set('creditCardStatus', 'CreditCardError');
        this.set('CreditCardErrorcheck', 'undefined');
        if (typeOf(error.errors) != 'undefined') {
          this.set('CreditCardErrorcheck', error.errors[0].code);
        } else {
          this.set('CreditCardErrorcheck', error.code);
        }
        this.get('error').creditCardErrorHandler(this);
      }
    }
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  }
});
