import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';

export default Mixin.create({
  rdcLoadingIndicator: service(),

  setCustomLoader(text, className) {
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    this.get('rdcLoadingIndicator').setLoadingMessage(text);
    this.get('rdcLoadingIndicator').setCustomClass(className);
    this.get('rdcLoadingIndicator').showLoadingIndicator();
  }
});
