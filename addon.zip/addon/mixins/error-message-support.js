import { readOnly, not, none } from '@ember/object/computed';
import { inject as service } from '@ember/service';
import Mixin from '@ember/object/mixin';
import { buildValidations, validator } from 'ember-cp-validations';
import moment from 'moment';
import { isEmpty, isNone } from '@ember/utils';
import { computed } from '@ember/object';

const Validations = buildValidations({
  value: [
    validator('presence', {
      presence: readOnly('model.required'),
      message: computed({
        get() {
          let label = this.get('model.label');
          if (isEmpty(label)) {
            label = 'This field';
          }

          label = label.replace(/<{1}[^<>]{1,}>{1}/g, '');
          return label + this.get('model.i18n').t('FERE.validation.error.message');
        }
      }),
      disabled: not('model.required')
    }),

    validator('number', {
      dependentKeys: ['model.maxValue'],
      lte: readOnly('model.maxValue'),
      message: computed({
        get() {
          let label = this.get('model.label');
          if (isEmpty(label)) {
            label = 'This field';
          }

          label = label.replace(/<{1}[^<>]{1,}>{1}/g, '');
          return label + this.get('model.i18n').t('FERE.validation.error.labelNameError');
        }
      }),
      allowString: true,
      allowBlank: true,
      disabled: computed('model.{maxValue,value}', {
        get() {
          return isNone(this.get('model.maxValue')) || isEmpty(this.get('model.value'));
        }
      })
    }),

    validator('format', {
      regex: readOnly('model.regexp'),
      message: readOnly('model.regexpErrorMessage'),
      disabled: none('model.regexp'),
      allowBlank: true
    }),

    validator('date', {
      dependentKeys: ['model.dateFormat', 'model.minDate', 'model.maxDate'],
      disabled: computed('model.dateFormat', {
        get() {
          return isEmpty(this.get('model.dateFormat'));
        }
      }),
      after: computed('model.minDate', {
        get() {
          let minDate = this.get('model.minDate');
          if (!isEmpty(minDate) && minDate.indexOf('/') == -1) {
            let iMinDate = parseInt(minDate);
            minDate = moment()
              .add(iMinDate, 'days')
              .format('DD/MM/YYYY');
          }
          return minDate;
        }
      }),
      before: computed('model.maxDate', {
        get() {
          let maxDate = this.get('model.maxDate');
          if (!isEmpty(maxDate) && maxDate.indexOf('/') == -1) {
            let iMaxDate = parseInt(maxDate);
            maxDate = moment()
              .add(iMaxDate, 'days')
              .format('DD/MM/YYYY');
          }
          return maxDate;
        }
      }),
      precision: 'day',
      format: readOnly('model.dateFormat'),
      errorFormat: readOnly('model.dateFormat'),
      message: readOnly('model.regexpErrorMessage'),
      allowBlank: true
    })
  ]
});

export default Mixin.create(Validations, {
  mandatoryInput: null,
  validation: null,
  value: null,
  regexp: null,
  regexpErrorMessage: '',
  required: false,
  isValid: true,
  hasError: false,
  classNameBindings: ['hasError:has-error'],
  i18n: service(),
  focusOutValidation() {
    if (isEmpty(this.get('value'))) {
      this.removeValidationError();
    }

    this.validateSync();
    let errors = this.get('validations.attrs.value.errors');
    if (isEmpty(errors) === false) {
      this.setValidationError(errors[0].message);
    } else {
      this.removeValidationError();
    }
  },

  setValidationError(message) {
    this.set('isValid', false);
    this.set('hasError', true);
    this.set('errorLabel', message);
  },

  removeValidationError() {
    this.set('isValid', true);
    this.set('hasError', false);
    this.set('errorLabel', null);
  }
});
