import { inject as service } from '@ember/service';
import Mixin from '@ember/object/mixin';

export default Mixin.create({
  queries: service('customer-info'),
  gaUpdate: function(routeName) {
    let t_routeName = routeName;
    if (!t_routeName) t_routeName = this.routeName;

    let relIDValue = this.get('queries.customerId');
    let screenName;
    if (t_routeName) {
      t_routeName = t_routeName.replace(/\./g, '/');
      screenName = t_routeName.substring(t_routeName.lastIndexOf('/') + 1);
    }
    window['dataLayer'] = [];
    let gaPushObject;
    gaPushObject = {
      ebID: relIDValue,
      event: 'virtualPageView',
      screen: {
        screenName: screenName,
        url: t_routeName
      }
    };
    for (let propValue in gaPushObject) {
      if (!gaPushObject[propValue]) {
        delete gaPushObject[propValue];
      }
    }
    window['dataLayer'].push(gaPushObject);
    (function(w, d, s, l, i) {
      w[l] = w[l] || [];
      w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
      let f = d.getElementsByTagName(s)[0],
        j = d.createElement(s),
        dl = l != 'dataLayer' ? '&l=' + l : '';
      j.async = true;
      j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
      f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-NK6NQ3Z');
  }
});
