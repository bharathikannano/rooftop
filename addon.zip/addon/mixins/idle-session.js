import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';

export default Mixin.create({
  sessionManager: service(),

  activate() {
    this._super(...arguments);

    if (this.get('sessionManager').getPreLoginStatus()) {
      this.get('sessionManager').stopIdleSessionTimer();
    } else {
      this.get('sessionManager').clearTimeout();
    }
  },

  deactivate() {
    this._super(...arguments);

    this.get('sessionManager').clearTimeout();
  }
});
