import Mixin from '@ember/object/mixin';
import { inject as service } from '@ember/service';
import { Promise as EmberPromise } from 'rsvp';
import { A } from '@ember/array';
import { computed } from '@ember/object';
import { isEmpty, isEqual } from '@ember/utils';
export default Mixin.create({
  customerInfo: service(),
  i18n: service(),
  pageArray: A([]),
  cardMaskConfig: computed(function() {
    return this.customerInfo.cardMaskConfig();
  }),
  loanMaskConfig: computed(function() {
    return this.customerInfo.loanMaskConfig();
  }),
  cardMasking: computed(function() {
    return this.customerInfo.cardMasking();
  }),
  getdataValues(data) {
    return new EmberPromise(resolve => {
      let productDetail = A();
      data.forEach(item => {
        let listData = ((cardImg, accountNo, value, id, alerts, currencyCode, segmentType) => ({
          cardImg,
          accountNo,
          value,
          id,
          alerts,
          currencyCode,
          segmentType
        }))(
          item.get('cardImageName') ? item.get('cardImageName') : null,
          item.get('cardNum') ? item.get('cardNum') : item.get('accountNumber'),
          item.get('desc') ? item.get('desc') : item.get('productDescription'),
          item.get('relId'),
          item.get('alerts') ? true : false,
          item.get('currencyCode') ? item.get('currencyCode') : null,
          item.get('segmentType') ? item.get('segmentType') : null
        );
        listData['modelName'] = data.modelName;
        productDetail.pushObject(listData);
      });
      resolve(productDetail);
    });
  },
  getCurrentStepName(currentPageNo) {
    const charingCnty = A(['SG', 'MY', 'VN', 'BN']);
    let country = this.get('customerInfo.countryName');
    let curPage = currentPageNo;
    const statementData = this.controllerFor('duplicate-statement').statementData;
    this.set('pageArray', [1, 2, 3, 4, 5]);
    if (!isEqual(statementData.entity, 'ALL')) {
      this.removeArrayIndex(1);
    }
    if (charingCnty.includes(country)) {
      if (
        (!isEmpty(statementData.productReview) && !isEmpty(statementData.productReview.deliveryMode) && country === 'MY' && statementData.productReview.deliveryMode.toString().includes('Email')) ||
        (country === 'VN' && statementData.customerCont.priorityCustomer ) ||
        (country === 'VN' && (statementData.entity === "ALL" ? !isEmpty(statementData.product) ? statementData.product.entity : statementData.entity : statementData.entity) !== "CASA")
      ) {
        this.removeArrayIndex(4);
      }
    } else {
      this.removeArrayIndex(4);
    }
    this.get('pageArray').sort();
    let curIndex = this.get('pageArray').indexOf(curPage);
    curPage = curIndex + 1;
    return `${curPage} ${this.get('i18n').t('ServiceRequest.COMMON.progress.stepOf')} ${this.get('pageArray').length}`;
  },
  removeArrayIndex(index) {
    let removeIndex = this.get('pageArray').indexOf(index);
    if (removeIndex > -1) {
      this.get('pageArray').splice(removeIndex, 1);
    }
  },
  actions: {
    goToPage(routeName) {
      this.transitionTo(routeName);
    }
  }
});