import { isEmpty } from '@ember/utils';
import Mixin from '@ember/object/mixin';

export default Mixin.create({
  /**
   * Method called to verify if the content of the field is matched with regular expression.
   *
   * @method match
   */
  match(regexp, data) {
    this._super(...arguments);
    if (isEmpty(regexp)) {
      return true;
    } else {
      let exp = new RegExp(regexp);
      return exp.test(data);
    }
  }
});
