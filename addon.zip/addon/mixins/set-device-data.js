/* eslint-disable no-redeclare */
/* global PushNotification, cordova */
import Mixin from '@ember/object/mixin';
import Ember from 'ember';
import { inject as service } from '@ember/service';
import { Promise as EmberPromise } from 'rsvp';

export default Mixin.create({
  store: service(),
  axwayConfig: service(),
  apnsOrFcmRegID: null,

  setDeviceDataBeforeSubmit() {
    const countries = ['KE', 'UG', 'TZ', 'GH', 'BW', 'ZM', 'ZW', 'NG', 'CI'];
    if (countries.indexOf(this.get('axwayConfig.country')) !== -1) {
      let deviceId = this.get('store').peekRecord('field', 'DeviceId');
      let deviceName = this.get('store').peekRecord('field', 'DeviceName');
      let deviceOS = this.get('store').peekRecord('field', 'DeviceOS');
      let deviceOsVersion = this.get('store').peekRecord('field', 'DeviceOsVersion');
      let deviceModel = this.get('store').peekRecord('field', 'DeviceModel');
      let deviceToken = this.get('store').peekRecord('field', 'DeviceToken');
      let ntbRegistrationId = this.get('store').peekRecord('field', 'NtbRegistrationId');
      if (window.cordova) {
        if (deviceId && deviceName && deviceOS && deviceOsVersion && deviceModel && deviceToken) {
          deviceId.set('value', window.device.uuid);
          deviceName.set('value', window.device.name);
          deviceOS.set('value', window.device.platform);
          deviceOsVersion.set('value', window.device.version);
          deviceModel.set('value', window.device.model);
          if (localStorage.getItem('NtbRegistrationId')) {
            ntbRegistrationId.set('value', localStorage.getItem('NtbRegistrationId'));
          }
          if (this.apnsOrFcmRegID) {
            deviceToken.set('value', this.apnsOrFcmRegID);
          }
        }
      }
    }
  },

  storeNtbRegistrationId(NtbRegistrationId) {
    localStorage.setItem('NtbRegistrationId', NtbRegistrationId);
  },

  setDeviceToken() {
    this.isNotificationEnabled().then(
      isEnabled => {
        if (isEnabled) {
          this.getDeviceTokenFromFCMOrAPNS()
            .then(registrationId => {
              if (registrationId) {
                this.set('apnsOrFcmRegID', registrationId);
              }
            })
            .catch(err => {
              Ember.Logger.log('Error while enableForNotifications' + err);
            });
        }
      },
      error => {
        Ember.Logger.log('is Already registered with APNS/FCM value thrown error' + JSON.stringify(error));
      }
    );
  },

  // For the native iOS, the push notification plugin isn't shipped, however these two methods are provided via an
  // alternative plugin that can be access directly via cordova.exec(...)
  addPluginInterfaceIfNeeded() {
    if (!window.PushNotification) {
      window.PushNotification = {
        hasPermission: function(success, error) {
          cordova.exec(success, error, 'PushNotification', 'hasPermission', []);
        },
        getToken: function(success, error) {
          cordova.exec(success, error, 'PushNotification', 'getToken', []);
        }
      };
    }
  },

  isNotificationEnabled() {
    this.addPluginInterfaceIfNeeded();
    return new EmberPromise((resolve, reject) => {
      PushNotification.hasPermission(
        data => {
          Ember.Logger.log('Is APNS/FCM already Registered: ' + JSON.stringify(data));
          resolve(data.isEnabled);
        },
        error => {
          reject(error);
        }
      );
    });
  },

  getDeviceTokenFromFCMOrAPNS() {
    this.addPluginInterfaceIfNeeded();
    return new EmberPromise((resolve, reject) => {
      PushNotification.getToken(
        data => {
          Ember.Logger.log('Get device token from FCM or APNS:' + JSON.stringify(data));
          resolve(data.registrationId);
        },
        error => {
          reject(error);
        }
      );
    });
  }
});
