import DS from 'ember-data';

export default DS.Model.extend({
  childRefNo: DS.attr('string'),
  floatingTxn: DS.attr('string'),
  posCode: DS.attr('string'),
  txnCode: DS.attr('string'),
  goodWillRevFlag: DS.attr('string'),
  txnDate: DS.attr('string'),
  actualTxnCurr: DS.attr('string'),
  actualTxnAmount: DS.attr('string'),
  originTxnCurr: DS.attr('string'),
  originTxnAmt: DS.attr('string'),
  arnCode: DS.attr('string'),
  approvalCode: DS.attr('string'),
  postedDate: DS.attr('string'),
  transactionDesc: DS.attr('string'),
  status: DS.attr('string'),
  visible: DS.attr('boolean')
});
