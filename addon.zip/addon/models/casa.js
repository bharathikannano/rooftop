import DS from 'ember-data';

export default DS.Model.extend({
  accountStatus: DS.attr(''),
  relId: DS.attr(''),
  productDescription: DS.attr(''),
  subProductDescription: DS.attr(''),
  currencyCode: DS.attr(''),
  alerts: DS.attr(''),
  accountNumber: DS.attr(''),
  accountType: DS.attr(''),
  availableBalance: DS.attr(''),
  amountType: DS.attr(''),
  productCode: DS.attr(''),
  subProductCode: DS.attr(''),
  currentBalance: DS.attr(''),
  blockListCat: DS.attr(''),
  accountEligibility: DS.attr(''),
  eligibleCasas: DS.attr(''),
  branches: DS.attr(''),
  depositMaturityDate: DS.attr(''),
  ownerName: DS.attr(''),
  depositProductCode: DS.attr(''),
  operatingInstructions: DS.attr(''),
  segmentType: DS.attr('')
});
