import DS from 'ember-data';

export default DS.Model.extend({
  address1: DS.attr('string'),
  address2: DS.attr('string'),
  address3: DS.attr('string'),
  address4: DS.attr('string'),
  city: DS.attr('string'),
  postalCode: DS.attr('string'),
  state: DS.attr('string')
});
