import DS from 'ember-data';

export default DS.Model.extend({
  payload: DS.attr(''),
  serviceRequest: DS.attr('')
});
