import DS from 'ember-data';

export default DS.Model.extend({
  country: DS.attr('string'),
  randomChallenge: DS.attr()
});
