import DS from 'ember-data';

export default DS.Model.extend({
  key: DS.attr('string'),
  value: DS.attr('string'),
  channelDesc: DS.attr('string'),
  cvStatus: DS.attr('string'),
  channelId: DS.attr('string'),
  countryCode: DS.attr('string'),
  custVerified: DS.attr('string'),
  basicVerification: DS.attr(''),
  additionalVerification: DS.attr(''),
  errorDescription: DS.attr('string'),
  errorCode: DS.attr('string'),
  creditCardFeeWaiver: DS.attr(''),
  srDetails: DS.hasMany('srDetail'),
  userGroup: DS.attr('string')
});
