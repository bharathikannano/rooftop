import DS from 'ember-data';

export default DS.Model.extend({
  risks: DS.attr(''),
  alerts: DS.attr(''),
  profile: DS.attr(''),
  customercontacts: DS.attr(''),
  customeraddresses: DS.attr(''),
  custEligibleFlag: DS.attr('boolean'),
  priorityCustomerFlag: DS.attr('boolean')
});
