import DS from 'ember-data';

export default DS.Model.extend({
  blkInd: DS.attr('string'),
  franchise: DS.attr('string'),
  prod: DS.attr('string'),
  cardType: DS.attr('string'),
  expDt: DS.attr('string'),
  cardNum: DS.attr('string'),
  cardImageName: DS.attr('string'),
  primaryFlag: DS.attr('string'),
  customerId: DS.attr('string'),
  variant: DS.attr('string'),
  custShortName: DS.attr('string'),
  currencyCode: DS.attr('string'),
  desc: DS.attr('string'),
  status: DS.attr('string'),
  cardSeq: DS.attr('string'),
  relType: DS.attr('string'),
  relId: DS.attr('string'),
  cardTypeCd: DS.attr('string'),
  linkAccNum: DS.attr('string'),
  linkAccStatus: DS.attr('string'),
  cardLangCd: DS.attr('string'),
  linkedAccounts: DS.attr(''),
  cardEmboserName: DS.attr('string'),
  cardStatus: DS.attr('string'),
  alerts: DS.attr('')
});
