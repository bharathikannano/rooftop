import DS from 'ember-data';

export default DS.Model.extend({
  type: DS.attr('string'),
  images: DS.attr(),
  typeDesc: DS.attr('string'),
  cardTitle: DS.attr('string'),
  cardDesc: DS.attr('string'),
  defaultImg: DS.attr('string'),
  imageBytes: DS.attr()
});
