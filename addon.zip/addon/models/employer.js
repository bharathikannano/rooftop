import DS from 'ember-data';

export default DS.Model.extend({
  companyCode: DS.attr('string'),
  country: DS.attr('string'),
  choiceName: DS.attr('string'),
  displayOrder: DS.attr('number'),
  readOnly: DS.attr('string'),
  label: DS.attr('string'),
  value: DS.attr('string')
});
