import DS from 'ember-data';

export default DS.Model.extend({
  fee: DS.attr(''),
  title: DS.attr('string')
});
