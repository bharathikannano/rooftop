import DS from 'ember-data';

export default DS.Model.extend({
  productDescription: DS.attr('string'),
  accountNumber: DS.attr('string'),
  accountType: DS.attr('string'),
  subProductCode: DS.attr('string'),
  relId: DS.attr('string'),
  accountDescription: DS.attr('string'),
  alerts: DS.attr(''),
  currencyCode: DS.attr('')
});
