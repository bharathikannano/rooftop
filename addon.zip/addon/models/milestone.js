import { computed } from '@ember/object';
import DS from 'ember-data';

export default DS.Model.extend({
  startTime: DS.attr('string'),
  endTime: DS.attr('string'),
  status: DS.attr('string'),
  description: DS.attr('string'),
  elapsedTime: DS.attr('string'),

  isReferralInProgress: computed('description', 'status', {
    get() {
      return (
        (this.get('description') === 'REFERRAL' ||
          this.get('description') === 'AUTHREFERRAL' ||
          this.get('description') === 'AuthCode VERIFICATION') &&
        this.get('status') === 'In Progress'
      );
    }
  }),

  isResumeInProgress: computed('description', 'status', {
    get() {
      return this.get('description') === 'INCOMPLETE' && this.get('status') === 'In Progress';
    }
  }),

  isResumeCompleted: computed('description', 'status', {
    get() {
      return this.get('description') === 'INCOMPLETE' && this.get('status') === 'Completed';
    }
  }),

  isVerificationInProgress: computed('description', 'status', {
    get() {
      return this.get('description') === 'ID VERIFICATION' && this.get('status') === 'In Progress';
    }
  }),

  isYetToStart: computed('status', {
    get() {
      return this.get('status') === 'Yet to start';
    }
  }),

  isCompletedOrInProgress: computed('status', {
    get() {
      return this.get('status') === 'Completed' || this.get('status') === 'In Progress';
    }
  })
});
