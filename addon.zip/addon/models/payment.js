import DS from 'ember-data';

export default DS.Model.extend({
  paymentType: DS.attr('string'),
  subPaymentType: DS.attr('string'),
  settlementType: DS.attr('string'),
  paymentScheme: DS.attr('string'),
  txnCur: DS.attr('string'),
  txnAmount: DS.attr('string'),
  dtTransfer: DS.attr('string'),
  pop: DS.attr('string'),
  dbtAccName: DS.attr('string'),
  dbtAccNumber: DS.attr('string'),
  dbtAccCur: DS.attr('string'),
  dbtAccType: DS.attr('string'),
  cdtAccName: DS.attr('string'),
  cdtAccNumber: DS.attr('string'),
  cdtAccCur: DS.attr('string'),
  cdtAccType: DS.attr('string'),
  excessAmount: DS.attr('string'),
  reasonToRefund: DS.attr('string'),
  otherReason: DS.attr('string'),
  frtlnUserType: DS.attr('string')
});
