import DS from 'ember-data';

export default DS.Model.extend({
  cardNum: DS.attr('string'),
  encCardPin: DS.attr('string'),
  encCardInfo: DS.attr('string'),
  pinKeyIndex: DS.attr('string')
});
