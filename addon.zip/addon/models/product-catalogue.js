import DS from 'ember-data';

export default DS.Model.extend({
  categoryName: DS.attr('string'),
  categoryImage: DS.attr('string'),
  products: DS.hasMany('product'),
  categoryDisabled: DS.attr('boolean')
});
