import DS from 'ember-data';

export default DS.Model.extend({
  criteriaTitle: DS.attr(''),
  conditions: DS.attr('')
});
