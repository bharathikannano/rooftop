import DS from 'ember-data';

export default DS.Model.extend({
  productDescription: DS.attr('string'),
  productType: DS.attr('string'),
  productImage: DS.attr('string'),
  selectable: DS.attr('string'),
  learnMore: DS.attr('string'),
  detailDescription: DS.attr('string'),
  stepName: DS.attr('string'),
  processId: DS.attr('string'),
  landscapeImage: DS.attr('string'),
  squareImage: DS.attr('string'),
  subProductTypeCode: DS.attr('string'),
  productName: DS.attr('string'),
  category: DS.attr('string'),
  termsAndConditions: DS.hasMany('product-terms-and-condition'),
  eligibility: DS.hasMany('product-eligibility'),
  feeAndCharges: DS.hasMany('fee-and-charge')
});
