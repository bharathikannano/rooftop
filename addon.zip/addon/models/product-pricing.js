import DS from 'ember-data';

export default DS.Model.extend({
  charges: DS.attr('string'),
  footer: DS.attr('string'),
  header: DS.attr('string'),
  annualFee: DS.attr('string'),
  annualFeeInfo: DS.attr('string'),
  multiProdFooter: DS.attr('string')
});
