import DS from 'ember-data';

export default DS.Model.extend({
  rewardsPoint: DS.attr(''),
  cashBack: DS.attr(''),
  worldMiles: DS.attr(''),
  type: DS.attr('string'),
  asiaMiles: DS.attr(''),
  alerts: DS.attr('')
});
