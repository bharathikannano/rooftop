import { isEmpty } from '@ember/utils';
import { computed } from '@ember/object';
import DS from 'ember-data';

export default DS.Model.extend({
  serviceType: DS.attr('string'),
  relNumber: DS.attr('string'),
  status: DS.attr('string'),
  estimatedCompletionDate: DS.attr('string'),
  payload: DS.attr(''),
  lastUpdatedDate: DS.attr('string'),
  completedDate: DS.attr('string'),
  submittedDate: DS.attr('string'),
  lastGroupCompletedDate: DS.attr('string'),
  country: DS.attr('string'),
  dateOrder: DS.attr('string'),
  responsePayload: DS.attr(''),
  retryCount: DS.attr('string'),
  sessionId: DS.attr('string'),
  statusOrder: DS.attr('string'),
  isCritical: DS.attr('string'),
  createdBy: DS.attr('string'),
  receivedDate: DS.attr('string'),
  isCemsRequest: DS.attr('boolean'),
  statusDescription: DS.attr('string'),
  replacementStatus: DS.attr('string'),
  milestones: DS.hasMany('milestone'),
  mobileNo: DS.attr('string'),
  eopsReferenceUrl: DS.attr('string'),
  serviceTypeEn: DS.attr('string'),
  isDocAvailable: DS.attr('boolean'),
  additionalInfo: DS.attr(''),
  hostReceiptId: DS.attr('string'),
  patchRequestId: DS.attr('string'),
  isPatchRequest: DS.attr('string'),
  documentList: DS.attr(''),
  isNstpRequest: DS.attr('string'),
  isBoRequest: DS.attr('boolean'),
  currentMilestone: computed('milestones.@each.{status,description}', {
    get() {
      let currentMilestone = this.get('milestones').findBy('status', 'In Progress');
      if (currentMilestone != null) {
        return currentMilestone;
      }

      return this.get('milestones.lastObject');
    }
  }),

  isReferral: computed('serviceType', 'milestones.@each.{status,description}', {
    get() {
      let referralMileStone = this.get('milestones').filter(milestone => {
        return (
          (milestone.get('description') === 'REFERRAL' ||
            milestone.get('description') === 'AUTHREFERRAL' ||
            milestone.get('description') === 'AuthCode VERIFICATION') &&
          milestone.get('status') === 'In Progress'
        );
      });

      return isEmpty(referralMileStone) === false;
    }
  }),

  isResume: computed('serviceType', 'additionalInfo', 'additionalInfo.eventType', {
    get() {
      let resume = this.get('additionalInfo') && this.get('additionalInfo.eventType');

      return resume === 'RESUME';
    }
  }),

  isVerification: computed('serviceType', 'additionalInfo', 'additionalInfo.eventType', {
    get() {
      let verification = this.get('additionalInfo') && this.get('additionalInfo.eventType');

      return verification === 'VERIFICATION';
    }
  }),

  isProcessingNotStarted: computed('serviceType', 'milestones.@each.{status,description}', {
    get() {
      let processingNotStarted = this.get('milestones').filter(milestone => {
        return milestone.get('description') == 'PROCESSING' && milestone.get('status') == 'Yet to start';
      });

      return isEmpty(processingNotStarted) === false;
    }
  }),

  referralResumeData: computed(
    'isReferral',
    'isResume',
    'isVerification',
    'hostReceiptId',
    'id',
    'additionalInfo',
    'mobileNo',
    {
      get() {
        if (this.get('isResume') || this.get('isReferral') || this.get('isVerification')) {
          let data = {
            id: this.get('additionalInfo.processId'),
            stepName: this.get('additionalInfo.primaryStep'),
            eopsTxnRefNo: this.get('hostReceiptId'),
            sourceRefNo: this.get('id'),
            eventType: this.get('additionalInfo.eventType'),
            TASKID: this.get('additionalInfo.taskId'),
            operationName: this.get('additionalInfo.OperationName')
          };

          if (this.get('mobileNo')) {
            data.mobileNo = this.get('mobileNo');
          }

          return JSON.stringify(data);
        }

        return false;
      }
    }
  ),

  routeName: computed('additionalInfo', {
    get() {
      let additionalInfo = this.get('additionalInfo');
      if (additionalInfo && additionalInfo.actionUrl) {
        return additionalInfo.actionUrl;
      }
    }
  }),

  isOpen: computed(function() {
    return this.get('isReferral') || this.get('isResume') || this.get('isVerification');
  })
});
