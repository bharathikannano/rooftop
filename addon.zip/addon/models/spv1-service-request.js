import DS from 'ember-data';

export default DS.Model.extend({
  alerts: DS.attr(''),
  errors: DS.attr('')
});
