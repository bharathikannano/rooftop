import DS from 'ember-data';

export default DS.Model.extend({
  srName: DS.attr('string'),
  addVerifyMandatary: DS.attr('string'),
  basicVerifyMandatary: DS.attr('string')
});
