import DS from 'ember-data';

export default DS.Model.extend({
  txnRefNo: DS.attr('string'),
  batchNumber: DS.attr('string'),
  desc: DS.attr('string'),
  sequenceNumber: DS.attr('string'),
  cardNum: DS.attr('string'),
  txnDate: DS.attr('string'),
  originTxnAmt: DS.attr('number'),
  primarySuppInd: DS.attr('string'),
  actualTxnAmt: DS.attr('number'),
  equivalentRewardPoints: DS.attr(''),
  rewardPts: DS.attr('string'),
  partialrevTxnAmt: DS.attr('number'),
  partialrevTxnDate: DS.attr('string'),
  txnCurrency: DS.attr('string'),
  debitCreditFlag: DS.attr('string'),
  isPartiallyReversed: DS.attr('string'),
  rewardsPoints: DS.attr('string'),

  txnCode: DS.attr('string'),
  transacOrgnAmount: DS.attr('string'),
  transactionFlag: DS.attr(''),
  transactionAmount: DS.attr('number')
});
