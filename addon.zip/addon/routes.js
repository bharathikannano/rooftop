import buildRoutes from 'ember-engines/routes';

export default buildRoutes(function() {
  this.route('serviceRequest', { path: '/' }, function() {
    this.route('new-request', { path: '/new' });
    this.route('status', { path: '/status' });
    this.route('rdc-confirmpopup', { path: '/error' });
  });

  this.route('chequeRequest', { path: '/cheque-request' }, function() {
    this.route('new-request', { path: '/new' });
    this.route('delivery-method-selection');
    this.route('request-confirm', { path: '/confirmation' });
    this.route('request-status', { path: '/result' });
  });
  this.route('chequeBookRequest', { path: '/cheque-book-request' }, function() {
    this.route('new-request', { path: '/new' });
    this.route('delivery-method-selection');
    this.route('delivery-address');
    this.route('request-confirm', { path: '/confirmation' });
    this.route('request-status', { path: '/result' });
  });

  this.route('fixed-deposit-upliftment', { path: '/fixed-deposit-upliftment' }, function() {
    this.route('new-request', { path: '/new-request' });
    this.route('confirm');
    this.route('status');
  });

  this.route('card-block', { path: '/card-block' }, function() {
    this.route('select');
    this.route('confirm');
    this.route('status');
  });

  this.route('card-replacement', { path: '/card-replacement' }, function() {
    this.route('select');
    this.route('confirm');
    this.route('status');
  });

  this.route('debitcard-new-replacement', { path: '/debitcard-new-replacement' }, function() {
    this.route('select-existing-card');
    this.route('select-new-card');
    this.route('select-card-face');
    this.route('confirm');
    this.route('status');
  });
  this.route('card-cancellation', { path: '/card-cancellation' }, function() {
    this.route('select');
    this.route('confirm');
    this.route('status');
    this.route('error-handler');
  });

  this.route('credit-balance-refund', { path: '/credit-balance-refund' }, function() {
    this.route('new-request', { path: '/new-request' });
    this.route('refund-method', { path: '/refund-method' });
    this.route('refund-amount', { path: '/refund-amount' });
    this.route('request-confirm', { path: '/request-confirm' });
    this.route('request-status', { path: '/request-status' });
    this.route('error-status', { path: '/error-status' });
  });

  this.fereRoute('profileUpdate', { path: '/profile-update' });
  this.fereRoute('disclaimer', { path: '/disclaimer' });
  this.fereRoute('accountOpening', { path: '/account-opening' });
  this.fereRoute('accountUpgrade', { path: '/account-upgrade' });
  this.fereRoute('plTopup', { path: '/pl-topup' });
  this.fereRoute('demandDraft', { path: '/demand-draft' });
  this.fereRoute('accountClosure', { path: '/account-closure' });
  this.fereRoute('updateFatcaStatus', { path: '/update-fatca-status' });
  this.fereRoute('cddUpdate', { path: '/cdd-update' });
  this.fereRoute('kycDocumentRequest', { path: '/kyc-document-request' });
  this.fereRoute('newSignAddition', { path: '/new-sign-addition' });
  this.fereRoute('signChange', { path: '/sign-change' });
  this.fereRoute('sweepSetup', { path: '/sweep-setup' });
  this.fereRoute('upliftFullFd', { path: '/uplift-full-fd' });
  this.fereRoute('dndRequestRemoval', { path: '/dnd-request-removal' });
  this.fereRoute('requestStatement', { path: '/request-statement' });
  this.fereRoute('debit-card-block-and-replace', { path: '/debit-card-block-and-replace' });
  this.fereRoute('debit-card-replace', { path: '/debit-card-replace' });
  this.fereRoute('debit-card-activation-pinset', { path: '/debit-card-activation-pinset' });
  this.fereRoute('debit-card-pin-reset', { path: '/debit-card-pin-reset' });
  this.fereRoute('letters', { path: '/letters' });
  this.fereRoute('cheque-book-activation', { path: '/cheque-book-activation' });
  this.fereRoute('cheque-stop', { path: '/cheque-stop' });
  this.fereRoute('high-value-cheque-confirmation', { path: '/high-value-cheque-confirmation' });
  this.fereRoute('issue-new-cheque-book', { path: '/issue-new-cheque-book' });
  this.fereRoute('fixedDeposit', { path: '/fixed-deposit' });
  this.fereRoute('jointAccount', { path: '/joint-account' });
  this.fereRoute('accountInformation', { path: '/account-information' });
  this.fereRoute('visaTransfer', { path: '/visa-transfer' });
  this.fereRoute('apply-products', { path: '/apply-products' });
  this.fereRoute('get-cvv', { path: '/get-cvv' });
  this.fereRoute('ecocash-registration', { path: '/ecocash-registration' });
  this.fereRoute('hr-portal-applications', { path: '/hr-portal-application' });

  this.route('card-feewavier', { path: '/card-feewavier' }, function() {
    this.route('new-request');
    this.route('selected-card');
    this.route('cards-point');
    this.route('request-status');
    this.route('card-validation');
    this.route('charge-page');
  });

  this.route('product', { path: '/product' }, function() {
    this.route('opening');
    this.route('current-account');
    this.route('excel-saver-account');
    this.route('fixed-deposit');
    this.route('multiple-currencies');
  });
  this.route('credit-activation', { path: '/credit-activation' }, function() {
    this.route('select');
    this.route('create-pin', { path: '/:selectedCardId' });
    this.route('status');
  });

  this.route('credit-pin-change', { path: '/credit-pin-change' }, function() {
    this.route('select');
    this.route('create-pin', { path: '/:selectedCardId' });
    this.route('status');
  });

  this.route('card-setting', { path: '/card-setting' }, function() {
    this.route('index', { path: '/' });
    //this.route('select');
    this.route('credit-card', { path: '/credit-card/:cardNumEncrypted' }, function() {
      this.route('index', { path: '/' });
      this.route('transaction-limit', { path: '/transaction-limit' });
      this.route('payment-channels', { path: '/payment-channels' });
      this.route('controlled-categories', { path: '/controlled-categories' });
      this.route('country-limits', { path: '/country-limits' });
    });
    this.route('confirm');
  });

  this.route('manage-card-usage', { path: '/manage-card-usage' }, function() {
    this.route('index', { path: '/' });
    this.route('card-management', { path: '/card-management/:cardNumEncrypted' }, function() {
      this.route('index', { path: '/' });
      this.route('atm-transactions', { path: '/atm-transactions' });
      this.route('overseas-transactions', { path: '/overseas-transactions' });
      this.route('tokenized-transactions', { path: '/tokenized-transactions' });
    });
    this.route('success-summary', { path: '/success-summary' });
    this.route('failure-summary', { path: '/failure-summary' });
  });

  this.route('trackApplication', { path: '/track-application' });
  this.route('statusAccounts', { path: '/status-accounts' });
  this.route('registerOnlineBanking', { path: '/register-online-banking' });
  this.route('resumeApplication', { path: '/resume-application' });
  this.route('statusTracking', { path: '/status-tracking' });

  this.route('loan-closure', { path: '/loan-closure' }, function() {
    this.route('select');
    this.route('confirm');
    this.route('status');
    this.route('error-handler');
  });
  this.route('transfer-of-payments', { path: '/transfer-of-payments' }, function() {
    this.route('display-from-card', { path: '/displaying-from-card' });
    this.route('display-to-card', { path: '/displaying-to-card' });
    this.route('confirm', { path: '/confirm' });
    this.route('status-result', { path: '/status-result' });
    this.route('no-card', { path: '/no-card' });
  });
  this.route('product-list', { path: '/product-list' }, function() {
    this.route('category');
    this.route('list');
    this.route('details');
  });
  this.route('staff-document-dashboard', { path: '/staff-document-dashboard' });
  this.route('staff-product-category', { path: '/staff-product-category' });
  this.fereRoute('start-application', { path: '/start-application' });
  this.route('assetAccountSelection', { path: '/asset-account-selection' });
  this.route('appDedupe', { path: '/app-dedupe' });
  this.fereRoute('dhlAgents', { path: '/dhl-agents' });
  this.fereRoute('credit-limit-increase', { path: '/credit-limit-increase' });
  this.fereRoute('generic-fere-form', { path: '/generic-fere-form' });
  this.fereRoute('generic-lightbox-fere-form', { path: '/generic-lightbox-fere-form' });
  this.fereRoute('staff-document-collection', { path: '/staff-document-collection' });

  this.route('generic-request-form', { path: '/generic-request-form' }, function() {
    this.route('select');
    this.route('upload');
    this.route('review');
    this.route('status');
    this.route('referral');
  });

  this.fereRoute('creditCardActivationPinset', { path: '/credit-card-activation-pinset' });

  this.route('duplicate-statement', { path: '/duplicate-statement' }, function() {
    this.route('select');
    this.route('product');
    this.route('statement');
    this.route('account');
    this.route('confirm');
    this.route('review');
    this.route('status');
  });

  this.route('change-statement-date', { path: '/change-statement-date' }, function() {
    this.route('change');
    this.route('confirm');
    this.route('status');
  });

  this.fereRoute('formw-8ben', { path: '/formw-8ben' });

  this.route('certificates-request', { path: '/certificates-request' }, function() {
    this.route('select');
    this.route('year-selection');
    this.route('confirm');
    this.route('status');
  });

  this.route('signature-update', { path: '/signature-update' }, function() {
    this.route('select-product', { path: '/select-product' });
    this.route('confirmation', { path: '/confirmation' });
    this.route('status', { path: '/status' });
    this.route('upload-signature', { path: '/upload-signature' });
    this.route('verify-signature', { path: '/verify-signature' });
    this.route('review-signature', { path: '/review-signature' });
  });

  this.route('dollar-reinstatement', { path: '/dollar-reinstatement' }, function() {
    this.route('select');
    this.route('review');
    this.route('status');
  });

  this.route('pos-limit', { path: '/pos-limit' }, function() {
    this.route('select');
    this.route('product');
    this.route('all-products');
    this.route('confirm');
    this.route('status');
  });

  this.route('hr-portal-dashboard', { path: '/hr-portal-dashboard' });

  this.route('debit-card-setting', { path: '/debit-card-setting' }, function() {
    this.route('select-card');
    this.route('card-setting', { path: '/:selectedCardId' });
    this.route('confirmation');
    this.route('status');
  });
});
