import { inject as service } from '@ember/service';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import idleSession from 'rdc-ui-eng-service-requests/mixins/idle-session';
import { computed } from '@ember/object';
import customLoader from 'rdc-ui-eng-service-requests/mixins/custom-loader';
import { isEmpty } from '@ember/utils';

export default FereFormRoute.extend(idleSession, customLoader, {
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),

  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'MK_F1', countryCode: this.get('axwayConfig.country'), id: 'W400' } };
    }
  }),

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
  },

  closeThisForm() {
    if (this.get('axwayConfig.country') == 'CI') {
      this.transitionTo('product.opening');
    } else {
      this.transitionTo('product-list.list');
    }
  },

  setLoader() {
    if (this.get('formId') === 'W400' && this.get('filter.stepName') === 'MK_F1') {
      this.setCustomLoader(
        this.get('i18n')
          .t('rdc.loading.saving')
          .toString(),
        ' '
      );
      if (isEmpty(this.currentModel.receiptId)) {
        this.setCustomLoader(
          this.get('i18n')
            .t('rdc.loading.text')
            .toString(),
          ' '
        );
      }
    }
  },

  actions: {
    submitFirstPage() {
      let cardName = this.get('store').peekRecord('field', 'CardName');
      if (cardName) {
        let value = cardName.get('value');
        let newValue = value && value.substring(0, 19);
        cardName.set('value', newValue);
      }
      this.setLoader();
      this.goToNextPage();
    },

    goToNextPage() {
      this.setLoader();
      this.goToNextPage();
    },

    goToBack() {
      let mobileNo = this.get('store').peekRecord('field', 'ContactValue1');
      let emailId = this.get('store').peekRecord('field', 'ContactValue3');
      if (mobileNo && emailId) {
        mobileNo.set('editable', false);
        emailId.set('editable', false);
      }

      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        if (this.get('axwayConfig.country') == 'CI') {
          this.transitionTo('product.opening');
        } else {
          this.transitionTo('product-list.list');
        }
      }
    },

    closeForm() {
      if (this.get('axwayConfig.country') == 'CI') {
        this.transitionTo('product.opening');
      } else {
        this.transitionTo('product-list.list');
      }
    },

    callAssistance() {
      document.location.href = 'tel:+22520303281';
    }
  }
});
