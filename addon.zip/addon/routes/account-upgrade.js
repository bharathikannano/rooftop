import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';
import config from '../config/environment';
import checkMaintenance from 'rdc-ui-eng-service-requests/mixins/check-maintenance';
import { Promise as EmberPromise } from 'rsvp';

export default FereFormRoute.extend(checkMaintenance, {
  axwayConfig: service(),
  iframeManager: service(),
  otpManager: service(),
  rdcLoadingIndicator: service(),
  store: service(),
  i18n: service(),
  session: service(),
  accessToken: computed('session', {
    get() {
      const accessToken = this.get('session.data.authenticated.access_token');
      return accessToken;
    }
  }),
  refreshToken: computed('session', {
    get() {
      const refreshToken = this.get('session.data.authenticated.refresh_token');
      return refreshToken;
    }
  }),
  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'MK_F4', countryCode: this.get('axwayConfig.country'), id: 'W400' } };
    }
  }),

  beforeModel(params) {
    this._super(...arguments);
    // To not allow the user to continue the application if the query params are empty to avoid error in CSL.
    if (
      isEmpty(params.queryParams.toTier) ||
      isEmpty(params.queryParams.fromTier) ||
      isEmpty(params.queryParams.accountNumber)
    ) {
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'error',
          title: this.get('i18n').t('ServiceRequest.COMMON.sessionExpire.title'),
          message: this.get('i18n').t('ServiceRequest.COMMON.sessionExpire.message'),
          acceptButtonLabel: this.get('i18n').t('generic.ok')
        })
        .then(() => {
          this.send('goToHome');
        });
    } else {
      // Sending only the required params as sending other params will throw Mapping error in CSL side.
      let filterParams = {
        toTier: params.queryParams.toTier,
        fromTier: params.queryParams.fromTier,
        accountNumber: params.queryParams.accountNumber,
        // Sending the productList for upgrade journey.
        productList:
          params.queryParams.toTier == '006' ? `CA~${params.queryParams.toTier}~0` : `SA~${params.queryParams.toTier}~0`
      };
      Object.keys(filterParams).forEach(element => {
        this.queryParams.filter[element] = filterParams[element];
      });
    }
  },

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));

    /* TO check if the application is under maintanence.
     * This check is used to alert the user by just changing a flag in JSON file.
     */
    this.checkMaintenance().then(isUnderMaintanence => {
      if (isUnderMaintanence) {
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'error',
            title: this.get('i18n').t('ServiceRequest.COMMON.maintanence.title'),
            message: this.get('i18n').t('ServiceRequest.COMMON.maintanence.message'),
            acceptButtonLabel: this.get('i18n').t('generic.ok')
          })
          .then(() => {
            this.send('goToHome');
          });
      }
    });
  },

  afterFileUpload(saveModel) {
    if (window.cordova && saveModel && !isEmpty(saveModel.get('model.fieldConfig.scanFieldConfig.documentType'))) {
      this.makeProspectsCall(saveModel);
    }
  },

  makeProspectsCall(saveModel) {
    let endAction = 'ACCOUNT_UPGRADE_END';
    let fileIdArray = saveModel.fileIds.getEach('refNo');
    saveModel.get('model.section.fields').forEach(data => {
      if (
        data.get('isVisible') &&
        data.get('required') &&
        data.get('fieldConfig.scanFieldConfig.documentType') &&
        isEmpty(data.get('value'))
      ) {
        endAction = null;
      }
    });

    let prospectId = this.get('store').peekRecord('field', 'prospectId'),
      prospectData,
      fieldVal =
        'fields=name,first-name,last-name,middle-name,country,dob,gender,national-id,national-doe,is-id-exist,is-key-fields-match,is-face-match,id-number,id-expiry-date,surname,id-type,residential-address-line1,residential-address-line2,residential-address-line3,place-of-birth';
    if (!prospectId || !prospectId.get('value')) {
      prospectData = this.get('store').createRecord('prospect', {
        documentIds: fileIdArray,
        country: this.get('axwayConfig.country'),
        action: endAction,
        fields: endAction ? fieldVal : null
      });
    } else {
      prospectData = this.get('store').peekRecord('prospect', prospectId.get('value'));
      prospectData.set('documentIds', fileIdArray);
      prospectData.set('country', this.get('axwayConfig.country'));
      prospectData.set('action', endAction);
      if (endAction) {
        prospectData.set('fields', fieldVal);
      } else {
        prospectData.set('fields', null);
      }
    }

    return this.get('rdcLoadingIndicator')
      .showLoadingIndicatorForPromise(prospectData.save())
      .then(prospectDatum => {
        prospectId.set('value', prospectDatum.id);
        if (endAction) {
          this.setScanData(prospectDatum);
        }
        return;
      });
  },

  setScanData(prospectData) {
    let fieldMapping;
    let ocrEditedFlagVal = this.get('store').peekRecord('field', 'OCReditedFlag');
    if (ocrEditedFlagVal) {
      ocrEditedFlagVal.set('value', false);
    }
    let idnumberMap = {
      PASSPORTID: 'DocumentNo1',
      NATIONALID: 'DocumentNo2',
      VOTERID: 'DocumentNo3',
      DRIVINGLICENSE: 'DocumentNo4'
    };
    let expirydateMap = {
      PASSPORTID: 'DocumentExpiryDt1',
      NATIONALID: 'DocumentExpiryDt2',
      VOTERID: 'DocumentExpiryDt3',
      DRIVINGLICENSE: 'DocumentExpiryDt4'
    };
    fieldMapping = {
      idNumber: idnumberMap[prospectData.idType],
      idExpiryDate: expirydateMap[prospectData.idType]
    };
    for (let field in fieldMapping) {
      //if (fieldMapping.hasOwnProperty(field)) {
      if (Object.prototype.hasOwnProperty.call(fieldMapping, field)) {
        if (prospectData[field] != null) {
          let formField = this.get('store').peekRecord('field', fieldMapping[field]);
          if (formField) {
            if (formField.fieldType === 'rdc-form-select') {
              let fieldOption = formField.get('fieldConfig.fieldOptions').findBy('value', prospectData[field]);
              formField.set('value', fieldOption);
            } else {
              formField.set('value', prospectData[field]);
            }
          }
        }
      }
    }
  },

  afterSubmit(formDatum, isFileDelete) {
    const promise = new EmberPromise(resolve => {
      let isPurposeOfAccBusiness =
          formDatum.get('additionalInfo') && formDatum.get('additionalInfo').isPurposeOfAccBusiness,
        isCRSETB = formDatum.get('additionalInfo') && formDatum.get('additionalInfo').CRSETB;
      if (!isEmpty(isPurposeOfAccBusiness) && isPurposeOfAccBusiness) {
        resolve('isPurposeOfAccBusiness');
      } else if (!isEmpty(isCRSETB) && isCRSETB) {
        resolve('CRSETB');
      } else {
        resolve();
      }
    });
    promise.then(result => {
      if (result && result.length > 0) {
        if (result === 'isPurposeOfAccBusiness') {
          this.controller.set('showActionSheet', true);
          this.controller.set('fallbackType', 'isPurposeOfAccBusiness');
          this.controller.set('staticPopup', 'dedupe-failure');
        } else if (result === 'CRSETB') {
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'error',
              title: this.get('i18n').t('ServiceRequest.COMMON.crsMessage.title'),
              message: this.get('i18n').t('ServiceRequest.COMMON.crsMessage.CRSETB'),
              rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok')
            })
            .then(() => {
              this.transitionTo('serviceRequest.new-request');
            })
            .catch(() => {});
        }
      } else {
        if (!isFileDelete) this.goToReceiptPage();
      }
    });
  },

  closeThisForm() {
    let title = this.get('i18n').t('FERE.action.modal.quitApp.title');
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'error',
        title,
        message: this.currentModel.receiptId
          ? this.get('i18n').t('FERE.action.modal.quitApp.messageEmailSms')
          : this.get('i18n').t('FERE.action.modal.quitApp.messageProgressLost'),
        acceptButtonLabel: this.get('i18n').t('FERE.action.button.YES'),
        rejectButtonLabel: this.get('i18n').t('FERE.action.button.NO')
      })
      .then(() => {
        if (window.cordova) {
          // Sending refresh token and access token while exit from fere to legecy screen.
          if (this.accessToken && this.refreshToken) {
            window.location.href =
              window.location.protocol +
              '//' +
              window.location.host +
              '/exit?RDC-ACCESS-TOKEN=' +
              this.accessToken +
              '&RDC-REFRESH-TOKEN=' +
              this.refreshToken;
          } else {
            window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
          }
        } else {
          document.location.href = config.backToiBankURL;
        }
      });
  },

  actions: {
    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        this.closeThisForm();
      }
    },
    closeForm() {
      this.closeThisForm();
    },
    goToHome() {
      if (window.cordova) {
        // Sending refresh token and access token while exit from fere to legecy screen.
        if (this.accessToken && this.refreshToken) {
          window.location.href =
            window.location.protocol +
            '//' +
            window.location.host +
            '/exit?RDC-ACCESS-TOKEN=' +
            this.accessToken +
            '&RDC-REFRESH-TOKEN=' +
            this.refreshToken;
        } else {
          window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
        }
      } else {
        document.location.href = config.backToiBankURL;
      }
    }
  }
});
