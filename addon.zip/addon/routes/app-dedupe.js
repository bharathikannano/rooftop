import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../config/environment';
import { computed } from '@ember/object';
export default Route.extend({
  customerInfo: service(),
  axwayConfig: service(),
  i18n: service(),
  queryParams: {
    dedupeType: {
      refreshModel: true
    }
  },
  session: service(),
  accessToken: computed('session', {
    get() {
      const accessToken = this.get('session.data.authenticated.access_token');
      return accessToken;
    }
  }),
  refreshToken: computed('session', {
    get() {
      const refreshToken = this.get('session.data.authenticated.refresh_token');
      return refreshToken;
    }
  }),
  model(params) {
    if (params.dedupeType) {
      let fallbackMessage;
      if (params.dedupeType === 'etbResume') {
        fallbackMessage = this.get('i18n').t('productSummary.etbResumeDedupeMessage');
      } else if (params.dedupeType === 'resumeViaMbnk') {
        fallbackMessage = this.get('i18n').t('productSummary.mbnkResumeDedupeMessage');
      } else if (params.dedupeType === 'resumeViaIbnk') {
        fallbackMessage = this.get('i18n').t('productSummary.ibnkResumeDedupeMessage');
      } else if (params.dedupeType === 'resumeViaMbkStf') {
        fallbackMessage = this.get('i18n').t('productSummary.staffMbnkResumeDedupeMessage');
      } else if (params.dedupeType === 'resumeViaIbkStf') {
        fallbackMessage = this.get('i18n').t('productSummary.staffIbnkResumeDedupeMessage');
      } else if (params.dedupeType === 'abortStaffResume') {
        fallbackMessage = this.get('i18n').t('productSummary.staffAbortResumeDedupeMessage');
      }
      this.controllerFor('app-dedupe').set('fallbackMessage', fallbackMessage);
    }
  },
  actions: {
    goBack() {
      this.set('customerInfo.applyProductDedupeType', null);
      this.transitionTo('product-list.list');
    },
    goToResume() {
      let mobileNo = this.get('customerInfo.resumeApplicationMobNo');
      this.set('customerInfo.applyProductDedupeType', null);
      let filterParams = JSON.stringify({
        stepName: 'MK_F1',
        countryCode: this.get('axwayConfig.country'),
        id: 'W400',
        eventType: 'RESUME',
        mobileNo: mobileNo,
        resume: true
      });
      this.transitionTo('apply-products', {
        queryParams: {
          filter: filterParams
        }
      });
    },
    goToHome() {
      if (window.cordova) {
        // Sending refresh token and access token while exit from fere to legecy screen.
        if (this.accessToken && this.refreshToken) {
          window.location.href =
            window.location.protocol +
            '//' +
            window.location.host +
            '/exit?RDC-ACCESS-TOKEN=' +
            this.accessToken +
            '&RDC-REFRESH-TOKEN=' +
            this.refreshToken;
        } else {
          window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
        }
      } else {
        if (this.get('axwayConfig.country') === 'AE') {
          window.location.href = config.backToiBankNTBURL['AE'];
        } else {
          document.location.href = config.backToiBankURL;
        }
      }
    }
  }
});
