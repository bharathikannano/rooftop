import { inject as service } from '@ember/service';
import { Promise as EmberPromise } from 'rsvp';
import { isEmpty } from '@ember/utils';
import { isNone } from '@ember/utils';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import idleSession from 'rdc-ui-eng-service-requests/mixins/idle-session';
import { computed, get } from '@ember/object';
import setDeviceData from 'rdc-ui-eng-service-requests/mixins/set-device-data';
import config from '../config/environment';
import CordovaPluginWrapper from 'rdc-ui-eng-service-requests/mixins/cordova-plugin-wrapper';
import CryptoJS from 'cryptojs';
import customLoader from 'rdc-ui-eng-service-requests/mixins/custom-loader';

export default FereFormRoute.extend(CordovaPluginWrapper, idleSession, setDeviceData, customLoader, {
  pluginName: 'Onboarding',
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),
  sessionManager: service(),
  rdcModalManager: service(),
  store: service(),
  rdcLoadingIndicator: service(),
  adobeDataService: service(),
  queries: service('customer-info'),
  i18n: service(),
  firebaseAnalytics: service(),
  session: service(),
  accessToken: computed('session', {
    get() {
      const accessToken = this.get('session.data.authenticated.access_token');
      return accessToken;
    }
  }),
  refreshToken: computed('session', {
    get() {
      const refreshToken = this.get('session.data.authenticated.refresh_token');
      return refreshToken;
    }
  }),
  queryParams: computed('axwayConfig', {
    get() {
      /* For New ETB account opening, the step Name should be MK_F5.
       * For KE NTB asset Onboarding, the step Name should be MK_F6.
       * for eKYC, the stepName should be MK_F3.
       * the default should be MK_F1.
       */
      let stepName = 'MK_F1';
      let processId = 'W400';
      if (!isEmpty(this.get('axwayConfig.assetOnboarding')) && isEmpty(this.get('axwayConfig.ETBAccountOpening'))) {
        stepName = 'MK_F6';
      } else if (this.get('axwayConfig.ETBAccountOpening')) {
        stepName = 'MK_F5';
      } else if (this.get('axwayConfig.eKYC')) {
        stepName = 'MK_F3';
      } else if (this.get('axwayConfig.zibukaWebFlow')) {
        stepName = 'CK_ScanCkr';
        processId = 'C150';
      } else if (this.get('axwayConfig.nGenFlow')) {
        stepName = 'MK_NGEN';
      }
      let channel = this.get('queries.channelId');
      let filterParams = {
        filter: {
          stepName: stepName,
          countryCode: this.get('axwayConfig.country'),
          id: processId,
          staffId: this.get('axwayConfig.staffId'),
          channelId: channel
        }
      };
      Object.keys(filterParams.filter).forEach(key => !filterParams.filter[key] && delete filterParams.filter[key]);
      return filterParams;
    }
  }),
  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
    let headerTitle = this.get('i18n').t(
      'ServiceRequest.COMMON.pageTitles.applyProduct.' + this.get('axwayConfig.country')
    ).string
      ? this.get('i18n').t('ServiceRequest.COMMON.pageTitles.applyProduct.' + this.get('axwayConfig.country'))
      : this.get('i18n').t('ServiceRequest.COMMON.pageTitles.applyProduct.default');
    controller.set('title', headerTitle);
    controller.set('hasCloseBtn', false);
    if (this.media.isDesktop) {
      this.controller.set('bpClass', 'is-desktop');
    }
    //FetchDeviceToken From Plugin nad set locally
    this.setDeviceToken();

    //To remove the cart buttons in all the pages if the ZIBUKA flow for african countries alone.
    if (config.isAfricanCtry.includes(this.get('axwayConfig.country'))) {
      this.removeZibukaCartAndBackButton('onLoad');
    }

    // All Countries - Referral/Promo Code SCMobile changes
    let ReferralCode = this.get('store').peekRecord('field', 'ReferralCode');
    if (!isEmpty(ReferralCode)) {
      ReferralCode.set('value', ReferralCode.value ? ReferralCode.value : this.get('axwayConfig.referralCode'));
    }
  },
  beforeModel(params) {
    this._super(...arguments);
    // Sending only the required params as sending other params will throw Mapping error in CSL side.
    if (
      params &&
      params.queryParams &&
      ((params.queryParams.code && params.queryParams.state) || (params.queryParams.error && params.queryParams.state))
    ) {
      this.set('uaePassRedirectFlow', true);
      let decodeMobileNo = decodeURIComponent(params.queryParams.state);
      let mobileNoBytes = CryptoJS.AES.decrypt(decodeMobileNo.toString(), config.uaePass.cryptoKey);
      let mobileNo = mobileNoBytes.toString(CryptoJS.enc.Utf8);

      let redirectUrl;
      if (window.cordova) {
        redirectUrl = config.uaePass.redirectUrlMobile;
      } else {
        redirectUrl = window.location.protocol + '//' + window.location.host + config.uaePass.redirectUrlWeb;
      }
      redirectUrl = encodeURIComponent(redirectUrl);
      let filterParams = {
        code: params.queryParams.code,
        status: params.queryParams.error,
        redirectUrl: redirectUrl,
        mobileNo: mobileNo,
        eventType: 'RESUME',
        resume: true
      };
      Object.keys(filterParams).forEach(element => {
        this.queryParams.filter[element] = filterParams[element];
      });
    }
  },
  afterModel(model) {
    if (
      arguments[0].additionalInfo.etbResume ||
      arguments[0].additionalInfo.resumeViaMbnk ||
      arguments[0].additionalInfo.resumeViaIbnk ||
      arguments[0].additionalInfo.resumeViaMbkStf ||
      arguments[0].additionalInfo.resumeViaIbkStf ||
      arguments[0].additionalInfo.abortStaffResume
    ) {
      let dedupeType = arguments[0].additionalInfo.etbResume
        ? 'etbResume'
        : arguments[0].additionalInfo.resumeViaMbnk
        ? 'resumeViaMbnk'
        : arguments[0].additionalInfo.resumeViaIbnk
        ? 'resumeViaIbnk'
        : arguments[0].additionalInfo.resumeViaMbkStf
        ? 'resumeViaMbkStf'
        : arguments[0].additionalInfo.resumeViaIbkStf
        ? 'resumeViaIbkStf'
        : 'abortStaffResume';
      this.transitionTo('appDedupe', {
        queryParams: {
          dedupeType: dedupeType
        }
      });
    } else if (this.get('uaePassRedirectFlow')) {
      let receiptId = model.get('additionalInfo') && model.get('additionalInfo').sourceRefNo;
      if (receiptId) {
        this.get('rdcLoadingIndicator')
          .showLoadingIndicatorForPromise(this.get('store').findRecord('formDatum', receiptId))
          .then(formData => {
            this.set('formData', formData);
            this.set('currentDisplayPage', model.get('pages').objectAt(model.get('pages').length - 2));
            this.submitForm();
          })
          .catch(() => {
            this.set('formData', null);
          });
      }
    } else {
      this._super(...arguments);
    }
  },
  // Method for setting the BVN data to form data.
  setBvnDataToFormData(bvnData) {
    let fieldMapping = {
        firstName: 'FirstName',
        middleName: 'MiddleName',
        lastName: 'LastName',
        gender: 'Gender',
        nationality: 'Nationality',
        dob: 'DateofBirth',
        email: 'ContactValue3,NonEditContactValue3',
        residentialAddress: 'ResidentialAddress1,NonEditResidentialAddress1',
        residentialAddressLine2: 'ResidentialAddress2,NonEditResidentialAddress2',
        residentialAddressLine3: 'ResidentialAddress3,NonEditResidentialAddress3',
        residentialAddressLine4: 'ResidentialAddress4,NonEditResidentialAddress4',
        title: 'Title,NonEditTitle',
        watchListed: 'WatchListed',
        category: 'WatchListedCategory',
        maritalStatus: 'MaritalStatus',
        bvnDocId: 'BvnDocId',
        lgaOfResidence: 'RCity,NonEditRCity,MCity',
        lgaOfOrgin: 'LgaOfOrigin',
        stateOfOrigin: 'StateOfOrigin',
        stateOfResidence: 'RState,NonEditRState,MState',
        mailingAddress: 'MailingAddress1',
        mailingAddressLine2: 'MailingAddress2',
        mailingAddressLine3: 'MailingAddress3',
        mailingAddressLine4: 'MailingAddress4',
        verifiedTime: 'VerifiedDateTime'
      },
      primaryMobNo = this.get('store').peekRecord('field', 'ContactValue1');

    for (let field in fieldMapping) {
      //if (fieldMapping.hasOwnProperty(field)) {
      if (Object.prototype.hasOwnProperty.call(fieldMapping, field)) {
        if (bvnData[field] != null) {
          // Added functionality to map the same BVN data to more than one fere field.
          let fereFieldArray = fieldMapping[field].split(',');
          fereFieldArray.forEach(fieldkey => {
            let formField = this.get('store').peekRecord('field', fieldkey);
            if (formField) {
              if (formField.fieldType === 'rdc-form-select') {
                let fieldOption = formField.get('fieldConfig.fieldOptions').findBy('value', bvnData[field]);
                formField.set('value', fieldOption);
              } else {
                formField.set('value', bvnData[field]);
              }
            }
          });
        }
      }
    }
    // Checking if there are two phone numbers associated with BVN.
    if (!isEmpty(bvnData.get('phoneNumber')) && !isEmpty(bvnData.get('phoneNumber2'))) {
      let merchantMobileNos = `${bvnData.get('phoneNumber')},${bvnData.get('phoneNumber2')}`;
      this.controller.setProperties({
        showActionSheet: true,
        actionSheetAutoHeight: true,
        merchantValidationType: 'radio',
        merchantMobileNos: merchantMobileNos,
        staticPopup: 'merchant-validation',
        hasCloseBtn: true
      });
      // Form submit will be done in Merchant-validation component.
      return;
      // If one phonenumber is present, set that and proceed to OTP page.
    } else if (!isEmpty(bvnData.get('phoneNumber'))) {
      primaryMobNo.set('value', bvnData.get('phoneNumber'));
    } else if (!isEmpty(bvnData.get('phoneNumber2'))) {
      primaryMobNo.set('value', bvnData.get('phoneNumber2'));
    }
    this.goToNextPage();
  },
  // Checking if user wishes to upgrade to tier 2 account directly in NTB flow for NG.
  checkAccountUpgrade() {
    this.controller.setProperties({
      showActionSheet: true,
      actionSheetAutoHeight: true,
      staticPopup: 'account-upgrade-confirmation',
      hasCloseBtn: true
    });
  },
  // Method for creating a BVN record and getting data for pre-populating BVN data.
  getBvnRequestData() {
    let bvnNumber = this.get('store').peekRecord('field', 'BVNNumber'),
      bvnData;
    if (bvnNumber || bvnNumber.get('value')) {
      bvnData = this.get('store').createRecord('ng-bvn', {
        bvnNo: bvnNumber.get('value'),
        country: this.get('axwayConfig.country')
      });
      return this.get('rdcLoadingIndicator')
        .showLoadingIndicatorForPromise(bvnData.save())
        .then(finalBvnData => {
          this.setBvnDataToFormData(finalBvnData);
        })
        .catch(err => {
          this.send('error', err);
        });
    }
  },
  async invokeDaonScan(scanComponent) {
    let scanCompField = scanComponent.shift();
    let daonScanField = this.get('store').peekRecord('field', scanCompField);
    let daonScanFieldConfig = daonScanField.get('fieldConfig.scanFieldConfig');
    if (isEmpty(daonScanField.get('value'))) {
      try {
        let scanResult = await this._exec('startScan', [
          {
            documentId: daonScanFieldConfig.get('documentType'),
            hasBackSide: daonScanFieldConfig.get('backScan'),
            countryCode: get(this, 'axwayConfig.country'),
            language: get(this, 'axwayConfig.language'),
            returnFileNetID: true
          }
        ]);

        if (typeof scanResult === 'string') {
          scanResult = JSON.parse(scanResult);
        }
        await this._exec('stopScan', []);
        if (scanResult.status === 'success') {
          let scannedFiles = [],
            formDataVal = [];
          scanResult.files.forEach(fileInfo => {
            scannedFiles.push(fileInfo.fileNetId);
            formDataVal.push({
              type: daonScanFieldConfig.get('documentType'),
              refNo: fileInfo.fileNetId
            });
          });
          daonScanField.set('value', formDataVal);
          this.makeProspectsCall(null, scannedFiles, scanComponent);
        }
      } catch (scanError) {
        scanStatus = JSON.parse(scanError);
        if (scanStatus.status === 'cancel') {
          set(this, 'showActionSheet', false);
        }
      }
    }
  },
  // Using async here to wait for prospects data during ZIBUKA resume journey.
  async makeProspectsCall(saveModel, fileIdArray, scanComponent) {
    let endAction = 'END',
      fieldVal = null;
    if (scanComponent && scanComponent.length) {
      endAction = null;
    }
    if (saveModel) {
      fileIdArray = saveModel.fileIds.getEach('refNo');
      /* Getting the end action based on the fields available in same section.
       * If another upload field is available in the section then endAction is null.
       * If no more fields are available then endAction is "END".
       */
      saveModel.get('model.section.fields').forEach(data => {
        if (
          data.get('isVisible') &&
          data.get('required') &&
          data.get('fieldConfig.scanFieldConfig.documentType') &&
          isEmpty(data.get('value'))
        ) {
          endAction = null;
        }
      });
    }
    // For sending the required fields to CSL for getting data from DAON for pre-population.
    if (endAction === 'END') {
      if (this.get('axwayConfig.country') == 'AE') {
        fieldVal =
          'fields=first-name,surname,middle-name,country,dob,gender,national-id,passport-id,passport-doe,visa-id,visa-doe,national-doe,is-face-match,nationality,full-name,passport-gender,passport-name,passport-nationality,passport-dob,id-full-name,passport-first-name,passport-last-name,passport-middle-name';
      } else {
        fieldVal =
          'fields=name,first-name,last-name,middle-name,country,dob,gender,national-id,national-doe,is-id-exist,is-key-fields-match,is-face-match,id-number,id-expiry-date,surname,id-type,residential-address-line1,residential-address-line2,residential-address-line3,place-of-birth,id-check-status,key-fields-match-status,facial-match-status';
      }
    }
    // Getting the prospectsId.
    let prospectId = this.get('store').peekRecord('field', 'prospectId'),
      prospectData,
      mobileNo = this.get('store').peekRecord('field', 'ContactValue1');

    // if prospectsId available, peeking the prospects record or creating new one.
    if (isEmpty(prospectId) || isEmpty(prospectId.get('value'))) {
      prospectData = this.get('store').createRecord('prospect', {});
    } else {
      prospectData = this.get('store').peekRecord('prospect', prospectId.get('value'));
      if (isEmpty(prospectData)) {
        // During Zibuka resume, the prospects local data is null.
        prospectData = await this.get('store').findRecord('prospect', prospectId.get('value'));
      }
    }
    // Setting the params to prospect record..
    prospectData.setProperties({
      documentIds: fileIdArray,
      country: this.get('axwayConfig.country'),
      staffId: this.get('axwayConfig.staffId'),
      action: endAction,
      fields: fieldVal,
      stepName: this.get('filter.stepName') ? this.get('filter.stepName') : 'MK_F3',
      processId: this.get('formId') ? this.get('formId') : 'W400',
      mobileNumber: mobileNo && mobileNo.value ? mobileNo.value : null
    });
    // saving the prospects record.
    return this.get('rdcLoadingIndicator')
      .showLoadingIndicatorForPromise(prospectData.save())
      .then(prospectDatum => {
        prospectId.set('value', prospectDatum.id);
        if (endAction) {
          this.setScanData(prospectDatum, saveModel);
        } else if (scanComponent && scanComponent.length) {
          this.invokeDaonScan(scanComponent);
        }
        return;
      });
  },
  setScanData(prospectData, saveModel) {
    let fieldMapping, criticalFieldMapping;
    let prospectRecord = this.get('store').peekRecord('prospect', prospectData.get('id'));

    if (this.get('axwayConfig.country') == 'AE') {
      fieldMapping = {
        passportFirstName: 'FirstName',
        fullName: 'EIDFullName',
        passportName: 'MRZPassportIDName',
        passportLastName: 'LastName',
        passportMiddleName: 'MiddleName',
        passportGender: 'Gender',
        gender: 'EIDGender',
        dob: 'DateofBirth',
        passportDob: 'PassportDOB',
        passportNationality: 'MRZPassportIDNat',
        nationality: 'Nationality',
        nationalId: 'EmiratesID',
        nationalDoe: 'EIDExpiryDate',
        passportId: 'PassportNumber',
        passportDoe: 'PassportExpiryDate',
        visaId: 'VisaNumber',
        visaDoe: 'VisaExpiryDate',
        isFaceMatch: 'SelfieValidation',
        firstName: 'EIDFirstName',
        surname: 'EIDLastName'
      };
      criticalFieldMapping = {
        fullName: 'MRZEIDFullName',
        nationality: 'MRZEIDNationality',
        gender: 'MRZEmiratesIDGender',
        dob: 'EmiratesIDDOB',
        nationalDoe: 'MRZEIDExpiryDate',
        nationalId: 'MRZEmiratesID',
        passportDoe: 'MRZPassportExpDate',
        passportId: 'MRZPassportNumber',
        visaId: 'MRZVisaNumber',
        visaDoe: 'MRZVisaExpiryDate',
        passportGender: 'MRZPassportIDGender',
        firstName: 'MRZEIDFirstName',
        surname: 'MRZEIDLastName'
      };
    } else if (this.get('axwayConfig.country') == 'NG') {
      let ocrEditedFlagVal = this.get('store').peekRecord('field', 'OCReditedFlag');
      if (ocrEditedFlagVal) {
        ocrEditedFlagVal.set('value', false);
      }
      let idnumberMap = {
        PASSPORTID: 'DocumentNo1',
        NATIONALID: 'DocumentNo2',
        VOTERID: 'DocumentNo3',
        DRIVINGLICENSE: 'DocumentNo4'
      };
      let expirydateMap = {
        PASSPORTID: 'DocumentExpiryDt1',
        NATIONALID: 'DocumentExpiryDt2',
        VOTERID: 'DocumentExpiryDt3',
        DRIVINGLICENSE: 'DocumentExpiryDt4'
      };
      fieldMapping = {
        idNumber: idnumberMap[prospectData.idType],
        idExpiryDate: expirydateMap[prospectData.idType]
      };
    } else {
      let ocrEditedFlagVal = this.get('store').peekRecord('field', 'OCReditedFlag');
      if (ocrEditedFlagVal) {
        ocrEditedFlagVal.set('value', false);
      }
      let idnumberMap = {
        PASSPORTID: 'DocumentNo1',
        NATIONALID: 'DocumentNo2',
        VOTERID: 'DocumentNo3',
        DRIVINGLICENSE: 'DocumentNo4',
        ALIENID: 'DocumentNo6',
        SOCIALSECURITY: 'DocumentNo7'
      };
      let expirydateMap = {
        PASSPORTID: 'DocumentExpiryDt1',
        NATIONALID: 'DocumentExpiryDt2',
        VOTERID: 'DocumentExpiryDt3',
        DRIVINGLICENSE: 'DocumentExpiryDt4',
        ALIENID: 'DocumentExpiryDt6',
        SOCIALSECURITY: 'DocumentExpiryDt7'
      };
      fieldMapping = {
        firstName: 'FirstName',
        surname: 'LastName',
        middleName: 'MiddleName',
        gender: 'Gender',
        title: 'Title',
        dob: 'DateofBirth',
        idNumber: idnumberMap[prospectData.idType],
        isKeyFieldsMatch: 'IsKeyFieldsMatch',
        isFaceMatch: 'isFaceMatch',
        idExpiryDate: expirydateMap[prospectData.idType],
        isIdExist: 'IsIDExist',
        placeOfBirth: 'PlaceofBirth',
        residentialAddressLine1: 'ResidentialAddress1',
        residentialAddressLine2: 'ResidentialAddress2',
        residentialAddressLine3: 'ResidentialAddress3',
        idCheckStatus: 'idCheckStatus',
        keyFieldsMatchStatus: 'KeyfieldsMatchstatus',
        facialMatchStatus: 'FacialMatchStatus'
      };
    }
    for (let field in fieldMapping) {
      if (Object.prototype.hasOwnProperty.call(fieldMapping, field)) {
        if (prospectData[field] != null) {
          let formField = this.get('store').peekRecord('field', fieldMapping[field]);
          if (formField) {
            if (formField.fieldType === 'rdc-form-select') {
              let fieldOption = formField.get('fieldConfig.fieldOptions').findBy('value', prospectData[field]);
              formField.set('value', fieldOption);
            } else {
              if (this.get('axwayConfig.country') === 'AE' && fieldMapping[field] === 'SelfieValidation') {
                formField.set('value', prospectData[field] ? 'Y' : 'N');
              } else if(this.get('axwayConfig.country') === 'AE' && fieldMapping[field] === 'EIDFirstName'){
                let firstNameSplit = prospectData[field].split(' ');
                let fName = firstNameSplit.shift();
                let mName = firstNameSplit.join(" ");
                formField.set('value',fName);
                if(mName){
                  let mNameField = this.get('store').peekRecord('field', 'EIDMiddleName');
                  if(mNameField){
                    mNameField.set('value',mName);
                  }
                }
              }else {
                formField.set('value', prospectData[field]);
              }
            }
          }
          // To reset the prospectss data once the value is set to the fields.
          if (!isEmpty(prospectRecord)) {
            prospectRecord.set(field, null);
          }
        }
      }
    }
    if (criticalFieldMapping) {
      for (let criticalField in criticalFieldMapping) {
        // if (criticalFieldMapping.hasOwnProperty(criticalField)) {
        if (Object.prototype.hasOwnProperty.call(criticalFieldMapping, criticalField)) {
          let criticalFormField = this.get('store').peekRecord('field', criticalFieldMapping[criticalField]);
          if (criticalFormField && prospectData[criticalField]) {
            criticalFormField.set('value', prospectData[criticalField]);
          }
        }
      }
    }
    if (!saveModel) {
      this.send('moveToNextPage', false);
    }
  },
  afterFileUpload(saveModel) {
    if (window.cordova && saveModel && !isEmpty(saveModel.get('model.fieldConfig.scanFieldConfig.documentType'))) {
      this.makeProspectsCall(saveModel);
    }
  },
  beforeSubmit(formDatum) {
    let uaePassFlag = this.get('store').peekRecord('field', 'UAEPFlag');
    let reviewPageObj = formDatum.get('pages').objectAt(formDatum.get('pages').length - 2);
    if (this.currentDisplayPage.id === reviewPageObj.id) {
      if (uaePassFlag && uaePassFlag.get('value')) {
        formDatum
          .get('pages')
          .objectAt(formDatum.get('pages').length - 2)
          .set('partialSaving', true);
      } else if (uaePassFlag) {
        formDatum
          .get('pages')
          .objectAt(formDatum.get('pages').length - 2)
          .set('partialSaving', false);
      }
    }
  },
  /* Checking if the page validations are valid.
   * Duplicating this function from fere-route.js.
   * The variables isValid and isTruelyValid from fere are inconsistentant across env which breaks NG NTB first page.
   * Since there are only two fields, it is not costly.
   */
  checkIfPageValid() {
    let isValid = true;
    this.get('currentDisplayPage')
      .get('sectionGroups')
      .forEach(sectionGroup => {
        sectionGroup.get('sections').forEach(section => {
          section.get('fields').forEach(field => {
            if (field.get('visible') && field.get('editable')) {
              isValid =
                isValid &&
                get(field, 'isValid') &&
                (get(field, 'validations.isValid') || isEmpty(get(field, 'validations.errors')));
            }
          });
        });
      });
    return isValid;
  },
  afterSubmit(formDatum, isFileDelete) {
    const promise = new EmberPromise(resolve => {
      let customMessage = formDatum.get('message');
      let actionMessage = '';
      let scanComponent = null;
      // resetting the autoheight and closebtn value which was set for NG mobile number selection and upgrade check.
      this.controller.setProperties({
        hasCloseBtn: false,
        actionSheetAutoHeight: false
      });
      if (this.get('axwayConfig.country') != 'AE') {
        actionMessage =
          '<div class=' +
          'action-message' +
          '>Your account will be activated after the verification by our Card Delivery Agent.</div>';
      }
      if (formDatum.get('additionalInfo').entityDetail) {
        formDatum.get('additionalInfo').entityDetail.forEach(entity => {
          if (entity.entityType) {
            customMessage = customMessage + '<div class=' + 'account-number' + '>' + entity.entityType + '</div>';
          }
        });
        formDatum.set('message', customMessage + actionMessage);
      }
      this._exec('getOnboardingStatus').then(onboardingStatus => {
        if (onboardingStatus != 20 || onboardingStatus != 30) {
          if (this.currentModel.receiptId) {
            // Setting the onboarding status to 11 if receiptId is generated and onboarding status is not already 11.
            if (onboardingStatus != 11) {
              this.firebaseAnalytics.logEvent('ntb_application_started');
              //setOnboardingStatus for application in progress
              this._exec('setOnboardingStatus', [11]);
            }
            // For NTB and ETB (including resume) the messageId will be 'INITCASA'.
            // So anything other than 'INITCASA', we are setting the status to completed.
            if (
              formDatum.get('message') ||
              (!isEmpty(formDatum.get('messageId')) && formDatum.get('messageId') !== 'INITCASA')
            ) {
              this.firebaseAnalytics.logEvent('ntb_submit_success');
              //setOnboardingStatus for application completed
              this._exec('setOnboardingStatus', [15]);
            }
          }
          if (formDatum.get('additionalInfo').isETBCSLDedupeMatch || formDatum.get('additionalInfo').isETB) {
            this.firebaseAnalytics.logEvent('ntb_is_etb');
            //setOnboardingStatus for application dedupe For ETB
            this._exec('setOnboardingStatus', [10]);
          }
        }
      });
      //Store NTB registration ID in local storage
      this.storeNtbRegistrationId(formDatum.get('additionalInfo').NtbRegistrationId);
      let store = this.get('store');
      if (formDatum.get('additionalInfo').fieldOptions) {
        Object.keys(formDatum.get('additionalInfo').fieldOptions).forEach(key => {
          let optionReplace = store.peekRecord('field', key);
          if (optionReplace) {
            let arrayVal = formDatum.get('additionalInfo').fieldOptions[key];
            optionReplace.set('fieldConfig.listOptions', arrayVal);
          }
        });
      }
      let additionalFields = formDatum.get('additionalInfo') && formDatum.get('additionalInfo').fields;
      let isMerchantNoAvailable = this.get('store').peekRecord('field', 'IsMerchantNoAvailable');
      let zibukaFlag = this.get('store').peekRecord('field', 'ZibukaFlag');

      if (isMerchantNoAvailable) {
        isMerchantNoAvailable.set('value', 'N');
      }

      if (!isEmpty(additionalFields)) {
        this.set('additionalFields', additionalFields);
        this.send('setAdditionalFields', additionalFields);
      }

      if (formDatum.get('additionalInfo').otpFieldName) {
        let otpMobileNumberRecord = store.peekRecord('field', formDatum.get('additionalInfo').otpFieldName);
        let otpMobileNumber = otpMobileNumberRecord.get('value');
        this.set('otpMobileNumber', otpMobileNumber);
      }

      // To hide the page in reviewMode based on the flag and page id received.
      if (
        !isEmpty(formDatum.get('additionalInfo').hideOnReviewPage) &&
        typeof formDatum.get('additionalInfo').hideOnReviewPage === 'string'
      ) {
        let tabArry = formDatum.get('additionalInfo').hideOnReviewPage.split(',');
        tabArry.forEach(tabId => {
          // getting the tab based on tab id.
          let toBeHiddenTab = this.store.peekRecord('page', tabId);
          // setting the hideInReviewMode flag to hide in review page.
          if (!isEmpty(toBeHiddenTab)) {
            toBeHiddenTab.set('hideInReviewMode', true);
          }
        });
      }

      if (window.cordova && formDatum.get('additionalInfo').performDaonScan) {
        scanComponent = formDatum.get('additionalInfo').performDaonScan;
        resolve('performDaonScan');
      }
      if (formDatum.get('additionalInfo').terminateApp) {
        resolve('terminateApp');
      } else if (formDatum.get('additionalInfo').redirectToUAEPass) {
        this.get('rdcLoadingIndicator').setThemeClass('ui10');
        this.get('rdcLoadingIndicator').setLoadingMessage('You are being redirected to UAE Pass');
        this.get('rdcLoadingIndicator').showLoadingIndicator('You are being redirected to UAE Pass');
        let mobileNo =
          this.get('store').peekRecord('field', 'MobileNumber') &&
          this.get('store')
            .peekRecord('field', 'MobileNumber')
            .get('value');
        let redirectUri;
        if (window.cordova) {
          redirectUri = config.uaePass.redirectUrlMobile;
        } else {
          redirectUri = window.location.protocol + '//' + window.location.host + config.uaePass.redirectUrlWeb;
        }
        redirectUri = encodeURIComponent(redirectUri);
        let encryptMobileNo = encodeURIComponent(CryptoJS.AES.encrypt(mobileNo, config.uaePass.cryptoKey));
        let redirectUrl =
          config.uaePass.passUrl + '&redirect_uri=' + redirectUri + '&state=' + encryptMobileNo + config.uaePass.params;
        window.open(redirectUrl, '_self');
        if (window.cordova) {
          window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
        }
      } else if (formDatum.get('additionalInfo').monthlyIncomeAlert) {
        let selectedProducts = this.store.peekRecord('field', 'ProductList').value;
        let componentType = 'CC';
        if (selectedProducts) {
          selectedProducts.split(',').forEach(item => {
            if (item.split('~')[0] != 'CC') {
              componentType = 'Other';
            }
          });
        }
        this.controller.set('componentType', componentType);
        if (selectedProducts.split(',').length > 1) {
          resolve('monthlyIncomeAlertMultiple');
        } else {
          resolve('monthlyIncomeAlertSingle');
        }
      } else if (formDatum.get('additionalInfo').icmDedupe) {
        resolve('icmDedupe');
      } else if (formDatum.get('additionalInfo').isETBCSLDedupeMatch) {
        resolve('isETBCSLDedupeMatch');
      } else if (formDatum.get('additionalInfo').isETB) {
        resolve('isETB');
      } else if (formDatum.get('additionalInfo').appDedupe) {
        resolve('appDedupe');
      } else if (formDatum.get('additionalInfo').sanctionCntry) {
        resolve('sanctionCntry');
      } else if (formDatum.get('additionalInfo').isPurposeOfAccBusiness) {
        resolve('isPurposeOfAccBusiness');
      } else if (formDatum.get('additionalInfo').purposeOfAccAlert) {
        resolve('purposeOfAccAlert');
      } else if (formDatum.get('additionalInfo').appSubmitDedupe) {
        resolve('appSubmitDedupe');
      } else if (formDatum.get('additionalInfo').relPartyDedupe) {
        resolve('relPartyDedupe');
      } else if (formDatum.get('additionalInfo').etcCustomer) {
        resolve('etcCustomer');
      } else if (formDatum.get('additionalInfo').etbHardHold) {
        resolve('etbHardHold');
      } else if (formDatum.get('additionalInfo').etbInactive) {
        resolve('etbInactive');
      } else if (formDatum.get('additionalInfo').ineligibleCustomer) {
        resolve('ineligibleCustomer');
      } else if (formDatum.get('additionalInfo').aipDeclined) {
        this.controller.set('message', formDatum.get('additionalInfo').declineReason);
        resolve('aipDeclined');
      } else if (formDatum.get('additionalInfo').aipDoNotAgree) {
        resolve('aipDoNotAgree');
      } else if (formDatum.get('additionalInfo').isDocExpired) {
        resolve('isDocExpired');
      } else if (formDatum.get('additionalInfo').crossBorderAlert) {
        resolve('crossBorderAlert');
      } else if (formDatum.get('additionalInfo').isCDDRiskAvailable) {
        resolve('isCDDRiskAvailable');
      } else if (formDatum.get('additionalInfo').sessionTimeOut) {
        resolve('sessionTimeOut');
      } else if (formDatum.get('additionalInfo').bureauNoMatch) {
        resolve('bureauNoMatch');
      } else if (formDatum.get('additionalInfo').appNTBApproved) {
        resolve('appNTBApproved');
      } else if (formDatum.get('additionalInfo').icmMobMismatch) {
        resolve('icmMobMismatch');
      } else if (formDatum.get('additionalInfo').onBoardingRisk) {
        resolve('onBoardingRisk');
      } else if (formDatum.get('additionalInfo').insufficientFund) {
        resolve('insufficientFund');
      } else if (
        formDatum.get('additionalInfo').authVerifyFlag ||
        (formDatum.get('additionalInfo').authVerifyAsset && zibukaFlag.value === 'Y')
      ) {
        if (formDatum.get('additionalInfo').authVerifyAsset) {
          this.controller.set('hasCloseBtn', true);
          this.controller.set('fallbackType', 'authVerifyAsset');
        }
        resolve('authVerifyFlag');
      } else if (formDatum.get('additionalInfo').isNonResident) {
        resolve('isNonResident');
      } else if (formDatum.get('additionalInfo').invalidPromoCode) {
        resolve('invalidPromoCode');
      } else if (
        formDatum.get('additionalInfo').merchantMobileNos &&
        this.get('store').peekRecord('field', 'MerchantOTPValidFlag') &&
        this.get('store').peekRecord('field', 'MerchantOTPValidFlag').value == 'N'
      ) {
        this.controller.set('merchantMobileNos', formDatum.get('additionalInfo').merchantMobileNos);
        resolve('merchantValid');
      } else if (formDatum.get('additionalInfo').privateBankingFlag) {
        resolve('privateBankingFlag');
      } else if (formDatum.get('additionalInfo').isPurposeOfAccBusiness) {
        resolve('isPurposeOfAccBusiness');
      } else if (formDatum.get('additionalInfo').showBureauConsent) {
        this.controller.set('showActionSheet', true);
        this.controller.set('staticPopup', 'bureau-consent');
      } else if (formDatum.get('additionalInfo').appReferred) {
        resolve('appReferred');
      } else if (formDatum.get('additionalInfo').notEligible) {
        resolve('notEligible');
      } else if (formDatum.get('additionalInfo').genderAlert) {
        resolve('genderAlert');
      } else if (formDatum.get('additionalInfo').formResubmit) {
        resolve('formResubmit');
      } else if (formDatum.get('additionalInfo').CRSNTB) {
        resolve('CRSNTB');
      } else if (formDatum.get('additionalInfo').CRSETB) {
        resolve('CRSETB');
      } else {
        resolve();
      }
    });

    promise.then(result => {
      /* To remove the cart buttons in all the pages if the ZIBUKA flow for african countries alone.
       * Adding the function call here so that the method gets executed, once the promise is resolved.
       */
      if (config.isAfricanCtry.includes(this.get('axwayConfig.country'))) {
        this.removeZibukaCartAndBackButton('onNextPage');
      }

      if (result && result.length > 0) {
        if (result == 'terminateApp') {
          this.send('goToPreLogin');
        } else if (result === 'performDaonScan') {
          let scanCompArray = scanComponent.split(',');
          this.invokeDaonScan(scanCompArray);
        } else if (
          // Showing different popup for isETB assetonboarding journey. if not handled normally.
          !isEmpty(this.get('axwayConfig.assetOnboarding')) &&
          this.get('axwayConfig.assetOnboarding') === true &&
          (result == 'isETBCSLDedupeMatch' || result == 'isETB')
        ) {
          let message = this.get('i18n').t('productSummary.assetOnboardingisETB');
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              message,
              acceptButtonLabel: this.get('i18n').t('applyProducts.continueToLogin'),
              iconClass: 'asset-onboarding-info-icon',
              popupClass: 'asset-onboarding-theme',
              customClass: 'theme2'
            })
            .then(() => {
              // TO re-direct to login screen and then to apply-products directly.
              if (window.cordova) {
                window.location.href =
                  window.location.protocol + '//' + window.location.host + '/exit?RedirPageId=applyProductsETB';
              } else if (this.get('axwayConfig.country') === 'AE') {
                window.location.href = config.backToiBankNTBURL['AE'];
              } else {
                document.location.href = config.backToiBankURL;
              }
            });
        } else if (
          result == 'icmDedupe' ||
          result == 'monthlyIncomeAlertMultiple' ||
          result == 'monthlyIncomeAlertSingle' ||
          result == 'sanctionCntry' ||
          result == 'appSubmitDedupe' ||
          result === 'appNTBApproved' ||
          result == 'relPartyDedupe' ||
          result == 'etcCustomer' ||
          result == 'isETBCSLDedupeMatch' ||
          result == 'isETB' ||
          result == 'isPurposeOfAccBusiness' ||
          result == 'isNonResident' ||
          result == 'purposeOfAccAlert'
        ) {
          this.controller.set('showActionSheet', true);
          this.controller.set('fallbackType', result);
          this.controller.set('staticPopup', 'dedupe-failure');
        } else if (result === 'appReferred') {
          let customClass = `app-result ${result}`;
          this.controller.set('bpClass', customClass);
          this.controller.set('appResultType', result);
          this.controller.set('showActionSheet', true);
          this.controller.set('staticPopup', 'rdc-application-result');
        } else if (result == 'notEligible') {
          let relationshipNo = this.get('store').peekRecord('field', 'RelationshipNo'),
            message = {},
            isHardBundleField = this.get('store').peekRecord('field', 'isHardBundle');
          this.updateFlag(result);
          this.controller.set('showActionSheet', true);
          this.controller.set('staticPopup', 'ineligible-customer');
          //Not Eligible customer continue button disable case.
          if (
            !isEmpty(relationshipNo) &&
            (relationshipNo.get('value') !== null &&
              relationshipNo.get('value') !== 'NTB' &&
              relationshipNo.get('value') !== '')
          ) {
            message.isETB = true;
          } else {
            message.isETB = false;
          }
          message.isHardBundle = !isEmpty(isHardBundleField) && isHardBundleField.value === 'Y' ? true : false;
          this.controller.set('message', message);
        } else if (result == 'genderAlert') {
          let message = this.get('i18n').t('FERE.validation.error.invalidGender');
          this.showErrorMessage(message);
        } else if (result == 'authVerifyFlag') {
          this.controller.set('showActionSheet', true);
          if (this.media.isDesktop) {
            this.controller.set('bpClass', 'is-desktop email-verify');
          }
          this.controller.set('disableVerify', false);
          this.controller.set('staticPopup', 'email-verification');
          let verifyRetryCount = this.get('store').peekRecord('field', 'AuthRetryCount');
          let verifyMaxRetryCount = this.get('store').peekRecord('field', 'AuthMaxRetryCount');
          if (!isEmpty(verifyRetryCount) && !isEmpty(verifyMaxRetryCount)) {
            if (parseInt(verifyRetryCount.value) == parseInt(verifyMaxRetryCount.value)) {
              this.controller.set('disableVerify', true);
              this.controller.set('showActionSheet', true);
              if (this.get('axwayConfig.country') == 'KE') {
                this.controller.set('componentType', 'maxAttemptReached');
              } else {
                this.controller.set('componentType', 'redirectToHomePage');
              }
              this.controller.set('staticPopup', 'product-fallback');
            }
          }
        } else if (result == 'insufficientFund') {
          let amount = 'XXXXXXX',
            thresholdField = this.get('store').peekRecord('field', 'ThresholdAmount'),
            amountField = this.get('store').peekRecord('field', 'DebitAccountNumber');

          if (
            !isEmpty(thresholdField) &&
            !isEmpty(amountField) &&
            !isEmpty(thresholdField.value) &&
            !isEmpty(amountField.value)
          ) {
            amount = `${amountField.value.value.currencyCode} ${thresholdField.value}`;
          }
          this.controller.setProperties({
            showActionSheet: true,
            actionSheetAutoHeight: true,
            staticPopup: 'fund-account-failure',
            message: amount
          });
        } else if (
          result == 'ineligibleCustomer' ||
          result == 'isCDDRiskAvailable' ||
          result == 'crossBorderAlert' ||
          result == 'icmMobMismatch' ||
          result == 'etbInactive' ||
          result == 'etbHardHold' ||
          result == 'privateBankingFlag' ||
          result == 'onBoardingRisk' ||
          result == 'bureauNoMatch'
        ) {
          this.controller.set('showActionSheet', true);
          switch (result) {
            case 'crossBorderAlert':
              this.controller.set('componentType', 'redirectToHomePage');
              break;
            case 'isCDDRiskAvailable':
              this.controller.set('componentType', 'isCDDRiskAvailable');
              break;
            case 'ineligibleCustomer':
              let prodList = this.get('store').peekRecord('field', 'ProductList');
              let componentType = 'CC';
              if (prodList && prodList.value) {
                prodList.value.split(',').forEach(item => {
                  if (item.split('~')[0] != 'CC') {
                    componentType = 'Other';
                  }
                });
              }
              this.controller.set('componentType', componentType);
              break;
            default:
              this.controller.set('componentType', null);
          }
          this.controller.set('staticPopup', 'product-fallback');
        } else if (result === 'aipDeclined') {
          this.controller.setProperties({
            showActionSheet: true,
            staticPopup: 'nstl-declined',
            componentType: 'aipDeclined'
          });
        } else if (result === 'aipDoNotAgree') {
          this.controller.setProperties({
            showActionSheet: true,
            staticPopup: 'nstl-declined'
          });
        } else if (result == 'merchantValid') {
          if (this.media.isDesktop) {
            this.controller.set('bpClass', 'is-desktop merchant-desktop');
          }
          let isMerchantNoAvailable = this.get('store').peekRecord('field', 'IsMerchantNoAvailable');
          if (isMerchantNoAvailable) {
            isMerchantNoAvailable.set('value', 'N');
          }
          let merchantMobileNos = formDatum.get('additionalInfo').merchantMobileNos;
          if (merchantMobileNos) {
            isMerchantNoAvailable.set('value', 'Y');
          }
          this.controller.set('showActionSheet', true);
          this.controller.set('staticPopup', 'merchant-validation');
        } else if (result === 'isDocExpired') {
          let message = this.get('i18n').t('applyProducts.docExpireMessage'),
            title = this.get('i18n').t('applyProducts.docExpireTitle');
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              title,
              message,
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.goToProfileUpdate'),
              rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
              iconClass: 'asset-onboarding-info-icon',
              popupClass: 'asset-onboarding-theme',
              customClass: 'theme2 no-bg-btns'
            })
            .then(() => {
              this.set('isRetry', true);
              this.transitionTo('profileUpdate');
            });
        } else if (result == 'sessionTimeOut') {
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'error',
              title: this.get('i18n').t('ServiceRequest.COMMON.sessionExpire.title'),
              message: this.get('i18n').t('ServiceRequest.COMMON.sessionExpire.message'),
              acceptButtonLabel: this.get('i18n').t('generic.ok')
            })
            .then(() => {
              this.send('goToPreLogin');
            });
        } else if (result === 'CRSETB' || result === 'CRSNTB') {
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'error',
              title: this.get('i18n').t('ServiceRequest.COMMON.crsMessage.title'),
              message: this.get('i18n').t('ServiceRequest.COMMON.crsMessage.' + result),
              rejectButtonLabel:
                result === 'CRSNTB'
                  ? this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest')
                  : this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
              acceptButtonLabel:
                result === 'CRSNTB'
                  ? this.get('i18n').t('ServiceRequest.COMMON.button.close')
                  : this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
              customClass: 'custom-crs-class'
            })
            .then(() => {
              if (result !== 'CRSNTB') {
                this.set('isRetry', true);
                this.transitionTo('serviceRequest.new-request');
              }
            })
            .catch(() => {
              if (result === 'CRSNTB') {
                this.set('isRetry', true);
                this.send('goToPreLogin');
              }
            });
        } else if (result == 'invalidPromoCode') {
          const store = this.get('store');
          const PromoMaxRetryCount = store.peekRecord('field', 'PromoMaxRetryCount');
          let PromoRetryCount = store.peekRecord('field', 'PromoRetryCount');
          PromoRetryCount.set('value', parseInt(PromoRetryCount.value) + 1);
          let message, acceptButton, rejectButton;
          if (PromoRetryCount.value == PromoMaxRetryCount.value) {
            message = this.get('i18n').t('applyProducts.maxRetryLimitReached');
            acceptButton = this.get('i18n').t('applyProducts.continue');
            rejectButton = this.get('i18n').t('applyProducts.stopMyJourney');
          } else {
            message = this.get('i18n').t('applyProducts.promoRetryMsg');
            acceptButton = this.get('i18n').t('applyProducts.skipBtn');
            rejectButton = this.get('i18n').t('applyProducts.tryAgain');
          }
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              message,
              acceptButtonLabel: acceptButton,
              rejectButtonLabel: rejectButton,
              iconClass: 'service-journey-info-icon',
              popupClass: 'service-journey-info-popup'
            })
            .then(() => {
              let PromoSkipFlag = store.peekRecord('field', 'PromoSkipFlag');
              PromoSkipFlag.set('value', 'Y');
              this.send('moveToNextPage', false);
            })
            .catch(() => {
              let promoCode = store.peekRecord('field', 'PromoCode');
              promoCode.set('value', '');
              let promoRetryFlag = store.peekRecord('field', 'PromoRetryFlag');
              promoRetryFlag.set('value', 'Y');
              if (PromoRetryCount.value == PromoMaxRetryCount.value) {
                let terminateJourney = this.get('store').peekRecord('field', 'TerminateJourney');
                if (terminateJourney) {
                  terminateJourney.set('value', 'Y');
                }
                this.submitForm();
              }
            });
        } else if (result == 'appDedupe') {
          let mobileNumberField = this.get('store').peekRecord('field', 'MobileNumber');
          let mobileNumber;
          if (mobileNumberField && mobileNumberField.get('value')) {
            mobileNumber = mobileNumberField.get('value');
          }
          this.set('queries.resumeApplicationMobNo', mobileNumber);
          this.set('queries.applyProductDedupeType', 'appDedupe');
          this.resetForm(true);
          this.set('isRetry', true);
          this.transitionTo('appDedupe');
        } else if (result == 'formResubmit') {
          this.submitForm();
        } else {
          this.resetForm(true);
          this.transitionTo(result);
        }
      } else {
        if (!isFileDelete) this.goToReceiptPage();
      }
      this.setCustomLoader();
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.enableGoToNext();
    });
    return;
  },
  closeThisForm(category) {
    if (this.get('axwayConfig.country') == 'CI') {
      /* For resetting the form if the product selected in CI country is different.
       * Since fere peeks and loads the same form, selecting another product
       * does not reset the form data. So resetting it manually on back from 1st page.
       */
      this.resetForm(true);
      this.transitionTo('product.opening');
    } else {
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      this.get('rdcLoadingIndicator').showLoadingIndicator();
      if (!isEmpty(category) && category === 'category') {
        this.transitionTo('product-list.category');
      } else {
        this.transitionTo('product-list.list');
      }
    }
  },
  _validateCheckSum(emiratesID) {
    let checkSumOdd = 0;
    let checkSumEven = 0;
    for (let i = 1; i < emiratesID.length; i = i + 2) {
      let tempVal = emiratesID.charAt(i) * 2;
      if (tempVal >= 10) {
        tempVal = this.sumDigit(tempVal);
      }
      if (tempVal) checkSumEven += tempVal;
    }
    for (let j = 0; j <= 13; j = j + 2) {
      checkSumOdd += parseInt(emiratesID.charAt(j));
    }
    let sum = (checkSumOdd + checkSumEven).toString();
    let checkSum = parseInt(sum.charAt(sum.length - 1));
    if (checkSum != 0) {
      checkSum = 10 - checkSum;
    }
    return checkSum == emiratesID.toString().charAt(emiratesID.length - 1);
  },

  sumDigit(value) {
    let result = 0;
    let tempVale = value.toString();
    for (let i = 0; i < tempVale.length; i++) {
      result += parseInt(tempVale.charAt(i));
    }
    return result;
  },

  showErrorMessage(message) {
    this.get('rdcModalManager').showDialogModal({
      level: 'warning',
      message,
      acceptButtonLabel: 'OK',
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },
  /* For removing the cart button during Zibuka flow,
   * to continue with only CASA for KE (ZIBUKA)
   */
  removeZibukaCartAndBackButton(scenario) {
    // Getting the particular tab buttons for hiding..
    let zibukaFlag = this.get('store').peekRecord('field', 'ZibukaFlag'),
      declineFlag = this.get('store').peekRecord('field', 'GenDeclineFlag');
    if (
      (!isEmpty(declineFlag) && declineFlag.value === 'Y') ||
      (!isEmpty(zibukaFlag) && !isEmpty(declineFlag) && zibukaFlag.value === 'Y' && declineFlag.value === 'N')
    ) {
      let toBeHiddenbuttons = [];
      // fetching the cart buttons bnased on scenario for Zibuka flow for hiding.
      if (scenario === 'onLoad') {
        // fetching the cart buttons for all pages for Zibuka flow for hiding.
        this.currentModel.pages.map(page => {
          page.buttons.filter(button => {
            if (button.get('cssClassName').indexOf('cart-btn') !== -1) {
              toBeHiddenbuttons.push(button);
            }
          });
        });
      } else if (scenario === 'onNextPage') {
        // fetching the cart button for next page for Zibuka flow for hiding.
        toBeHiddenbuttons = this.nextPage.buttons.filter(button => {
          return button.get('cssClassName').indexOf('cart-btn') !== -1;
        });
      }

      // To hide back button in fatca page only if gendecline flag is Y.
      if (!isEmpty(declineFlag) && declineFlag.value === 'Y') {
        let fatcaBackButton = this.get('store').peekRecord('button', 'tab6back');
        if (!isEmpty(fatcaBackButton)) {
          toBeHiddenbuttons.push(fatcaBackButton);
        }
      }

      toBeHiddenbuttons.forEach(button => {
        let buttonCss = button.get('cssClassName');
        // Getting the existing class and appending hide-btn to it.
        if (buttonCss.indexOf('hide-btn') === -1) {
          buttonCss = `${buttonCss} hide-btn`;
        }
        // Setting back the class for the particular tab.
        button.set('cssClassName', buttonCss);
      });
    }
  },
  // To add back the hidden cart button in all pages in case of ineligible customer.
  addZibukaCartButton() {
    let toBeShownButtons = [];
    // fetching the cart buttons for all pages for Zibuka flow for showing.
    this.currentModel.pages.map(page => {
      page.buttons.filter(button => {
        if (button.get('cssClassName').indexOf('cart-btn') !== -1) {
          toBeShownButtons.push(button);
        }
      });
    });

    toBeShownButtons.forEach(button => {
      let buttonCss = button.get('cssClassName');
      // Getting the existing class and removing hide-btn from it.
      if (buttonCss.indexOf('hide-btn') !== -1) {
        buttonCss = buttonCss.replace('hide-btn', '');
      }
      // Setting back the class for the particular tab.
      button.set('cssClassName', buttonCss);
    });
    /* The below condition is remove the class in the currently loaded page.
     * This cannot be removed without querying the element.
     */
    document.querySelector('.cart-btn').classList.remove('hide-btn');
  },

  updateFlag(scenario) {
    if (scenario === 'notEligible') {
      this.addZibukaCartButton();
    }
    let productList = this.get('store').peekRecord('field', 'ProductList'),
      productListVal = productList.value.split(',') || productList.value;
    let zibukaFlag = this.get('store').peekRecord('field', 'ZibukaFlag');
    let casaFlag = this.get('store').peekRecord('field', 'CASAFlag');
    if (!isEmpty(zibukaFlag) && !isEmpty(casaFlag)) {
      zibukaFlag.set('value', 'N');
      casaFlag.set('value', 'Y');
      // To remove all three PL, CC, OD.
      let productString = productListVal.filter(val => {
        return !val.includes('CC') && !val.includes('PL') && !val.includes('OD');
      });
      productList.set('value', productString.toString());
    }
  },

  actions: {
    // To execute below action "field-action": "applicationResult" should be configured in CSL side.
    // From the component rdc-application-result.hbs
    applicationResult(updateFlag, terminateFlag, appResultType) {
      if (updateFlag) {
        this.updateFlag(appResultType);
      }
      if (terminateFlag) {
        let terminateJourney = this.get('store').peekRecord('field', 'terminateApp');
        if (!isEmpty(terminateJourney)) {
          terminateJourney.set('value', 'Y');
        }
      }
      if (!updateFlag && !terminateFlag && appResultType === 'declineSoftBundleFlag') {
        this.send('goToPreviousPage');
        return;
      }
      this.send('moveToNextPage', true);
    },

    loading(transition, originRoute) {
      if ('redirectUrl' in originRoute.queryParams.filter) {
        this.controllerFor('apply-products').set('currentlyLoading', true);
        return true;
      }
    },
    goToNormalMode(sectionModel) {
      // To change the reviewMode only if reviewEditAction is not profileUpdate.
      if (!isEmpty(sectionModel.reviewEditAction) && sectionModel.reviewEditAction === 'profileUpdate') {
        let title = this.get('i18n').t('applyProducts.editMailingAddressTitle');
        let message = this.get('i18n').t('applyProducts.editMailingAddressMessage');
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            title,
            message,
            acceptButtonLabel: this.get('i18n').t('applyProducts.editMailingAddressButton'),
            rejectButtonLabel: this.get('i18n').t('FERE.action.button.cancel'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup edit-mailing-address with-red-title'
          })
          .then(() => {
            this.set('isRetry', true);
            this.transitionTo(sectionModel.reviewEditAction);
          });
      } else {
        if (!isEmpty(this.get('axwayConfig.assetOnboarding')) && this.get('axwayConfig.assetOnboarding') === true) {
          let title = this.get('i18n').t('applyProducts.editDaonDetailsTitle');
          let message = this.get('i18n').t('applyProducts.editDaonDetailsMessage');
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              title,
              message,
              acceptButtonLabel: this.get('i18n').t('applyProducts.editDaonDetailsButton'),
              rejectButtonLabel: this.get('i18n').t('FERE.action.button.NO'),
              iconClass: 'asset-onboarding-question-icon',
              popupClass: 'service-journey-info-popup asset-onboarding-theme',
              customClass: 'theme2'
            })
            .then(() => {
              const isKeyFieldsMatch = this.get('store').peekRecord('field', 'IsKeyFieldsMatch');
              if (!isKeyFieldsMatch || !isKeyFieldsMatch.value || isKeyFieldsMatch.value === 'false') {
                sectionModel.set('showReviewMode', false);
                sectionModel.set('showReviewEdit', false);
                let ocrEditedFlagVal = this.get('store').peekRecord('field', 'OCReditedFlag');
                if (ocrEditedFlagVal !== null) {
                  ocrEditedFlagVal.set('value', true);
                }
              }
              if (!isEmpty(sectionModel.reviewEditAction)) {
                this.transitionTo(sectionModel.reviewEditAction);
              }
            });
          return;
        }
        const isKeyFieldsMatch = this.get('store').peekRecord('field', 'IsKeyFieldsMatch');
        if (!isKeyFieldsMatch || !isKeyFieldsMatch.value || isKeyFieldsMatch.value === 'false') {
          sectionModel.set('showReviewMode', false);
          sectionModel.set('showReviewEdit', false);
          let ocrEditedFlagVal = this.get('store').peekRecord('field', 'OCReditedFlag');
          if (ocrEditedFlagVal !== null) {
            ocrEditedFlagVal.set('value', true);
          }
        }
        if (!isEmpty(sectionModel.reviewEditAction)) {
          this.transitionTo(sectionModel.reviewEditAction);
        }
      }
    },
    setAdditionalFields(fields) {
      if (fields) {
        let store = this.get('store');
        fields.forEach(item => {
          let field = store.peekRecord('field', item.id);
          if (field) {
            if (item.fieldType === 'rdc-form-select' && !isEmpty(item.newValue)) {
              let fieldOption = field.get('fieldConfig.fieldOptions').findBy('value', item.newValue);
              field.set('value', fieldOption);
            } else {
              field.set('value', item.newValue);
            }
          }
        });
      }
    },
    submitFirstPage() {
      /* Action for getting BVN details.
            This condition is added here since the progress bar will be shown only if,
            the action in formdata is either "goToNextPage" or "submitFirstPage".
            Checking if country is Nigeria.
            This has to be removed and configured in form data once this is fixed in fere. */
      if (this.get('axwayConfig.country') === 'NG') {
        // Checking if the page has any validation errors.
        let isValid = this.checkIfPageValid();
        if (isValid) {
          // since account upgrade check happens only in page 6 after selfie upload.
          if (this.get('currentDisplayPage').id == 'W400-Pg6') {
            /* Checking if nationality is "NGA",
             * if not it is considered as expat and checkAccountUpgrade popup is not shown.
             */
            let nationality = this.get('store').peekRecord('field', 'Nationality');
            if (nationality && nationality.get('value') && nationality.get('value.value') === 'NGA') {
              this.checkAccountUpgrade();
            } else {
              this.goToNextPage();
            }
          } else {
            this.getBvnRequestData();
          }
        } else {
          this.goToNextPage();
        }
        return;
      }

      let cardName = this.get('store').peekRecord('field', 'CardName');
      if (cardName) {
        let value = cardName.get('value');
        let newValue = value && value.substring(0, 19);
        cardName.set('value', newValue);
      }

      //For NTB notifications pass device data
      this.setDeviceDataBeforeSubmit();

      let EmiratesIdField = this.get('store').peekRecord('field', 'EmiratesID');
      let residentialCountry = this.get('store').peekRecord('field', 'CountryofResident');
      let gender = this.get('store').peekRecord('field', 'Gender');
      let salutation = this.get('store').peekRecord('field', 'Salutation');
      let livingLocation = this.get('store').peekRecord('field', 'LivingLocation');

      if (EmiratesIdField || residentialCountry) {
        if (
          EmiratesIdField.get('visible') &&
          EmiratesIdField.get('value') &&
          !this._validateCheckSum(EmiratesIdField.get('value'))
        ) {
          let message = this.get('i18n').t('FERE.validation.error.invalidEmiratesId');
          this.showErrorMessage(message);
        } else if (residentialCountry || (gender && salutation)) {
          let countryValue = residentialCountry.get('value');
          if (
            this.get('currentDisplayPage').id == 'W400-Pg8' &&
            this.get('axwayConfig.country') == 'AE' &&
            countryValue &&
            countryValue.value !== 'AE'
          ) {
            let message = this.get('i18n').t('FERE.validation.error.invalidResidentialCountry');
            this.showErrorMessage(message);
          } else if (
            this.get('currentDisplayPage').id == 'W400-Pg6' &&
            gender.get('value') == 'F' &&
            salutation.get('value') == 'MR'
          ) {
            let message = this.get('i18n').t('FERE.validation.error.invalidGender');
            this.showErrorMessage(message);
          } else if (
            this.get('currentDisplayPage').id == 'W400-Pg6' &&
            gender.get('value') == 'M' &&
            (salutation.get('value') == 'MRS' || salutation.get('value') == 'MS')
          ) {
            let message = this.get('i18n').t('FERE.validation.error.invalidGender');
            this.showErrorMessage(message);
          } else {
            this.goToNextPage();
          }
        } else {
          this.goToNextPage();
        }
      } else if (livingLocation && livingLocation.get('value') === 'N') {
        let message = this.get('i18n').t('applyProducts.nonResident');
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message,
            acceptButtonLabel: this.get('i18n').t('applyProducts.quitBtn'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          })
          .then(() => {
            this.send('goToPreLogin');
          });
      } else {
        this.goToNextPage();
      }
    },

    nextPageCustomLoader() {
      this.setCustomLoader(this.get('i18n').t('applyProducts.customLoaderMsg'), 'eligibility-loader');
      this.goToNextPage();
    },

    goToNextPage() {
      if (
        this.get('formId') === 'W400' &&
        (this.get('filter.stepName') === 'MK_F1' ||
          this.get('filter.stepName') === 'MK_F3' ||
          this.get('filter.stepName') === 'MK_F6' ||
          this.get('filter.stepName') === 'MK_F5')
      ) {
        this.setCustomLoader(
          this.get('i18n')
            .t('rdc.loading.saving')
            .toString(),
          ' '
        );
        if (isEmpty(this.currentModel.receiptId)) {
          this.setCustomLoader(
            this.get('i18n')
              .t('rdc.loading.text')
              .toString(),
            ' '
          );
        }
      }
      this.setDeviceDataBeforeSubmit();
      this._super(...arguments);

      this._exec('getOnboardingStatus').then(onboardingStatus => {
        if (onboardingStatus != 20 || onboardingStatus != 30) {
          this.firebaseAnalytics.logEvent(this.get('currentDisplayPage.id'));
        }
      });
    },

    goToBack() {
      let mobileNo = this.get('store').peekRecord('field', 'ContactValue1');
      let emailId = this.get('store').peekRecord('field', 'ContactValue3');
      let DateofBirth = this.get('store').peekRecord('field', 'DateofBirth');
      let relationshipNo = this.get('store').peekRecord('field', 'RelationshipNo');
      let bvnNumber = this.get('store').peekRecord('field', 'BVNNumber');
      let bvnDecl = this.get('store').peekRecord('field', 'BVNDeclaration'),
        eventType = this.get('store').peekRecord('field', 'eventType');

      if (mobileNo && mobileNo.value && (emailId && emailId.value)) {
        mobileNo.set('editable', false);
        emailId.set('editable', false);
      }
      if (mobileNo && mobileNo.value && (DateofBirth && DateofBirth.value)) {
        mobileNo.set('editable', false);
        if (!config.isAfricanCtry.includes(this.get('axwayConfig.country'))) {
          DateofBirth.set('editable', false);
        }
      }
      if (bvnNumber && bvnNumber.value && (bvnDecl && bvnDecl.value)) {
        bvnNumber.set('editable', false);
        bvnDecl.set('editable', false);
      }
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        if (this.get('axwayConfig.country') == 'CI') {
          /* For resetting the form if the product selected in CI country is different.
           * Since fere peeks and loads the same form, selecting another product
           * does not reset the form data. So resetting it manually on back from 1st page.
           */
          this.resetForm(true);
          this.transitionTo('product.opening');
        } else if (
          (this.get('axwayConfig.country') === 'NG' || (!isEmpty(eventType) && eventType.value === 'RESUME')) &&
          relationshipNo &&
          (relationshipNo.get('value') !== null &&
            relationshipNo.get('value') !== 'NTB' &&
            relationshipNo.get('value') !== '')
        ) {
          this.transitionTo('serviceRequest.new-request');
        } else if (this.get('axwayConfig.staffEligibilityCheck')) {
          this.transitionTo('staff-product-category');
        } else {
          this.transitionTo('start-application');
        }
      }
    },
    goToHome() {
      this.send('closeFormWithoutPrompt');
    },
    closeForm() {
      if (this.get('axwayConfig.country') == 'CI') {
        this.transitionTo('product.opening');
      } else {
        let title = this.get('i18n').t('FERE.action.modal.quitApp.title');
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'error',
            title,
            message: this.currentModel.receiptId
              ? this.get('i18n').t('FERE.action.modal.quitApp.messageEmailSms')
              : this.get('i18n').t('FERE.action.modal.quitApp.messageProgressLost'),
            acceptButtonLabel: this.get('i18n').t('FERE.action.button.YES'),
            rejectButtonLabel: this.get('i18n').t('FERE.action.button.NO')
          })
          .then(() => {
            if (config.isAfricanCtry.includes(this.get('axwayConfig.country'))) {
              let label = '';
              this.get('currentDisplayPage')
                .get('sectionGroups')
                .forEach(sectionGroup => {
                  sectionGroup.get('sections').forEach(section => {
                    section.get('fields').forEach(field => {
                      if (field.get('visible') && field.get('editable')) {
                        // Set the iterated feilds label here and pass the Last Interacted feild to adobe data service
                        label = field.get('dirtyType') == 'updated' ? field.label : label;
                      }
                    });
                  });
                });
              this.adobeDataService.setField(label, '');
              this.adobeDataService.formAbandonment();
            }
            if (window.cordova) {
              this._exec('getOnboardingStatus').then(onboardingStatus => {
                if (onboardingStatus != 20 || onboardingStatus != 30) {
                  this.firebaseAnalytics.logEvent(this.get('currentDisplayPage.id'));
                }
              });
              // Sending refresh token and access token while exit from fere to legecy screen.
              if (this.accessToken && this.refreshToken) {
                window.location.href =
                  window.location.protocol +
                  '//' +
                  window.location.host +
                  '/exit?RDC-ACCESS-TOKEN=' +
                  this.accessToken +
                  '&RDC-REFRESH-TOKEN=' +
                  this.refreshToken;
              } else {
                window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
              }
            } else {
              const preloginStatus =
                !this.store.peekRecord('field', 'RelationshipNo') ||
                this.store.peekRecord('field', 'RelationshipNo').value === 'NTB';
              if (this.get('axwayConfig.country') === 'AE' && preloginStatus) {
                window.location.href = config.backToiBankNTBURL['AE'];
              } else {
                document.location.href = config.backToiBankURL;
              }
            }
          });
      }
    },

    callAssistance() {
      document.location.href = 'tel:+22520303281';
    },
    onCancel() {
      this.controller.set('showActionSheet', false);
    },
    onNext(flag) {
      if (flag && flag === 'terminateApp') {
        let terminateJourney = this.get('store').peekRecord('field', 'terminateApp');
        if (!isEmpty(terminateJourney)) {
          terminateJourney.set('value', 'Y');
        }
      } else {
        let bureauIndicator = this.get('store').peekRecord('field', 'BureauIndicator');
        if (bureauIndicator) {
          bureauIndicator.set('value', 'Y');
        }
      }
      this.submitForm();
      this.controller.set('showActionSheet', false);
    },
    upgradeNgAccount(upgradeFlag) {
      this.controller.set('showActionSheet', false);
      let upgradeFlagField = this.get('store').peekRecord('field', 'UpgradeFlag');
      if (upgradeFlagField) {
        upgradeFlagField.set('value', upgradeFlag);
      }
      this.goToNextPage();
    },
    onBack(page) {
      this.controller.set('showActionSheet', false);
      this.set('isRetry', true);
      if (page == 'home') {
        if (!this.get('sessionManager').getPreLoginStatus()) {
          if (this.get('queries.countryName') == 'CI') {
            this.transitionTo('serviceRequest.new-request');
          } else {
            window.location.href =
              window.location.protocol + '//' + window.location.host + '/retail/api/security/v1/ssoRequest';
          }
        } else {
          if (window.cordova) {
            if (this.get('queries.countryName') == 'CI') {
              if (!isNone(window.PGMultiView)) {
                window.PGMultiView.dismissView();
              } else {
                this.get('iframeManager').close();
              }
            } else {
              // Sending refresh token and access token while exit from fere to legecy screen.
              if (this.accessToken && this.refreshToken) {
                window.location.href =
                  window.location.protocol +
                  '//' +
                  window.location.host +
                  '/exit?RDC-ACCESS-TOKEN=' +
                  this.accessToken +
                  '&RDC-REFRESH-TOKEN=' +
                  this.refreshToken;
              } else {
                window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
              }
            }
          } else if (this.get('axwayConfig.country') === 'AE') {
            window.location.href = config.backToiBankNTBURL['AE'];
          } else {
            window.location.href =
              window.location.protocol + '//' + window.location.host + '/retail/api/security/v1/ssoRequest';
          }
        }
      } else {
        this.send('closeFormWithoutPrompt');
      }
    },
    modifyProduct() {
      this.get('rdcLoadingIndicator').showLoadingIndicator();
      let title = this.get('i18n').t('applyProducts.productChangeTitle'),
        message = this.get('i18n').t('applyProducts.changeMsg'),
        transitionProductPage;
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'error',
          title,
          message,
          acceptButtonLabel: this.get('i18n').t('FERE.action.button.YES'),
          rejectButtonLabel: this.get('i18n').t('FERE.action.button.NO'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          this.set('isRetry', true);
          let selectedProducts = this.store.peekRecord('field', 'ProductList').value;
          // (ZIBUKA) For removing the hardbundled item from product string to prevent from soft bundling.
          if (selectedProducts.indexOf('ihb') !== -1) {
            let selectedProductsArray = selectedProducts.split(',');
            selectedProductsArray = selectedProductsArray.filter(string => {
              return string.includes('ihb');
            });
            selectedProducts = selectedProductsArray.join();
          }
          let qryPrms = {
            products: selectedProducts
          };
          if (this.currentModel.receiptId) {
            this.get('rdcLoadingIndicator').showLoadingIndicator();
            let reciptID = this.currentModel.receiptId;
            qryPrms.sourceRefNo = reciptID;
          }
          transitionProductPage = this.get('axwayConfig.assetOnboarding')
            ? 'product-list.category'
            : 'product-list.list';
          this.transitionTo(transitionProductPage, { queryParams: qryPrms });
        })
        .catch(() => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          return;
        });
    },
    moveToNextPage(flag) {
      if (this.controller.showActionSheet) {
        this.controller.set('showActionSheet', false);
      }
      if (flag) {
        this.setCustomLoader();
        this.goToNextPage();
      } else {
        this.transitionTo(this.routeName + '.ferePage', this.get('nextPage').id);
      }
    },

    setEligibilityLimit() {
      let creditLimitField = this.get('store').peekRecord('field', 'CreditLimit'),
        creditLimit = null,
        creditLimitInfinite = this.get('store').peekRecord('field', 'MonthlyRepaymentInfinite'),
        creditLimitGold = this.get('store').peekRecord('field', 'MonthlyRepaymentGold'),
        creditLimitPlatinum = this.get('store').peekRecord('field', 'MonthlyRepaymentPlatinum');
      if (!isEmpty(creditLimitField)) {
        creditLimit = creditLimitField.value;
      }
      if (!isEmpty(creditLimitInfinite)) {
        creditLimitInfinite.set('retypeValue', creditLimit);
      }
      if (!isEmpty(creditLimitGold)) {
        creditLimitGold.set('retypeValue', creditLimit);
      }
      if (!isEmpty(creditLimitPlatinum)) {
        creditLimitPlatinum.set('retypeValue', creditLimit);
      }
      this.goToNextPage();
    },

    flagUpdate(isETB, buttonType, resultType) {
      /*
       * isETB - to diff NTB and ETB journey to handle different flow.
       * buttonType - Close / Continue to quit based on isETB flag.
       */
      if (!isEmpty(buttonType) && buttonType === 'close') {
        if (!isEmpty(isETB) && isETB === true) {
          this.set('isRetry', true);
          this.transitionTo('serviceRequest.new-request');
        } else {
          this.send('goToPreLogin');
        }
      } else {
        let hardBundleFlag = this.get('store').peekRecord('field', 'isHardBundle');
        if (!isEmpty(hardBundleFlag)) {
          if (hardBundleFlag.value === 'Y') {
            this.send('onBack');
            return;
          } else {
            this.updateFlag(resultType);
          }
        }
        if (!isEmpty(isETB) && isETB === true) {
          this.get('rdcLoadingIndicator').showLoadingIndicator();
          this.controller.set('showActionSheet', false);
          this.set('isRetry', true);
          this.transitionTo('product-list.category');
        } else {
          this.send('moveToNextPage', true);
        }
      }
    },
    goToPreLogin() {
      if (this.get('axwayConfig.country') == 'CI') {
        window.PGMultiView.dismissView();
      } else {
        if (window.cordova) {
          // Sending refresh token and access token while exit from fere to legecy screen.
          if (this.accessToken && this.refreshToken) {
            window.location.href =
              window.location.protocol +
              '//' +
              window.location.host +
              '/exit?RDC-ACCESS-TOKEN=' +
              this.accessToken +
              '&RDC-REFRESH-TOKEN=' +
              this.refreshToken;
          } else {
            window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
          }
        } else {
          const preloginStatus =
            !this.store.peekRecord('field', 'RelationshipNo') ||
            this.store.peekRecord('field', 'RelationshipNo').value === 'NTB';
          if (this.get('axwayConfig.country') === 'AE' && preloginStatus) {
            window.location.href = config.backToiBankNTBURL['AE'];
          } else {
            document.location.href = config.backToiBankURL;
          }
        }
      }
    },
    goToProductSelection(category) {
      this.controller.set('showActionSheet', false);
      this.set('isRetry', true);
      this.closeThisForm(category);
    }
  }
});
