import Route from '@ember/routing/route';

export default Route.extend({
  actions: {
    selectCurrentAccount() {
      this.controllerFor('product-list.list').set('bundlingCurrentAccount', true);
      this.transitionTo('product-list.list', {
        queryParams: {
          categoryId: 'ACD'
        }
      });
    }
  }
});
