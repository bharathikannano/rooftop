import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../config/environment';
import { isBlank, isNone } from '@ember/utils';

export default Route.extend({
  i18n: service(),
  rdcModalManager: service(),
  store: service(),
  queries: service('customer-info'),
  rdcLoadingIndicator: service(),
  setupController(controller) {
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    let creditCardsDisplayIndex, debitCardsDisplayIndex;
    if (this.get('entity') === 'CCARD') {
      creditCardsDisplayIndex = config.ctryBasedCards.cardBlockCredit.indexOf(this.get('queries.countryName'));
    } else if (this.get('entity') === 'DCARD') {
      debitCardsDisplayIndex = config.ctryBasedCards.cardBlockDebit.indexOf(this.get('queries.countryName'));
    } else {
      creditCardsDisplayIndex = config.ctryBasedCards.cardBlockCredit.indexOf(this.get('queries.countryName'));
      debitCardsDisplayIndex = config.ctryBasedCards.cardBlockDebit.indexOf(this.get('queries.countryName'));
    }
    if (creditCardsDisplayIndex >= 0 && debitCardsDisplayIndex >= 0) {
      controller.set('labelDisplay', this.get('i18n').t('ServiceRequest.COMMON.subCategoryText.cardBlock'));
    } else if (creditCardsDisplayIndex >= 0) {
      controller.set('labelDisplay', this.get('i18n').t('ServiceRequest.COMMON.subCategoryText.cardBlock1'));
    } else {
      controller.set('labelDisplay', this.get('i18n').t('ServiceRequest.COMMON.subCategoryText.cardBlock2'));
    }
  },
  beforeModel(params) {
    if (params) {
      this.set('entity', params.queryParams ? params.queryParams.entity : '');
    }

    let countryCode = this.get('queries.countryName');
    if (isNone(countryCode) || isBlank(countryCode)) {
      this.transitionTo('serviceRequest.new-request');
    } else {
      this.transitionTo('card-block.select');
    }
  },
  resetController(controller, isExiting, transition) {
    if (transition.targetName.indexOf('card-block') == -1) {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.controllerFor('card-block.select').set('selectedFromAcc', null);
      this.controllerFor('card-block.select').set('reasonSelected', null);
      this.controllerFor('card-block.select').set('cardData', '');
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
    }
  },
  actions: {
    didTransition() {
      if (document.querySelector('.popup-wrapper')) {
        document.querySelector('.popup-wrapper').scrollTop = 0;
      }
    },
    cancelProgress() {
      this.controller.set('clickCancel', true);
      let message = this.get('i18n').t('ServiceRequest.CARDBLOCK.cancelPopup');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          this.get('store').unloadAll('credit-card');
          this.get('store').unloadAll('debit-card');
          this.transitionTo('serviceRequest.new-request');
        });
    },
    closePopupAction() {
      this.controller.set('clickCancel', true);
      let message;
      if (this.get('media.isDesktop')) {
        message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankBefAckText');
      } else {
        message = this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankBefAckText');
      }
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
        });
    }
  }
});
