import { htmlSafe } from '@ember/string';
import { A } from '@ember/array';
import { Promise as EmberPromise, hash } from 'rsvp';
import { typeOf, isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from './../../config/environment';
export default Route.extend({
  store: service(),
  queries: service('customer-info'),
  i18n: service(),
  error: service('card-error-handler'),
  rdcModalManager: service(),
  idle: service('idle-ticker'),
  rdcLoadingIndicator: service(),
  router: service(),

  model() {
    let chkRoutename = null;
    let chkConfirmRoutename = null;
    this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    let msgContent = this.get('queries.countryName') == 'SG' ? 'SG.content' : 'content';
    this.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.nocard.header'));
    this.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.nocard.' + msgContent));
    this.set(
      'sublable',
      this.get('i18n').t('ServiceRequest.CARDBLOCK.cardlistSubHeader.' + this.get('queries.countryName'), {
        default: 'ServiceRequest.CARDBLOCK.cardlistSubHeader'
      })
    );
    let CreditCardDetails, DebitCardDetails;
    this.set('cards', config.cards != 'credit' ? 'true' : '');
    let creditCardsDisplayIndex, debitCardsDisplayIndex;
    if (config.ctryBasedCards.validateQueryparam.indexOf(this.get('queries.countryName')) !== -1) {
      if (!isEmpty(this.get('entity'))) {
        if (this.get('entity') === 'CCARD') {
          creditCardsDisplayIndex = config.ctryBasedCards.cardBlockCredit.indexOf(this.get('queries.countryName'));
        } else if (this.get('entity') === 'DCARD') {
          debitCardsDisplayIndex = config.ctryBasedCards.cardBlockDebit.indexOf(this.get('queries.countryName'));
        }
      }
    } else {
      creditCardsDisplayIndex = config.ctryBasedCards.cardBlockCredit.indexOf(this.get('queries.countryName'));
      debitCardsDisplayIndex = config.ctryBasedCards.cardBlockDebit.indexOf(this.get('queries.countryName'));
    }
    this.set(
      'creditCardsDisplay',
      creditCardsDisplayIndex >= 0 ? 'true' : creditCardsDisplayIndex < 0 && debitCardsDisplayIndex < 0 ? 'true' : ''
    );
    this.set(
      'debitCardsDisplay',
      debitCardsDisplayIndex >= 0 ? 'true' : creditCardsDisplayIndex < 0 && debitCardsDisplayIndex < 0 ? 'true' : ''
    );

    if (this.get('router.currentRouteName') != null) {
      chkRoutename = this.get('router.currentRouteName').indexOf('new-request') != -1 ? true : false;
      chkConfirmRoutename = this.get('router.currentRouteName').indexOf('confirm') != -1 ? true : false;
    }
    if (chkRoutename) {
      this.set('creditCardStatus', null);
      this.set('debitCardStatus', null);
      this.set('DebitCardErrorcheck', null);
      this.set('CreditCardErrorcheck', null);
    }
    if (this.get('creditCardsDisplay') == 'true') {
      this.set('CreditCardErrorcheck', false);
      if ((!chkConfirmRoutename && chkRoutename) || (chkRoutename == null && chkConfirmRoutename == null)) {
        CreditCardDetails = this.get('store')
          .query('credit-card', {
            filter: config.Filters.creditCard[this.get('queries.countryName')]
          })
          .then(
            data => {
              this.set('creditCardStatus', 'CreditCardSuccess');
              this.set('creditCardDataLength', data.get('length'));
              return data;
            },
            error => {
              this.set('creditCardStatus', 'CreditCardError');
              typeOf(error.errors[0].code) === undefined
                ? this.set('CreditCardErrorcheck', true)
                : this.set('CreditCardErrorcheck', error.errors[0].code);
            }
          );
      } else {
        CreditCardDetails = this.controllerFor('card-block.select').get('currentCreditCard');
      }
    }

    if (this.get('debitCardsDisplay') == 'true') {
      this.set('DebitCardErrorcheck', false);
      if ((!chkConfirmRoutename && chkRoutename) || (chkRoutename == null && chkConfirmRoutename == null)) {
        DebitCardDetails = this.get('store')
          .query('debit-card', {
            filter: config.Filters.debitCard[this.get('queries.countryName')]
          })
          .then(
            data => {
              this.set('debitCardStatus', 'DebitCardSuccess');
              this.set('debitCardDataLength', data.get('length'));
              return data;
            },
            error => {
              this.set('debitCardStatus', 'DebitCardError');
              typeOf(error.errors[0].code) === undefined
                ? this.set('DebitCardErrorcheck', true)
                : this.set('DebitCardErrorcheck', error.errors[0].code);
            }
          );
      } else {
        DebitCardDetails = this.controllerFor('card-block.select').get('currentDebitCard');
      }
    }

    let promises = [CreditCardDetails, DebitCardDetails];
    EmberPromise.all(promises).then(
      () => {
        this.get('error').errorHandler(this);
        this.get('rdcLoadingIndicator').hideLoadingIndicator();
      },
      () => {
        this.get('error').errorHandler(this);
        this.get('rdcLoadingIndicator').hideLoadingIndicator();
      }
    );

    this.set('accList', [
      {
        value: this.get('i18n')
          .t('ServiceRequest.CARDBLOCK.selectreason.reason1')
          .toString(),
        id: 'L'
      },
      {
        value: this.get('i18n')
          .t('ServiceRequest.CARDBLOCK.selectreason.reason2')
          .toString(),
        id: 'S'
      },
      {
        value: this.get('i18n')
          .t('ServiceRequest.CARDBLOCK.selectreason.reason3')
          .toString(),
        id: 'C'
      }
    ]);

    const accList = A(this.get('accList'));

    let newAccList = accList.filter(x => {
      if (this.get('queries.countryName') === 'BN') {
        return x.id !== 'C';
      } else {
        return x;
      }
    });

    return hash({
      AccListt: newAccList,
      CreditCardDetails: CreditCardDetails,
      DebitCardDetails: DebitCardDetails
    });
  },
  beforeModel(params) {
    let chkRoutename = null;
    let chkConfirmRoutename = null;
    if (this.get('router.currentRouteName')) {
      chkRoutename = this.get('router.currentRouteName').indexOf('new-request') != -1 ? true : false;
      chkConfirmRoutename = this.get('router.currentRouteName').indexOf('confirm') != -1 ? true : false;
    }

    if ((!chkConfirmRoutename && chkRoutename) || (chkRoutename == null && chkConfirmRoutename == null)) {
      if (params) {
        this.set('entity', params.queryParams ? params.queryParams.entity : '');
      }
    }
  },
  afterModel(data) {
    data.nocardsTitle = this.get('nocardsTitle');
    data.nocardsContent = this.get('nocardsContent');
    data.sublable = this.get('sublable');
  },
  setupController(controller, model) {
    this._super(controller, model);
    /* transition login for notes */
    controller.set(
      'countryLinks',
      this.get('i18n').t('ServiceRequest.CARDBLOCK.countryLinks.' + this.get('queries.countryName'))
    );
    controller.set(
      'countryLinksTxt',
      this.get('i18n').t('ServiceRequest.CARDBLOCK.countryLinksTxt.' + this.get('queries.countryName'), {
        default: 'ServiceRequest.CARDBLOCK.countryLinksTxt.default'
      })
    );
    controller.set(
      'links',
      htmlSafe(
        `<a href="javascript:;" onclick ="window.open('${controller
          .get('countryLinks')
          .toString()}','_system')">${controller.get('countryLinksTxt').toString()}</a>`
      )
    );
    controller.set(
      'countryNotes',
      this.get('i18n').t('ServiceRequest.CARDBLOCK.countryNotes.' + this.get('queries.countryName'), {
        inter_link: controller.get('links')
      })
    );
    let getval = controller.get('countryNotes').toString();
    let res = getval.split('<br>');
    let appendtext = '';

    for (let i = 0; i < res.length; i++) {
      appendtext += '<li>' + res[i] + '</li>';
    }
    appendtext = '<ul>' + appendtext + '</ul>';

    appendtext = htmlSafe(appendtext);
    controller.set('notemessages', appendtext);

    if (this.controller.get('reasonSelected') == null) {
      controller.set('reasonSelected', false);
      controller.set('enableNext', false);
    } else {
      controller.set('reasonSelected', true);
      controller.set('enableNext', true);
    }
    controller.set('getCountry', this.get('queries.countryName'));
    controller.set('checkValue', true);
    controller.set('isCreditCard', false);
    controller.set('isDebitCard', false);

    controller.set('cards', config.cards != 'credit' ? 'true' : '');

    if (
      (model.CreditCardDetails != undefined && model.CreditCardDetails.get('length') > 0) ||
      (model.DebitCardDetails != undefined && model.DebitCardDetails.get('length') > 0)
    ) {
      controller.set('dataAvailable', true);
    } else {
      controller.set('dataAvailable', false);
    }
    controller.set('errorPopUp', this.errorPopUp);
    controller.set('creditCardsDisplay', this.get('creditCardsDisplay'));
    controller.set('debitCardsDisplay', this.get('debitCardsDisplay'));

    if (!isEmpty(controller.get('cardData'))) {
      let selectedData = {
        id: controller.get('cardData')[0].selectedReasonId,
        value: controller.get('cardData')[0].selectedReason
      };
      controller.set('selectedFromAcc', selectedData);
    }
    controller.set('multiCards', this.get('creditCardsDisplay') && this.get('debitCardsDisplay') ? true : false);
    this.controllerFor('card-block.select').set('currentCreditCard', model.CreditCardDetails);
    this.controllerFor('card-block.select').set('currentDebitCard', model.DebitCardDetails);
  },

  actions: {
    displayCardDetails(account) {
      if (typeOf(account) != 'undefined') {
        account.value.charAt(0) == 'I'
          ? this.controller.set('charZeroI', true)
          : this.controller.set('charZeroI', false);
        if (account.value != 'Select Reason') {
          this.controller.set('reasonSelected', true);
        }
      }
      this.controller.set('selectedFromAcc', account);
    },
    enableNext() {
      if (
        (this.controller.get('model').CreditCardDetails != undefined &&
          this.controller.get('model').CreditCardDetails.filterBy('isSelected').length > 0) ||
        (this.controller.get('model').DebitCardDetails != undefined &&
          this.controller.get('model').DebitCardDetails.filterBy('isSelected').length > 0)
      ) {
        this.controller.set('enableNext', true);
      } else {
        this.controller.set('enableNext', false);
      }
    },
    goToBack() {
      this.transitionTo('serviceRequest.new-request');
    },

    navigateConfirm(model) {
      let creditCardDetails = null;
      let debitCardDetails = null;

      if (this.get('creditCardStatus') == 'CreditCardSuccess') {
        creditCardDetails = model.CreditCardDetails.filterBy('isSelected');
      } else {
        creditCardDetails = null;
      }

      if (this.get('debitCardStatus') == 'DebitCardSuccess') {
        debitCardDetails = model.DebitCardDetails.filterBy('isSelected');
      } else {
        debitCardDetails = null;
      }

      let pageData = [
        {
          selectedReason: this.controller.get('selectedFromAcc').value,
          selectedReasonId: this.controller.get('selectedFromAcc').id,
          selectedCard: creditCardDetails,
          selectedDebitCard: debitCardDetails,
          notes: this.controller.get('notemessages')
        }
      ];

      this.controllerFor('card-block.select').set('cardData', pageData);
      this.transitionTo('card-block.confirm');
    }
  }
});
