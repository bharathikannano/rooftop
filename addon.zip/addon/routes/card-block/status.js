import { htmlSafe } from '@ember/string';
import { typeOf } from '@ember/utils';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';

export default Route.extend({
  i18n: service(),
  store: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  customerInfo: service(),
  model: function() {
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
    let controller = this.controllerFor('card-block.confirm');
    this.controllerFor('card-block').set('leftIcon', '');
    this.set('resSuccessCount', 0);
    this.set('resFailureCount', 0);
    let cardDetails = controller.get('cardData'),
      cardResponseData = controller.get('cardResData');

    cardResponseData.forEach(item => {
      this.set('resRefNo', item.id);
      if (
        typeOf(item.data.responsePayload.initiateProcessResPayloadData) != 'undefined' &&
        typeOf(item.data.responsePayload.initiateProcessResPayloadData.processData) != 'undefined'
      ) {
        let responseServiceData =
          item.data.responsePayload.initiateProcessResPayloadData.processData.processdetails.serviceRequests
            .entityDetails.entityDetail;
        if (typeOf(responseServiceData) == 'object') {
          this.setCardStatus(responseServiceData, cardDetails);
        } else {
          responseServiceData.forEach(item => {
            this.setCardStatus(item, cardDetails);
          });
        }

        if (this.get('resSuccessCount') > 0 && this.get('resFailureCount') > 0) {
          this.set('resStatus', 'I');
        } else if (this.get('resSuccessCount') > 0 && this.get('resFailureCount') == 0) {
          this.set('resStatus', 'S');
        } else {
          this.set('resStatus', 'F');
        }
      } else {
        let creditCardData = cardDetails[0].selectedCard;
        let debitCardData = cardDetails[0].selectedDebitCard;

        if (creditCardData != null) {
          creditCardData.forEach(
            function(item) {
              item.set(
                'data.cardStatus',
                this.get('i18n')
                  .t('ServiceRequest.COMMON.progress.failure')
                  .toString()
              );
              item.data.statuscolor = 'bgcolor-red';
            }.bind(this)
          );
        }
        if (debitCardData != null) {
          debitCardData.forEach(
            function(item) {
              item.set(
                'data.cardStatus',
                this.get('i18n')
                  .t('ServiceRequest.COMMON.progress.failure')
                  .toString()
              );
              item.data.statuscolor = 'bgcolor-red';
            }.bind(this)
          );
        }
        this.set('resStatus', 'F');
      }
    });
    return cardDetails;
  },

  setCardStatus(serviceDetails, cardDetails) {
    let creditCardData = cardDetails[0].selectedCard;
    if (creditCardData != null) {
      for (let i = 0; i < creditCardData.length; i++) {
        if (creditCardData[i].data.cardNum == serviceDetails.entityType) {
          if (serviceDetails.status == 'Approved') {
            creditCardData[i].set(
              'data.cardStatus',
              this.get('i18n')
                .t('ServiceRequest.COMMON.progress.success')
                .toString()
            );
            creditCardData[i].data.statuscolor = 'bgcolor-green';
            this.set('resSuccessCount', this.get('resSuccessCount') + 1);
          } else {
            creditCardData[i].set(
              'data.cardStatus',
              this.get('i18n')
                .t('ServiceRequest.COMMON.progress.failure')
                .toString()
            );
            creditCardData[i].data.statuscolor = 'bgcolor-red';
            this.set('resFailureCount', this.get('resFailureCount') + 1);
          }
        }
      }
    }
    let debitCardData = cardDetails[0].selectedDebitCard;
    if (debitCardData != null) {
      for (let i = 0; i < debitCardData.length; i++) {
        if (debitCardData[i].data.cardNum == serviceDetails.entityType) {
          if (serviceDetails.status == 'Approved') {
            debitCardData[i].set(
              'data.cardStatus',
              this.get('i18n')
                .t('ServiceRequest.COMMON.progress.success')
                .toString()
            );
            debitCardData[i].data.statuscolor = 'bgcolor-green';
            this.set('resSuccessCount', this.get('resSuccessCount') + 1);
          } else {
            debitCardData[i].set(
              'data.cardStatus',
              this.get('i18n')
                .t('ServiceRequest.COMMON.progress.failure')
                .toString()
            );
            debitCardData[i].data.statuscolor = 'bgcolor-red';
            this.set('resFailureCount', this.get('resFailureCount') + 1);
          }
        }
      }
    }
  },

  setupController(controller, model) {
    this._super(controller, model);
    switch (this.get('resStatus')) {
      case 'S':
        controller.set('responseVal', 'success');
        controller.set('resClass', 'success-block-lg');
        break;
      case 'F':
        controller.set('responseVal', 'failure');
        controller.set('resClass', 'warning');
        break;
      case 'I':
        controller.set('responseVal', 'incomplete');
        controller.set('resClass', 'partialwarning');
        break;
    }
    controller.set(
      'contactLinks',
      this.get('i18n').t('ServiceRequest.COMMON.contactLinks.' + this.get('customerInfo.countryName'))
    );
    controller.set('contactLinksTxt', this.get('i18n').t('ServiceRequest.COMMON.contactLinksTxt.default'));
    controller.set(
      'contactUsLink',
      this.get('contactLinks') != ''
        ? htmlSafe(
            '<a href="javascript:;" onclick ="window.open(\'' +
              controller.get('contactLinks').toString() +
              "','_system')\">" +
              controller.get('contactLinksTxt').toString() +
              '</a>'
          )
        : htmlSafe('<a href="javascript:;">' + this.get('contactLinksTxt').toString() + '</a>')
    );
    controller.set('refNumber', this.get('resRefNo'));
    controller.set('resValTmp', this.get('i18n').t('ServiceRequest.COMMON.progress.' + controller.get('responseVal')));
    controller.set(
      'resContentTmp',
      this.get('i18n').t(
        'ServiceRequest.CARDBLOCK.statusMsg.' +
          this.get('customerInfo.countryName') +
          '.' +
          controller.get('responseVal'),
        {
          refNo: this.get('resRefNo'),
          contactUsLink: controller.get('contactUsLink'),
          default: 'ServiceRequest.CARDBLOCK.statusMsg.' + controller.get('responseVal')
        }
      )
    );
  },

  actions: {
    goToBack() {
      this.transitionTo('card-block.confirm');
    },
    navigateSatus() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
      this.controllerFor('card-block.select').set('cardData', '');
      this.transitionTo('serviceRequest.status');
    },
    enableNext(selectedData) {
      this.get('store').unloadAll('service-request');
      let selectedDebitCardData;
      let debitCardData = this.controllerFor('card-block.select').get('cardData')[0].selectedDebitCard;
      this.controllerFor('card-block.status').set('cardData', selectedData.cardItem.data);
      debitCardData.forEach((data, index) => {
        if (data.data.cardNum == selectedData.cardItem.data.cardNum) {
          selectedDebitCardData = debitCardData[index];
        }
      });
      debitCardData.removeAt(0, debitCardData.length);
      debitCardData[0] = selectedDebitCardData;
      this.transitionTo('debitcard-new-replacement.select-new-card', { queryParams: { replacement: 'cardBlock' } });
    }
  }
});
