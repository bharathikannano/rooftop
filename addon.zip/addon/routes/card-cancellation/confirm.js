import { set } from '@ember/object';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';
import { htmlSafe } from '@ember/string';

export default Route.extend({
  postDataForm: service('cardblock-replacement-save'),
  store: service(),
  error: service('card-error-handler'),
  i18n: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  confirmBtnDisable: false,
  model: function() {
    return this.get('store')
      .peekAll('credit-card')
      .filterBy('isSelected');
  },
  afterModel: function(data) {
    data.set(
      'notesText',
      this.get('i18n').t('ServiceRequest.CARDCANCELLATION.confirmationNotes.' + this.get('queries.countryName')).string
        ? this.get('i18n').t('ServiceRequest.CARDCANCELLATION.confirmationNotes.' + this.get('queries.countryName'))
        : this.get('i18n').t('ServiceRequest.CARDCANCELLATION.confirmationNotes.default')
    );
    if (this.get('queries.countryName') == 'SG') {
      data.set('contactUpdateNeeded', true);
      if (!this.get('queries.customerFlowFlag')) {
        data.set('hideEditContact', true);
      }
    }
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    if (
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'hk') ||
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'sg')
    ) {
      return controller.set('cardMasking', false);
    } else {
      return controller.set('cardMasking', true);
    }
  },
  actions: {
    error: error => {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      if (error.errors && error.errors[0].code == '1702') {
        document.location.href = config.backToiBankURL;
        return;
      }
      let message = htmlSafe(
        this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName')).string
          ? this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName')).string
          : this.get('i18n').t('ServiceRequest.COMMON.systemError').string
      );
      let title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          title,
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.transitionTo('serviceRequest.new-request');
        });
    },
    gotoBack() {
      this.transitionTo('card-cancellation.select');
      this.controllerFor('card-cancellation.select').set('backNavigation', true);
      this.transitionTo('card-cancellation.select').then(selectRoute => {
        set(selectRoute.currentModel, 'enableNext', true);
        set(selectRoute.currentModel, 'CreditCardDetails', this.currentModel.creditCardsList);
        set(selectRoute.currentModel, 'AccListt', this.currentModel.AccListt);
      });
    },
    navigateStatus(model) {
      set(this.currentModel, 'confirmBtnDisable', true);
      let selectedReason = model.selectedReason[0].id;
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      let ccRequest = [];
      model.selectedCards.forEach(function(item) {
        let pushData = {};
        pushData.cardNumber = item.get('card-num');
        pushData.currBlockCode = item.get('block-code');
        pushData.cardExpiryDate = item.get('exp-dt');
        pushData.cardVariant = item.get('variant');
        pushData.franchise = item.get('franchise');
        ccRequest.push(pushData);
      });
      let data = {
        payload: {
          creditCardCancel: {
            cancelReason: selectedReason,
            card: []
          }
        }
      };
      data.operationName = 'CCCANCEL';
      data.payload.creditCardCancel.card = ccRequest;
      let postData = this.get('store').createRecord('credit-card', data);
      postData.save().then(
        data => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          let postResData = data;
          this.controller.set('postData', postResData);
          this.controller.set('selectedCards', this.currentModel.selectedCards);
          this.controller.set('selectedReason', model.selectedReason[0]);
          this.transitionTo('card-cancellation.status');
        },
        error => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.send('error', error);
        }
      );
    },
    editContact() {
      let message = this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.updateAddress.confirmation.message');
      let title = this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.updateAddress.confirmation.title');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'info',
          message,
          title,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup card-cancellation-updatecontact'
        })
        .then(() => {
          document.location.href = config.dataLockerURL;
        });
    }
  }
});
