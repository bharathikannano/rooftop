import Route from '@ember/routing/route';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
export default Route.extend({
  store: service(),
  i18n: service(),
  model: function() {
    return hash({
      errorTitle: this.get('i18n').t('ServiceRequest.CARDCANCELLATION.noCardsHeading').string
    });
  },
  actions: {
    gotoBack() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
      this.controller.set('selectedReason', null);
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
