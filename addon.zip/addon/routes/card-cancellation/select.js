import EmberObject, { set } from '@ember/object';
import { typeOf } from '@ember/utils';
import { hash } from 'rsvp';
import { A } from '@ember/array';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from './../../config/environment';
import { htmlSafe } from '@ember/string';
//import { translationMacro as t } from "ember-i18n";
export default Route.extend({
  store: service(),
  queries: service('customer-info'),
  i18n: service(),
  error: service('card-error-handler'),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  mobileNumber: null,
  balTransferCheckNeeded: false,
  init() {
    this._super();
    this.set('reasonValues', {
      default: ['CCCRSN01', 'CCCRSN02', 'CCCRSN03', 'CCCRSN04', 'CCCRSN05', 'CCCRSN06', 'CCCRSN07'],
      SG: ['CCCRSN01', 'CCCRSN02', 'CCCRSN03', 'CCCRSN04', 'CCCRSN05', 'CCCRSN06']
    });
  },
  model() {
    // let CreditCardDetails;
    this.set('cards', config.cards != 'credit' ? 'true' : '');

    this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    let accountList = A();
    let reasonCountryList = this.get('reasonValues')[this.get('queries.countryName')]
      ? this.get('reasonValues')[this.get('queries.countryName')]
      : this.get('reasonValues')['default'];
    reasonCountryList.forEach(reasonCode => {
      accountList.push({
        value: this.get('i18n').t(
          'ServiceRequest.CARDCANCELLATION.selectreason.' + reasonCode + '.' + this.get('queries.countryName')
        ).string
          ? this.get('i18n').t(
              'ServiceRequest.CARDCANCELLATION.selectreason.' + reasonCode + '.' + this.get('queries.countryName')
            ).string
          : this.get('i18n').t('ServiceRequest.CARDCANCELLATION.selectreason.' + reasonCode + '.default').string,
        id: reasonCode
      });
    });

    this.get('rdcLoadingIndicator').hideLoadingIndicator();
    let showAccounts = false;
    if (this.controller && this.controller.backNavigation) {
      showAccounts = true;
      this.controllerFor('card-cancellation.select').set('backNavigation', false);
    } else {
      showAccounts = false;
      if (this.controller) this.controller.set('selectedReason', null);
    }

    return hash({
      AccListt: accountList,
      showAccounts: showAccounts,
      notesText: this.get('i18n').t('ServiceRequest.CARDCANCELLATION.countryNotes.' + this.get('queries.countryName'))
        .string
        ? this.get('i18n').t('ServiceRequest.CARDCANCELLATION.countryNotes.' + this.get('queries.countryName'))
        : this.get('i18n').t('ServiceRequest.CARDCANCELLATION.countryNotes.default')
    });
  },
  actions: {
    loading(transition) {
      transition.promise.finally(() => {
        this.controllerFor('serviceRequest').set('loaderInProgress', false);
      });
    },
    displayCardDetails(account) {
      this.set('currentModel.enableNext', false);
      if (typeOf(account) != 'undefined') {
        this.currentModel.AccListt.forEach(function(reasonVal) {
          if (reasonVal.id != account.id) {
            reasonVal.isSelected = false;
          }
        });
        this.controller.set('selectedReason', account);
        account.isSelected = true;
        let reasonSelected = this.controller.get('selectedReason.id');
        this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
        this.get('rdcLoadingIndicator').setThemeClass('ui10');
        this.get('store')
          .query('credit-card', {
            filter: {
              operationName: 'CCCANCEL',
              reasonCode: reasonSelected
            }

            // config.Filters.cardCancellation[this.get('queries.countryName')]
          })
          .then(
            data => {
              let cardDetailsObj = A();
              let hideSection, validCardChecker;
              data.forEach(CardDetails => {
                this.set('mobileNumber', CardDetails.get('mobileNumber'));
                if (CardDetails.get('alerts') && CardDetails.get('alerts').length) {
                  this.transitionTo('card-cancellation.error-handler').then(errorRoute => {
                    errorRoute.currentModel.alertMessage = CardDetails.get('alerts');
                  });
                } else {
                  if (CardDetails.get('eligibleCreditCards') && CardDetails.get('eligibleCreditCards').length) {
                    if (CardDetails.get('activeBalTransferAccFlag') == 'Y') {
                      let inEligibleCardPresent = false;
                      CardDetails.get('eligibleCreditCards').filter(function(element) {
                        if (element.alerts && element.alerts.length >= 1) inEligibleCardPresent = true;
                      });
                      if (!inEligibleCardPresent) this.set('balTransferCheckNeeded', true);
                    }
                    CardDetails.get('eligibleCreditCards').forEach(function(element) {
                      element = EmberObject.create(element);
                      if (
                        !element.get('is-giro') &&
                        !element.get('is-suppliment-card') &&
                        !element.get('is-easy-acnt-status')
                      ) {
                        element.set('showSection', false);
                      } else {
                        element.set('showSection', true);
                      }
                      element.set('checked', false);

                      cardDetailsObj.push(element);

                      validCardChecker = CardDetails.get('eligibleCreditCards').filter(function(element) {
                        if (!element.alerts || element.alerts.length < 1) return element;
                      });
                    });
                  } else {
                    this.transitionTo('card-cancellation.error-handler').then(errorRoute => {
                      errorRoute.currentModel.errorTitle = this.get('i18n').t(
                        'ServiceRequest.CARDCANCELLATION.noCardsHeading'
                      ).string;
                      errorRoute.currentModel.errorSubject = this.get('i18n').t(
                        'ServiceRequest.CARDCANCELLATION.noCardsMessage'
                      ).string;
                    });
                  }
                }
              });
              if (this.get('queries.countryName') == 'AE') {
                hideSection = true;
              } else {
                hideSection = false;
              }
              this.set('currentModel.hideSection', hideSection);
              this.set('currentModel.CreditCardDetails', cardDetailsObj);
              if (validCardChecker && validCardChecker.length < 1) {
                this.set('currentModel.CreditCardDetails.selectAllDisable', true);
              }
              this.set('currentModel.CreditCardDetails.selectAll', true);
              this.set('currentModel.showAccounts', true);
              this.get('rdcLoadingIndicator').hideLoadingIndicator();
            },
            error => {
              this.send('error', error);
            }
          );
      }
      this.controller.set('selectedReason', account);

      return account;
    },
    error: error => {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      if (error.errors && error.errors[0].code == '1702') {
        document.location.href = config.backToiBankURL;
        return;
      }
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      let message = htmlSafe(
        this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName')).string
          ? this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName')).string
          : this.get('i18n').t('ServiceRequest.COMMON.systemError').string
      );
      let title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          title,
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.transitionTo('serviceRequest.new-request');
        });
    },
    enableNext() {
      if (this.get('currentModel').CreditCardDetails.filterBy('checked').length > 0) {
        this.set('currentModel.enableNext', true);
      } else {
        this.set('currentModel.enableNext', false);
      }
    },
    gotoBack() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
      this.controller.set('selectedReason', null);
      //this.controller = null;
      this.transitionTo('serviceRequest.new-request');
    },

    navigateConfirm() {
      if (
        this.get('balTransferCheckNeeded') &&
        this.get('currentModel').CreditCardDetails.filterBy('checked').length ==
          this.get('currentModel').CreditCardDetails.length
      ) {
        let message = this.get('i18n').t('ServiceRequest.CARDCANCELLATION.balanceTransferErrorMessage');
        this.get('rdcModalManager').showDialogModal({
          level: 'warning',
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.CARDCANCELLATION.balanceTransferButtonLabel'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        });
      } else {
        let selectedReason = this.get('currentModel.AccListt').filterBy('isSelected');
        let selectedCards = this.get('currentModel').CreditCardDetails.filterBy('checked');
        let creditCardsList = this.get('currentModel').CreditCardDetails;
        let mobileNumber = this.get('mobileNumber');
        let accListt = this.get('currentModel').AccListt;
        this.transitionTo('card-cancellation.confirm').then(confirmRoute => {
          selectedReason.forEach(reason => {
            let selectedReasonConfirmText = this.get('i18n').t(
              'ServiceRequest.CARDCANCELLATION.confirmReason.' + reason.id + '.' + this.get('queries.countryName')
            ).string
              ? this.get('i18n').t(
                  'ServiceRequest.CARDCANCELLATION.confirmReason.' + reason.id + '.' + this.get('queries.countryName')
                ).string
              : this.get('i18n').t('ServiceRequest.CARDCANCELLATION.confirmReason.' + reason.id + '.default').string;
            set(reason, 'value', selectedReasonConfirmText);
          });
          confirmRoute.currentModel.set('selectedReason', selectedReason);
          confirmRoute.currentModel.set('selectedCards', selectedCards);
          confirmRoute.currentModel.set('creditCardsList', creditCardsList);
          confirmRoute.currentModel.set('AccListt', accListt);
          confirmRoute.currentModel.set('mobileNumber', mobileNumber);
        });
      }
    }
  }
});
