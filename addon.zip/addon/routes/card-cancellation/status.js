import { typeOf } from '@ember/utils';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { htmlSafe } from '@ember/string';

export default Route.extend({
  i18n: service(),
  store: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),

  model: function() {
    this.set('resSuccessCount', 0);
    this.set('resFailureCount', 0);
    return hash({
      selectedCards: this.controllerFor('card-cancellation.confirm').get('selectedCards'),
      postData: this.controllerFor('card-cancellation.confirm').get('postData'),
      selectedReason: this.controllerFor('card-cancellation.confirm').get('selectedReason')
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    if (
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'hk') ||
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'sg')
    ) {
      return controller.set('cardMasking', false);
    } else {
      return controller.set('cardMasking', true);
    }
  },
  afterModel(data) {
    this.controllerFor('card-cancellation').set('leftIcon', '');
    let confirmationText = this.get('i18n').t('ServiceRequest.CARDCANCELLATION.statusMsg.submitted.bankCallBack');

    this.set('resRefNo', data.postData.data.serviceRequest['receipt-id']);
    if (
      typeOf(data.postData.data.serviceRequest['response-payload'].initiateProcessResPayloadData) != 'undefined' &&
      typeOf(data.postData.data.serviceRequest['response-payload'].initiateProcessResPayloadData.processData) !=
        'undefined'
    ) {
      let responseServiceData =
        data.postData.data.serviceRequest['response-payload'].initiateProcessResPayloadData.processData.processdetails
          .serviceRequests.entityDetails.entityDetail;
      if (typeOf(responseServiceData) == 'object') {
        this.setCardStatus(responseServiceData, data.selectedCards);
      } else {
        responseServiceData.forEach(item => {
          this.setCardStatus(item, data.selectedCards);
        });
      }

      if (this.get('resSuccessCount') > 0 && this.get('resFailureCount') > 0) {
        this.set('resStatus', 'I');
      } else if (this.get('resSuccessCount') > 0 && this.get('resFailureCount') == 0) {
        this.set('resStatus', 'S');
      } else {
        this.set('resStatus', 'F');
      }
    } else {
      if (data.selectedCards != null) {
        if (this.get('queries.countryName') == 'AE') {
          /*Setting confirmation message text */
          data.selectedCards.forEach(item => {
            let blockCode = item.get('block-code');
            if (blockCode == 'SP' || blockCode == 'SB' || blockCode == 'FE' || blockCode == 'FC') {
              confirmationText = this.get('i18n').t(
                'ServiceRequest.CARDCANCELLATION.statusMsg.submitted.bankNoCallBack'
              );
            }
            item.cardStatus = this.get('i18n').t('ServiceRequest.COMMON.progress.submitted');
            item.statuscolor = 'bgcolor-green';
          });
          if (data.selectedReason.id == 'CCCRSN06') {
            confirmationText = this.get('i18n').t('ServiceRequest.CARDCANCELLATION.statusMsg.submitted.bankNoCallBack');
          }
          this.set('resStatus', 'SB');
        } else {
          data.selectedCards.forEach(
            function(item) {
              item.cardStatus = this.get('i18n').t('ServiceRequest.COMMON.progress.failure');
              item.statuscolor = 'bgcolor-red';
            }.bind(this)
          );
          this.set('resStatus', 'F');
        }
      }
    }
    switch (this.get('resStatus')) {
      case 'S':
        data.responseVal = 'success';
        data.resClass = 'success-block-lg';
        break;
      case 'SB':
        data.responseVal = 'submitted';
        data.resClass = 'success-block-lg';
        break;
      case 'F':
        data.responseVal = 'failure';
        data.resClass = 'warning';
        break;
      case 'I':
        data.responseVal = 'incomplete';
        data.resClass = 'partialwarning';
        break;
    }
    data.resValTmp = this.get('i18n').t('ServiceRequest.COMMON.progress.' + data.responseVal);
    if (this.get('resStatus') == 'SB') {
      data.resContentTmp = confirmationText;
    } else {
      data.resContentTmp = htmlSafe(
        this.get('i18n').t(
          'ServiceRequest.CARDCANCELLATION.statusMsg.' + data.responseVal + '.' + this.get('queries.countryName')
        ).string
          ? this.get('i18n').t(
              'ServiceRequest.CARDCANCELLATION.statusMsg.' + data.responseVal + '.' + this.get('queries.countryName')
            )
          : this.get('i18n').t('ServiceRequest.CARDCANCELLATION.statusMsg.' + data.responseVal + '.default')
      );
    }
  },
  setCardStatus(serviceDetails, cardDetails) {
    if (cardDetails != null) {
      // console.log('set card sattus');
      // console.log(cardDetails);
      cardDetails.forEach(cards => {
        if (cards['card-num'] == serviceDetails.entityType) {
          if (serviceDetails.status == 'Approved') {
            cards.cardStatus = 'Success';
            cards.statuscolor = 'bgcolor-green';
            this.set('resSuccessCount', this.get('resSuccessCount') + 1);
          } else {
            cards.cardStatus = 'Failed';
            cards.statuscolor = 'bgcolor-red';
            this.set('resFailureCount', this.get('resFailureCount') + 1);
          }
        }
      });
      // for (var i = 0; i < cardDetails.length; i++) {
      //     if (cardDetails[i].data["card-num"] == serviceDetails.EntityType) {
      //         if (serviceDetails.Status == "Approved") {
      //             cardDetails[i].data.cardStatus = "Success";
      //             cardDetails[i].data.statuscolor = "bgcolor-green";
      //             this.set('resSuccessCount', this.get('resSuccessCount') + 1);
      //         } else {
      //             cardDetails[i].data.cardStatus = "Failed";
      //             cardDetails[i].data.statuscolor = "bgcolor-red";
      //             this.set('resFailureCount', this.get('resFailureCount') + 1);
      //         }
      //     }
      // }
    }
  },
  actions: {
    gotoStatus() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
      this.transitionTo('serviceRequest.status');
    }
  }
});
