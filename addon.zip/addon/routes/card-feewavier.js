import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../config/environment';
import { htmlSafe } from '@ember/string';

export default Route.extend({
  i18n: service(),
  rdcModalManager: service(),
  store: service(),
  loaderInProgress: false,
  queries: service('customer-info'),

  setupController() {
    this.controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
  },

  actions: {
    closePopupAction() {
      this.controllerFor('cardFeewavier').set('cancelPopup', true);
      let message;
      if (!this.get('queries.customerFlowFlag')) {
        message = htmlSafe(this.get('i18n').t('ServiceRequest.COMMON.closeWindowText'));
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup frontline-close-alert'
          })
          .then(() => {
            if (!this.get('queries.customerFlowFlag')) {
              this.controllerFor('cardFeewavier').set('cancelPopup', false);
            } else {
              document.location.href = config.backToiBankURL;
              this.controllerFor('cardFeewavier').set('cancelPopup', false);
            }
          })
          .catch(() => {
            this.controllerFor('cardFeewavier').set('cancelPopup', false);
          });
      } else {
        message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message,
            rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          })
          .then(() => {
            if (!this.get('queries.customerFlowFlag')) {
              this.controllerFor('cardFeewavier').set('cancelPopup', false);
            } else {
              document.location.href = config.backToiBankURL;
              this.controllerFor('cardFeewavier').set('cancelPopup', false);
            }
          })
          .catch(() => {
            this.controllerFor('cardFeewavier').set('cancelPopup', false);
          });
      }
    }
  }
});
