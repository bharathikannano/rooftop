import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),

  model: function() {
    return this.controllerFor('card-feewavier.card-validation').get('jsonRes');
  },
  actions: {
    close() {
      this.get('store').unloadAll('credit-card');
      this.controllerFor('card-feewavier.new-request').set('rev', true);
      this.controllerFor('card-feewavier.new-request').set('charge', false);
      this.controllerFor('card-feewavier.new-request').set('otherFee', false);
      this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
      this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
      this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
      this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
      this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
      this.controllerFor('card-feewavier.new-request').set('rewardData', false);
      this.controllerFor('card-feewavier.new-request').set('enableNext', false);
      this.controllerFor('card-feewavier.card-validation').set('override', false);
      this.controllerFor('card-feewavier.card-validation').set('enableForOverRide', false);
      this.controllerFor('card-feewavier.card-validation').set('enableNextButton', false);
      this.controllerFor('card-feewavier.card-validation').set('selectedReason', '');
      this.set('selectedReasonOverRide', '');
      this.transitionTo('serviceRequest.new-request');
    },
    goToBack() {
      this.get('store').unloadAll('credit-card');
      this.controllerFor('card-feewavier.new-request').set('rev', true);
      this.controllerFor('card-feewavier.new-request').set('charge', false);
      this.controllerFor('card-feewavier.new-request').set('otherFee', false);
      this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
      this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
      this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
      this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
      this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
      this.controllerFor('card-feewavier.new-request').set('rewardData', false);
      this.controllerFor('card-feewavier.new-request').set('enableNext', false);
      this.transitionTo('serviceRequest.new-request');
    },
    radioOverRideAction() {
      if (!this.controllerFor('card-feewavier.card-validation').get('override')) {
        this.controllerFor('card-feewavier.card-validation').set('override', true);
        this.controllerFor('card-feewavier.card-validation').set('enableForOverRide', true);
        this.send('mandatoryCheck');
      } else {
        this.controllerFor('card-feewavier.card-validation').set('override', false);
        this.controllerFor('card-feewavier.card-validation').set('enableForOverRide', false);
        this.send('mandatoryCheck');
      }
    },

    navigateConfirm(model) {
      let pageData = [
        {
          cardSelectedDetails: this.controllerFor('card-feewavier.card-validation').get('jsonRes')[0]
            .cardSelectedDetails,
          selectedData: true,
          rewardFlag: false,
          override: true,
          reasonSelected: this.get('selectedReasonOverRide') ? this.get('selectedReasonOverRide').value : null,
          reversalcharge: this.controllerFor('card-feewavier.card-validation').get('jsonRes')[0].reversalcharge,
          notes: model.notesText,
          commonData: this.controllerFor('card-feewavier.card-validation').get('jsonRes'),
          userGroup: this.controllerFor('card-feewavier.card-validation').get('jsonRes')[0].userGroup,
          selectedAddVerification: this.controllerFor('card-feewavier.card-validation').get('jsonRes')[0]
            .selectedAddVerification,
          selectedBasicVerification: this.controllerFor('card-feewavier.card-validation').get('jsonRes')[0]
            .selectedBasicVerification,
          feeTypeName: this.controllerFor('card-feewavier.card-validation').get('jsonRes')[0].feeTypeName,
          feeTypeID: this.controllerFor('card-feewavier.card-validation').get('jsonRes')[0].feeTypeID,
          indicatorFlag: this.controllerFor('card-feewavier.card-validation').get('jsonRes')[0].indicatorFlag,
          countryCode: this.controllerFor('card-feewavier.card-validation').get('jsonRes')[0].countryCode
        }
      ];

      this.controllerFor('card-feewavier.cards-point').set('jsonRes', pageData);
      this.transitionTo('card-feewavier.cards-point');
    },
    mandatoryCheck() {
      let selectedReason = false;
      let checkBoxChecked = false;

      if (this.get('selectedReasonOverRide')) {
        selectedReason = true;
      }

      if (this.controllerFor('card-feewavier.card-validation').get('override')) {
        checkBoxChecked = true;
      }

      if (selectedReason && checkBoxChecked) {
        this.controllerFor('card-feewavier.card-validation').set('enableNextButton', true);
      } else {
        this.controllerFor('card-feewavier.card-validation').set('enableNextButton', false);
      }
    },
    selectedReasonOverRide(reason) {
      this.set('selectedReasonOverRide', reason);
      this.send('mandatoryCheck');
    }
  },
  setupController(controller, model) {
    later(() => {
      document.getElementById('ccf-focus-id').scrollIntoView();
    }, 5);
    this._super(controller, model);

    /* transition login for notes */
    this._super(controller, model);
    /* transition login for notes */
    let countryCode = this.get('queries.countryName');
    controller.set('isNotASA_AE', ['AE', 'BN', 'NP', 'LK'].indexOf(countryCode) === -1);

    controller.set(
      'countryLinks',
      this.get('i18n').t('ServiceRequest.CCFEEWAVIER.countryLinks.' + this.get('queries.countryName'))
    );
    controller.set(
      'countryLinksTxt',
      this.get('i18n').t('ServiceRequest.CCFEEWAVIER.countryLinksTxt.' + this.get('queries.countryName'))
    );
    controller.set('links', controller.get('countryLinksTxt').toString());
    controller.set(
      'countryNotes',
      this.get('i18n').t('ServiceRequest.CCFEEWAVIER.validationCountryNotes.' + this.get('queries.countryName'), {
        inter_link: controller.get('links')
      })
    );
    let getval = controller.get('countryNotes').toString();
    let res = getval.split('<br>');
    let appendtext = '';

    for (let i = 0; i < res.length; i++) {
      appendtext += '<li>' + res[i] + '</li>';
    }
    appendtext = htmlSafe('<ul>' + appendtext + '</ul>');
    controller.set('notemessages', appendtext);
  }
});
