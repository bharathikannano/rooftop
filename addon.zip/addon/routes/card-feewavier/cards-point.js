import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  model: function() {
    return this.controllerFor('card-feewavier.cards-point').get('jsonRes');
  },

  actions: {
    goToBack() {
      if (this.controllerFor('card-feewavier.cards-point').get('jsonRes')[0].override) {
        this.controllerFor('card-feewavier.card-validation').set(
          'jsonRes',
          this.controllerFor('card-feewavier.cards-point').get('jsonRes')[0].commonData
        );
        this.transitionTo('card-feewavier.card-validation');
      } else {
        this.get('store').unloadAll('credit-card');
        this.controllerFor('card-feewavier.new-request').set('rev', true);
        this.controllerFor('card-feewavier.new-request').set('charge', false);
        this.controllerFor('card-feewavier.new-request').set('otherFee', false);
        this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
        this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
        this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
        this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
        this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
        this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
        this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
        this.controllerFor('card-feewavier.new-request').set('rewardData', false);
        this.controllerFor('card-feewavier.new-request').set('enableNext', false);
        this.controllerFor('card-feewavier.cards-point').set('enableNextButton', false);
        if (!this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') === 'SG') {
          this.transitionTo('card-feewavier.new-request', { queryParams: { channel: 'IBK' } });
        } else if (!this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') === 'MY') {
          this.transitionTo('card-feewavier.new-request', { queryParams: { channel: 'IBK' } });
        } else {
          this.transitionTo('card-feewavier.new-request');
        }
        this.set('reasonSel', '');
      }
    },
    enableNextButton(param) {
      if (param) {
        this.set('param', param);
        this.send('mandatoryVal');
      } else {
        this.set('param', param);
        this.controllerFor('card-feewavier.cards-point').set('enableNextButton', false);
      }
    },
    reasonSel(reasonSel) {
      this.model()[0].reasonSelected = reasonSel;
      this.set('reasonSel', reasonSel.value);
      this.send('mandatoryVal');
    },

    tooltipOpacityFlag(errorFlag) {
      this.controllerFor('card-feewavier').set('tooltipOpacityFlag', errorFlag);
    },
    mandatoryVal() {
      let overrideCheck = this.context[0].override;
      let reasonFlag = false;
      let selectedTransacVal = false;
      let fronline = this.controllerFor('card-feewavier.cards-point').get('jsonRes')[0].customerFlowFlag ? true : false;

      if (!overrideCheck && !fronline) {
        if (this.get('reasonSel') && this.get('reasonSel') != '') {
          reasonFlag = true;
        } else {
          reasonFlag = false;
        }
      } else {
        reasonFlag = true;
      }

      if (this.get('param')) {
        selectedTransacVal = true;
      } else {
        selectedTransacVal = false;
      }

      if (reasonFlag && selectedTransacVal) {
        this.controllerFor('card-feewavier.cards-point').set('enableNextButton', true);
      } else {
        this.controllerFor('card-feewavier.cards-point').set('enableNextButton', false);
      }
    },

    navigateConfirm(model) {
      let selectedCardData = [];
      let rewardFlag = false;
      let totalRewardPoints = 0;
      let rewardRemaining = 0;
      let me = this;
      let customerFlowFlag;
      let indicatorFlag;
      let overrideLimitAmtFlag = false;

      model.forEach(itemVal => {
        let rewardAmt = 0;
        itemVal.cardSelectedDetails.forEach(selectedCardDetail => {
          let selectedTransData = [];
          selectedCardDetail.get('cardtransactions').forEach(selectedValue => {
            if (selectedValue.get('transactionSelected')) {
              selectedTransData.push(selectedValue);
            }
          });

          if (
            this.controllerFor('card-feewavier').staffAssist &&
            me.get('queries.countryName') == 'MY' &&
            selectedTransData.length > 0
          ) {
            selectedTransData = [];
            selectedCardDetail.get('cardtransactions').forEach(selectedValue => {
              if (selectedValue.get('transactionSelected') || selectedValue.get('isDiscountTransaction') == 'Y') {
                selectedTransData.push(selectedValue);
              }
            });
          }
          /*reward point calculation.*/
          selectedTransData.forEach(rewardPointObj => {
            if (rewardPointObj.data.equivalentRewardPoints) {
              rewardAmt = parseFloat(rewardAmt) + parseFloat(rewardPointObj.data.equivalentRewardPoints.rewardsPoints);
            }

            if (rewardPointObj.data.transactionAmount < rewardPointObj.data.transacOrgnAmount) {
              overrideLimitAmtFlag = true;
            }
          });

          selectedCardDetail.set('data.overrideLimitAmtFlag', overrideLimitAmtFlag);

          let cardData = {
            cardNumber: selectedCardDetail.get('cardNum'),
            cardDesc: selectedCardDetail.get('desc'),
            cardType: selectedCardDetail.get('cardType'),
            currencyCode: selectedCardDetail.get('currencyCode'),
            blockCode: selectedCardDetail.get('blockCode'),
            availableCustomerRewardpoint: selectedCardDetail.get('availableCustomerRewardpoint'),
            eligibleFlag: selectedCardDetail.get('eligibleFeeWaiver'),
            rewardPointRedepmtion:
              (me.controllerFor('card-feewavier.cards-point').get('jsonRes')[0].override &&
                me.controllerFor('card-feewavier.cards-point').get('jsonRes')[0].override) ||
              !me.controllerFor('card-feewavier.cards-point').get('jsonRes')[0].rewardFlag
                ? 'N'
                : 'Y',
            overRideFlag:
              (me.controllerFor('card-feewavier.cards-point').get('jsonRes')[0].override &&
                me.controllerFor('card-feewavier.cards-point').get('jsonRes')[0].override) ||
              selectedCardDetail.get('data.overrideLimitAmtFlag')
                ? 'Y'
                : '',
            selectedTransDetails: selectedTransData,
            primaryFlag: selectedCardDetail.get('primaryFlag'),
            maskFlag: selectedCardDetail.get('isMaskCardNo'),
            cardRewardCategory: selectedCardDetail.get('cardRewardCategory'),
            cardGroupableFeeTypes: selectedCardDetail.get('cardGroupableFeeTypes'),
            historicalTxnCount: selectedCardDetail.get('historicalTxnCount'),
            displayTransactionFlag: selectedCardDetail.get('displayTransactionFlag'),
            grpAccNum: selectedCardDetail.get('grpAccNum')
          };
          if (selectedTransData.length > 0) {
            selectedCardData.push(cardData);
          }
        });
        customerFlowFlag = itemVal.customerFlowFlag;
        rewardFlag = itemVal.rewardFlag;
        totalRewardPoints = itemVal.totalRewardPoints;
        indicatorFlag = itemVal.indicatorFlag;

        rewardRemaining = parseFloat(totalRewardPoints) - parseFloat(rewardAmt);
      });

      let pageData = [
        {
          customerFlowFlag: customerFlowFlag,
          selectedCardData: selectedCardData,
          rewardFlag: rewardFlag,
          rewardRemaining: rewardRemaining,
          charge: false,
          reasonSelected: !model[0].override ? me.get('reasonSel') : model[0].reasonSelected,
          postingData: this.controllerFor('card-feewavier.cards-point').get('jsonRes'),
          requestType: this.controllerFor('card-feewavier.cards-point').get('jsonRes')[0].reversalcharge,
          notes: !model[0].override ? model[0].cardSelectedDetails.notesText : model[0].notes,
          indicatorFlag: indicatorFlag,
          countryCode: this.controllerFor('card-feewavier.cards-point').get('jsonRes')[0].countryCode
        }
      ];
      this.controllerFor('card-feewavier.selected-card').set('cardCredit', pageData);
      this.transitionTo('card-feewavier.selected-card');
    }
  },
  setupController(controller, model) {
    //Non Staff Assist
    controller.setProperties({
      nonStaffAssist: this.controllerFor('card-feewavier').get('staffAssist')
    });

    later(() => {
      document.getElementById('ccf-focus-id').scrollIntoView();
    }, 5);
    this._super(controller, model);
    /* transition login for notes */
    controller.setProperties({
      countryNotesTransactionPage: this.get('i18n').t('ServiceRequest.CCFEEWAVIER.countryNotesTransactionPage.' + this.get('queries.countryName'))
    });
    let getval = controller.get('countryNotesTransactionPage').toString();
    let res = getval.split('<br>');
    let appendtext = '';

    for (let i = 0; i < res.length; i++) {
      appendtext += '<li>' + res[i] + '</li>';
    }
    appendtext = htmlSafe('<ul>' + appendtext + '</ul>');
    controller.set('notemessages', appendtext);
  }
});
