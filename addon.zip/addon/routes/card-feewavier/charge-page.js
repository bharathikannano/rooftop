import { htmlSafe } from '@ember/string';
import { set } from '@ember/object';
import $ from 'jquery';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  rdcLoadingIndicator: service(),
  beforeModel() {
    this.set('reasonSel', '');
    this.controllerFor('serviceRequest.new-request').set('loaderInProgress', true);
  },
  model() {
    let CreditCardDetails, creditCardStoreData;
    if (this.controller && this.controllerFor('card-feewavier.charge-page')) {
      creditCardStoreData = this.controllerFor('card-feewavier.charge-page').get('creditCardDetails');
    }
    let primaryFlagIndicator = false;
    let maskFlag = false;

    if (!creditCardStoreData || creditCardStoreData.content.length == 0) {
      CreditCardDetails = this.get('store')
        .query('credit-card', {
          filter: {
            activeCards: 'Yes',
            srName: 'CCFEEW'
          }
        })
        .then(
          CreditCardDetails => {
            this.controllerFor('card-feewavier.charge-page').set('creditCardDetails', CreditCardDetails);
            CreditCardDetails.forEach(element => {
              if (element.get('primaryFlag') == 'Y') {
                primaryFlagIndicator = true;
              } else {
                primaryFlagIndicator = false;
              }

              if (element.get('isMaskCardNo') == 'Y') {
                maskFlag = true;
              } else {
                maskFlag = false;
              }
              element.set('checked', false);
              element.set('primaryFlag', primaryFlagIndicator);
              element.set('isMaskCardNo', maskFlag);
            });
            CreditCardDetails.set('nextBtnEnabled', false);
            CreditCardDetails.set(
              'indicatorFlag',
              this.get('queries.countryName') == 'IN' || this.get('queries.countryName') == 'MY' ? true : false
            );
            CreditCardDetails.set('countryCode', this.get('queries.countryName'));
            return CreditCardDetails;
          },
          error => {
            this.send('error', error);
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(CreditCardDetails, ' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
    } else {
      creditCardStoreData.content.length > 0 ? (CreditCardDetails = creditCardStoreData) : (CreditCardDetails = null);
    }
    if (this.get('queries.countryName') == 'SG') {
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE_BASIC',
            value: 'CC Annual Fee (Basic)'
          },
          {
            id: 'ANNUAL_FEE_SUPP',
            value: 'CC Annual Fee (Supp)'
          },
          {
            id: 'LATE_PAYMENT',
            value: 'Late Charge'
          },
          {
            id: 'Other Fee',
            value: 'Other Fee'
          }
        ],
        otherFeeList: [
          {
            id: 'ADMIN_FEE',
            value: 'Admin fee for funds transfer and easypay'
          },
          {
            id: 'CASH_ADV_NON_STMT',
            value: 'Cash Advance Fee - Non Statemented Transaction'
          },
          {
            id: 'CASH_ADV_STMT',
            value: 'Cash Advance Fee - Statemented Transaction'
          },
          {
            id: 'CHQ_RETRN',
            value: 'Cheque Return Fee'
          },
          {
            id: 'DEBIT_INT',
            value: 'Dr and Accrued interest'
          },
          {
            id: 'GIRO_RETRN',
            value: 'Giro Return Fee'
          },
          {
            id: 'OVER_LIMIT',
            value: 'Overlimit fee'
          },
          {
            id: 'SALES_COPY',
            value: 'Sales copy fee'
          },
          {
            id: 'STMT_REQ',
            value: 'Statement request fee'
          },
          {
            id: 'UPFRONT_REWARD',
            value: 'Upfront Reward Penalty'
          },
          {
            id: 'GST',
            value: 'GST(on annual fee)'
          }
        ],

        ChargesReasonList: [
          {
            id: 'Bank Error',
            value: 'Bank Error'
          },
          {
            id: 'Adjustment',
            value: 'Adjustment'
          }
        ],
        CreditCardDetails: CreditCardDetails
      });
    }
    if (this.get('queries.countryName') == 'IN') {
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE',
            value: 'Annual fee Reversal'
          },
          {
            id: 'LATE_PAYMENT',
            value: 'Late Payment Charge'
          },
          {
            id: 'OVER_LIMIT',
            value: 'Over Limit Fee'
          },
          {
            id: 'INTEREST',
            value: 'Interest'
          },
          {
            id: 'Other Fee',
            value: 'Other Fee'
          }
        ],

        otherFeeList: [
          {
            id: 'JOING_FEE',
            value: 'Joining Fee waiver'
          },
          {
            id: 'PIN_REPLACEMENT',
            value: 'PIN Replacement Fee'
          },
          {
            id: 'CARD_ REPLACEMENT',
            value: 'Card Replacement Fee'
          },
          {
            id: 'CHQ_RETRN',
            value: 'Cheque Return Fee'
          },
          {
            id: 'OUTSTATION_TELE_DRAFT',
            value: 'Outstation Teledraft Charges'
          },
          {
            id: 'OUTSTATION_CHQ',
            value: 'Outstation Cheque Fee'
          },
          {
            id: 'BT_PROCESS',
            value: 'BT Processing Fee'
          },
          {
            id: 'TELEDRAFT_CANCEL',
            value: 'Teledraft Cancellation Charges'
          },
          {
            id: 'CHARGE_SLIP_RETRV',
            value: 'Chargeslip retrieval fee'
          },
          {
            id: 'PRC_PREMIUM',
            value: 'PRC Premium Reversals'
          },
          {
            id: 'STMT_RETRV',
            value: 'Statement Retrieval Fee'
          },
          {
            id: 'SURCHARG_REV',
            value: 'Surcharge Reversal'
          },
          {
            id: 'BT_ACC_SETUP',
            value: 'BT Account Set Up Fee'
          },
          {
            id: 'DIAL_PROCESS',
            value: 'DAL Processing Fee'
          },
          {
            id: 'ONE_TIME_CARD',
            value: 'One Time Card Set Fee'
          },
          {
            id: 'CASH_ADVANCE',
            value: 'Cash Advance Fee'
          },
          {
            id: 'CHQ_PICK_UP',
            value: 'Cheque Pick up fee'
          },
          {
            id: 'PAYEASY_PRE_CLOSURE',
            value: 'PRECLOSURE FEE REVSD'
          },
          {
            id: 'REDEMPTION',
            value: 'Redemption Fee Reversal'
          },
          {
            id: 'CASH_REPAY_FEE',
            value: 'Cash Repayment Fee'
          }
        ],
        ChargesReasonList: [
          {
            id: 'Bank Error',
            value: 'Bank Error'
          },
          {
            id: 'Adjustment',
            value: 'Adjustment'
          }
        ],
        CreditCardDetails: CreditCardDetails
      });
    }
    if (this.get('queries.countryName') == 'MY') {
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE',
            value: 'Annual/Monthly Fee'
          },
          {
            id: 'CASH_ADVANCE',
            value: 'Cash Advance'
          },
          {
            id: 'CASH_INTEREST',
            value: 'Cash Interest'
          },
          {
            id: 'CASHBACK',
            value: 'Cashback'
          },
          {
            id: 'GIFT_REDIRECT_CHRG',
            value: 'Courier Charge For Gift Redirection'
          },
          {
            id: 'EARLY_REDMP_INSTL_P',
            value: 'Early Redemption Fee For Installment Plan'
          },
          {
            id: 'LATE_CHARGE',
            value: 'Late Charge'
          },
          {
            id: 'MULTI_CURRENCY_DIFF',
            value: 'Multi Currency Differs'
          },
          {
            id: 'OVERLIMIT_FEE',
            value: 'Overlimit Fee'
          },
          {
            id: 'PRIORITY_PASS_FEE',
            value: 'Priority Pass Fee'
          },
          {
            id: 'RETAIL_INTEREST',
            value: 'Retail Interest'
          },
          {
            id: 'SALES_DRF_RETRIEVAL',
            value: 'Sales Draft Retrivel Fee'
          },
          {
            id: 'STMT_REQUEST_FEE',
            value: 'Statement Request Fee'
          }
        ],

        ChargesReasonList: [{ id: 'Bank Error', value: 'Bank Error' }, { id: 'Adjustment', value: 'Adjustment' }],
        CreditCardDetails: CreditCardDetails
      });
    }

    if (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'hk') {
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE',
            value: 'Annual Fee'
          }
        ],
        ChargesReasonList: [{ id: 'Bank Error', value: 'Bank Error' }, { id: 'Adjustment', value: 'Adjustment' }],
        CreditCardDetails: CreditCardDetails
      });
    }

    if (this.get('queries.countryName') === 'LK') {
      return hash({
        AccListt: [
          {
            id: 'LATE_PAYMENT',
            value: 'Late Fee'
          }
        ],
        otherFeeList: [],
        CreditCardDetails: CreditCardDetails
      });
    }

    if (this.get('queries.countryName') === 'NP') {
      return hash({
        AccListt: [
          {
            id: 'LATE_PAYMENT',
            value: 'Late Payment Charge'
          }
        ],
        otherFeeList: [],
        CreditCardDetails: CreditCardDetails
      });
    }

    if (this.get('queries.countryName') === 'BN') {
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE',
            value: 'Annual Fee Reversal'
          }
        ],
        otherFeeList: [],
        CreditCardDetails: CreditCardDetails
      });
    }
  },
  getJSON(path) {
    return $.getJSON(path);
  },
  actions: {
    onChangeFeeType(feeType) {
      if (feeType && feeType.id) {
        if (feeType.id == 'Other Fee') {
          this.controllerFor('card-feewavier.charge-page').set('otherFee', true);
          this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
          this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
          this.controllerFor('card-feewavier.charge-page').set('enableNextChargePage', false);
          this.currentModel.CreditCardDetails.set('notesText', '');
        } else {
          this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
          this.controllerFor('card-feewavier.charge-page').set('activeCCList', true);
          this.controllerFor('card-feewavier.charge-page').set('enableNextChargePage', false);
          this.currentModel.CreditCardDetails.set('notesText', '');
        }
        this.currentModel.CreditCardDetails.forEach(childVal => {
          childVal.set('isSelected', false);
          childVal.set('disabledFlag', true);
          childVal.set('textData', '');
        });
        let groupA = [];
        let groupB = [];
        let groupC = [];
        let groupD = [];

        if (!this.get('queries.customerFlowFlag') && this.get('queries.countryName') == 'HK') {
          this.currentModel.CreditCardDetails.forEach(childVal => {
            if (childVal.get('currencyCode') == 'HKD') {
              groupA.push(childVal);
            }
            if (childVal.get('currencyCode') == 'CNY') {
              groupB.push(childVal);
            }
          });
          groupC.push(groupA);
          groupD.push(groupB);
          if (groupA.length > 0 && groupB.length > 0) {
            set(this.currentModel.CreditCardDetails, 'isGroupFlag', true);
          } else {
            set(this.currentModel.CreditCardDetails, 'isGroupFlag', false);
          }
          set(this.currentModel.CreditCardDetails, 'groupC', groupC);
          set(this.currentModel.CreditCardDetails, 'groupD', groupD);

          this.currentModel.CreditCardDetails.get('groupC').forEach(groupcChildVal => {
            groupcChildVal.forEach(childVal => {
              set(childVal, 'isSelected', false);
            });
          });

          this.currentModel.CreditCardDetails.get('groupD').forEach(groupdChildVal => {
            groupdChildVal.forEach(childVal => {
              set(childVal, 'isSelected', false);
            });
          });
        } else {
          set(this.currentModel.CreditCardDetails, 'isGroupFlag', false);
        }
      }
    },
    onChangeOtherFeeType(otherFeeType) {
      if (otherFeeType && otherFeeType.id) {
        this.controllerFor('card-feewavier.charge-page').set('otherFee', true);
        this.controllerFor('card-feewavier.charge-page').set('activeCCList', true);
        this.controllerFor('card-feewavier.charge-page').set('enableNextChargePage', false);
        this.currentModel.CreditCardDetails.set('notesText', '');
      }
      this.currentModel.CreditCardDetails.forEach(childVal => {
        childVal.set('isSelected', false);
        childVal.set('disabledFlag', true);
        childVal.set('textData', '');
      });
    },

    navigateConfirm(model) {
      let selectedCardData = [];
      this.get('store').init('credit-card');
      model.CreditCardDetails.forEach(contentVal => {
        if (contentVal.get('isSelected') == true) {
          let textData = contentVal.get('textData');
          let cardData = {
            cardNumber: contentVal.get('cardNum'),
            cardDesc: contentVal.get('desc'),
            cardType: contentVal.get('cardType'),
            currencyCode: contentVal.get('currencyCode'),
            blockCode: contentVal.get('blockCode'),
            availableCustomerRewardpoint: '',
            eligibleFlag: '',
            rewardPointRedepmtion: 'N',
            overRideFlag: 'N',
            textData: textData,
            primaryFlag: contentVal.get('primaryFlag'),
            maskFlag: contentVal.get('isMaskCardNo'),
            historicalTxnCount: contentVal.get('historicalTxnCount')
          };
          selectedCardData.push(cardData);
        }
      });
      let chargeNotes = '';
      if (model.CreditCardDetails.notesText) {
        chargeNotes = model.CreditCardDetails.notesText;
      }
      let pageData = [
        {
          feeTypeName:
            this.controller.get('selectedFromAcc').value != 'Other Fee'
              ? this.controller.get('selectedFromAcc').value
              : this.controller.get('otherFeeType').value,
          feeTypeID:
            this.controller.get('selectedFromAcc').id != 'Other Fee'
              ? this.controller.get('selectedFromAcc').id
              : this.controller.get('otherFeeType').id,
          reasonSelected: this.get('reasonSel'),
          charge: true,
          selectedCardData: selectedCardData,
          reversalcharge: this.controller.get('rev') ? 'REVERSAL' : 'CHARGE',
          notes: chargeNotes,
          userGroup: this.controllerFor('card-feewavier.charge-page').get('userGroup'),
          selectedAddVerification: this.controllerFor('card-feewavier.charge-page').get('selectedAddVerification'),
          selectedBasicVerification: this.controllerFor('card-feewavier.charge-page').get('selectedBasicVerification'),
          countryCode: this.get('queries.countryName')
        }
      ];
      this.controllerFor('card-feewavier.selected-card').set('cardCredit', pageData);
      this.transitionTo('card-feewavier.selected-card');
    },

    goToBack() {
      this.get('store').unloadAll('credit-card');
      this.controllerFor('card-feewavier.new-request').set('otherFee', false);
      this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
      this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
      this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
      this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
      this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
      this.controllerFor('card-feewavier.new-request').set('rewardData', false);
      this.controllerFor('card-feewavier.charge-page').set('enableNextChargePage', false);
      this.controllerFor('card-feewavier.new-request').set('enableNext', false);
      this.controllerFor('service-request.new-request').set('selectedFeeType', '');

      this.transitionTo('serviceRequest.new-request');
    },

    enableNext() {
      this.send('enableNextChargePage');
    },

    textDataCheck() {
      this.send('enableNextChargePage');
    },

    enableNextChargePage() {
      let ccValidate = false;
      let reasonValidation = false;
      let parent = this.controller.get('model').CreditCardDetails;

      if (parent) {
        parent.forEach(childVal => {
          if (childVal.get('isSelected')) {
            if (childVal.get('textData')) {
              ccValidate = true;
            } else {
              ccValidate = false;
            }
          }
        });
      }
      if (this.get('reasonSel')) {
        reasonValidation = true;
      } else {
        reasonValidation = false;
      }

      if (ccValidate && reasonValidation) {
        this.controllerFor('card-feewavier.charge-page').set('enableNextChargePage', true);
      } else {
        this.controllerFor('card-feewavier.charge-page').set('enableNextChargePage', false);
      }
    },
    notProceed() {
      this.transitionTo('serviceRequest.new-request');
    },
    yesProceed() {
      this.transitionTo('card-feewavier.cards-point');
    },
    radioChargeReversal() {
      this.get('store').unloadAll('credit-card');
      this.controllerFor('card-feewavier.new-request').set('rev', true);
      this.controllerFor('card-feewavier.new-request').set('charge', false);
      this.controllerFor('card-feewavier.new-request').set('otherFee', false);
      this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
      this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
      this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
      this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
      this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
      this.transitionTo('card-feewavier.new-request');
    },
    radioChargeCharge() {
      this.get('store').unloadAll('credit-card');
      this.controllerFor('card-feewavier.charge-page').set('rev', false);
      this.controllerFor('card-feewavier.charge-page').set('charge', true);
      this.controllerFor('card-feewavier.new-request').set('otherFee', false);
      this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
      this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
      this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
      this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
      this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
      this.transitionTo('card-feewavier.charge-page');
    },

    reasonSel(reasonSel) {
      this.currentModel.reasonSelected = reasonSel;
      this.set('reasonSel', reasonSel.value);
      this.send('enableNextChargePage');
    },
    error: function(error) {
      if (error.errors && error.errors[0].code == '1702') {
        document.location.href = config.backToiBankURL;
        return;
      }
      this.controllerFor('cardFeewavier').set('loaderInProgress', false);
      this.controllerFor('serviceRequest').set('cancelPopup', false);
      this.controllerFor('serviceRequest').set('systemErrorPopup', true);
      let message = this.get('i18n').t('ServiceRequest.CCFEEWAVIER.text.systemError.content');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          acceptButtonLabel: 'Cancel Request'
        })
        .then(() => {
          this.controllerFor('serviceRequest').set('systemErrorPopup', false);
          this.transitionTo('serviceRequest.new-request');
        });

      this.set('loaderInProgress', false);
    },
    loading(transition) {
      transition.promise.finally(() => {
        this.controllerFor('serviceRequest.new-request').set('loaderInProgress', false);
        this.controllerFor('cardFeewavier').set('loaderInProgress', false);
      });
    }
  },
  setupController(controller, model) {
    later(() => {
      document.getElementById('ccf-focus-id').scrollIntoView();
    }, 5);
    this._super(controller, model);
    this.controllerFor('card-feewavier.new-request').set('nextBtnEnabled', false);
    this.controllerFor('card-feewavier.new-request').set('rev', true);
    this.controllerFor('card-feewavier.new-request').set('charge', false);
    this.controllerFor('card-feewavier.new-request').set('otherFee', false);
    this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
    this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
    this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
    this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
    this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
    this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
    this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
    this.controllerFor('card-feewavier.new-request').set('rewardData', false);
    this.controllerFor('card-feewavier.charge-page').set('enableNextChargePage', false);
    this.controllerFor('card-feewavier.new-request').set('enableNext', false);

    /* transition login for notes */
    this._super(controller, model);
    /* transition login for notes */

    controller.set(
      'countryLinks',
      this.get('i18n').t('ServiceRequest.CCFEEWAVIER.countryLinks.' + this.get('queries.countryName'))
    );
    controller.set(
      'countryLinksTxt',
      this.get('i18n').t('ServiceRequest.CCFEEWAVIER.countryLinksTxt.' + this.get('queries.countryName'))
    );
    controller.set('links', controller.get('countryLinksTxt').toString());
    controller.set(
      'countryNotes',
      this.get('i18n').t('ServiceRequest.CCFEEWAVIER.countryNotes.' + this.get('queries.countryName'), {
        inter_link: controller.get('links')
      })
    );
    let getval = controller.get('countryNotes').toString();
    let res = getval.split('<br>');
    let appendtext = '';

    for (let i = 0; i < res.length; i++) {
      appendtext += '<li>' + res[i] + '</li>';
    }
    appendtext = htmlSafe('<ul>' + appendtext + '</ul>');
    controller.set('notemessages', appendtext);
  }
});
