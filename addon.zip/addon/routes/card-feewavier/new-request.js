import { htmlSafe } from '@ember/string';
import { set } from '@ember/object';
import $ from 'jquery';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { A } from '@ember/array';
import { isEmpty, isEqual } from '@ember/utils';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  error: service('card-error-handler'),
  rdcLoadingIndicator: service(),
  router: service(),
  nodataTmpCtry: A(['BN', 'LK', 'NP', 'MY', 'SG']),

  model(params, transtition) {
    this.controllerFor('card-feewavier').set(
      'staffAssist',
      !isEmpty(transtition.queryParams.channel) && isEqual(transtition.queryParams.channel, 'IBK') ? false : true
    );
    let CreditCardDetails, creditCardStoreData;
    let chkConfirmRoutename = null;
    if (this.get('router.currentRouteName')) {
      chkConfirmRoutename = this.get('router.currentRouteName').indexOf('cards-point') !== -1 ? true : false;
    }
    if (this.controller && this.controllerFor('card-feewavier.new-request')) {
      if (chkConfirmRoutename) {
        creditCardStoreData = this.controllerFor('card-feewavier.new-request').get('creditCardDetails');
      } else {
        this.get('store').unloadAll('credit-card');
        creditCardStoreData = null;
      }
    }
    let primaryFlagIndicator = false;
    let noActiveCardError = false;
    let errorDesc = '';
    let maskFlag = false;

    if (!creditCardStoreData || creditCardStoreData.content.length == 0) {
      CreditCardDetails = this.get('store')
        .query('credit-card', {
          filter: {
            activeCards: 'Yes',
            srName: 'CCFEEW'
          }
        })
        .then(
          CreditCardDetails => {
            this.controllerFor('card-feewavier.new-request').set('creditCardDetails', CreditCardDetails);
            CreditCardDetails.forEach(element => {
              if (element.get('primaryFlag') == 'Y') {
                primaryFlagIndicator = true;
              } else {
                primaryFlagIndicator = false;
              }

              if (element.get('isMaskCardNo') == 'Y') {
                maskFlag = true;
              } else {
                maskFlag = false;
              }
              if (element.get('errorCode')) {
                noActiveCardError = true;
              }
              if (noActiveCardError) {
                if (!this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') === 'MY') {
                  errorDesc = this.get('i18n').t('ServiceRequest.CCFEEWAVIER.nonStaffAssistNoCCards');
                } else {
                  errorDesc = element.get('errorDescription');
                }
              }
              element.set('primaryFlag', primaryFlagIndicator);
              element.set('isMaskCardNo', maskFlag);
            });
            CreditCardDetails.set('errorFlagVal', noActiveCardError);
            CreditCardDetails.set('errorDesc', errorDesc);
            CreditCardDetails.set('nextBtnEnabled', false);
            CreditCardDetails.set('customerFlowFlag', this.get('queries.customerFlowFlag') ? true : false);
            CreditCardDetails.set(
              'indicatorFlag',
              this.get('queries.countryName') == 'IN' ||
                (this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') == 'MY') ||
                this.get('queries.countryName') == 'AE'
                ? true
                : false
            );
            CreditCardDetails.set('countryCode', this.get('queries.countryName'));

            return CreditCardDetails;
          },
          error => {
            if (
              this.nodataTmpCtry.indexOf(this.get('queries.countryName')) !== -1 &&
              error.errors[0].code === 'ERR_CSL_CREDIT_CARDS_CUSTOMER_NOT_FOUND'
            ) {
              let CreditCardDetails = {
                errorFlagVal: true,
                errorDesc:
                  !this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') === 'MY'
                    ? this.get('i18n').t('ServiceRequest.CCFEEWAVIER.nonStaffAssistNoCCards')
                    : this.get('i18n').t('ServiceRequest.CCFEEWAVIER.noCCards'),
                customerFlowFlag: true
              };
              return CreditCardDetails;
            } else {
              this.send('error', error);
            }
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(CreditCardDetails, ' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
    } else {
      creditCardStoreData.content.length > 0 ? (CreditCardDetails = creditCardStoreData) : (CreditCardDetails = null);
    }
    if (this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') == 'SG') {
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE_BASIC',
            value: 'CC Annual Fee (Basic)'
          },
          {
            id: 'ANNUAL_FEE_SUPP',
            value: 'CC Annual Fee (Supp)'
          },
          {
            id: 'LATE_PAYMENT',
            value: 'Late Charge'
          },
          {
            id: 'Other Fee',
            value: 'Other Fee'
          }
        ],
        otherFeeList: [
          {
            id: 'ADMIN_FEE',
            value: 'Admin fee for funds transfer and easypay'
          },
          {
            id: 'CASH_ADV_NON_STMT',
            value: 'Cash Advance Fee - Non Statemented Transaction'
          },
          {
            id: 'CASH_ADV_STMT',
            value: 'Cash Advance Fee - Statemented Transaction'
          },
          {
            id: 'CHQ_RETRN',
            value: 'Cheque Return Fee'
          },
          {
            id: 'DEBIT_INT',
            value: 'Dr and Accrued interest'
          },
          {
            id: 'GIRO_RETRN',
            value: 'Giro Return Fee'
          },
          {
            id: 'OVER_LIMIT',
            value: 'Overlimit fee'
          },
          {
            id: 'SALES_COPY',
            value: 'Sales copy fee'
          },
          {
            id: 'STMT_REQ',
            value: 'Statement request fee'
          },
          {
            id: 'UPFRONT_REWARD',
            value: 'Upfront Reward Penalty'
          },
          {
            id: 'ANNUAL_FEE_PL',
            value: 'PL Annual Fee'
          },
          {
            id: 'COL_INT_REVRSL',
            value: 'COLLECTIONS ONLY - Interest Reversal'
          },
          {
            id: 'COL_LATE_CHRG',
            value: 'COLLECTIONS ONLY - Late Charge'
          }
        ],

        CreditCardDetails: CreditCardDetails
      });
    }
    if (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'hk') {
      let nameAnnualFee = this.get('i18n').t('ServiceRequest.CCFEEWAVIER.annualFee');
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE',
            value: nameAnnualFee
          }
        ],
        otherFeeList: [],
        CreditCardDetails: CreditCardDetails
      });
    }

    if (this.get('queries.countryName') == 'IN') {
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE',
            value: 'Annual fee Reversal'
          },
          {
            id: 'LATE_PAYMENT',
            value: 'Late Payment Charge'
          },
          {
            id: 'OVER_LIMIT',
            value: 'Over Limit Fee'
          },
          {
            id: 'INTEREST',
            value: 'Interest'
          },
          {
            id: 'Other Fee',
            value: 'Other Fee'
          }
        ],

        otherFeeList: [
          {
            id: 'JOING_FEE',
            value: 'Joining Fee waiver'
          },
          {
            id: 'PIN_REPLACEMENT',
            value: 'PIN Replacement Fee'
          },
          {
            id: 'CARD_REPLACEMENT',
            value: 'Card Replacement Fee'
          },
          {
            id: 'CHQ_RETRN',
            value: 'Cheque Return Fee'
          },
          {
            id: 'OUTSTATION_TELE_DRAFT',
            value: 'Outstation Teledraft Charges'
          },
          {
            id: 'OUTSTATION_CHQ',
            value: 'Outstation Cheque Fee'
          },
          {
            id: 'BT_PROCESS',
            value: 'BT Processing Fee'
          },
          {
            id: 'TELEDRAFT_CANCEL',
            value: 'Teledraft Cancellation Charges'
          },
          {
            id: 'CHARGE_SLIP_RETRV',
            value: 'Chargeslip retrieval fee'
          },
          {
            id: 'PRC_PREMIUM',
            value: 'PRC Premium Reversals'
          },
          {
            id: 'STMT_RETRV',
            value: 'Statement Retrieval Fee'
          },
          {
            id: 'SURCHARG_REV',
            value: 'Surcharge Reversal'
          },
          {
            id: 'BT_ACC_SETUP',
            value: 'BT Account Set Up Fee'
          },
          {
            id: 'DIAL_PROCESS',
            value: 'DAL Processing Fee'
          },
          {
            id: 'ONE_TIME_CARD',
            value: 'One Time Card Set Fee'
          },
          {
            id: 'CASH_ADVANCE',
            value: 'Cash Advance Fee'
          },
          {
            id: 'CHQ_PICK_UP',
            value: 'Cheque Pick up fee'
          },
          {
            id: 'PAYEASY_PRE_CLOSURE',
            value: 'PRECLOSURE FEE REVSD'
          },
          {
            id: 'REDEMPTION',
            value: 'Redemption Fee Reversal'
          },
          {
            id: 'CASH_REPAY_FEE',
            value: 'Cash Repayment Fee'
          }
        ],

        CreditCardDetails: CreditCardDetails
      });
    }
    if (this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') == 'MY') {
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE',
            value: 'Annual/Monthly Fee'
          },
          {
            id: 'CASH_ADVANCE',
            value: 'Cash Advance'
          },
          {
            id: 'CASH_INTEREST',
            value: 'Cash Interest'
          },
          {
            id: 'CASHBACK',
            value: 'Cashback'
          },
          {
            id: 'GIFT_REDIRECT_CHRG',
            value: 'Courier Charge For Gift Redirection'
          },
          {
            id: 'EARLY_REDMP_INSTL_P',
            value: 'Early Redemption Fee For Installment Plan'
          },
          {
            id: 'LATE_CHARGE',
            value: 'Late Charge'
          },
          {
            id: 'MULTI_CURRENCY_DIFF',
            value: 'Multi Currency Differs'
          },
          {
            id: 'OVERLIMIT_FEE',
            value: 'Overlimit Fee'
          },
          {
            id: 'PRIORITY_PASS_FEE',
            value: 'Priority Pass Fee'
          },
          {
            id: 'RETAIL_INTEREST',
            value: 'Retail Interest'
          },
          {
            id: 'SALES_DRF_RETRIEVAL',
            value: 'Sales Draft Retrivel Fee'
          },
          {
            id: 'STMT_REQUEST_FEE',
            value: 'Statement Request Fee'
          }
        ],

        CreditCardDetails: CreditCardDetails
      });
    }

    if (this.get('queries.countryName') == 'AE') {
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE',
            value: 'Annual fee Reversal'
          },
          {
            id: 'LATE_PAYMENT',
            value: 'Late Payment Charge'
          },
          {
            id: 'OVER_LIMIT',
            value: 'Over Limit Fee'
          }
        ],
        otherFeeList: [],

        CreditCardDetails: CreditCardDetails
      });
    }

    if (this.get('queries.countryName') === 'LK') {
      return hash({
        AccListt: [
          {
            id: 'LATE_PAYMENT',
            value: 'Late Fee'
          }
        ],
        otherFeeList: [],
        CreditCardDetails: CreditCardDetails
      });
    }

    if (
      this.get('queries.countryName') === 'NP' ||
      (!this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') === 'SG')
    ) {
      return hash({
        AccListt: [
          {
            id: 'LATE_PAYMENT',
            value: 'Late Fee'
          }
        ],
        otherFeeList: [],
        CreditCardDetails: CreditCardDetails
      });
    }

    if (this.get('queries.countryName') === 'BN') {
      return hash({
        AccListt: [
          {
            id: 'ANNUAL_FEE',
            value: 'Annual Fee'
          }
        ],
        otherFeeList: [],
        CreditCardDetails: CreditCardDetails
      });
    }

    if (!this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') === 'MY') {
      return hash({
        AccListt: [
          {
            id: 'LATE_CHARGE',
            value: 'Late payment penalty charges'
          }
        ],
        otherFeeList: [],
        CreditCardDetails: CreditCardDetails
      });
    }
  },
  getJSON(path) {
    return $.getJSON(path);
  },

  actions: {
    onChangeFeeType(feeType) {
      let feeTypeSplit;
      if (feeType && feeType.id) {
        if (feeType.id == 'Other Fee') {
          this.controllerFor('card-feewavier.new-request').set('otherFee', true);
          this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
          this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
          this.controllerFor('card-feewavier.new-request').set('enableNext', false);
        } else {
          this.controllerFor('card-feewavier.new-request').set('otherFee', false);
          this.controllerFor('card-feewavier.new-request').set('activeCCList', true);
          this.controllerFor('card-feewavier.new-request').set('enableNext', false);
        }
        this.currentModel.CreditCardDetails.forEach(childVal => {
          if (childVal.isSelected) {
            set(childVal, 'isSelected', false);
          }
        });

        let groupA = [];
        let groupB = [];
        let groupC = [];
        let groupD = [];

        if (
          (this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') == 'MY') ||
          (!this.get('queries.customerFlowFlag') && this.get('queries.countryName') == 'HK')
        ) {
          let feeTypeFlag = false;
          if (this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') == 'MY') {
            this.currentModel.CreditCardDetails.forEach(childVal => {
              feeTypeSplit = childVal.get('cardGroupableFeeTypes').split(',');
              feeTypeSplit.forEach(feeTypeSplited => {
                if (feeType.id == feeTypeSplited) {
                  feeTypeFlag = true;
                }
              });
            });
          } else if (this.get('queries.countryName') == 'HK') {
            feeTypeFlag = true;
          } else {
            feeTypeFlag = false;
          }

          if (feeTypeFlag) {
            this.currentModel.CreditCardDetails.forEach(childVal => {
              if (this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') == 'MY') {
                if (childVal.get('cardRewardCategory') == 'A') {
                  groupA.push(childVal);
                }
                if (childVal.get('cardRewardCategory') == 'B') {
                  groupB.push(childVal);
                }
              }
              if (this.get('queries.countryName') == 'HK') {
                if (childVal.get('currencyCode') == 'HKD') {
                  groupA.push(childVal);
                }
                if (childVal.get('currencyCode') == 'CNY') {
                  groupB.push(childVal);
                }
              }
            });

            groupC.push(groupA);
            groupD.push(groupB);
            if (groupA.length > 0 && groupB.length > 0) {
              set(this.currentModel.CreditCardDetails, 'isGroupFlag', true);
            } else {
              set(this.currentModel.CreditCardDetails, 'isGroupFlag', false);
            }
            set(this.currentModel.CreditCardDetails, 'groupC', groupC);
            set(this.currentModel.CreditCardDetails, 'groupD', groupD);

            this.currentModel.CreditCardDetails.get('groupC').forEach(groupcChildVal => {
              groupcChildVal.forEach(childVal => {
                set(childVal, 'isSelected', false);
              });
            });

            this.currentModel.CreditCardDetails.get('groupD').forEach(groupdChildVal => {
              groupdChildVal.forEach(childVal => {
                set(childVal, 'isSelected', false);
              });
            });
          } else {
            set(this.currentModel.CreditCardDetails, 'isGroupFlag', false);
          }
        } else if (this.get('queries.countryName') == 'AE') {
          let annualFeeFlag = false;
          let lateOverlmtFlag = false;

          this.send('groupBy', this.currentModel.CreditCardDetails, accNum => accNum.get('grpAccNum'));
          if (feeType.id == 'ANNUAL_FEE' && this.currentModel.CreditCardDetails.accNoGrouping[0].accNo != 'undefined') {
            annualFeeFlag = true;
          }
          this.currentModel.CreditCardDetails.accNoGrouping.forEach(accountSet => {
            accountSet.values.forEach(value => {
              if ((feeType.id == 'LATE_PAYMENT' || feeType.id == 'OVER_LIMIT') && accountSet.accNo != 'undefined') {
                if (!value.get('primaryFlag')) {
                  value.set('isSupplemtryDisableFlag', true);
                }
                lateOverlmtFlag = true;
              } else {
                value.set('isSupplemtryDisableFlag', false);
              }
            });
          });
          set(this.currentModel.CreditCardDetails, 'annualFeeFlag', annualFeeFlag);
          set(this.currentModel.CreditCardDetails, 'lateOverlmtFlag', lateOverlmtFlag);
        } else {
          set(this.currentModel.CreditCardDetails, 'isGroupFlag', false);
        }
      }
    },

    groupBy(list, keyGetter) {
      let map = {};
      list.forEach(item => {
        const key = keyGetter(item);
        const collection = map[key];
        if (!collection) {
          map[key] = [item];
        } else {
          collection.push(item);
        }
      });

      let groupngArray = [];
      for (let key in map) {
        /**
         * Replaced below line for eslint error: no-prototype-builtins
         * if (map.hasOwnProperty(key)) { **/
        if (Object.prototype.hasOwnProperty.call(map, key)) {
          let childVal = map[key];
          let groupingObj = {};
          groupingObj.accNo = key;
          groupingObj.values = childVal;
          groupngArray.push(groupingObj);
        }
      }

      set(this.currentModel.CreditCardDetails, 'accNoGrouping', groupngArray);
      if (groupngArray.length > 0 && groupngArray[0].accNo != 'undefined') {
        set(this.currentModel.CreditCardDetails, 'groupAccountNumberFlag', true);
      } else {
        set(this.currentModel.CreditCardDetails, 'groupAccountNumberFlag', false);
      }
    },
    onChangeOtherFeeType(otherFeeType) {
      if (otherFeeType && otherFeeType.id) {
        this.controllerFor('card-feewavier.new-request').set('otherFee', true);
        this.controllerFor('card-feewavier.new-request').set('activeCCList', true);
        this.controllerFor('card-feewavier.new-request').set('enableNext', false);
      }
      this.currentModel.CreditCardDetails.forEach(childVal => {
        if (childVal.isSelected) {
          set(childVal, 'isSelected', false);
        }
      });
    },
    navigateConfirm() {
      let transactionRes;

      let cardNumSel = '';
      let creditCardDetailsSel;

      creditCardDetailsSel = this.controllerFor('card-feewavier.new-request')
        .get('model')
        .CreditCardDetails.filterBy('isSelected');
      if (creditCardDetailsSel) {
        if (this.get('queries.countryName') == 'HK') {
          creditCardDetailsSel.forEach(selectedCardNum => {
            cardNumSel = selectedCardNum.data.cardNum + selectedCardNum.data.currencyCode + ',' + cardNumSel;
          });
        } else {
          creditCardDetailsSel.forEach(selectedCardNum => {
            cardNumSel = selectedCardNum.data.cardNum + ',' + cardNumSel;
          });
        }
      } else {
        cardNumSel = '';
      }
      if (cardNumSel.charAt(cardNumSel.length - 1) == ',') {
        cardNumSel = cardNumSel.slice(0, -1);
      }

      this.get('store').init('credit-card');

      transactionRes = this.get('store')
        .query('credit-card', {
          filter: {
            eligibleFeeWaiver: 'Yes',
            feeType: this.controller.get('otherFeeType')
              ? this.controller.get('otherFeeType').id
              : this.controller.get('selectedFromAcc').id,
            cardNumbers: cardNumSel
          },
          include: 'cardtransactions'
        })
        .then(
          response => {
            let cardDetails = [];
            let OverRideReasonList = [];

            response.forEach(element => {
              /*error flag setting*/

              let isCardHasPartialPaymentFlag = false;
              let primaryFlag = false;
              let maskFlag = false;

              if (element.get('isCardPartialPayment') == 'Y') {
                isCardHasPartialPaymentFlag = true;
              } else {
                isCardHasPartialPaymentFlag = false;
              }
              if (element.get('primaryFlag') == 'Y') {
                primaryFlag = true;
              } else {
                primaryFlag = false;
              }
              if (element.get('isMaskCardNo') == 'Y') {
                maskFlag = true;
              } else {
                maskFlag = false;
              }

              element.get('cardtransactions').forEach(transactionElement => {
                if (transactionElement.get('primarySuppInd') == 'P') {
                  transactionElement.set('data.primarySuppIndVal', true);
                } else {
                  transactionElement.set('data.primarySuppIndVal', false);
                }
                if (transactionElement.get('isPartiallyReversed') == 'Y') {
                  transactionElement.set('data.isPartiallyReversedFlag', true);
                } else {
                  transactionElement.set('data.isPartiallyReversedFlag', false);
                }

                transactionElement.set('data.transactionSelected', false);
                transactionElement.set('data.transactionFlag', false);
                transactionElement.set('data.transacOrgnAmount', transactionElement.get('transactionAmount'));
                if (
                  this.controllerFor('card-feewavier').staffAssist &&
                  this.get('queries.countryName') == 'MY' &&
                  transactionElement.get('isDiscountTransaction') == 'Y'
                ) {
                  transactionElement.set('data.displayTransactionFlag', true);
                } else {
                  transactionElement.set('data.displayTransactionFlag', false);
                }
              });
              element.set('primaryFlag', primaryFlag);
              element.set('isCardPartialPayment', isCardHasPartialPaymentFlag);
              element.set('isMaskCardNo', maskFlag);
              cardDetails.push(element);
            });

            let errorFlag = false;
            let errorData = '';
            let commonError = '';
            let imgicon1 = false;
            let imgicon2 = false;
            let imgicon3 = false;
            let imgicon4 = false;
            let imgicon5 = false;
            let imgicon6 = false;
            let imgicon7 = false;
            /*error page routing validation -same error(error page) or dynamic error(transactionpage)*/
            /*imageicon setup*/
            try {
              cardDetails.forEach(errorValid => {
                if (errorValid.get('errorCode')) {
                  if (errorData == '') {
                    errorData = errorValid.get('errorCode');
                  }
                  if (errorData == errorValid.get('errorCode')) {
                    commonError = errorValid.get('errorDescription');
                    if (commonError && errorValid.get('errorCode') == '1000') {
                      imgicon1 = true;
                      errorFlag = true;
                    } else if (commonError && errorValid.get('errorCode') == '2000') {
                      imgicon2 = true;
                      errorFlag = true;
                    } else if (commonError && errorValid.get('errorCode') == '3000') {
                      imgicon3 = true;
                      errorFlag = true;
                    } else if (commonError && errorValid.get('errorCode') == '4000') {
                      imgicon5 = true;
                      errorFlag = true;
                    } else if (commonError && errorValid.get('errorCode') == '6000') {
                      imgicon6 = true;
                      errorFlag = true;
                    } else if (commonError && errorValid.get('errorCode') == '7000') {
                      imgicon7 = true;
                      errorFlag = true;
                    }
                  } else {
                    errorFlag = false;
                  }
                  if (!errorFlag) {
                    throw new Error();
                  }
                } else {
                  errorData = '0000';
                  errorFlag = false;
                }
              });
            } catch (e) {
              errorFlag = false;
              /*do nothing here*/
            }

            let eligibilityCheck = false;
            cardDetails.forEach(rewardPointObj => {
              if (rewardPointObj.get('eligibleFeeWaiver') == 'Yes') {
                eligibilityCheck = true;
              }
              if (eligibilityCheck) {
                return;
              }
            });
            //Validation For single card - 5000 error code not eligible - AE

            let cardCountFlag = false;
            if (cardDetails.length == 1) {
              if (cardDetails[0].get('errorCode') == '5000') cardCountFlag = true;
            }

            let rewardEligiblityFlag = false;
            let eligiblityValFlag = false;
            let availableOverLimitFlag = false;
            let cardRewardPoint;
            let rewardFlowVal = false;
            /*reward point calculation.*/
            let rewardAmt = 0;
            let rewardAmtVal;
            cardDetails.forEach(rewardPointObj => {
              try {
                if (this.get('queries.countryName') == 'AE') {
                  availableOverLimitFlag = false;
                  rewardAmtVal = 0;
                  if (rewardPointObj.get('cardAvailableRewardPoint')) {
                    rewardAmtVal = parseFloat(rewardPointObj.get('cardAvailableRewardPoint').rewardsPoints);
                  }

                  rewardPointObj.get('cardtransactions').forEach(childData => {
                    if (childData.get('equivalentRewardPoints'))
                      cardRewardPoint = parseFloat(childData.get('equivalentRewardPoints').rewardsPoints);
                    if (rewardAmtVal && cardRewardPoint && rewardAmtVal >= cardRewardPoint) {
                      availableOverLimitFlag = true;
                    }
                    if (availableOverLimitFlag) {
                      return;
                    }
                  });
                  if (availableOverLimitFlag) {
                    rewardAmt = parseFloat(rewardAmt) + parseFloat(rewardAmtVal);
                  } else if (!eligibilityCheck && rewardAmtVal <= cardRewardPoint && !cardCountFlag) {
                    availableOverLimitFlag = true;
                    rewardPointObj.set('errorTransFlag', true);
                    rewardPointObj.set('errorDescription', "Card doesn't have sufficient points to redeem");
                  } else {
                    availableOverLimitFlag = false;
                  }
                } else {
                  if (rewardPointObj.get('availableCustomerRewardpoint')) {
                    rewardAmt = parseFloat(rewardPointObj.get('availableCustomerRewardpoint'));
                  }

                  rewardPointObj.get('cardtransactions').forEach(childData => {
                    if (childData.get('equivalentRewardPoints'))
                      cardRewardPoint = parseFloat(childData.get('equivalentRewardPoints').rewardsPoints);
                    if (rewardAmt && cardRewardPoint && rewardAmt >= cardRewardPoint) {
                      availableOverLimitFlag = true;
                    }
                    if (availableOverLimitFlag) {
                      return;
                    }
                  });
                }
                if (eligibilityCheck && rewardPointObj.get('eligibleFeeWaiver') == 'Yes') {
                  rewardEligiblityFlag = false;
                  eligiblityValFlag = true;
                  rewardAmt = 0;
                } else if (
                  !eligibilityCheck &&
                  rewardPointObj.get('errorCode') == '5000' &&
                  rewardPointObj.get('errorDescription') &&
                  availableOverLimitFlag &&
                  rewardPointObj.get('eligibleFeeWaiver') == 'No' &&
                  (rewardPointObj.get('availableCustomerRewardpoint') || rewardAmtVal != 0)
                ) {
                  rewardEligiblityFlag = true;
                  eligiblityValFlag = true;
                  rewardFlowVal = true;
                } else if (
                  !eligibilityCheck &&
                  rewardPointObj.get('errorCode') == '5000' &&
                  rewardPointObj.get('errorDescription') &&
                  !availableOverLimitFlag &&
                  rewardPointObj.get('eligibleFeeWaiver') == 'No'
                ) {
                  /*over -ride*/
                  imgicon1 = false;
                  imgicon2 = false;
                  imgicon3 = false;
                  imgicon4 = true;
                  imgicon5 = false;
                  imgicon6 = false;
                  imgicon7 = false;
                  commonError = rewardPointObj.get('errorDescription');
                  rewardEligiblityFlag = false;
                  eligiblityValFlag = true;
                  rewardAmt = 0;
                } else {
                  rewardEligiblityFlag = false;
                  eligiblityValFlag = false;
                }

                if (this.get('queries.countryName') == 'HK') {
                  rewardPointObj.set('toolTipErrorText', true);
                } else {
                  rewardPointObj.set('toolTipErrorText', false);
                }

                if (!rewardEligiblityFlag && !eligiblityValFlag) {
                  throw new Error();
                }
              } catch (e) {
                rewardPointObj.set('errorTransFlag', true);
              }
            });

            /* }*/
            /*IscardPartialPaycheck : remove card if it is  partial paid =="Y"*/
            let vaildCardPartial = [];
            let paritalFlag = false;
            let TransactionReasonList;
            if (rewardFlowVal && rewardAmt > 0) {
              cardDetails.forEach(rewardPointObj => {
                if (rewardPointObj.get('isCardPartialPayment')) {
                  paritalFlag = true;
                } else {
                  vaildCardPartial.push(rewardPointObj);
                }
              });
            }
            if (this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') == 'MY') {
              TransactionReasonList = [
                {
                  id: 'Retention -  Customer wanted to go for cancellation if Reversal not given',
                  value: 'Retention -  Customer wanted to go for cancellation if Reversal not given'
                },
                {
                  id: 'Never Used Never Paid',
                  value: 'Never Used Never Paid'
                },
                {
                  id: ' Cancelled/Void transaction credited by merchant',
                  value: ' Cancelled/Void transaction credited by merchant'
                },
                {
                  id: 'Charges due to dispute on foreign currency conversion amount',
                  value: 'Charges due to dispute on foreign currency conversion amount'
                },
                {
                  id: 'Valid dispute transaction credited by charge back unit',
                  value: 'Valid dispute transaction credited by charge back unit'
                },
                {
                  id: 'Delay in insurance cancellation',
                  value: 'Delay in insurance cancellation'
                },
                {
                  id: 'Mass error',
                  value: 'Mass error'
                },
                {
                  id: 'Apportionment issue',
                  value: 'Apportionment issue'
                },
                {
                  id: 'Cheque not found',
                  value: 'Cheque not found'
                },
                {
                  id: 'Delay in credit of repayment',
                  value: 'Delay in credit of repayment'
                },
                {
                  id: 'Delay in reciept of repayment',
                  value: 'Delay in reciept of repayment'
                },
                {
                  id: ' Delay in reversal of earlier waiver',
                  value: ' Delay in reversal of earlier waiver'
                },
                {
                  id: 'Erroneous charges levied',
                  value: 'Erroneous charges levied'
                },
                {
                  id: 'Insurance cancellation not done',
                  value: 'Insurance cancellation not done'
                },
                {
                  id: 'Wrong information provided at frontline',
                  value: 'Wrong information provided at frontline'
                },
                {
                  id: 'Earlier reversals given in non payment mode (Cash back, dispute credit etc)',
                  value: 'Earlier reversals given in non payment mode (Cash back, dispute credit etc)'
                },
                {
                  id: 'First time reversal',
                  value: 'First time reversal'
                },
                {
                  id: 'STAFF REVERSAL',
                  value: 'STAFF REVERSAL'
                },
                {
                  id: ' Delay in receipt of statement',
                  value: ' Delay in receipt of statement'
                },
                {
                  id: 'E-statement not accessible and No SMS received',
                  value: 'E-statement not accessible and No SMS received'
                },
                {
                  id: 'Statement not received',
                  value: 'Statement not received'
                }
              ];
            }
            if (this.get('queries.countryName') == 'IN') {
              TransactionReasonList = [
                {
                  id: 'Retention -  Customer wanted to go for cancellation if Reversal not given',
                  value: 'Retention -  Customer wanted to go for cancellation if Reversal not given'
                },
                {
                  id: 'Never Used Never Paid',
                  value: 'Never Used Never Paid'
                },
                {
                  id: 'Charges due to line decrease',
                  value: 'Charges due to line decrease'
                },
                {
                  id: 'Limit not assigned to Linked account',
                  value: 'Limit not assigned to Linked account'
                },
                {
                  id: ' Cancelled/Void transaction credited by merchant',
                  value: ' Cancelled/Void transaction credited by merchant'
                },
                {
                  id: 'Charges due to dispute on foreign currency conversion amount',
                  value: 'Charges due to dispute on foreign currency conversion amount'
                },
                {
                  id: 'Valid dispute transaction credited by charge back unit',
                  value: 'Valid dispute transaction credited by charge back unit'
                },
                {
                  id: 'Draft cancelled basis indemnity bond ',
                  value: 'Draft cancelled basis indemnity bond '
                },
                {
                  id: 'Draft lost not found',
                  value: 'Draft lost not found'
                },
                {
                  id: 'Draft RTOed but charges not reversed',
                  value: 'Draft RTOed but charges not reversed'
                },
                {
                  id: 'Delay in insurance cancellation',
                  value: 'Delay in insurance cancellation'
                },
                {
                  id: 'Mass error',
                  value: 'Mass error'
                },
                {
                  id: ' due to loan amount block',
                  value: ' due to loan amount block'
                },
                {
                  id: 'due to usage of buffer limit',
                  value: 'due to usage of buffer limit'
                },
                {
                  id: 'other reasons',
                  value: 'other reasons'
                },
                {
                  id: 'Apportionment issue',
                  value: 'Apportionment issue'
                },
                {
                  id: 'Cheque not found',
                  value: 'Cheque not found'
                },
                {
                  id: 'Delay in credit of repayment',
                  value: 'Delay in credit of repayment'
                },
                {
                  id: 'Delay in reciept of repayment',
                  value: 'Delay in reciept of repayment'
                },
                {
                  id: 'ECS mandate not received',
                  value: 'ECS mandate not received'
                },
                {
                  id: ' Delay in reversal of earlier waiver',
                  value: ' Delay in reversal of earlier waiver'
                },
                {
                  id: 'Erroneous charges levied',
                  value: 'Erroneous charges levied'
                },
                {
                  id: 'Insurance cancellation not done',
                  value: 'Insurance cancellation not done'
                },
                {
                  id: 'Marketing related Reversal eg. Surcharge reversal etc.',
                  value: 'Marketing related Reversal eg. Surcharge reversal etc.'
                },
                {
                  id: 'Wrong information provided at frontline',
                  value: 'Wrong information provided at frontline'
                },
                {
                  id: 'Card RTOed and loan accounts closed resulting in charges',
                  value: 'Card RTOed and loan accounts closed resulting in charges'
                },
                {
                  id: 'Incorrect closure of instabuy accounts resulting on charges',
                  value: 'Incorrect closure of instabuy accounts resulting on charges'
                },
                {
                  id: 'Charges due to upgrade or downgrade of account',
                  value: 'Charges due to upgrade or downgrade of account'
                },
                {
                  id: 'Earlier reversals given in non payment mode (Cash back, dispute credit etc)',
                  value: 'Earlier reversals given in non payment mode (Cash back, dispute credit etc)'
                },
                {
                  id: 'Escalation -  customer not accepting hence reversing',
                  value: 'Escalation -  customer not accepting hence reversing'
                },
                {
                  id: 'Family death hence delayed payment',
                  value: 'Family death hence delayed payment'
                },
                {
                  id: 'First time reversal',
                  value: 'First time reversal'
                },
                {
                  id: 'Medical emergency -  Hence no payment made',
                  value: 'Medical emergency -  Hence no payment made'
                },
                {
                  id: 'STAFF REVERSAL',
                  value: 'STAFF REVERSAL'
                },
                {
                  id: ' Delay in receipt of statement',
                  value: ' Delay in receipt of statement'
                },
                {
                  id: 'E-statement not accessible and No SMS received',
                  value: 'E-statement not accessible and No SMS received'
                },
                {
                  id: 'Statement not received',
                  value: 'Statement not received'
                },
                {
                  id: 'Trailing interest',
                  value: 'Trailing interest'
                }
              ];
            }
            if (this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') == 'SG') {
              TransactionReasonList = [
                {
                  id: 'Retention',
                  value: 'Retention'
                },
                {
                  id: 'Card Cancelled',
                  value: 'Card Cancelled'
                },
                {
                  id: 'Merchant Reversal/Reversal not recognized as payment',
                  value: 'Merchant Reversal/Reversal not recognized as payment'
                },
                {
                  id: 'Dispute Transaction',
                  value: 'Dispute Transaction'
                },
                {
                  id: 'System/Mass Error',
                  value: 'System/Mass Error'
                },
                {
                  id: 'Payment on due date',
                  value: 'Payment on due date'
                },
                {
                  id: 'Small Outstanding Balance<$100',
                  value: 'Small Outstanding Balance<$100'
                },
                {
                  id: 'Paid to Wrong Account',
                  value: 'Paid to Wrong Account'
                },
                {
                  id: 'Credit Balance in other Account',
                  value: 'Credit Balance in other Account'
                },
                {
                  id: 'Forgot about payment',
                  value: 'Forgot about payment'
                },
                {
                  id: 'Staff Error',
                  value: 'Staff Error'
                },
                {
                  id: 'High Net Worth/VIP',
                  value: 'High Net Worth/VIP'
                },
                {
                  id: 'Out of Town/Overseas',
                  value: 'Out of Town/Overseas'
                },
                {
                  id: 'High risk complaint',
                  value: 'High risk complaint'
                },
                {
                  id: 'Compassionate',
                  value: 'Compassionate'
                },
                {
                  id: 'Goodwill/Loyal Customer',
                  value: 'Goodwill/Loyal Customer'
                },
                {
                  id: 'Others-Please Specify',
                  value: 'Others-Please Specify'
                },
                {
                  id: 'Non-receipt of statement',
                  value: 'Non-receipt of statement'
                },
                {
                  id: 'Snowball charges due to Annual Fee',
                  value: 'Snowball charges due to Annual Fee'
                }
              ];
            }

            if (this.get('queries.countryName') == 'AE') {
              TransactionReasonList = [
                {
                  id: 'Reversal as one of gesture',
                  value: 'Reversal as one of gesture'
                },
                {
                  id: 'Not Aware of the charges and came to know only after getting levied.',
                  value: 'Not Aware of the charges and came to know only after getting levied.'
                },
                {
                  id: 'Card was free for 1st year and hence wants to get the waiver for current year too.',
                  value: 'Card was free for 1st year and hence wants to get the waiver for current year too.'
                },
                {
                  id: 'Not aware about any such charge and not been told about the charge at the time of application.',
                  value:
                    'Not aware about any such charge and not been told about the charge at the time of application.'
                },
                {
                  id:
                    'Given incorrect information about the charge and hence wantes to log complaint and reverse the charges. 	',
                  value:
                    'Given incorrect information about the charge and hence wantes to log complaint and reverse the charges. 	'
                },
                {
                  id: 'Reversal as one of Gesture.',
                  value: 'Reversal as one of Gesture.'
                },
                {
                  id: '1st time asking for this reversal.',
                  value: '1st time asking for this reversal.'
                },
                {
                  id: 'Not aware of the charges and came to know after gettng the statement.',
                  value: 'Not aware of the charges and came to know after gettng the statement.'
                },
                {
                  id:
                    'The charges are not legitinmate and hence wants to log a complaint for the same and also wants reversals.',
                  value:
                    'The charges are not legitinmate and hence wants to log a complaint for the same and also wants reversals.'
                }
              ];
            }

            if (this.get('queries.countryName') == 'HK') {
              TransactionReasonList = [
                {
                  id: 'Goodwill ~ Wrong information provided',
                  value: 'Goodwill ~ Wrong information provided'
                },
                {
                  id: 'Goodwill ~ No Time / Forgot / Late / Non-Receipt of Stmt',
                  value: 'Goodwill ~ No Time / Forgot / Late / Non-Receipt of Stmt'
                },
                {
                  id: 'Goodwill ~ Payment Lost In Transit',
                  value: 'Goodwill ~ Payment Lost In Transit'
                },
                {
                  id: 'Goodwill ~ Branch Refer',
                  value: 'Goodwill ~ Branch Refer'
                },
                {
                  id: 'Goodwill ~ Corporate Account',
                  value: 'Goodwill ~ Corporate Account'
                },
                {
                  id: 'Operating Procedures ~ Card Cancellation',
                  value: 'Operating Procedures ~ Card Cancellation'
                },
                {
                  id: 'Operating Procedures ~ Exchange Rate Differ',
                  value: 'Operating Procedures ~ Exchange Rate Differ'
                },
                {
                  id: 'Operating Procedures ~ Retention',
                  value: 'Operating Procedures ~ Retention'
                },
                {
                  id: 'System / Operation Error ~ Branch Error ',
                  value: 'System / Operation Error ~ Branch Error '
                },
                {
                  id: 'System / Operation Error ~ Operation Error',
                  value: 'System / Operation Error ~ Operation Error '
                },
                {
                  id: 'System / Operation Error ~ System Error / Constraint',
                  value: 'System / Operation Error ~ System Error / Constraint'
                }
              ];
            }

            if (this.get('queries.countryName') == 'IN') {
              OverRideReasonList = [
                {
                  id: 'Retention -  Customer wanted to go for cancellation if Reversal not given',
                  value: 'Retention -  Customer wanted to go for cancellation if Reversal not given'
                },
                {
                  id: 'Charges due to line decrease',
                  value: 'Charges due to line decrease'
                },
                {
                  id: 'Limit not assigned to Linked account',
                  value: 'Limit not assigned to Linked account'
                },
                {
                  id: 'Cancelled/Void transaction credited by merchant',
                  value: 'Cancelled/Void transaction credited by merchant'
                },
                {
                  id: 'Charges due to dispute on foreign currency conversion amount',
                  value: 'Charges due to dispute on foreign currency conversion amount'
                },
                {
                  id: 'Valid dispute transaction credited by charge back unit',
                  value: 'Valid dispute transaction credited by charge back unit'
                },
                {
                  id: 'Draft cancelled basis indemnity bond ',
                  value: 'Draft cancelled basis indemnity bond '
                },
                {
                  id: 'Draft lost not found',
                  value: 'Draft lost not found'
                },
                {
                  id: 'Draft RTOed but charges not reversed',
                  value: 'Draft RTOed but charges not reversed'
                },
                {
                  id: 'Delay in insurance cancellation',
                  value: 'Delay in insurance cancellation'
                },
                {
                  id: 'Mass error',
                  value: 'Mass error'
                },
                {
                  id: 'due to loan amount block',
                  value: 'due to loan amount block'
                },
                {
                  id: 'due to usage of buffer limit',
                  value: 'due to usage of buffer limit'
                },
                {
                  id: 'other reasons',
                  value: 'other reasons'
                },
                {
                  id: 'Apportionment issue',
                  value: 'Apportionment issue'
                },
                {
                  id: 'Cheque not found',
                  value: 'Cheque not found'
                },
                {
                  id: 'Delay in credit of repayment',
                  value: 'Delay in credit of repayment'
                },
                {
                  id: 'Delay in reciept of repayment',
                  value: 'Delay in reciept of repayment'
                },
                {
                  id: 'ECS mandate not received',
                  value: 'ECS mandate not received'
                },
                {
                  id: 'Delay in reversal of earlier waiver',
                  value: 'Delay in reversal of earlier waiver'
                },
                {
                  id: 'Erroneous charges levied',
                  value: 'Erroneous charges levied'
                },
                {
                  id: 'Insurance cancellation not done',
                  value: 'Insurance cancellation not done'
                },
                {
                  id: 'Marketing related Reversal eg. Surcharge reversal etc.',
                  value: 'Marketing related Reversal eg. Surcharge reversal etc.'
                },
                {
                  id: 'Wrong information provided at frontline',
                  value: 'Wrong information provided at frontline'
                },
                {
                  id: 'Card RTOed and loan accounts closed resulting in charges',
                  value: 'Card RTOed and loan accounts closed resulting in charges'
                },
                {
                  id: 'Incorrect closure of instabuy accounts resulting on charges',
                  value: 'Incorrect closure of instabuy accounts resulting on charges'
                },
                {
                  id: 'Charges due to upgrade or downgrade of account',
                  value: 'Charges due to upgrade or downgrade of account'
                },
                {
                  id: 'Earlier reversals given in non payment mode (Cash back, dispute credit etc)',
                  value: 'Earlier reversals given in non payment mode (Cash back, dispute credit etc)'
                },
                {
                  id: 'Escalation -  customer not accepting hence reversing',
                  value: 'Escalation -  customer not accepting hence reversing'
                },
                {
                  id: 'Family death hence delayed payment',
                  value: 'Family death hence delayed payment'
                },
                {
                  id: 'First time reversal',
                  value: 'First time reversal'
                },
                {
                  id: 'Medical emergency -  Hence no payment made',
                  value: 'Medical emergency -  Hence no payment made'
                },
                {
                  id: 'STAFF REVERSAL',
                  value: 'STAFF REVERSAL'
                },
                {
                  id: 'Delay in receipt of statement',
                  value: 'Delay in receipt of statement'
                },
                {
                  id: 'E-statement not accessible and No SMS received',
                  value: 'E-statement not accessible and No SMS received'
                },
                {
                  id: 'Statement not received',
                  value: 'Statement not received'
                },
                {
                  id: 'Trailing interest',
                  value: 'Trailing interest'
                }
              ];
            }

            if (
              (this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') == 'SG') ||
              this.get('queries.countryName') == 'MY'
            ) {
              OverRideReasonList = [
                {
                  id: 'Card Cancelled/Account Closure',
                  value: 'Card Cancelled/Account Closure'
                },
                {
                  id: 'Payment on due date',
                  value: 'Payment on due date'
                },
                {
                  id: 'Retention',
                  value: 'Retention'
                },
                {
                  id: 'Compassionate',
                  value: 'Compassionate'
                },
                {
                  id: 'Dispute Transaction',
                  value: 'Dispute Transaction'
                },
                {
                  id: 'High Net Worth/ VIP',
                  value: 'High Net Worth/ VIP'
                },
                {
                  id: 'High Risk Complaint',
                  value: 'High Risk Complaint '
                },
                {
                  id: 'Snowball charge due to Annual Fee',
                  value: 'Snowball charge due to Annual Fee'
                },
                {
                  id: 'Merchant Reversal/ Reversal',
                  value: 'Merchant Reversal/ Reversal'
                },
                {
                  id: 'Staff Error',
                  value: 'Staff Error'
                },
                {
                  id: 'System/ Mass error',
                  value: 'System/ Mass error'
                },
                {
                  id: 'Credit Balance in other Account',
                  value: 'Credit Balance in other Account'
                },
                {
                  id: 'Paid to Wrong Account',
                  value: 'Paid to Wrong Account'
                },
                {
                  id: 'Small Outstanding Amount',
                  value: 'Small Outstanding Amount'
                }
              ];
            }

            if (this.get('queries.countryName') == 'HK') {
              OverRideReasonList = [
                {
                  id: 'Goodwill ~ Wrong information provided',
                  value: 'Goodwill ~ Wrong information provided'
                },
                {
                  id: 'Goodwill ~ No Time / Forgot / Late / Non-Receipt of Stmt',
                  value: 'Goodwill ~ No Time / Forgot / Late / Non-Receipt of Stmt'
                },
                {
                  id: 'Goodwill ~ Payment Lost In Transit',
                  value: 'Goodwill ~ Payment Lost In Transit'
                },
                {
                  id: 'Goodwill ~ Branch Refer',
                  value: 'Goodwill ~ Branch Refer'
                },
                {
                  id: 'Goodwill ~ Corporate Account',
                  value: 'Goodwill ~ Corporate Account'
                },
                {
                  id: 'Operating Procedures ~ Card Cancellation',
                  value: 'Operating Procedures ~ Card Cancellation'
                },
                {
                  id: 'Operating Procedures ~ Exchange Rate Differ',
                  value: 'Operating Procedures ~ Exchange Rate Differ'
                },
                {
                  id: 'Operating Procedures ~ Retention',
                  value: 'Operating Procedures ~ Retention'
                },
                {
                  id: 'System / Operation Error ~ Branch Error ',
                  value: 'System / Operation Error ~ Branch Error '
                },
                {
                  id: 'System / Operation Error ~ Operation Error',
                  value: 'System / Operation Error ~ Operation Error '
                },
                {
                  id: 'System / Operation Error ~ System Error / Constraint',
                  value: 'System / Operation Error ~ System Error / Constraint'
                }
              ];
            }

            let pageData = [
              {
                customerFlowFlag: this.get('queries.customerFlowFlag') ? true : false,
                indicatorFlag: this.currentModel.CreditCardDetails.indicatorFlag,
                cardSelectedDetails: cardDetails,
                selectedData: true,
                commonErrorDesc: commonError,
                imgicon1: imgicon1,
                imgicon2: imgicon2,
                imgicon3: imgicon3,
                imgicon4: imgicon4,
                imgicon5: imgicon5,
                imgicon6: imgicon6,
                imgicon7: imgicon7,
                totalRewardPoints: rewardAmt,
                rewardFlag: rewardAmt > 0 && rewardFlowVal ? true : false,
                rewardEligiblityFlag: rewardFlowVal,
                TransactionReasonList: TransactionReasonList,
                OverRideReasonList: OverRideReasonList,
                reversalcharge: this.controller.get('rev') ? 'REVERSAL' : 'CHARGE',

                feeTypeName:
                  this.controller.get('selectedFromAcc').value != 'Other Fee'
                    ? this.controller.get('selectedFromAcc').value
                    : this.controller.get('otherFeeType').value,
                feeTypeID:
                  this.controller.get('selectedFromAcc').id != 'Other Fee'
                    ? this.controller.get('selectedFromAcc').id
                    : this.controller.get('otherFeeType').id,
                countryCode: this.get('queries.countryName')
              }
            ];
            let pageDataPartial = [
              {
                customerFlowFlag: this.get('queries.customerFlowFlag') ? true : false,
                indicatorFlag: this.currentModel.CreditCardDetails.indicatorFlag,
                cardSelectedDetails: paritalFlag ? vaildCardPartial : cardDetails,
                selectedData: true,
                commonErrorDesc: commonError,
                imgicon1: imgicon1,
                imgicon2: imgicon2,
                imgicon3: imgicon3,
                imgicon4: imgicon4,
                imgicon5: imgicon5,
                imgicon6: imgicon6,
                imgicon7: imgicon7,
                totalRewardPoints: rewardAmt,
                rewardFlag: rewardAmt > 0 && rewardFlowVal ? true : false,
                rewardEligiblityFlag: rewardFlowVal,
                TransactionReasonList: TransactionReasonList,
                OverRideReasonList: OverRideReasonList,
                reversalcharge: this.controller.get('rev') ? 'REVERSAL' : 'CHARGE',
                userGroup: this.controllerFor('card-feewavier.new-request').get('userGroup'),
                selectedAddVerification: this.controllerFor('card-feewavier.new-request').get(
                  'selectedAddVerification'
                ),
                selectedBasicVerification: this.controllerFor('card-feewavier.new-request').get(
                  'selectedBasicVerification'
                ),
                feeTypeName:
                  this.controller.get('selectedFromAcc').value != 'Other Fee'
                    ? this.controller.get('selectedFromAcc').value
                    : this.controller.get('otherFeeType').value,
                feeTypeID:
                  this.controller.get('selectedFromAcc').id != 'Other Fee'
                    ? this.controller.get('selectedFromAcc').id
                    : this.controller.get('otherFeeType').id,
                countryCode: this.get('queries.countryName')
              }
            ];
            if (rewardAmt > 0 && rewardFlowVal) {
              this.controllerFor('card-feewavier.new-request').set('rewardData', true);
              this.controllerFor('card-feewavier.new-request').set('rewardAmount', rewardAmt);
              this.controllerFor('card-feewavier.cards-point').set('jsonRes', pageDataPartial);
              this.controllerFor('card-feewavier.new-request').set('jsonRes', pageData);
              this.transitionTo('card-feewavier.new-request');
            } else {
              /*routing for error page and transaction page according to response.*/
              if (errorFlag || imgicon4) {
                this.controllerFor('card-feewavier.card-validation').set('jsonRes', pageData);
                this.transitionTo('card-feewavier.card-validation');
              } else {
                this.controllerFor('card-feewavier.cards-point').set('jsonRes', pageData);
                //Alert for SG Non Assist
                if (!this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') === 'SG') {
                  this.get('rdcModalManager')
                    .showDialogModal({
                      level: 'warning',
                      message: this.get('i18n').t(
                        'ServiceRequest.CCFEEWAVIER.countryLinks.SG.notStaffAssist.sgNonStaffAssistPopText'
                      ),
                      rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
                      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
                      iconClass: 'service-journey-info-icon',
                      popupClass: 'service-journey-info-popup'
                    })
                    .then(() => {
                      this.transitionTo('card-feewavier.cards-point');
                    });
                } else {
                  this.transitionTo('card-feewavier.cards-point');
                }
              }
            }
          },
          error => {
            this.send('error', error);
          }
        );

      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(transactionRes, ' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
    },
    goToBack() {
      this.get('store').unloadAll('credit-card');
      this.controllerFor('card-feewavier.new-request').set('otherFee', false);
      this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
      this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
      this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
      this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', false);
      this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
      this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
      this.controllerFor('card-feewavier.new-request').set('rewardData', false);
      this.controllerFor('card-feewavier.charge-page').set('enableNextChargePage', false);
      this.controllerFor('card-feewavier.new-request').set('enableNext', false);
      this.controllerFor('service-request.new-request').set('selectedFeeType', '');

      this.transitionTo('serviceRequest.new-request');
    },
    enableNext() {
      if (
        this.controller.get('model').CreditCardDetails &&
        this.controller.get('model').CreditCardDetails.filterBy('isSelected').length > 0
      ) {
        this.controllerFor('card-feewavier.new-request').set('enableNext', true);
      } else {
        this.controllerFor('card-feewavier.new-request').set('enableNext', false);
      }
    },
    notProceed() {
      let OverRideReasonList = [];
      if (this.get('queries.countryName') == 'IN') {
        OverRideReasonList = [
          {
            id: 'Retention -  Customer wanted to go for cancellation if Reversal not given',
            value: 'Retention -  Customer wanted to go for cancellation if Reversal not given'
          },
          {
            id: 'Charges due to line decrease',
            value: 'Charges due to line decrease'
          },
          {
            id: 'Limit not assigned to Linked account',
            value: 'Limit not assigned to Linked account'
          },
          {
            id: 'Cancelled/Void transaction credited by merchant',
            value: 'Cancelled/Void transaction credited by merchant'
          },
          {
            id: 'Charges due to dispute on foreign currency conversion amount',
            value: 'Charges due to dispute on foreign currency conversion amount'
          },
          {
            id: 'Valid dispute transaction credited by charge back unit',
            value: 'Valid dispute transaction credited by charge back unit'
          },
          {
            id: 'Draft cancelled basis indemnity bond ',
            value: 'Draft cancelled basis indemnity bond '
          },
          {
            id: 'Draft lost not found',
            value: 'Draft lost not found'
          },
          {
            id: 'Draft RTOed but charges not reversed',
            value: 'Draft RTOed but charges not reversed'
          },
          {
            id: 'Delay in insurance cancellation',
            value: 'Delay in insurance cancellation'
          },
          {
            id: 'Mass error',
            value: 'Mass error'
          },
          {
            id: 'due to loan amount block',
            value: 'due to loan amount block'
          },
          {
            id: 'due to usage of buffer limit',
            value: 'due to usage of buffer limit'
          },
          {
            id: 'other reasons',
            value: 'other reasons'
          },
          {
            id: 'Apportionment issue',
            value: 'Apportionment issue'
          },
          {
            id: 'Cheque not found',
            value: 'Cheque not found'
          },
          {
            id: 'Delay in credit of repayment',
            value: 'Delay in credit of repayment'
          },
          {
            id: 'Delay in reciept of repayment',
            value: 'Delay in reciept of repayment'
          },
          {
            id: 'ECS mandate not received',
            value: 'ECS mandate not received'
          },
          {
            id: 'Delay in reversal of earlier waiver',
            value: 'Delay in reversal of earlier waiver'
          },
          {
            id: 'Erroneous charges levied',
            value: 'Erroneous charges levied'
          },
          {
            id: 'Insurance cancellation not done',
            value: 'Insurance cancellation not done'
          },
          {
            id: 'Marketing related Reversal eg. Surcharge reversal etc.',
            value: 'Marketing related Reversal eg. Surcharge reversal etc.'
          },
          {
            id: 'Wrong information provided at frontline',
            value: 'Wrong information provided at frontline'
          },
          {
            id: 'Card RTOed and loan accounts closed resulting in charges',
            value: 'Card RTOed and loan accounts closed resulting in charges'
          },
          {
            id: 'Incorrect closure of instabuy accounts resulting on charges',
            value: 'Incorrect closure of instabuy accounts resulting on charges'
          },
          {
            id: 'Charges due to upgrade or downgrade of account',
            value: 'Charges due to upgrade or downgrade of account'
          },
          {
            id: 'Earlier reversals given in non payment mode (Cash back, dispute credit etc)',
            value: 'Earlier reversals given in non payment mode (Cash back, dispute credit etc)'
          },
          {
            id: 'Escalation -  customer not accepting hence reversing',
            value: 'Escalation -  customer not accepting hence reversing'
          },
          {
            id: 'Family death hence delayed payment',
            value: 'Family death hence delayed payment'
          },
          {
            id: 'First time reversal',
            value: 'First time reversal'
          },
          {
            id: 'Medical emergency -  Hence no payment made',
            value: 'Medical emergency -  Hence no payment made'
          },
          {
            id: 'STAFF REVERSAL',
            value: 'STAFF REVERSAL'
          },
          {
            id: 'Delay in receipt of statement',
            value: 'Delay in receipt of statement'
          },
          {
            id: 'E-statement not accessible and No SMS received',
            value: 'E-statement not accessible and No SMS received'
          },
          {
            id: 'Statement not received',
            value: 'Statement not received'
          },
          {
            id: 'Trailing interest',
            value: 'Trailing interest'
          }
        ];
      }

      if (
        (this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') == 'SG') ||
        this.get('queries.countryName') == 'MY'
      ) {
        OverRideReasonList = [
          {
            id: 'Card Cancelled/Account Closure',
            value: 'Card Cancelled/Account Closure'
          },
          {
            id: 'Payment on due date',
            value: 'Payment on due date'
          },
          {
            id: 'Retention',
            value: 'Retention'
          },
          {
            id: 'Compassionate',
            value: 'Compassionate'
          },
          {
            id: 'Dispute Transaction',
            value: 'Dispute Transaction'
          },
          {
            id: 'High Net Worth/ VIP',
            value: 'High Net Worth/ VIP'
          },
          {
            id: 'High Risk Complaint',
            value: 'High Risk Complaint '
          },
          {
            id: 'Snowball charge due to Annual Fee',
            value: 'Snowball charge due to Annual Fee'
          },
          {
            id: 'Merchant Reversal/ Reversal',
            value: 'Merchant Reversal/ Reversal'
          },
          {
            id: 'Staff Error',
            value: 'Staff Error'
          },
          {
            id: 'System/ Mass error',
            value: 'System/ Mass error'
          },
          {
            id: 'Credit Balance in other Account',
            value: 'Credit Balance in other Account'
          },
          {
            id: 'Paid to Wrong Account',
            value: 'Paid to Wrong Account'
          },
          {
            id: 'Small Outstanding Amount',
            value: 'Small Outstanding Amount'
          }
        ];
      }

      if (this.get('queries.countryName') == 'HK') {
        OverRideReasonList = [
          {
            id: 'Goodwill ~ Wrong information provided',
            value: 'Goodwill ~ Wrong information provided'
          },
          {
            id: 'Goodwill ~ No Time / Forgot / Late / Non-Receipt of Stmt',
            value: 'Goodwill ~ No Time / Forgot / Late / Non-Receipt of Stmt'
          },
          {
            id: 'Goodwill ~ Payment Lost In Transit',
            value: 'Goodwill ~ Payment Lost In Transit'
          },
          {
            id: 'Goodwill ~ Branch Refer',
            value: 'Goodwill ~ Branch Refer'
          },
          {
            id: 'Goodwill ~ Corporate Account',
            value: 'Goodwill ~ Corporate Account'
          },
          {
            id: 'Operating Procedures ~ Card Cancellation',
            value: 'Operating Procedures ~ Card Cancellation'
          },
          {
            id: 'Operating Procedures ~ Exchange Rate Differ',
            value: 'Operating Procedures ~ Exchange Rate Differ'
          },
          {
            id: 'Operating Procedures ~ Retention',
            value: 'Operating Procedures ~ Retention'
          },
          {
            id: 'System / Operation Error ~ Branch Error ',
            value: 'System / Operation Error ~ Branch Error '
          },
          {
            id: 'System / Operation Error ~ Operation Error',
            value: 'System / Operation Error ~ Operation Error '
          },
          {
            id: 'System / Operation Error ~ System Error / Constraint',
            value: 'System / Operation Error ~ System Error / Constraint'
          }
        ];
      }

      let pageData = [
        {
          imgicon1: false,
          imgicon2: false,
          imgicon3: false,
          imgicon4: true,
          imgicon5: false,
          imgicon6: false,
          imgicon7: false,
          commonErrorDesc: this.get('i18n').t('ServiceRequest.CCFEEWAVIER.commonErrtext'),
          rewardFlag: false,
          cardSelectedDetails: this.controllerFor('card-feewavier.new-request').jsonRes[0].cardSelectedDetails,
          selectedData: true,
          OverRideReasonList: OverRideReasonList,
          reversalcharge: this.controller.get('rev') ? 'REVERSAL' : 'CHARGE',

          feeTypeName:
            this.controller.get('selectedFromAcc').value != 'Other Fee'
              ? this.controller.get('selectedFromAcc').value
              : this.controller.get('otherFeeType').value,
          feeTypeID:
            this.controller.get('selectedFromAcc').id != 'Other Fee'
              ? this.controller.get('selectedFromAcc').id
              : this.controller.get('otherFeeType').id,
          indicatorFlag: this.currentModel.CreditCardDetails.indicatorFlag,
          countryCode: this.get('queries.countryName')
        }
      ];

      this.controllerFor('card-feewavier.card-validation').set('jsonRes', pageData);
      this.transitionTo('card-feewavier.card-validation');
    },

    yesProceed() {
      this.transitionTo('card-feewavier.cards-point');
    },

    radioChargeReversal() {
      this.get('store').unloadAll('credit-card');
      this.controllerFor('card-feewavier.new-request').set('rev', true);
      this.controllerFor('card-feewavier.new-request').set('charge', false);
      this.controllerFor('card-feewavier.new-request').set('otherFee', false);
      this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
      this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
      this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
      this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
      this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
      this.transitionTo('card-feewavier.new-request');
    },

    radioChargeCharge() {
      this.get('store').unloadAll('credit-card');
      this.controllerFor('card-feewavier.charge-page').set('rev', false);
      this.controllerFor('card-feewavier.charge-page').set('charge', true);
      this.controllerFor('card-feewavier.new-request').set('otherFee', false);
      this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
      this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
      this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
      this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
      this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
      this.transitionTo('card-feewavier.charge-page');
    },
    error: function() {
      this.controllerFor('cardFeewavier').set('loaderInProgress', false);
      this.controllerFor('serviceRequest').set('cancelPopup', false);
      this.controllerFor('serviceRequest').set('systemErrorPopup', true);
      let message = this.get('i18n').t('ServiceRequest.CCFEEWAVIER.text.systemError.content');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          acceptButtonLabel: 'Cancel Request',
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.controllerFor('serviceRequest').set('systemErrorPopup', false);
          this.transitionTo('serviceRequest.new-request');
        });

      this.set('loaderInProgress', false);
    },
    loading(transition) {
      transition.promise.finally(() => {
        this.controllerFor('serviceRequest.new-request').set('loaderInProgress', false);
        this.controllerFor('cardFeewavier').set('loaderInProgress', false);
      });
    },

    close() {
      this.get('store').unloadAll('credit-card');
      this.transitionTo('serviceRequest.new-request');
    }
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.setProperties({
      nonStaffAssist: this.controllerFor('card-feewavier').get('staffAssist'),
      cardMasking: this.queries.cardMasking()
    });

    //Staff Assist False
    if (!this.controllerFor('card-feewavier').staffAssist && this.get('queries.countryName') === 'SG') {
      this.controller.set('notStaffAssist', true);
    } else {
      this.controller.set('notStaffAssist', false);
    }
    if (document.getElementById('ccf-focus-id')) {
      later(() => {
        document.getElementById('ccf-focus-id').scrollIntoView();
      }, 5);
    }
    let chkRoutename = null;
    let chkConfirmRoutename = null;
    if (this.get('router.currentRouteName')) {
      chkRoutename = this.get('router.currentRouteName').indexOf('new-request') !== -1 ? true : false;
      chkConfirmRoutename = this.get('router.currentRouteName').indexOf('cards-point') !== -1 ? true : false;
    }

    this.controllerFor('card-feewavier.new-request').set('nextBtnEnabled', false);
    this.controllerFor('card-feewavier.new-request').set('rev', true);
    this.controllerFor('card-feewavier.new-request').set('charge', false);
    this.controllerFor('card-feewavier.new-request').set('otherFee', false);
    this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
    this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
    this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
    this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
    this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
    this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
    this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
    this.controllerFor('card-feewavier.new-request').set('rewardData', false);
    this.controllerFor('card-feewavier.charge-page').set('enableNextChargePage', false);
    this.controllerFor('card-feewavier.new-request').set('enableNext', false);
    if (
      this.get('queries.countryName') === 'LK' ||
      this.get('queries.countryName') === 'NP' ||
      this.get('queries.countryName') === 'BN' ||
      this.get('queries.countryName') === 'MY' ||
      this.get('queries.countryName') === 'SG'
    ) {
      controller.setProperties({
        selectedFromAcc: model.AccListt[0]
      });
      this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', controller.get('selectedFromAcc'));
      this.controllerFor('card-feewavier.new-request').set('activeCCList', true);
      this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
      if ((!chkConfirmRoutename && chkRoutename) || (chkRoutename === null && chkConfirmRoutename === null)) {
        let CCDetails = this.currentModel.CreditCardDetails;
        if (!isEmpty(CCDetails.modelName)) {
          CCDetails.forEach(childVal => {
            if (childVal.isSelected) {
              set(childVal, 'isSelected', false);
            }
          });
        }
        this.controllerFor('card-feewavier.new-request').set('enableNext', false);
      } else {
        this.controllerFor('card-feewavier.new-request').set('enableNext', true);
      }
    }

    /* transition login for notes */

    /* transition login for notes */

    controller.set(
      'countryLinks',
      this.get('i18n').t('ServiceRequest.CCFEEWAVIER.countryLinks.' + this.get('queries.countryName'))
    );
    controller.set(
      'countryLinksTxt',
      this.get('i18n').t('ServiceRequest.CCFEEWAVIER.countryLinksTxt.' + this.get('queries.countryName'))
    );
    controller.set('links', controller.get('countryLinksTxt').toString());
    if (model.CreditCardDetails && model.CreditCardDetails.errorFlagVal) {
      controller.setProperties({
        countryNotes: this.get('i18n').t(
          'ServiceRequest.CCFEEWAVIER.validationCountryNotes.' + this.get('queries.countryName'),
          {
            inter_link: controller.get('links')
          }
        )
      });
    } else {
      controller.setProperties({
        countryNotes: this.get('i18n').t('ServiceRequest.CCFEEWAVIER.countryNotes.' + this.get('queries.countryName'), {
          inter_link: controller.get('links')
        })
      });
    }
    let getval = controller.get('countryNotes').toString();
    let res = getval.split('<br>');
    let appendtext = '';
    for (let i = 0; i < res.length; i++) {
      appendtext += '<li>' + res[i] + '</li>';
    }
    appendtext = htmlSafe('<ul>' + appendtext + '</ul>');
    controller.setProperties({
      notemessages: appendtext
    });
  }
});
