import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { later } from '@ember/runloop';

export default Route.extend({
  customerInfo: service(),
  i18n: service(),
  store: service(),
  rdcModalManager: service(),
  model: function() {
    let controller = this.controllerFor('card-feewavier.request-status');
    this.controllerFor('card-feewavier').set('leftIcon', '');
    controller.set('resSuccessCount', 0);
    controller.set('resFailureCount', 0);
    controller.set('resStatus', 'S');
    controller.set('cardMasking', this.customerInfo.cardMasking());
    controller.set('maskConfig', this.customerInfo.cardMaskConfig());
    controller.set('nonStaffAssist', this.controllerFor('card-feewavier').staffAssist);

    let cardDetails = controller.get('cardDetails');

    return cardDetails;
  },
  actions: {
    gotoHome() {
      this.get('store').unloadAll('credit-card');
      this.controllerFor('card-feewavier.new-request').set('creditCardDetails', null);
      this.transitionTo('serviceRequest.status');
      this.controllerFor('card-feewavier.card-validation').set('override', false);
      this.controllerFor('card-feewavier.card-validation').set('enableForOverRide', false);
      this.controllerFor('card-feewavier.card-validation').set('enableNextButton', false);
      this.controllerFor('card-feewavier.cards-point').set('enableNextButton', false);
    }
  },

  setupController(controller, model) {
    //MY Non Staff Assist Suceess Text
    if (!this.controllerFor('card-feewavier').staffAssist && this.get('customerInfo.countryName') === 'MY') {
      this.controller.set(
        'statusSuccessInfo',
        this.get('i18n').t('ServiceRequest.CCFEEWAVIER.statusMsg.notStaffAssistSuccessMsg')
      );
    } else {
      this.controller.set('statusSuccessInfo', this.get('i18n').t('ServiceRequest.CCFEEWAVIER.statusMsg.success'));
    }

    later(() => {
      document.getElementById('ccf-focus-id').scrollIntoView();
    }, 5);
    this._super(controller, model);
    switch ("controller.get('resStatus')") {
      case 'S':
        controller.set('responseVal', 'success');
        controller.set('resClass', 'success-block-lg');
        break;
      case 'F':
        controller.set('responseVal', 'failure');
        controller.set('resClass', 'warning');
        break;
      case 'I':
        controller.set('responseVal', 'incomplete');
        controller.set('resClass', 'partialwarning');
        break;
    }
    controller.set('responseVal', 'success');
    controller.set('resClass', 'success-block-lg');
    controller.set('resValTmp', this.get('i18n').t('ServiceRequest.COMMON.progress.' + controller.get('responseVal')));
    controller.set(
      'resContentTmp',
      this.get('i18n').t('ServiceRequest.CCFEEWAVIER.statusMsg.' + controller.get('responseVal'), {
        refNo: controller.get('resRefNo')
      })
    );
    this.controllerFor('card-feewavier').set('loaderInProgress', false);
  }
});
