import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  postDataForm: service('credit-card'),
  error: service('card-error-handler'),
  rdcLoadingIndicator: service(),

  model: function() {
    //Masking for MY Non Staff
    this.controllerFor('card-feewavier.selected-card').set('cardMasking', this.queries.cardMasking());
    this.controllerFor('card-feewavier.selected-card').set('maskConfig', this.queries.cardMaskConfig());
    this.controllerFor('card-feewavier.selected-card').set(
      'nonStaffAssist',
      this.controllerFor('card-feewavier').staffAssist
    );

    later(() => {
      document.getElementById('ccf-focus-id').scrollIntoView();
    }, 5);
    return this.controllerFor('card-feewavier.selected-card').get('cardCredit');
  },
  actions: {
    goToBack() {
      if (this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].postingData[0].override) {
        this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].postingData;
        this.transitionTo('card-feewavier.cards-point');
      } else {
        this.transitionTo('card-feewavier.cards-point');
      }
    },
    goToBackCharge() {
      this.get('store').unloadAll('credit-card');
      this.controllerFor('card-feewavier.new-request').set('rev', false);
      this.controllerFor('card-feewavier.new-request').set('charge', true);
      this.controllerFor('card-feewavier.new-request').set('otherFee', false);
      this.controllerFor('card-feewavier.new-request').set('activeCCList', false);
      this.controllerFor('card-feewavier.charge-page').set('otherFee', false);
      this.controllerFor('card-feewavier.charge-page').set('activeCCList', false);
      this.controllerFor('card-feewavier.new-request').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.new-request').set('otherFeeType', '');
      this.controllerFor('card-feewavier.charge-page').set('selectedFromAcc', '');
      this.controllerFor('card-feewavier.charge-page').set('otherFeeType', '');
      this.controllerFor('card-feewavier.charge-page').set('enableNextChargePage', false);
      this.transitionTo('card-feewavier.charge-page');
    },

    navigateSatus() {
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      let pageDataVal = [
        {
          customerFlowFlag: this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].customerFlowFlag,
          postedData: this.controllerFor('card-feewavier.selected-card').get('cardCredit'),
          rewardFlag: this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].rewardFlag,
          rewardRemaining: this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].rewardRemaining,
          charge: this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].charge == true ? true : false,
          reasonChange: this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].reasonChange,
          textData: this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].textData,
          txnCurrency: this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].txnCurrency,
          reasonSelected: this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].reasonSelected,
          notes: this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].notes,
          indicatorFlag: this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].indicatorFlag,
          bannerValidFlag:
            !this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].customerFlowFlag &&
            this.controllerFor('card-feewavier.selected-card').get('cardCredit')[0].countryCode == 'HK'
              ? true
              : false
        }
      ];

      let pageData = this.controllerFor('card-feewavier.selected-card').get('cardCredit');

      let postReqData = this.get('postDataForm').callForData(pageData);

      let postData = this.get('store').createRecord('credit-card', postReqData);

      postData.save().then(
        postResData => {
          this.controllerFor('card-feewavier.request-status').set('cardDetails', pageDataVal);
          this.controllerFor('card-feewavier.request-status').set('cardResData', postResData.get('receiptId'));
          this.get('rdcLoadingIndicator').hideLoadingIndicator(
            this.get('i18n').t('ServiceRequest.COMMON.loadingIndicatorText')
          );
          this.transitionTo('card-feewavier.request-status');
        },
        () => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator(
            this.get('i18n').t('ServiceRequest.COMMON.loadingIndicatorText')
          );
          this.controllerFor('card-feewavier.request-status').set('errorPopUp', true);
          let message = this.get('i18n').t('ServiceRequest.COMMON.systemError'),
            title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              message,
              title,
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest')
            })
            .then(() => {
              this.get('rdcLoadingIndicator').hideLoadingIndicator(
                this.get('i18n').t('ServiceRequest.COMMON.loadingIndicatorText')
              );
              this.controllerFor('card-feewavier.request-status').set('errorPopUp', false);
              this.get('store').unloadAll('credit-card');
              this.transitionTo('serviceRequest.new-request');
            })
            .catch(() => {
              this.get('rdcLoadingIndicator').hideLoadingIndicator(
                this.get('i18n').t('ServiceRequest.COMMON.loadingIndicatorText')
              );
              this.transitionTo('serviceRequest.new-request');
            });
        }
      );
    }
  }
});
