import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';

export default Route.extend({
  i18n: service(),
  classNames: ['rdc-cards col-lg-3'],
  rdcLoadingIndicator: service(),
  store: service(),
  postDataForm: service('cardblock-replacement-save'),
  rdcModalManager: service(),
  customerInfo: service(),
  router: service(),

  model: function() {
    return this.controllerFor('card-replacement.select').get('cardData');
  },
  setupController(controller, model) {
    this._super(controller, model);
    if (this.get('router.currentRouteName').indexOf('status') == -1) {
      controller.set('disableConfirm', false);
    }
    controller.set('label', this.get('i18n').t('ServiceRequest.CARDREPLACEMENT.cardlistHeader2'));
    if (controller.get('model')[0].selectedCard != null && controller.get('model')[0].selectedCard.length > 0) {
      controller.set('creditlabel', controller.get('label'));
    } else {
      controller.set('debitlabel', controller.get('label'));
    }
    let creditCardalias = controller.get('model')[0].selectedCard;
    let debitCardalias = controller.get('model')[0].selectedDebitCard;
    creditCardalias != null && creditCardalias.length && (debitCardalias != null && debitCardalias.length)
      ? controller.set('cardQuantity', 'multi-cards')
      : controller.set('cardQuantity', 'single-card');
  },
  actions: {
    goToBack() {
      this.transitionTo('card-replacement.select');
    },

    navigateSatus(model) {
      this.controller.set('disableConfirm', true);
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      this.get('store').unloadAll('service-request');
      let postData = this.get('store').createRecord('service-request', this.get('postDataForm').callForData(model));
      postData.save().then(
        () => {
          let postResData = this.get('store').peekAll('service-request');
          this.controllerFor('card-replacement.confirm').set('cardData', model);
          this.controllerFor('card-replacement.confirm').set('cardResData', postResData);
          this.transitionTo('card-replacement.status');
        },
        () => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.controllerFor('card-replacement.confirm').set('errorPopUp', true);
          let message = this.get('i18n').t(
              'ServiceRequest.COMMON.genericError.' + this.get('customerInfo.countryName')
            ),
            title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              message,
              title,
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
              iconClass: 'service-journey-system-error-icon',
              popupClass: 'service-journey-system-error-popup'
            })
            .then(() => {
              this.controllerFor('card-replacement.confirm').set('errorPopUp', false);
              this.get('store').unloadAll('credit-card');
              this.get('store').unloadAll('debit-card');
              this.transitionTo('serviceRequest.new-request');
            })
            .catch(() => {
              this.transitionTo('serviceRequest.new-request');
            });
        }
      );
    }
  }
});
