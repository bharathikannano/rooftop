import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
export default Route.extend({
  i18n: service(),
  store: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  customerInfo: service(),
  model: function() {
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
    let controller = this.controllerFor('card-replacement.confirm');
    this.controllerFor('card-replacement').set('leftIcon', '');
    this.set('resSuccessCount', 0);
    this.set('resFailureCount', 0);
    let cardDetails = controller.get('cardData'),
      cardResponseData = controller.get('cardResData');
    cardResponseData.forEach(item => {
      this.set('resRefNo', item.id);

      let creditCardData = cardDetails[0].selectedCard;
      let debitCardData = cardDetails[0].selectedDebitCard;

      if (creditCardData != null) {
        creditCardData.forEach(
          function(item) {
            item.set(
              'data.cardStatus',
              this.get('i18n')
                .t('ServiceRequest.COMMON.progress.submit')
                .toString()
            );
            item.data.statuscolor = 'bgcolor-green';
          }.bind(this)
        );
      }
      if (debitCardData != null) {
        debitCardData.forEach(
          function(item) {
            item.set(
              'data.cardStatus',
              this.get('i18n')
                .t('ServiceRequest.COMMON.progress.submit')
                .toString()
            );
            item.data.statuscolor = 'bgcolor-green';
          }.bind(this)
        );
      }
      this.set('resStatus', 'S');
    });
    return cardDetails;
  },

  setupController(controller, model) {
    this._super(controller, model);
    controller.set(
      'contactLinks',
      this.get('i18n').t('ServiceRequest.COMMON.contactLinks.' + this.get('customerInfo.countryName'))
    );
    controller.set('contactLinksTxt', this.get('i18n').t('ServiceRequest.COMMON.contactLinksTxt.default'));
    controller.set(
      'contactUsLink',
      this.get('contactLinks') != ''
        ? htmlSafe(
            '<a href="javascript:;" onclick ="window.open(\'' +
              controller.get('contactLinks').toString() +
              "','_system')\">" +
              controller.get('contactLinksTxt').toString() +
              '</a>'
          )
        : htmlSafe('<a href="javascript:;">' + this.get('contactLinksTxt').toString() + '</a>')
    );
    controller.set('refNumber', this.get('resRefNo'));
    controller.set('resClass', 'success-block-lg');
    controller.set('resValTmp', this.get('i18n').t('ServiceRequest.COMMON.progress.submit'));
    controller.set(
      'resContentTmp',
      this.get('i18n').t(
        'ServiceRequest.CARDREPLACEMENT.statusMsg.' + this.get('customerInfo.countryName') + '.success',
        {
          refNo: this.get('resRefNo'),
          contactUsLink: controller.get('contactUsLink'),
          default: 'ServiceRequest.CARDREPLACEMENT.statusMsg.success'
        }
      )
    );
  },

  actions: {
    goToBack() {
      this.transitionTo('card-replacement.confirm');
    },
    navigateSatus() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
      this.transitionTo('serviceRequest.status');
    }
  }
});
