import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import constants from '../constants';
import { isNone, isBlank, isEmpty } from '@ember/utils';
import { A } from '@ember/array';
import EmberObject from '@ember/object';
import { alias } from '@ember/object/computed';
import CryptoJS from 'cryptojs';
import config from 'rdc-ui-eng-service-requests/config/environment';

export default Route.extend({
  rdcModalManager: service(),
  store: service(),
  rdcLoadingIndicator: service(),
  i18n: service(),
  queries: service('customer-info'),
  init() {
    this._super(...arguments);
    this._parseHREF();
  },
  COUNTRYCONFIG: constants.COUNTRYCONFIG,
  country: alias('queries.countryName'),
  _getOptsListObj() {
    let setOpt = this.get('COUNTRYCONFIG');
    let countryName = this.get('queries.countryName');
    let list = setOpt[countryName] ? setOpt[countryName] : null;
    return list ? list.availableSettings : list;
  },
  _getOptsListArray() {
    let optsList = EmberObject.create(this._getOptsListObj());
    let optsNameList = A();
    let keys = Object.keys(optsList);
    const PREFIX = 'settingsDesc';
    for (let i = 0; i < keys.length; i++) {
      if (optsList[keys[i]]) {
        optsNameList.pushObject(this._translation(keys[i], PREFIX));
      }
    }
    return optsNameList;
  },
  _encryptCardNum(data) {
    data.forEach(item => {
      item.set('cardNumEncrypted', CryptoJS.SHA256(item.get('cardNum')).toString());
    });
    return data;
  },
  _setCreditCardStatus(data) {
    this.set('creditCardStatus', data && data.length == 0 ? 'emptyAndNoError' : 'CreditCardSuccess');
  },
  _queryCards() {
    let countryCode = this.get('queries.countryName');
    let CreditCardDetails = this.get('store')
      .query('credit-card', {
        filter: config.Filters.creditCardControl.API[countryCode]
      })
      .then(
        data => {
          data = this._encryptCardNum(data);
          data = this._without_loadn_cards(data);
          data = this._hide_same_number_supplementary(data);
          data = this._only_MC_and_Visa(data);
          data = this._set_card_desc_i18n(data);
          data = this._hide_card_holder_name(data);
          data = this._only_have_supplementary_card(data);
          data = this._have_same_customerId(data);
          data = this._hide_invalid_block_codes(data);
          data = this._hide_invalid_card_statuses(data);
          data = this._hide_invalid_card_ack_statuses(data);
          data = this._hide_invalid_emboss_status(data);
          data = this._hide_duplicate_card_numbers(data);
          this._setCreditCardStatus(data);
          return data;
        },
        error => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.errorHandler(error);
        }
      );
    return CreditCardDetails;
  },
  _peekCards() {
    let CreditCardDetails = this.get('store').peekAll('credit-card');
    return CreditCardDetails;
  },
  _hide_duplicate_card_numbers(data) {
    let cardNumList = data.map(item => {
      return item.get('cardNum');
    });
    return data.filter((item, index) => {
      return cardNumList.indexOf(item.get('cardNum')) == index;
    });
  },
  _hide_invalid_emboss_status(data) {
    let countryCode = this.get('queries.countryName');
    if (
      !config.Filters.creditCardControl[countryCode] ||
      !config.Filters.creditCardControl[countryCode].isCardEmbossed
    ) {
      return data;
    }
    let validEmbossStatuses = config.Filters.creditCardControl[countryCode].isCardEmbossed;
    return data.filter(item => {
      let embossStatus =
        isNone(item.get('isCardEmbossed')) || isEmpty(item.get('isCardEmbossed')) || isBlank(item.get('isCardEmbossed'))
          ? 'empty'
          : item.get('isCardEmbossed');
      return validEmbossStatuses.includes(embossStatus);
    });
  },
  _hide_invalid_card_ack_statuses(data) {
    let countryCode = this.get('queries.countryName');
    if (!config.Filters.creditCardControl[countryCode] || !config.Filters.creditCardControl[countryCode].ackStatus) {
      return data;
    }
    let validAckStatuses = config.Filters.creditCardControl[countryCode].ackStatus;
    return data.filter(item => {
      let ackStatus =
        isNone(item.get('ackStatus')) || isEmpty(item.get('ackStatus')) || isBlank(item.get('ackStatus'))
          ? 'empty'
          : item.get('ackStatus');
      return validAckStatuses.includes(ackStatus);
    });
  },
  _hide_invalid_block_codes(data) {
    let countryCode = this.get('queries.countryName');
    if (!config.Filters.creditCardControl[countryCode] || !config.Filters.creditCardControl[countryCode].blockCode) {
      return data;
    }
    let validBlockCodes = config.Filters.creditCardControl[countryCode].blockCode;
    return data.filter(item => {
      let blockCode =
        isNone(item.get('blockCode')) || isEmpty(item.get('blockCode')) || isBlank(item.get('blockCode'))
          ? 'empty'
          : item.get('blockCode');
      return validBlockCodes.includes(blockCode);
    });
  },
  _hide_invalid_card_statuses(data) {
    let countryCode = this.get('queries.countryName');
    if (
      !config.Filters.creditCardControl[countryCode] ||
      !config.Filters.creditCardControl[countryCode].cardStatusForListing
    ) {
      return data;
    }
    let cardStatusesForListing = config.Filters.creditCardControl[countryCode].cardStatusForListing;
    return data.filter(item => {
      let cardStatus =
        isNone(item.get('cardStatus')) || isEmpty(item.get('cardStatus')) || isBlank(item.get('cardStatus'))
          ? 'empty'
          : item.get('cardStatus');
      return cardStatusesForListing.includes(cardStatus);
    });
  },
  _translation(item, prefix) {
    let path = 'ServiceRequest.CREDITCARD.cardSetting.' + prefix + '.' + item;
    return this.get('i18n').t(path);
  },
  _trackEvent(ctry, a, l, v) {
    if (window.dataLayer) {
      let dataObject = {
        event: 'trackEvent',
        'eventDetails.category': 'card management - card settings',
        'eventDetails.action': a || 'click',
        'eventDetails.label': '/' + ctry + '/service-request/card-setting/' + l
      };
      if (typeof v !== 'undefined') {
        dataObject['eventDetails.value'] = v;
      }
      window.dataLayer.push(dataObject);
    }
  },
  _set_card_desc_i18n(data) {
    data.forEach(element => {
      if (!element.get('desc') && element.get('descCode')) {
        let digit = element.get('descCode').toString()[0],
          CardDesc,
          setDefault;
        setDefault =
          digit === 5
            ? 'MaestroCard'
            : digit === 4
            ? 'VisaCard'
            : digit === 0
            ? 'AmexCard'
            : digit === 6
            ? 'CUPCard'
            : 'DefaultCard';
        CardDesc = this.get('i18n').t('ServiceRequest.creditCardDesc.' + element.get('descCode'), {
          default: 'ServiceRequest.defaultcreditCardDesc.' + setDefault
        });
        element.set('desc', CardDesc);
      }
    });
    return data;
  },
  _only_have_supplementary_card(data) {
    this.set('onlyHaveSupplementaryCard', data.length === data.filter(item => item.get('primaryFlag') !== 'Y').length);
    return data;
  },
  _hide_same_number_supplementary(data) {
    let arrTmp = data.filter(item => item.get('primaryFlag') === 'Y');
    arrTmp = A(arrTmp.map(item => item.get('cardNum')));
    return data.filter(item => !(item.get('primaryFlag') !== 'Y' && arrTmp.includes(item.get('cardNum'))));
  },
  _hide_card_holder_name(data) {
    let supCards = data.filter(item => item.get('primaryFlag') !== 'Y');
    data.forEach(element => {
      if (element.get('primaryFlag') === 'Y') {
        supCards.forEach(sup => {
          if (sup.get('grpAccNum') === element.get('grpAccNum') && sup.get('cardNum') !== element.get('cardNum')) {
            element.set('isShowCustShortName', true);
          }
        });
      } else {
        element.set('isShowCustShortName', true);
      }
    });
    return data;
  },
  _only_MC_and_Visa(data) {
    data.forEach(item => {
      let cardType = item.get('cardType');
      let allCardType = item.get('allCardType') ? item.get('allCardType').toUpperCase() : cardType.toUpperCase();
      if (!isNone(allCardType) && (allCardType.indexOf('VISA') !== -1 || allCardType.indexOf('MASTERCARD') !== -1)) {
        item.set('mcOrVisa', true);
      } else {
        item.set('mcOrVisa', false);
      }
    });
    return data;
  },
  _without_loadn_cards(data) {
    //loan card number start with 9, filter with out loan card
    return data.filter(item => item.get('cardNum').indexOf('9') != 0);
  },
  _have_same_customerId(data) {
    //should be verified again
    let customerId;
    data.forEach(element => {
      if (element.get('primaryFlag') === 'Y') {
        customerId = element.get('customerId');
      }
    });
    return data.filter(item => !isBlank(item.get('customerId')) && item.get('customerId') === customerId);
  },
  _parseHREF(srcURL = document.location.href) {
    if (srcURL) {
      srcURL = srcURL.split('?')[1];
      if (srcURL) {
        srcURL = srcURL.split('&');
        let countryCode, langId;
        srcURL.forEach(item => {
          if (item.indexOf('ctry') !== -1) {
            countryCode = item.split('=')[1];
          } else if (item.indexOf('lang') !== -1) {
            langId = item.split('=')[1];
          }
        });
        if (countryCode) {
          this.set('queries.countryName', countryCode.toUpperCase());
        }
        if (langId) {
          this.set('queries.langId', langId);
        }
      }
    }
  },
  setupController(controller) {
    this._super(...arguments);
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    controller.set('rightIcon', this.get('queries.hideClose') === 'Y' ? '' : 'sc-icon uxlab-icon-sc-s-cross');
    controller.set('navTitleText', this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.journeyHeader'));
  },
  actions: {
    closePopupAction() {
      let message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
      this.get('_trackEvent')(this.get('country'), 'close', '', 'close');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          this.transitionTo('serviceRequest.new-request');
          this.controller.set('clickCancel', false);
        });
    }
  }
});
