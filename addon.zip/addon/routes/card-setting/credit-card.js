/* eslint-disable no-useless-escape */
import RSVP from 'rsvp';
import { inject as service } from '@ember/service';
import Route from '../card-setting';
import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';

const SCOPE0 = 'All_Overseas_Countries';

export default Route.extend({
  store: service(),
  i18n: service(),
  queries: service('customer-info'),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  rdcAjax: service(),

  init() {
    this._super();
    this.setProperties({
      params: {},
      settingOptions: this.get('COUNTRYCONFIG')
    });
  },
  _getCardAttr(obj, attr) {
    return obj.get(attr);
  },
  _getOptsList() {
    let setOpt = this.get('settingOptions');
    let countryName = this.get('country');
    return setOpt[countryName] ? setOpt[countryName] : null;
  },
  _checkCountryLimit(countries, scope, notification) {
    if (notification && scope !== SCOPE0) {
      if (countries.length === 0) {
        return false;
      }
    }
    return true;
  },
  _call_error_up(msg = this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.ERROR')) {
    this.get('rdcModalManager').showDialogModal({
      level: 'error',
      message: msg,
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },
  _updateSettingsVisibility(controller) {
    if (!isEmpty(controller.model.cardSettings.countrylimitvisibility)) {
      controller.set(
        'model.settingOptionsList.availableSettings.countryLimits',
        controller.model.cardSettings.countrylimitvisibility
      );
    }
    if (!isEmpty(controller.model.cardSettings.transactionlimitvisibility)) {
      controller.set(
        'model.settingOptionsList.availableSettings.transactionLimit',
        controller.model.cardSettings.transactionlimitvisibility
      );
    }
    if (!isEmpty(controller.model.cardSettings.paymentchannelvisibility)) {
      controller.set(
        'model.settingOptionsList.availableSettings.paymentChannels',
        controller.model.cardSettings.paymentchannelvisibility
      );
    }
    if (!isEmpty(controller.model.cardSettings.controlledcategoryvisibility)) {
      controller.set(
        'model.settingOptionsList.availableSettings.controlledCategories',
        controller.model.cardSettings.controlledcategoryvisibility
      );
    }
  },
  beforeModel() {
    this.set('settingOptions', this.get('COUNTRYCONFIG'));
  },
  setupController(controller, model) {
    this._super(...arguments);
    controller.set('needSaveButton', null);
    controller.set('saveButtonStatus', null);
    let country = this.get('country');
    controller.set('country', country);
    controller.set('rightIcon', this.get('queries.hideClose') === 'Y' ? '' : 'sc-icon uxlab-icon-sc-s-cross');

    let card = model.cards.filter(card => card.get('cardNumEncrypted') === model['cardNumber']);
    if (card.length) {
      model.selectedCardObject = card[0];
      model.cardType = this._getCardAttr(card[0], 'allCardType').replace(/mastercard/gi, 'MasterCard');
      model.defaultSettingObj['cardSchemes'] = model.cardType.split(',');
    }
    controller.set('_trackEvent', this.get('_trackEvent'));
    controller.set('showNotesInsteadOfTNC', this.get('queries.countryName').toUpperCase() === 'MY');
    this._updateSettingsVisibility(controller);
  },
  afterModel() {
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },
  _getSettingObj(cardNumEncrypted, min, cardType) {
    return {
      id: cardNumEncrypted,
      isN: true,
      tmpblock: false,
      translimitnotify: false,
      translimitamount: min,
      translimitblock: false,
      paychannelblock: false,
      onlineecommerce: false,
      contactless: false,
      physicalsale: false,
      categoriesblock: false,
      accessories: false,
      travel: false,
      entertainment: false,
      gas: false,
      groceries: false,
      household: false,
      countryblock: false,
      countrynotify: false,
      scope: SCOPE0,
      countries: A(),
      cardType: 'CreditCard',
      cardSchemes: cardType.split(',')
    };
  },
  model(params) {
    let store = this.get('store'),
      settingOptionsList = this._getOptsList(),
      cardNumEncrypted = params.cardNumEncrypted,
      cardObj,
      cardType,
      defaultSettingObj,
      return404Obj,
      rsvpObj,
      min;

    let cards = this._peekCards();

    min = settingOptionsList.minLimit;

    cardType = '';
    defaultSettingObj = this._getSettingObj(cardNumEncrypted, min, cardType);

    //should refact
    return404Obj = data => {
      if (data && data.errors && +data.errors[0].status === 404) {
        delete data.errors;
        return store.createRecord('card-setting', defaultSettingObj);
      } else if ((data && data.errors && data.errors[0].code) || (data && data.code)) {
        let msg;
        msg =
          data.errors && data.errors[0].code
            ? this.get('i18n').t('ServiceRequest.CREDITCARD_ERROR_MAP.' + data.errors[0].code, {
                default: 'ServiceRequest.CREDITCARD.cardSetting.terminateRequest'
              })
            : this.get('i18n').t('ServiceRequest.CREDITCARD_ERROR_MAP.' + data.code, {
                default: 'ServiceRequest.CREDITCARD.cardSetting.terminateRequest'
              });
        this.get('rdcLoadingIndicator').hideLoadingIndicator();
        this._call_error_up(msg);
        this.transitionTo('card-setting.index');
      } else {
        let msg =
          data && data.errors
            ? data.errors[0].detail
            : this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.terminateRequest');
        this.get('rdcLoadingIndicator').hideLoadingIndicator();
        this._call_error_up(msg);
        this.transitionTo('card-setting.index');
      }
    };
    rsvpObj = {
      defaultSettingObj,
      tmpBlockTxt: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.TMPBLOCKTXT'),
      cardNumber: cardNumEncrypted,
      cardType: cardType,
      cards,
      selectedCardObject: cardObj,
      cardSettings: store
        .findRecord('card-setting', cardNumEncrypted)
        .then(data => {
          let countries = data.get('countries'),
            scope = data.get('scope'),
            clnotification = data.get('countrynotify');
          if (this._checkCountryLimit(countries, scope, clnotification)) {
            return data;
          } else {
            this._call_error_up().then(() => {
              this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
              this.transitionTo('card-setting.index');
            });
          }
        })
        .catch(return404Obj),
      settingOptionsList
    };
    return RSVP.hash(rsvpObj);
  },
  actions: {
    openTermsAndConditionsPopup() {
      this.get('_trackEvent')(this.get('country'), 'terms-conditions');

      if (this.get('country') === 'SG') {
        this.get('rdcAjax')
          .raw('https://www.sc.com/sg/terms-and-conditions/cardsettings/', {
            method: 'GET',
            dataType: 'html'
          })
          .then(response => {
            let loadedDoc = new DOMParser().parseFromString(response.payload, 'text/html');
            let title = this.get('i18n').t('ServiceRequest.COMMON.termsAndConditions.title');
            let message = loadedDoc.querySelector('.message').innerHTML;

            this.get('rdcModalManager')
              .showDialogModal({
                popupClass: 'terms-conditions-popup',
                level: 'warning',
                message,
                title,
                acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.close')
              })
              .then(() => {
                this.get('rdcLoadingIndicator').hideLoadingIndicator(
                  this.get('i18n').t('ServiceRequest.COMMON.loadingIndicatorText')
                );
              })
              .catch(() => {
                this.get('rdcLoadingIndicator').hideLoadingIndicator(
                  this.get('i18n').t('ServiceRequest.COMMON.loadingIndicatorText')
                );
              });
          });
      } else {
        let message = this.get('i18n').t('ServiceRequest.COMMON.termsAndConditions');
        let title = this.get('i18n').t('ServiceRequest.COMMON.termsAndConditions.title');
        this.get('rdcModalManager')
          .showDialogModal({
            popupClass: 'terms-conditions-popup',
            level: 'warning',
            message,
            title,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.close')
          })
          .then(() => {
            this.get('rdcLoadingIndicator').hideLoadingIndicator(
              this.get('i18n').t('ServiceRequest.COMMON.loadingIndicatorText')
            );
          })
          .catch(() => {
            this.get('rdcLoadingIndicator').hideLoadingIndicator(
              this.get('i18n').t('ServiceRequest.COMMON.loadingIndicatorText')
            );
          });
      }
    }
  }
});
