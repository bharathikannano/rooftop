import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { A } from '@ember/array';
import $ from 'jquery';
import EmberObject from '@ember/object';
import { isBlank } from '@ember/utils';
import { alias } from '@ember/object/computed';
import constants from '../../../constants';
import { later } from '@ember/runloop';

let CS = 'cardSettings',
  LOADING = 'rdcLoadingIndicator',
  BLOCK = 'countryblock',
  NOTIFY = 'countrynotify',
  SCOPE = 'scope',
  FLAG = 'showList',
  COUNTRY = 'countries',
  PG = 'country-limits';

// const SCOPETA = ['Any overseas country', 'All overseas countries except...', 'These specific countries:'];
const SCOPEVA = ['All_Overseas_Countries', 'All_Countries_Except', 'Specific_Countries'];

export default Route.extend({
  i18n: service(),
  cp: null,
  cs: null,
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  countriesOld: '',
  countrySelectFlag: null,
  queries: service('customer-info'),
  country: alias('queries.countryName'),
  model() {
    return EmberObject.create(this.modelFor('card-setting.credit-card'));
  },
  _setDefaultSchemes() {
    let mod = this.controller.model.get('cardSettings');
    mod.set(
      'cardSchemes',
      this.controller.model
        .get('selectedCardObject')
        .get('cardType')
        .replace(/mastercard/gi, 'MasterCard')
        .split(',')
    );
  },
  _setSettingsType() {
    let mod = this.controller.model.cardSettings;
    mod.set('settingsType', 'OverseasTransactions');
  },
  _setFlag() {
    let conl = this.controller;
    let type = conl.get(SCOPE);
    if (type && +conl.get('optList').indexOf(type) === 0) {
      conl.set(FLAG, false);
    } else {
      conl.set(FLAG, true);
    }
  },
  _rollbackNewAttr(cs, changedAttrs, key, value = false) {
    if (cs) {
      if (Object.keys(changedAttrs).includes(key)) {
        cs.set(key, value);
      }
    } else {
      return false;
    }
  },
  _rollbackSettings() {
    let parentMod = this.controller.model;
    let cs = parentMod.cardSettings;
    if (cs.get('isN')) {
      let changedAttrs = cs.changedAttributes();
      this._rollbackNewAttr(cs, changedAttrs, BLOCK);
      this._rollbackNewAttr(cs, changedAttrs, NOTIFY);
      this._rollbackNewAttr(cs, changedAttrs, COUNTRY, A());
      this._rollbackNewAttr(cs, changedAttrs, SCOPE, SCOPEVA[0]);
    } else {
      parentMod.cardSettings.rollbackAttributes();
      let countriesOld = this.get('countriesOld');
      if (isBlank(countriesOld)) {
        cs.set(COUNTRY, A());
      } else {
        cs.set(COUNTRY, A(countriesOld.split(',')));
      }
    }
  },
  _hasCountries() {
    let cnty = this.get('cs').get(COUNTRY);
    return cnty && cnty.length;
  },
  _isCountriesChanged() {
    let cs = this.get('cs'),
      hasCountry = this._hasCountries();
    if (cs.get('isN')) {
      return hasCountry;
    } else {
      let ctrs = cs.get(COUNTRY),
        str = '';
      if (ctrs && ctrs.length) {
        str = ctrs
          .concat()
          .sort()
          .join(',');
      }
      return this.get('countriesOld') !== str;
    }
  },
  _isOptionsChanged() {
    let model = this.controller.model;
    let cs = model.get(CS);
    let hasCountry = this._hasCountries();
    if (cs.get('isN')) {
      let notify = cs.get(NOTIFY);
      let block = cs.get(BLOCK);
      let type = SCOPEVA.indexOf(cs.get(SCOPE));
      return notify || block || hasCountry || type !== 0;
    } else {
      let changedAttrs = cs.changedAttributes();
      let isNotifyChanged = NOTIFY in changedAttrs;
      let isBlockChanged = BLOCK in changedAttrs;
      let isTypeChanged = SCOPE in changedAttrs;
      let countriesChanged = this._isCountriesChanged();
      return isBlockChanged || isNotifyChanged || isTypeChanged || countriesChanged;
    }
  },
  _getSaveStatus() {
    let model = this.controller.model;
    let cs = model.get(CS),
      notify = cs.get(NOTIFY),
      type = SCOPEVA.indexOf(cs.get(SCOPE)),
      hasCountry = this._hasCountries(),
      countryChanged = this._isCountriesChanged();
    if (cs.get('isN')) {
      if (notify) {
        if (type === 0) {
          return true;
        } else {
          return hasCountry;
        }
      } else {
        return false;
      }
    } else {
      let changedAttrs = cs.changedAttributes();
      if (NOTIFY in changedAttrs) {
        if (notify) {
          if (type === 0) {
            return true;
          } else {
            return hasCountry;
          }
        } else {
          return true;
        }
      } else {
        if (notify) {
          if (SCOPE in changedAttrs) {
            if (type === 0) {
              return true;
            } else {
              return hasCountry;
            }
          } else {
            if (type === 0) {
              return BLOCK in changedAttrs;
            } else {
              if (hasCountry) {
                if (countryChanged) {
                  return true;
                } else {
                  return BLOCK in changedAttrs;
                }
              } else {
                return false;
              }
            }
          }
        } else {
          return false;
        }
      }
    }
  },
  _setSaveStatus(bl) {
    this.get('cp').set('saveButtonStatus', bl);
  },
  _updateSaveStatus() {
    let bl = this._getSaveStatus();
    this._setSaveStatus(bl);
  },
  _setDefaultCardType() {
    let mod = this.get('cs');
    if (!mod.get('cardType')) {
      mod.set('cardType', 'CreditCard');
    }
  },
  _setAllControlledCategoriesToFalse() {
    let country = this.get('country');
    if (country == 'SG' || country == 'MY') {
      let parentMod = this.controller.model;
      let cs = parentMod.cardSettings;
      cs.setProperties({
        accessories: false,
        gas: false,
        travel: false,
        entertainment: false,
        groceries: false,
        household: false,
        categoriesblock: false
      });
    }
  },
  _save() {
    this._setAllControlledCategoriesToFalse();
    this._setDefaultSchemes();
    this._setSettingsType();
    this._setDefaultCardType();
    this.get(LOADING).showLoadingIndicator(' ');
    let cs = this.get('cs');
    cs.save().then(
      () => {
        this.set('clickCancel', false);
        this.get('rdcLoadingIndicator').hideLoadingIndicator(' ');
        this._setSaveStatus(false);
        this._updateCountriesOld();
        this.controller.set(SCOPE, this.controller.get('optList')[SCOPEVA.indexOf(cs.get(SCOPE))]);
        this._showSuccessMsg();
        cs.set('isN', false);
      },
      error => {
        let ref, ref1;
        if (
          error &&
          (typeof error !== 'undefined' && error !== null ? error.errors : void 0) &&
          +(typeof error !== 'undefined' && error !== null
            ? (ref = error.errors) != null
              ? (ref1 = ref[0]) != null
                ? ref1.status
                : void 0
              : void 0
            : void 0) === 404
        ) {
          cs.set('isN', true);
          this.get('cp').set('saveButtonStatus', false);
          cs.set('isError', false);
          cs.setProperties(this.controller.model.defaultSettingObj);
          cs.set(COUNTRY, A());
          this.get(LOADING).hideLoadingIndicator(' ');
          this._showSuccessMsg();
        } else {
          this._call_error_up();
        }
        this.get('rdcLoadingIndicator').hideLoadingIndicator(' ');
      }
    );
  },
  _call_error_up() {
    this.get('rdcModalManager').showDialogModal({
      level: 'error',
      message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.ERROR'),
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },
  _setSuccessStatus(bl) {
    this.get('cp').setProperties({
      needPopMsg: bl,
      hasButton: '',
      showMsgTxt: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.settingsSaved'),
      msgIconClass: 'uxlab-icon-sc-s-global'
    });
  },
  _showSuccessMsg() {
    this._setSuccessStatus(true);
    this._destroySuccessMsg();
  },
  _destroySuccessMsg() {
    later(() => {
      this._setSuccessStatus(false);
    }, 4000);
  },
  _call_pop_up() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.notSaveConfirm'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
        this._rollbackSettings();
        later(() => {
          this._goBack();
        }, 500);
      })
      .catch(() => {});
  },
  _goBack() {
    this.get(LOADING).hideLoadingIndicator(' ');
    this.transitionTo('card-setting.credit-card', this.controller.model.selectedCardObject.get('cardNumEncrypted'));
  },
  _updateCountriesOld() {
    let cs = this.controller.model.get(CS);
    if (cs && cs.get(COUNTRY)) {
      let ctrTMP = cs.get(COUNTRY);
      if (ctrTMP && ctrTMP.length) {
        this.set(
          'countriesOld',
          ctrTMP
            .concat()
            .sort()
            .join(',')
        );
      } else {
        this.set('countriesOld', '');
      }
    } else {
      this.set('countriesOld', '');
    }
  },
  _initTypeList() {
    let conl = this.controller;
    if (conl.get('model')) {
      let cs = conl.get('model').get('cardSettings');
      if (cs) {
        let type = cs.get(SCOPE);
        if (!type) {
          type = SCOPEVA[0];
          cs.set(SCOPE, conl.get('optList')[SCOPEVA.indexOf(type)]);
        }
        conl.set(SCOPE, conl.get('optList')[SCOPEVA.indexOf(type)]);
        conl.set('cs', cs);
        this._setFlag();
      }
    }
  },
  _checkShouldAlert() {
    let parentMod = this.controller.model;
    let cs = parentMod.cardSettings;
    return cs.get(BLOCK) && cs.get(NOTIFY);
  },
  _showConfirmWhenBlock() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.SETBLOCK'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this.get('cp').get('_trackEvent')(this.get('country'), 'confirm', PG);
        this._save();
      })
      .catch(() => {
        this.get('cp').get('_trackEvent')(this.get('country'), 'cancel', PG);
      });
  },
  setupController(controller) {
    this._super(...arguments);
    let cs = controller.model.get(CS);
    this.set('cs', cs);
    this._updateCountriesOld();
    let cParent = this.controllerFor('card-setting.credit-card');
    this.set('cp', cParent);
    let country = cParent.get('country');
    let SCOPETA = [
      this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.countryLimitsPage.anyOverseasCountries'),
      this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.countryLimitsPage.allOverseasCountriesExcept'),
      this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.countryLimitsPage.theseSpecificCountries')
    ];
    controller.setProperties({
      countryListShowFlag: false,
      searchText: '',
      optList: SCOPETA,
      setSelected: this.get('setSelected'),
      _setCountrySelectFlag: this.get('_setCountrySelectFlag'),
      issueCountry: country,
      hideCountryLimitsSelection: this.shouldHideCountryLimitsSelection(country)
    });

    if (this.shouldHideCountryLimitsSelection(country)) {
      cs.set(BLOCK, false);
    }

    cParent.setProperties({
      navTitleText: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.settingsTitle.countryLimits'),
      needSaveButton: true,
      saveButtonStatus: false
    });

    this._initTypeList();
    this._setSuccessStatus(false);
  },
  afterModel() {
    this._super(...arguments);
    if (document) {
      let cardSettingWrapper = document.getElementsByClassName('rdc-view-credit-card-setting');
      later(() => {
        if (cardSettingWrapper) {
          cardSettingWrapper[0].addEventListener('click', e => {
            let t = $(e.target).closest('.add-country');
            if (t.length === 0) {
              this.controller.set('countryListShowFlag', false);
              this.controller.set('SearchText', '');
            }
          });
        }
      }, 0);
    }
  },
  shouldHideCountryLimitsSelection(country) {
    return constants.cardSettingsConfig.countriesToHideCountryLimitsSelection.includes(country);
  },
  actions: {
    setSelected(item) {
      let conl = this.controller;
      conl.set(SCOPE, item);
      let indOf = conl.get('optList').indexOf(item);
      let scopeTxt = SCOPEVA[indOf];
      this.get('cp').get('_trackEvent')(this.get('country'), 'overseas-transactions-control', PG, ++indOf);
      this._setFlag();
      this.get('cs').set(SCOPE, scopeTxt);
      this._updateSaveStatus();
    },
    notify() {
      let notifyOn = this.get('cs').get(NOTIFY);
      this.get('cp').get('_trackEvent')(this.get('country'), 'notifications-toggle', PG, ++notifyOn);
      this._updateSaveStatus();
    },
    checkSave() {
      this.get('cp').get('_trackEvent')(this.get('country'), 'block-checkbox', PG);
      this._updateSaveStatus();
    },
    selectCountry(itm) {
      this.get('cp').get('_trackEvent')(this.get('country'), 'add-country', PG, itm.countryId);
      this._isOptionsChanged();

      let cs = this.get('cs');
      if (cs.get(COUNTRY)) {
        cs.get(COUNTRY).pushObject(itm.countryId);
      } else {
        cs.set(COUNTRY, A([itm.countryId]));
      }
      this._updateSaveStatus();
    },
    removeCountry(itm) {
      this.get('cp').get('_trackEvent')(this.get('country'), 'remove-country', PG, itm.countryId);
      this._isOptionsChanged();

      let cs = this.controller.model.get(CS);
      cs.get(COUNTRY).removeObject(itm.countryId);
      this._updateSaveStatus();
    },
    saveSetting() {
      this.get('cp').get('_trackEvent')(
        this.get('country'),
        'save',
        PG,
        '[' +
          this.controller.model
            .get(CS)
            .get(COUNTRY)
            .join(',') +
          ']'
      );
      let cp = this.get('cp');
      if (cp.get('saveButtonStatus')) {
        if (this._checkShouldAlert()) {
          this._showConfirmWhenBlock();
        } else {
          this._save();
        }
      }
    },
    goToBack() {
      this.get('cp').get('_trackEvent')(this.get('country'), 'back', PG);
      if (this._isOptionsChanged()) {
        this._call_pop_up();
      } else {
        this.get(LOADING).showLoadingIndicator(' ');
        this._goBack();
      }
    }
  }
});
