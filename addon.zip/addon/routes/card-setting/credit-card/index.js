import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { isNone } from '@ember/utils';
import { alias } from '@ember/object/computed';
import { later } from '@ember/runloop';

const PG = 'dashboard';

export default Route.extend({
  rdcModalManager: service(),
  i18n: service(),
  rdcLoadingIndicator: service(),
  queries: service('customer-info'),
  country: alias('queries.countryName'),
  _rollbackSettings() {
    let parentMod = this.controller.model;
    let cs = parentMod.cardSettings;
    const TMP = 'tmpblock';
    if (cs.get('isN')) {
      let changedAttrs = cs.changedAttributes();
      if (Object.keys(changedAttrs).includes(TMP)) {
        cs.set(TMP, false);
      }
    } else {
      parentMod.cardSettings.rollbackAttributes();
    }
  },
  _setDefaultSchemes() {
    let mod = this.controller.model.cardSettings;
    mod.set(
      'cardSchemes',
      this.controller.model['selectedCardObject']
        .get('cardType')
        .replace(/mastercard/gi, 'MasterCard')
        .split(',')
    );
  },
  _setSettingsType() {
    let mod = this.controller.model.cardSettings;
    mod.set('settingsType', 'TemporaryBlock');
  },
  _setSuccessStatus(bl) {
    this.get('cp').setProperties({
      needPopMsg: bl,
      hasButton: 'noButton',
      // 'showMsgTxt': 'Settings saved!',
      showMsgTxt: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.settingsSaved'),
      msgIconClass: 'uxlab-icon-sc-s-secure-private'
    });
  },
  _showSuccessMsg() {
    this._setSuccessStatus(true);
    this._destroySuccessMsg();
  },
  _destroySuccessMsg() {
    later(() => {
      this._setSuccessStatus(false);
    }, 4000);
  },
  _setAllControlledCategoriesToFalse() {
    let country = this.get('country');
    if (country == 'SG' || country == 'MY') {
      let parentMod = this.controller.model;
      let cs = parentMod.cardSettings;
      cs.setProperties({
        accessories: false,
        gas: false,
        travel: false,
        entertainment: false,
        groceries: false,
        household: false,
        categoriesblock: false
      });
    }
  },
  _save() {
    this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
    let mod = this.controller.model.cardSettings;
    this._setAllControlledCategoriesToFalse();
    this._setDefaultSchemes();
    this._setSettingsType();
    mod.save().then(
      () => {
        this.set('clickCancel', false);
        this.get('rdcLoadingIndicator').hideLoadingIndicator(' ');
        this._showSuccessMsg();
      },
      error => {
        let ref, ref1;
        if (
          error &&
          (typeof error !== 'undefined' && error !== null ? error.errors : void 0) &&
          +(typeof error !== 'undefined' && error !== null
            ? (ref = error.errors) != null
              ? (ref1 = ref[0]) != null
                ? ref1.status
                : void 0
              : void 0
            : void 0) === 404
        ) {
          mod.set('isN', true);
          mod.set('isError', false);
          mod.setProperties(this.controller.model.defaultSettingObj);
          this.get('rdcLoadingIndicator').hideLoadingIndicator(' ');
          this._showSuccessMsg();
        } else {
          this._call_error_up();
          this.get('rdcLoadingIndicator').hideLoadingIndicator(' ');
          this._rollbackSettings();
        }
      }
    );
  },
  _call_error_up() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'error',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.ERROR'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this._rollbackSettings();
      });
  },
  _call_pop_up() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.TMPBLOCK'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this.get('cp').get('_trackEvent')(this.get('country'), 'confirm', PG);
        this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
        this._save();
      })
      .catch(() => {
        this.get('cp').get('_trackEvent')(this.get('country'), 'cancel', PG);
        this._rollbackSettings();
      });
  },
  //below two func can refact to one
  _paychannelIsOn() {
    let parentMod = this.controller.model;
    let cs = parentMod.cardSettings;
    let onlineecommerce = isNone(cs.get('onlineecommerce')) ? false : cs.get('onlineecommerce');
    let contactless = isNone(cs.get('contactless')) ? false : cs.get('contactless');
    let physicalsale = isNone(cs.get('physicalsale')) ? false : cs.get('physicalsale');
    return onlineecommerce || contactless || physicalsale;
  },
  _categoriesIsOn() {
    let parentMod = this.controller.model;
    let cs = parentMod.cardSettings;
    let accessories = isNone(cs.get('accessories')) ? false : cs.get('accessories');
    let travel = isNone(cs.get('travel')) ? false : cs.get('travel');
    let entertainment = isNone(cs.get('entertainment')) ? false : cs.get('entertainment');
    let groceries = isNone(cs.get('groceries')) ? false : cs.get('groceries');
    let gas = isNone(cs.get('gas')) ? false : cs.get('gas');
    let household = isNone(cs.get('household')) ? false : cs.get('household');
    return accessories || entertainment || travel || groceries || gas || household;
  },
  _countfeature(model) {
    let avlb = model.settingOptionsList.availableSettings;
    return (
      'cs-set-cnt' + (+avlb.transactionLimit + +avlb.paymentChannels + +avlb.controlledCategories + +avlb.countryLimits)
    );
  },
  _setCPTitleAndButton(cParent, title) {
    cParent.set('navTitleText', title);
    cParent.set('needSaveButton', null);
    cParent.set('saveButtonStatus', null);
    cParent.set('needApplyButton', null);
    return cParent;
  },
  setupController(cont, mod) {
    this._super(...arguments);
    let cParent = this.controllerFor('card-setting.credit-card');
    //let cont = this.controller;
    //let mod = this.controller.model;
    cont.set('csSettingAvailableCnt', this._countfeature(mod));
    let navTitleText = this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.journeyHeader');
    cParent = this._setCPTitleAndButton(cParent, navTitleText);
    cont.set('paychannel', this._paychannelIsOn());
    cont.set('categories', this._categoriesIsOn());
    cont.set('hideToolTip', this.get('country').toUpperCase() === 'SG');
    this.set('cp', cParent);
    this._setSuccessStatus(false);
  },
  model() {
    return this.modelFor('card-setting.credit-card');
  },
  actions: {
    goToBack() {
      this.get('cp').get('_trackEvent')(this.get('country'), 'back', PG);
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.transitionTo('card-setting.index');
    },
    tog() {
      let parentMod = this.controller.model,
        tmpON = parentMod.cardSettings.get('tmpblock');
      this[tmpON ? '_call_pop_up' : '_save']();
      this.get('cp').get('_trackEvent')(this.get('country'), 'tmp-lock', PG, ++tmpON);
    },
    redirectToTransactionLimit: function(routeInfo, selectedCardId) {
      if (typeof routeInfo != 'undefined' && routeInfo.length > 0) {
        let ra = routeInfo.split('.');
        this.get('cp').get('_trackEvent')(this.get('country'), ra[ra.length - 1], PG);
        this.transitionTo(routeInfo, selectedCardId);
      }
    }
  }
});
