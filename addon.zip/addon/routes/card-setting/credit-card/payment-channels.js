import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { isNone } from '@ember/utils';
import { alias } from '@ember/object/computed';
import { later } from '@ember/runloop';

const LOADING = 'rdcLoadingIndicator',
  OECISON = 'onlineecommerce',
  CISON = 'contactless',
  PPOSISON = 'physicalsale',
  PCBLOCK = 'paychannelblock',
  PG = 'payment-channels';
const GAMAP = {
  onlineecommerce: 'online-channel-toggle',
  contactless: 'contactless-channel-toggle',
  physicalsale: 'contact-channel-toggle',
  paychannelblock: 'block-checkbox'
};

export default Route.extend({
  i18n: service(),
  cp: null,
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  country: alias('queries.countryName'),
  _call_pop_up() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.notSaveConfirm'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this.get(LOADING).showLoadingIndicator(' ');
        this._rollbackSettings();
        later(() => {
          this._goBack();
        }, 500);
      });
  },
  _call_error_up() {
    this.get('rdcModalManager').showDialogModal({
      level: 'error',
      message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.ERROR'),
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },
  _goBack() {
    this.get(LOADING).hideLoadingIndicator(' ');
    this.transitionTo('card-setting.credit-card', this.controller.model.selectedCardObject.get('cardNumEncrypted'));
  },
  _rollbackSettings() {
    let parentMod = this.controller.model;
    let cs = parentMod.cardSettings;
    if (cs.get('isN')) {
      let changedAttrs = cs.changedAttributes();
      if (Object.keys(changedAttrs).includes(OECISON)) {
        cs.set(OECISON, false);
      }
      if (Object.keys(changedAttrs).includes(CISON)) {
        cs.set(CISON, false);
      }
      if (Object.keys(changedAttrs).includes(PPOSISON)) {
        cs.set(PPOSISON, false);
      }
      if (Object.keys(changedAttrs).includes(PCBLOCK)) {
        cs.set(PCBLOCK, false);
      }
    } else {
      parentMod.cardSettings.rollbackAttributes();
    }
  },
  _isChanged(item) {
    let parentMod = this.controller.model;
    let cs = parentMod.cardSettings;
    let def = parentMod.defaultSettingObj;
    let changedAttrs = cs.changedAttributes();
    if (cs.get('isN')) {
      return cs.get(item);
    } else {
      if (item in changedAttrs) {
        if (isNone(changedAttrs[item][0]) && (isNone(cs.get(item)) ? def[item] : cs.get(item)) === def[item])
          return false;
        return true;
      }
    }
    return false;
  },
  _setSuccessStatus(bl) {
    this.get('cp').setProperties({
      needPopMsg: bl,
      hasButton: '',
      showMsgTxt: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.settingsSaved'),
      msgIconClass: 'uxlab-icon-sc-s-arrow-swap'
    });
  },
  _showSuccessMsg() {
    this._setSuccessStatus(true);
    this._destroySuccessMsg();
  },
  _destroySuccessMsg() {
    later(() => {
      this._setSuccessStatus(false);
    }, 4000);
  },
  _isOptionsAllFalse() {
    let parentMod = this.controller.model;
    let cs = parentMod.cardSettings;
    return !(cs.get(OECISON) || cs.get(CISON) || cs.get(PPOSISON));
  },
  _checkOptionsChanged() {
    return this._isChanged(OECISON) || this._isChanged(CISON) || this._isChanged(PPOSISON) || this._isChanged(PCBLOCK);
  },
  _checkShouldAlert() {
    return this.controller.model.cardSettings.get(PCBLOCK) && !this._isOptionsAllFalse();
  },
  _showConfirmWhenBlock() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.SETBLOCK'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this._trackEvent('confirm');
        this._save();
      })
      .catch(() => {
        this._trackEvent('cancel');
      });
  },
  _setDefaultSchemes() {
    let mod = this.controller.model.cardSettings;
    mod.set(
      'cardSchemes',
      this.controller.model.selectedCardObject
        .get('cardType')
        .replace(/mastercard/gi, 'MasterCard')
        .split(',')
    );
  },
  _setSettingsType() {
    let mod = this.controller.model.cardSettings;
    mod.set('settingsType', 'PaymentChannels');
  },
  _updateCheckbox() {
    this.controller.set('disabled', this._isOptionsAllFalse());
  },
  _checkSaveStatus() {
    let parentMod = this.controller.model;
    let cs = parentMod.cardSettings;
    let cp = this.get('cp');
    this._updateCheckbox();
    if (cs.get('isN')) {
      let bl = this._isOptionsAllFalse();
      cp.set('saveButtonStatus', !bl);
    } else {
      cp.set('saveButtonStatus', this._checkOptionsChanged());
    }
  },
  _updateBackUp() {
    let cs = this.controller.model.cardSettings;
    let backUp = this.controller.get('backUp');
    for (let attr in backUp) {
      backUp[attr] = cs.get(attr) ? cs.get(attr) : false;
    }
  },
  _findClickEvt() {
    let cs = this.controller.model.cardSettings;
    let backUp = this.controller.get('backUp');
    for (let attr in backUp) {
      if (backUp[attr] !== (cs.get(attr) ? cs.get(attr) : false)) {
        return attr;
      }
    }
  },
  _getGAValue(clickOpt) {
    let cs = this.controller.model.cardSettings;
    let value = cs.get(clickOpt) ? cs.get(clickOpt) : false;
    if (value) {
      return '2';
    } else {
      return '1';
    }
  },
  _clickGAEvt() {
    let clickOpt = this._findClickEvt();
    this._updateBackUp();
    if (clickOpt === 'paychannelblock') {
      this._trackEvent(GAMAP[clickOpt]);
    } else {
      this._trackEvent(GAMAP[clickOpt], this._getGAValue(clickOpt));
    }
  },
  _saveGAEvt() {
    this._trackEvent('save');
  },
  _setDisplayContactPayment() {
    this.controller.set('displayContactPayment', false);
    if (
      this.controller.model.selectedCardObject.cardType != 'Visa' ||
      this.get('country') === 'SG' ||
      this.get('country') === 'MY'
    ) {
      this.controller.set('displayContactPayment', true);
    }
  },
  setupController() {
    this._super(...arguments);
    let cParent = this.controllerFor('card-setting.credit-card');
    let cs = this.controller.model.cardSettings;
    this.controller.set('disabled', this._isOptionsAllFalse());
    this.controller.set('backUp', {
      onlineecommerce: cs.get(OECISON) ? cs.get(OECISON) : false,
      contactless: cs.get(CISON) ? cs.get(CISON) : false,
      physicalsale: cs.get(PPOSISON) ? cs.get(PPOSISON) : false,
      paychannelblock: cs.get(PCBLOCK) ? cs.get(PCBLOCK) : false
    });
    this._setDisplayContactPayment();
    this.set('cp', cParent);
    cParent.setProperties({
      navTitleText: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.settingsTitle.paymentChannels'),
      needSaveButton: true,
      saveButtonStatus: false
    });
    this._setSuccessStatus(false);
  },
  model() {
    return this.modelFor('card-setting.credit-card');
  },
  _setAllControlledCategoriesToFalse() {
    let country = this.get('country');
    if (country == 'SG' || country == 'MY') {
      let parentMod = this.controller.model;
      let cs = parentMod.cardSettings;
      cs.setProperties({
        accessories: false,
        gas: false,
        travel: false,
        entertainment: false,
        groceries: false,
        household: false,
        categoriesblock: false
      });
    }
  },
  _save() {
    let cp = this.get('cp');
    let modelParent = this.controller.model;
    let cardSettings = modelParent.cardSettings;
    this._setAllControlledCategoriesToFalse();
    this._setDefaultSchemes();
    this._setSettingsType();
    this.get(LOADING).showLoadingIndicator(' ');
    cardSettings.save().then(
      () => {
        cardSettings.set('isN', false);
        cp.set('saveButtonStatus', false);
        this.get(LOADING).hideLoadingIndicator(' ');
        this._showSuccessMsg();
      },
      error => {
        let ref, ref1;
        if (
          error &&
          (typeof error !== 'undefined' && error !== null ? error.errors : void 0) &&
          +(typeof error !== 'undefined' && error !== null
            ? (ref = error.errors) != null
              ? (ref1 = ref[0]) != null
                ? ref1.status
                : void 0
              : void 0
            : void 0) === 404
        ) {
          cardSettings.set('isN', true);
          cp.set('saveButtonStatus', false);
          cardSettings.set('isError', false);
          cardSettings.setProperties(this.controller.model.defaultSettingObj);
          this._showSuccessMsg();
        } else {
          this._call_error_up();
        }
        this.get(LOADING).hideLoadingIndicator(' ');
      }
    );
  },
  _trackEvent(a, v) {
    this.get('cp').get('_trackEvent')(this.get('country'), a, PG, v);
  },
  actions: {
    checkSaveStatus() {
      this._clickGAEvt();
      this._checkSaveStatus();
    },
    saveSetting() {
      this._saveGAEvt();
      if (this.get('cp').get('saveButtonStatus')) {
        if (this._checkShouldAlert()) {
          this._showConfirmWhenBlock();
        } else {
          this._save();
        }
        this._updateBackUp();
      }
    },
    goToBack() {
      this._trackEvent('back');
      if (this._isChanged(OECISON) || this._isChanged(CISON) || this._isChanged(PPOSISON) || this._isChanged(PCBLOCK)) {
        this._call_pop_up();
      } else {
        this.get(LOADING).showLoadingIndicator(' ');
        this._goBack();
      }
    }
  }
});
