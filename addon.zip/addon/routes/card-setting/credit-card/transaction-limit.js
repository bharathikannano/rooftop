import Route from '@ember/routing/route';
import EmberObject from '@ember/object';
import { inject as service } from '@ember/service';
import { alias } from '@ember/object/computed';
import { later } from '@ember/runloop';

const ISON = 'translimitnotify',
  AMOUNT = 'translimitamount',
  BLOCK = 'translimitblock',
  CS = 'cardSettings',
  LOADING = 'rdcLoadingIndicator',
  PG = 'transaction-limit';

export default Route.extend({
  rdcModalManager: service(),
  i18n: service(),
  rdcLoadingIndicator: service(),
  queries: service('customer-info'),
  country: alias('queries.countryName'),
  cp: null,
  cs: null,
  minLimit: null,
  defaultCS: null,
  min: null,
  isN: false,
  _isAmountChanged() {
    let cs = this.get('cs'),
      amount = cs.get(AMOUNT);
    if (cs.get('isN')) {
      if (amount && amount != this.get('min')) {
        return true;
      } else {
        return false;
      }
    } else {
      let changedAttrs = cs.changedAttributes();
      if (AMOUNT in changedAttrs) {
        let amounts = changedAttrs[AMOUNT];
        return this._formatToCurrency(amounts[0]) !== amounts[1];
      } else {
        return false;
      }
    }
  },
  _getAttrsChanged() {
    let cs = this.get('cs');
    if (cs.get('isN')) {
      return cs.get(ISON) || cs.get(BLOCK) || this._isAmountChanged();
    } else {
      let changedAttrs = cs.changedAttributes();
      if (ISON in changedAttrs) {
        return true;
      }
      if (BLOCK in changedAttrs) {
        return true;
      }
      if (this._isAmountChanged()) {
        return true;
      }
      return false;
    }
  },
  _getSaveButtonStatus() {
    let cs = this.get('cs'),
      isOn = cs.get(ISON),
      isValid = this._checkAmountValid();
    if (cs.get('isN')) {
      if (isOn) {
        return isValid;
      } else {
        return false;
      }
    } else {
      let changedAttrs = cs.changedAttributes();
      if (ISON in changedAttrs) {
        if (isOn) {
          return isValid;
        } else {
          return true;
        }
      } else if (this._isAmountChanged()) {
        if (isOn) {
          return isValid;
        } else {
          return false;
        }
      } else if (BLOCK in changedAttrs) {
        if (isOn) {
          return isValid;
        } else {
          return false;
        }
      } else {
        return false;
      }
    }
  },
  _setSaveButtonStatus(bl) {
    this.get('cp').set('saveButtonStatus', bl);
  },
  _setTransAmountStatus(txt, isAmountValid) {
    let ctr = this.controller;
    ctr.set('limitAlter', txt);
    ctr.set('isTranslimitAmountValid', isAmountValid);
    ctr.set('transLimitError', !isAmountValid);
    this.set('isAmountValid', isAmountValid);
  },
  _formatToCurrency(s) {
    if (/[^0-9.,]/.test(s)) {
      return 'invalid value';
    }
    s = s + '';
    s = s.replace(/^(\d*)$/, '$1.');
    s = (s + '00').replace(/(\d*\.\d\d)\d*/, '$1');
    s = s.replace('.', ',');
    let re = /(\d)(\d{3},)/;
    while (re.test(s)) {
      s = s.replace(re, '$1,$2');
    }
    s = s.replace(/,(\d\d)$/, '.$1');
    return s.replace(/^\./, '0.');
  },
  _call_error_up() {
    this.get('rdcModalManager').showDialogModal({
      level: 'error',
      message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.ERROR'),
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },
  _checkAmount() {
    let model = this.controller.model,
      cs = model.get(CS),
      card = model.get('selectedCardObject'),
      max = card.get('creditLimit'),
      min = this.get('min'),
      amount = cs.get('translimitamount');
    amount = amount ? parseFloat(amount.toString().replace(/,/g, '')) : min;
    if (isNaN(amount) || !amount) {
      cs.set(AMOUNT, min);
      amount = min;
    } else {
      cs.set(AMOUNT, this._formatToCurrency(amount));
    }
    if (amount < +min || isNaN(amount)) {
      return 'tooSmall';
    } else if (amount > +max) {
      return 'tooLarge';
    } else {
      return 'correct';
    }
  },
  _showAmountValid() {
    let model = this.controller.model,
      card = model.get('selectedCardObject'),
      currencyCode = card.get('currencyCode'),
      max = card.get('creditLimit'),
      min = this.get('min');
    let result = this._checkAmount();
    if (result == 'tooSmall') {
      this._setTransAmountStatus(
        this.get('i18n')
          .t('ServiceRequest.CREDITCARD.cardSetting.transactionLimitPage.minLimitAlert')
          .toString()
          .replace('_AMOUNT_', currencyCode + ' ' + this._formatToCurrency(min)),
        false
      );
    } else if (result == 'tooLarge') {
      this._setTransAmountStatus(
        this.get('i18n')
          .t('ServiceRequest.CREDITCARD.cardSetting.transactionLimitPage.maxLimitAlert')
          .toString()
          .replace('_AMOUNT_', currencyCode + ' ' + this._formatToCurrency(max)),
        false
      );
    } else {
      this._setTransAmountStatus('', true);
    }
  },
  _checkAmountValid() {
    return this._checkAmount() === 'correct';
  },
  _checkDataChanged() {
    this._setSaveButtonStatus(this._getSaveButtonStatus());
  },
  _rollbackSettings() {
    let parentMod = this.controller.model;
    let cs = parentMod.get(CS);
    if (cs.get('isN')) {
      cs.set(ISON, false);
      cs.set(AMOUNT, this.get('min'));
      cs.set(BLOCK, false);
    } else {
      cs.rollbackAttributes();
    }
  },

  _setDefaultSchemes() {
    let mod = this.controller.model.get('cardSettings');
    mod.set(
      'cardSchemes',
      this.controller.model
        .get('selectedCardObject')
        .get('cardType')
        .replace(/mastercard/gi, 'MasterCard')
        .split(',')
    );
  },
  _setSettingsType() {
    let mod = this.controller.model.cardSettings;
    mod.set('settingsType', 'TransactionLimit');
  },
  _setSuccessStatus(bl) {
    this.get('cp').setProperties({
      needPopMsg: bl,
      hasButton: '',
      showMsgTxt: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.settingsSaved'),
      msgIconClass: 'uxlab-icon-sc-s-money-other-cash'
    });
  },
  _showSuccessMsg() {
    this._setSuccessStatus(true);
    this._destroySuccessMsg();
  },
  _destroySuccessMsg() {
    later(() => {
      this._setSuccessStatus(false);
    }, 4000);
  },
  _setAllControlledCategoriesToFalse() {
    let country = this.get('country');
    if (country == 'SG' || country == 'MY') {
      let parentMod = this.controller.model;
      let cs = parentMod.cardSettings;
      cs.setProperties({
        accessories: false,
        gas: false,
        travel: false,
        entertainment: false,
        groceries: false,
        household: false,
        categoriesblock: false
      });
    }
  },
  _save() {
    this._setAllControlledCategoriesToFalse();
    this._setDefaultSchemes();
    this._setSettingsType();
    this.get(LOADING).showLoadingIndicator(' ');
    let mod = this.controller.model.get(CS),
      amount = mod.get(AMOUNT),
      cp = this.get('cp');
    mod.save().then(
      () => {
        this.get(LOADING).hideLoadingIndicator(' ');
        if (+mod.get(AMOUNT)) {
          mod.set(AMOUNT, this._formatToCurrency(amount));
        }
        mod.set('isN', false);
        this._setSaveButtonStatus(false);
        this._showSuccessMsg();
      },
      error => {
        let ref, ref1;
        if (
          error &&
          (typeof error !== 'undefined' && error !== null ? error.errors : void 0) &&
          +(typeof error !== 'undefined' && error !== null
            ? (ref = error.errors) != null
              ? (ref1 = ref[0]) != null
                ? ref1.status
                : void 0
              : void 0
            : void 0) === 404
        ) {
          mod.set('isN', true);
          cp.set('saveButtonStatus', false);
          mod.set('isError', false);
          mod.setProperties(this.controller.model.defaultSettingObj);
          this.get(LOADING).hideLoadingIndicator(' ');
          this._showSuccessMsg();
        } else {
          this._call_error_up();
          this.get(LOADING).hideLoadingIndicator(' ');
        }
      }
    );
  },
  _goBack() {
    this.get(LOADING).hideLoadingIndicator(' ');
    this.transitionTo(
      'card-setting.credit-card',
      this.controller.model.get('selectedCardObject').get('cardNumEncrypted')
    );
  },
  _call_pop_up() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.notSaveConfirm'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
        this._rollbackSettings();
        later(() => {
          this._goBack();
        }, 500);
      });
  },
  _checkShouldAlert() {
    let cs = this.get('cs');
    return cs.get(ISON) && cs.get(BLOCK);
  },
  _showConfirmWhenBlock() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.SETBLOCK'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this.get('cp').get('_trackEvent')(this.get('country'), 'confirm', PG);
        this._save();
      })
      .catch(() => {
        this.get('cp').get('_trackEvent')(this.get('country'), 'cancel', PG);
      });
  },
  setupController(controller) {
    this._super(...arguments);
    let cParent = this.controllerFor('card-setting.credit-card');
    this.set('cp', cParent);
    this.set('defaultCS', controller.get('model').get('defaultSettingObj'));
    this.set('cs', this.controller.model.get(CS));
    this.set(
      'min',
      parseInt(this.get('cs').get('globalminimumamount'))
        ? parseInt(this.get('cs').get('globalminimumamount')).toFixed(2)
        : this.controller.model.get('settingOptionsList').minLimit.toFixed(2)
    );

    cParent.setProperties({
      navTitleText: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.settingsTitle.transactionLimit'),
      needSaveButton: true,
      saveButtonStatus: false
    });

    this._setSuccessStatus(false);
  },
  model() {
    let scope = EmberObject.create(this.modelFor('card-setting.credit-card'));
    return scope;
  },
  afterModel(model) {
    if (model.get(CS).get(AMOUNT)) {
      model.get(CS).set(AMOUNT, this._formatToCurrency(model.get(CS).get(AMOUNT)));
    }
  },
  actions: {
    onKeyPress(event) {
      let evt = event ? event : window.event;
      let charCode = evt.which ? evt.which : evt.keyCode;
      if (charCode > 31 && charCode !== 46 && (charCode < 48 || charCode > 57)) {
        evt.preventDefault();
      }
    },
    limitCheck() {
      this._showAmountValid();
      this._checkDataChanged();
    },
    autoRemoveZero(event) {
      let evt = event ? event : window.event;
      if (evt) {
        let EL = evt.srcElement;
        EL.setSelectionRange(0, EL.value.length);
      }
    },
    undisplaySpecialSimbol() {
      let cs = this.get('cs');
      cs.set(AMOUNT, cs.get(AMOUNT).replace(/[^\d.,]/g, ''));
    },
    notify() {
      let notifyOn = this.get('cs').get(ISON);
      this.get('cp').get('_trackEvent')(this.get('country'), 'notifications-toggle', PG, ++notifyOn);
      this._checkDataChanged();
    },
    trigCheck() {
      this.get('cp').get('_trackEvent')(this.get('country'), 'block-checkbox', PG);
      this._checkDataChanged();
    },
    saveSetting() {
      let cp = this.get('cp');
      let amt = this.get('cs').get(AMOUNT);
      amt = amt.length ? amt.replace(/,|\.00$/g, '') : 0;
      this.get('cp').get('_trackEvent')(this.get('country'), 'save', PG, amt);
      if (cp.get('saveButtonStatus')) {
        this[this._checkShouldAlert() ? '_showConfirmWhenBlock' : '_save']();
      }
    },
    goToBack() {
      this.get('cp').get('_trackEvent')(this.get('country'), 'back', PG);
      this._setTransAmountStatus('', true);
      if (this._getAttrsChanged()) {
        this._call_pop_up();
      } else {
        this.get(LOADING).showLoadingIndicator(' ');
        this._goBack();
      }
    }
  }
});
