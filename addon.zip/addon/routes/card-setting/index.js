import { hash } from 'rsvp';
import { isNone, isBlank, isEmpty, typeOf } from '@ember/utils';
import { inject as service } from '@ember/service';
import Route from '../card-setting';

export default Route.extend({
  store: service(),
  i18n: service(),
  error: service('card-error-handler'),
  rdcModalManager: service(),
  idle: service('idle-ticker'),
  rdcLoadingIndicator: service(),
  onlyHaveSupplementaryCard: true,
  init() {
    this._super();
    this.get('store').unloadAll('credit-card');
  },
  _showLoading(txt, uiClass) {
    this.get('rdcLoadingIndicator').showLoadingIndicator(txt);
    this.get('rdcLoadingIndicator').setThemeClass(uiClass);
  },
  _setNoCardsHT() {
    this.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.nocard.header'));
    this.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.nocard.content'));
  },
  model() {
    this._showLoading(' ', 'ui10');
    this._setNoCardsHT();
    this.get('store').unloadAll('credit-card');
    let CreditCardDetails = this._queryCards();
    return hash({ CreditCardDetails });
  },
  afterModel(data) {
    data.nocardsTitle = this.get('nocardsTitle');
    data.nocardsContent = this.get('nocardsContent');
  },
  setupController(controller, model) {
    this._super(controller, model);
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
    let optsList = this._getOptsListArray();

    controller.set('optsList', optsList);

    let creditcard;
    if (!isNone(model) && !isNone(model.CreditCardDetails)) {
      creditcard = model.CreditCardDetails;
    }
    if (!(isBlank(creditcard) || isNone(creditcard)) || this.get('creditCardStatus') == 'CreditCardSuccess') {
      if (!this.get('onlyHaveSupplementaryCard')) {
        controller.set('dataAvailable', true);
      }
    } else {
      controller.set('dataAvailable', false);
      controller.set('needApplyButton', true);
    }
    controller.set('errorPopUp', this.errorPopUp);
    controller.set('errorAlert', this.errorMessage);

    let disclaimerNotes = this.get('i18n').t(
      'ServiceRequest.CREDITCARD.cardSetting.disclaimerNotes.' + this.get('countryCode')
    );

    if (
      !isEmpty(disclaimerNotes) &&
      !isEmpty(disclaimerNotes.string) &&
      disclaimerNotes.string.indexOf('Missing translation') == -1
    ) {
      controller.set('disclaimerNotes', disclaimerNotes);
    }
  },
  errorHandler(error) {
    // needed?
    this.set('creditCardStatus', 'CreditCardError');
    typeOf(error.errors) == 'undefined'
      ? this.set('CreditCardErrorcheck', 'undefined')
      : this.set('CreditCardErrorcheck', error.errors[0].code);
    this.get('error').creditCardErrorHandler(this);
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },
  actions: {
    goToBack() {
      this.get('_trackEvent')(this.get('country'), 'back', 'select');
      this.get('store').unloadAll('credit-card');
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.transitionTo('serviceRequest.new-request');
    },
    goToAccountOpening(isDesktop) {
      let country = this.get('country');
      let countries = ['HK', 'IN', 'MY', 'AE', 'SG', 'VN'];
      let indexOfCountry = countries.indexOf(country);
      if (indexOfCountry < 0) indexOfCountry = 0;
      let urlStr = 'https://www.sc.com/' + countries[indexOfCountry].toLowerCase() + '/credit-cards/';
      if (isDesktop) {
        window.open(urlStr);
      } else {
        location.href = urlStr;
      }
      this.controller.set('clickCancel', false);
    }
  }
});
