import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { hash } from 'rsvp';
import { isEqual } from '@ember/utils';
import constants from '../../constants';

export default Route.extend({
  i18n: service(),
  store: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),
  customerInfo: service(''),
  rdcModalManager: service(),
  model() {
    return hash({
      reviewDetails: this.controllerFor('certificates-request').certificateData,
      selectedCertificate: this.controllerFor('certificates-request').certificateData.selectedCertificate
    });
  },
  actions: {
    goToBack() {
      this.transitionTo('certificates-request.year-selection');
    },
    navigateConfirm() {
      const certificateData = this.controllerFor('certificates-request').certificateData;
      const selectedQuarters = certificateData.selectedQuarters;
      let quarter1 = 'N',
        quarter2 = 'N',
        quarter3 = 'N',
        quarter4 = 'N';
      if (selectedQuarters) {
        selectedQuarters.forEach(item => {
          let value = item.value;
          switch (value) {
            case 'Apr-Jun':
              quarter1 = 'Y';
              break;
            case 'Jul-Sep':
              quarter2 = 'Y';
              break;
            case 'Oct-Dec':
              quarter3 = 'Y';
              break;
            case 'Jan-Mar':
              quarter4 = 'Y';
              break;
            default:
              break;
          }
        });
      }

      let postData = {
        status: 'INIT',
        serviceType: 'TAXCERTI',
        relNumber: certificateData.relId,
        isCritical: false,
        statusOrder: 0,
        dateOrder: 0,
        isPartialSave: false,
        isNstpRequest: 'true',
        payload: {
          serviceRequests: {
            operationName: 'TAXCERTI',
            customerDetails: {
              relationshipNo: certificateData.relId
            },
            taxCertificate: {
              productType: isEqual(certificateData.selectedCertificate.type, 'IBC') ||
                           isEqual(certificateData.selectedCertificate.type, 'TDS') ? 'AC' : 'LS',

              accountNumber: certificateData.accountNo ? certificateData.accountNo : null,
              certificateType: constants.certificatesRequest.payloadCertificateType[certificateData.selectedCertificate.type],
              selectedFinancialYear: certificateData.selectedYear.value,
              quarter1: quarter1 ? quarter1 : 'N',
              quarter2: quarter2 ? quarter2 : 'N',
              quarter3: quarter3 ? quarter3 : 'N',
              quarter4: quarter4 ? quarter4 : 'N'
            }
          }
        }
      };
      if (isEqual(this.get('customerInfo.countryName'), 'LK')) {
        postData.payload.serviceRequests.taxCertificate['accountNumberBalance'] = '';
      }
      this.get('store').unloadAll('service-request');
      const certificatePost = this.get('store')
        .createRecord('service-request', postData)
        .save()
        .then(
          item => {
            this.controllerFor('certificates-request').certificateData.srrefNo = item.id;
            this.transitionTo('certificates-request.status');
          },
          () => {
            this.get('cardErrorHandler').systemErrorPopup(this);
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(certificatePost);
    }
  }
});
