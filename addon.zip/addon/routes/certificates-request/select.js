import Route from '@ember/routing/route';
import { hash } from 'rsvp';
import { A } from '@ember/array';
import { Promise as EmberPromise } from 'rsvp';
import { inject as service } from '@ember/service';
import { isEqual } from '@ember/utils';
import constants from '../../constants';
import { htmlSafe } from '@ember/string';

export default Route.extend({
  i18n: service(),
  rdcLoadingIndicator: service(),
  store: service(),
  cslRequest: A(),
  customerInfo: service(''),
  cardErrorHandler: service(),
  rdcModalManager: service(),
  model() {
    const certificateData = this.controllerFor('certificates-request').certificateData;
    let certificates = A();
    if (isEqual(certificateData.entity, 'CASA')) {
      certificates.addObject({
        id: 1,
        value: this.get('customerInfo.countryName') === 'LK' ? 'TDS and Interest' : 'TDS',
        type: 'TDS'
      });
      certificates.addObject({
        id: 2,
        value: this.get('customerInfo.countryName') === 'LK' ? 'Balance' : 'Interest and Balance',
        type: 'IBC'
      });
    } else if (isEqual(certificateData.entity, 'LOAN')) {
      certificates.addObject({
        id: 3,
        value: 'Mortgage',
        type: 'PI'
      });
    }
    return hash({
      certificatesDetails: certificates
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.setProperties({
      selectedQuarters: null,
      isCustomerEligible: true,
      isNotesNoNeed:   (isEqual(this.get('customerInfo.countryName'), 'IN') ? true : 
                        isEqual(this.get('customerInfo.countryName'), 'LK') ? true : false)
    });
  },
  actions: {
    moveToNextPage(certificates) {
      this.get('rdcLoadingIndicator').showLoadingIndicator();
      let loanProduct = A();
      let casaProduct = A();
      let customerDetails = A();
      this.controllerFor('certificates-request').set('certificateData.selectedCertificate',certificates);
      const type = this.controllerFor('certificates-request').certificateData.selectedCertificate.type;
      this.controller.set("certificateType", type);

      const getCertificateDetails = isEqual(constants.certificatesRequest.query[type], 'customer')
        ? this.get('store')
            .queryRecord(constants.certificatesRequest.query[type], {
                filter: isEqual(this.get('customerInfo.countryName'), 'LK') ? 
                         constants.certificatesRequest.filters[type].LK.customer.certificate : 
                         constants.certificatesRequest.filters[type].customer.certificate,
            })
            .then(data => {
                if (data.custEligibleFlag) {
                  let listData = ((customer, eligibleFlag) => ({ customer, eligibleFlag }))(
                    data.get('customercontacts'),
                    data.get('custEligibleFlag')
                  );
                  Object.assign(customerDetails, listData);
                  this.cslRequest.pushObject(getCertificateDetails);
                } else {
                  this.cslRequest.pushObject(getCertificateDetails);
                }
                this.controller.set('isCustomerEligible', data.custEligibleFlag);
                if (this.controller.isCustomerEligible) {
                    EmberPromise.all(this.cslRequest).then(() => {
                      if (customerDetails.customer && customerDetails.customer.length>0) {
                        this.controllerFor('certificates-request').set('certificateData.relId',customerDetails.customer[0].customer.relId);
                          this.get('store')
                            .query('casa', {
                              filter: constants.certificatesRequest.filters[type].certificate
                            })
                            .then(data => {
                              if (data.length > 0) {
                                data.forEach(item => {
                                  let listData = ((value, label, balance, relNo) => ({ value, label, balance, relNo }))(
                                    item.get('accountNumber'),
                                    item.get('productDescription'),
                                    item.get('availableBalance'),
                                    item.get('relId')
                                  );
                                  casaProduct.pushObject(listData);
                                });
                                this.controllerFor('certificates-request').set(
                                  'certificateData.accountNo',
                                  casaProduct[0].value
                                );
                                this.get('rdcLoadingIndicator').hideLoadingIndicator();
                                this.replaceWith('certificates-request.year-selection');
                              } else {
                                this.get('rdcLoadingIndicator').hideLoadingIndicator();
                                this.controller.set('isCustomerEligible', false);
                              }
                            },
                            () => {
                              this.get('rdcLoadingIndicator').hideLoadingIndicator();
                              this.get('cardErrorHandler').systemErrorPopup(this);
                            });
                      } else {
                        this.controller.set('isCustomerEligible', false);
                        this.get('rdcLoadingIndicator').hideLoadingIndicator();
                      }
                    });
                } else {
                  this.get('rdcLoadingIndicator').hideLoadingIndicator();
                  this.controller.set("certificateType", null);
                }
            }, 
            () => {
              this.get('rdcLoadingIndicator').hideLoadingIndicator();
              this.get('cardErrorHandler').systemErrorPopup(this);
            })
        : this.get('store')
            .query(constants.certificatesRequest.query[type], {
              filter: (isEqual(this.get('customerInfo.countryName'), 'LK') & isEqual(type, 'PI')) 
              ? constants.certificatesRequest.filters[type].LK.certificate                                                            
              : constants.certificatesRequest.filters[type].certificate
            })
            .then(data => {
              if (isEqual(type, 'PI')) {
                if (data.length > 0) {
                  data.forEach(item => {
                    let listData = ((name, value, label, disabled, relNo) => ({
                      name,
                      value,
                      label,
                      disabled,
                      relNo
                    }))(
                      'loan',
                      item.get('accountNumber'),
                      new htmlSafe(
                        item.get('productDescription') + '<br><span>' + item.get('accountNumber') + '</span>'
                      ),
                      false,
                      item.get('relId')
                    );
                    loanProduct.pushObject(listData);
                  });
                  this.cslRequest.pushObject(getCertificateDetails);
                } else {
                  this.cslRequest.pushObject(getCertificateDetails);
                }
                EmberPromise.all(this.cslRequest).then(() => {
                  if(data.length>0){
                    this.controller.set('isCustomerEligible', true);
                    this.controllerFor('certificates-request').set('loans', loanProduct);
                    this.replaceWith('certificates-request.year-selection');
                  } else {
                    this.controller.set('isCustomerEligible', false);
                  }
                  this.get('rdcLoadingIndicator').hideLoadingIndicator();
                });
              } else if (isEqual(type, 'TDS')) {
                if (data.length > 0) {
                  data.forEach(item => {
                    let listData = ((value, label, balance, relNo) => ({ value, label, balance, relNo }))(
                      item.get('accountNumber'),
                      item.get('productDescription'),
                      item.get('availableBalance'),
                      item.get('relId')
                    );
                    casaProduct.pushObject(listData);
                  });
                  this.cslRequest.pushObject(getCertificateDetails);
                } else {
                  this.cslRequest.pushObject(getCertificateDetails);
                }
                EmberPromise.all(this.cslRequest).then(() => {
                  if (data.length > 0) {
                    this.controllerFor('certificates-request').set('certificateData.relId', casaProduct[0].relNo);
                    this.controllerFor('certificates-request').set('certificateData.accountNo', casaProduct[0].value);
                    this.controller.set('isCustomerEligible', true);
                    this.replaceWith('certificates-request.year-selection');
                  } else {
                    this.controller.set('isCustomerEligible', false);
                  } 
                  this.get('rdcLoadingIndicator').hideLoadingIndicator();
                });
              }
            },
            () => {
              this.get('rdcLoadingIndicator').hideLoadingIndicator();
              this.get('cardErrorHandler').systemErrorPopup(this);
            });
    },
    closeJourney() {
      this.get('store').unloadAll('customer');
      this.transitionTo('serviceRequest.new-request');
    } 
  }
});
