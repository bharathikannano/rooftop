import Route from '@ember/routing/route';

export default Route.extend({
  setupController(controller) {
    controller.set('refNo', this.controllerFor('certificates-request').certificateData.srrefNo);
  },
  actions: {
    checkStatus() {
      this.transitionTo('serviceRequest.status');
    },
    backToHomepage() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
