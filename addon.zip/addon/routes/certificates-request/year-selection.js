import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { Promise as EmberPromise } from 'rsvp';
import { hash } from 'rsvp';
import { A } from '@ember/array';
import constants from '../../constants';
import { isEqual, isEmpty } from '@ember/utils';

export default Route.extend({
  rdcLoadingIndicator: service(),
  store: service(),
  cslRequest: A(),
  router: service(),
  customerInfo: service(''),
  cardErrorHandler: service(),
  i18n: service(),

  model() {
    let controllerData = this.controllerFor('certificates-request');
    let certificateData = this.controllerFor('certificates-request').certificateData;
    const type = this.controllerFor('certificates-request').certificateData.selectedCertificate.type;
    let yearList = A();
    this.get('rdcLoadingIndicator').showLoadingIndicator();
    const getFinancialYears = this.get('store')
      .query('financial-year', {
        filter: constants.certificatesRequest.filters[type].financialYears
      })
      .then(
        data => {
          data.forEach(item => {
            let listData = ((value, quarters) => ({ value, quarters }))(item.get('value'), item.get('quarters'));
            yearList.pushObject(listData);
          });
          this.cslRequest.pushObject(getFinancialYears);
          EmberPromise.all(this.cslRequest).then(() => {
            this.controllerFor('certificates-request').set('financialYears', yearList);
            this.get('rdcLoadingIndicator').hideLoadingIndicator();
          });
        },
        () => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.get('cardErrorHandler').systemErrorPopup(this);
        }
      );

    return hash({
      financialYears: yearList,
      loanRadioGroupDetails: controllerData.loans,
      certificate: certificateData.selectedCertificate.value,
      certificateType: certificateData.selectedCertificate.type,
      isTextAreaCountryLK: this.get('customerInfo.countryName') === 'LK' ? true : false
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.setProperties({
      isSelectedLoan: false
    });
    if (this.router.currentRouteName.indexOf('select') !== -1) {
      this.controller.setProperties({
        selectedYear: null,
        showQuarters: false,
        disableNext: true,
        selectedQuarters: null,
        loanValue: null,
        comments: '',
        infoMsg: ''
      });
    }
    if (this.get('customerInfo.countryName') === 'LK') {
      controller.set(
        'txtboxLabel',
        this.get('i18n').t('ServiceRequest.certificatesRequest.header.optinalTitle.title').string
      );
      this.infoMessageforLK();
    }
  },
  infoMessageforLK() {
    const type = this.controllerFor('certificates-request').certificateData.selectedCertificate.type;
    this.controller.set(
      'infoMsg',
      this.get('i18n').t(`ServiceRequest.certificatesRequest.pageLabels.alertMsg.${type}`).string
    );
  },
  actions: {
    goToBack() {
      this.transitionTo('certificates-request.select');
    },
    navigateConfirm() {
      let certificateCtrl = this.controllerFor('certificates-request');

      const fieldExp = new RegExp('[^a-zA-Z0-9.,#\\n ]', 'g');
      this.controller.set('comments', this.controller.get('comments').replace(fieldExp, ''));
      certificateCtrl.setProperties({
        'certificateData.comments': this.controller.get('comments').trim(),
        'certificateData.selectedQuarters': this.controller.get('selectedQuarters')
      });
      this.transitionTo('certificates-request.confirm');
    },

    checkBoxAction() {
      !isEmpty(this.controller.get('selectedQuarters')) && this.controller.selectedYear
        ? this.controller.set('disableNext', false)
        : this.controller.set('disableNext', true);
    },

    loanAccountChange(value) {
      let certificateCtrl = this.controllerFor('certificates-request');
      this.controller.set('loanValue', value);
      this.controller.set('isSelectedLoan', true);

      let loanDetails = this.controller.model.loanRadioGroupDetails.filter(item => {
        return item.value === value;
      });

      certificateCtrl.setProperties({
        'certificateData.selectedLoan': loanDetails[0],
        'certificateData.relId': loanDetails[0].relNo,
        'certificateData.accountNo': loanDetails[0].value
      });

      const type = this.controllerFor('certificates-request').certificateData.selectedCertificate.type;
      if (isEqual(type, 'PI')) {
        if (this.controller.isSelectedLoan && this.controller.selectedYear) {
          this.controller.set('disableNext', false);
        } else {
          this.controller.set('disableNext', true);
        }
      } else {
        this.controller.set('disableNext', false);
      }
    },
    financialYearsChange(year) {
      this.controller.set('disableNext', true);
      const type = this.controllerFor('certificates-request').certificateData.selectedCertificate.type;
      this.controller.set('selectedYear', year);
      this.controllerFor('certificates-request').set('certificateData.selectedYear', year);
      let financialYears = A();
      let quarterDetails = A();
      Object.assign(financialYears, this.controllerFor('certificates-request').financialYears);
      quarterDetails = financialYears.filter(item => {
        return item.value === year.value;
      });
      if (quarterDetails[0].quarters && !isEmpty(quarterDetails[0].quarters)) {
        quarterDetails[0].quarters.forEach((item, index) => {
          switch (index) {
            case 0:
              item.label = 'Apr - Jun (1st Quarter)';
              break;
            case 1:
              item.label = 'July - Sep (2nd Quarter)';
              break;
            case 2:
              item.label = 'Oct - Dec (3rd Quarter)';
              break;
            case 3:
              item.label = 'Jan - March (4th Quarter)';
              break;
            default:
              break;
          }
        });
        this.controller.set('quarterDetails', quarterDetails[0].quarters);
        this.controller.set('showQuarters', true);
        this.controller.set('selectedQuarters', null);
        if (isEqual(type, 'PI') || isEqual(type, 'IBC')) {
          this.controller.set('quarterDetails', null);
          this.controller.set('showQuarters', false);
        }
      } else {
        this.controller.set('quarterDetails', null);
        this.controller.set('showQuarters', false);
      }
      if (isEqual(type, 'PI')) {
        this.controller.isSelectedLoan && this.controller.selectedYear
          ? this.controller.set('disableNext', false)
          : this.controller.set('disableNext', true);
      } else {
        this.controller.showQuarters
          ? this.controller.set('disableNext', true)
          : this.controller.set('disableNext', false);
      }
    },
    closeJourney() {
      this.get('store').unloadAll('customer');
      this.get('store').unloadAll('casa');
      this.get('store').unloadAll('loan');
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
