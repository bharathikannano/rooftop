import Route from '@ember/routing/route';
import { hash } from 'rsvp';
import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import EmberObject from '@ember/object';
import config from '../../constants';
export default Route.extend({
  i18n: service(),
  invalidDates: A(),
  store: service(),
  router: service(),
  cardErrorHandler: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),

  statementDate: EmberObject.create({
    billCycle: null,
    alerts: null
  }),

  cardDetails: EmberObject.create({}),

  alerts: null,
  model() {
    if (this.get('router.currentRouteName').indexOf('new-request') !== -1) {
      let getStatementDate = this.get('store')
        .query('credit-card', {
          filter: {
            operationName: 'STMTCYDC'
          }
        })
        .then(
          data => {
            if (isEmpty(data.findBy('id').alerts)) {
              if (!isEmpty(data.findBy('id').billingCycle)) {
                this.set('statementDate.billCycle', data.findBy('id').billingCycle);
                this.set('cardDetails', {
                  relNo: data.findBy('id').relId,
                  cardNo: data.findBy('id').cardNum
                });
              }
            } else {
              this.set('statementDate.alerts', data.findBy('id').alerts[0].message);
            }
            return this.get('statementDate');
          },
          error => {
            if (!isEmpty(error.errors[0]) && !config.genericRequestForm.noDatastrings.includes(error.errors[0].code)) {
              this.get('cardErrorHandler').systemErrorPopup(this);
            }
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(getStatementDate);

      return hash({
        currentDate: getStatementDate
      });
    }
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.setProperties({
      newStmtDate: this.get('i18n').t('ServiceRequest.changeStatDate.newStmtDate').string,
      hasError: false,
      disableNext: true
    });
    const curRoutename = this.get('router.currentRouteName');
    curRoutename !== null && curRoutename.indexOf('confirm') !== -1
      ? this._getResult()
      : controller.set('statementDate', null);
  },
  _getResult() {
    this.invalidDates.clear();
    const statementDate = Number(this.get('statementDate.billCycle'));
    this.invalidDates.push(26, 27, 28, 29, 30, 31, 1, 0, statementDate);
    if (
      isEmpty(this.controller.statementDate) ||
      this.invalidDates.indexOf(Number(this.controller.statementDate)) !== -1 ||
      this.controller.statementDate > 31
    ) {
      this.controller.set('hasError', true);
      this.controller.set('disableNext', true);
    } else {
      this.controller.set('hasError', false);
      this.controller.set('disableNext', false);
    }
  },
  actions: {
    validateDate() {
      this._getResult();
    },
    validateChar() {
      let evt = window.event;
      let keys = window.event.key;
      let fieldExp = new RegExp('[^0-9]', 'g');
      if (fieldExp.test(keys)) {
        evt.preventDefault();
        if (evt.defaultPrevented) {
          evt.defaultPrevented = true;
        }
      }
    },
    goToBack() {
      this.get('store').unloadAll('credit-card');
      this.transitionTo('serviceRequest.new-request');
    },
    navigateConfirm() {
      const statementValue = {
        currentDate: this.get('statementDate.billCycle'),
        newDate: this.controller.statementDate,
        cardDetails: this.get('cardDetails')
      };
      this.controllerFor('change-statement-date').set('dateValue', statementValue);
      this.transitionTo('change-statement-date.confirm');
    }
  }
});
