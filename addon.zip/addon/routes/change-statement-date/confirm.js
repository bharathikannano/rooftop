import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';

export default Route.extend({
  store: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  i18n: service(),
  setupController(controller) {
    const dispVal = this.controllerFor('change-statement-date').get('dateValue');
    controller.setProperties({
      currentDate: dispVal.currentDate,
      newDate: dispVal.newDate
    });
  },
  actions: {
    goToBack() {
      this.transitionTo('change-statement-date.change');
    },
    navigateConfirm() {
      this.get('store').unloadAll('service-request');
      const dispVal = this.controllerFor('change-statement-date').get('dateValue');
      let postData = {
        status: 'INIT',
        relNumber: dispVal.cardDetails.relNo,
        serviceType: 'STMTCYDC',
        isNstpRequest: 'true',
        payload: {
          serviceRequests: {
            operationName: 'STMTCYDC',
            statementCycleDateChange: {
              productType: 'CC',
              currentStmtDate: dispVal.currentDate,
              newStmtDate: dispVal.newDate,
              creditCardNos: {
                creditCardNo: dispVal.cardDetails.cardNo
              }
            },
            customerDetails: {
              relationshipNo: dispVal.cardDetails.relNo
            }
          }
        }
      };
      const genericPost = this.get('store')
        .createRecord('service-request', postData)
        .save()
        .then(
          item => {
            dispVal['refNo'] = item.id;
            this.transitionTo('change-statement-date.status');
          },
          () => {
            this.get('cardErrorHandler').systemErrorPopup(this);
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(genericPost);
    }
  }
});
