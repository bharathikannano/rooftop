import Route from '@ember/routing/route';

export default Route.extend({
  setupController(controller) {
    this.controllerFor('change-statement-date').set('leftIcon', '');
    controller.set('refNo', this.controllerFor('change-statement-date').get('dateValue.refNo'));
  },
  actions: {
    navigateStatus() {
      this.transitionTo('serviceRequest.status');
    }
  }
});
