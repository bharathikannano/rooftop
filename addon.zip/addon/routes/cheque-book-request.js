import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../config/environment';

export default Route.extend({
  i18n: service(),
  rdcModalManager: service(),
  setupController() {
    this.controllerFor('chequeRequest').set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    this.controllerFor('chequeRequest').set('errorType', 'systemError');
  },

  actions: {
    closePopupAction() {
      let message;
      this.controllerFor('chequeRequest').set('errorType', 'cancel');
      if (this.get('media.isDesktop')) {
        if (this.controllerFor('chequeRequest').get('leftIcon')) {
          message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankBefAckText');
        } else {
          message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
        }
      } else {
        if (this.controllerFor('chequeRequest').get('leftIcon')) {
          message = this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankBefAckText');
        } else {
          message = this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankText');
        }
      }
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
        });
    }
  }
});
