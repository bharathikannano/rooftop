import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';
export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  queries: service('customer-info'),
  model: function() {
    let casaData = this.get('store').peekAll('casa');
    let selectedCasa;
    casaData.forEach(function(casaVal) {
      selectedCasa = casaVal.get('eligibleCasas').filterBy('checked');
    });
    return {
      selectedCasa: selectedCasa
    };
  },
  actions: {
    gotoBack() {
      this.transitionTo('chequeRequest.new-request');
    },
    editAddress() {
      let message = this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.updateAddress.confirmation.message');
      let title = this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.updateAddress.confirmation.title');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'info',
          message,
          title,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup card-cancellation-updatecontact'
        })
        .then(() => {
          document.location.href = config.dataLockerURL;
        });
    },
    cancelBtn() {
      this.controllerFor('chequeRequest').set('errorType', 'cancel');
      let message = this.get('i18n').t('ServiceRequest.CHEQUEBOOK.confirmCancelText');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes')
        })
        .then(() => {
          this.set('currentModel.cancelPopup', false);
          this.transitionTo('serviceRequest.new-request');
          this.get('store').unloadAll('casa');
        });
    },

    gotoNext() {
      this.transitionTo('chequeBookRequest.request-confirm');
    }
  }
});
