import Route from '@ember/routing/route';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import { A } from '@ember/array';
import { set } from '@ember/object';

export default Route.extend({
  i18n: service(),
  queries: service('customer-info'),
  deliveryMethod: computed(function() {
    if (
      this.get('queries.countryName') == 'TZ' ||
      this.get('queries.countryName') == 'UG' ||
      this.get('queries.countryName') == 'GH' ||
      this.get('queries.countryName') == 'ZM' ||
      this.get('queries.countryName') == 'ZW' ||
      this.get('queries.countryName') == 'NG'
    ) {
      return 'registered-branch';
    } else {
      return 'registered-address';
    }
  }),
  model() {
    let radioGroup = A([
      {
        name: 'list-Values',
        value: 'registered-address',
        label: this.get('i18n').t('ServiceRequest.CHEQUEBOOK.deliveryToAddress'),
        ikon: 'radio-icon',
        disabled: false
      },
      {
        name: 'list-Values',
        value: 'registered-branch',
        label: this.get('i18n').t('ServiceRequest.CHEQUEBOOK.collectFromBranch'),
        ikon: 'radio-icon',
        disabled: false
      }
    ]);
    return {
      radioGroup: radioGroup,
      nextBtnEnabled: true
    };
  },
  afterModel(data) {
    let countryNotes = this.get('i18n').t('ServiceRequest.CHEQUEBOOK.countryNotes.' + this.get('queries.countryName'))
      .string
      ? this.get('i18n').t('ServiceRequest.CHEQUEBOOK.countryNotes.' + this.get('queries.countryName'))
      : this.get('i18n').t('ServiceRequest.CHEQUEBOOK.countryNotes.default');
    set(data, 'notesText', countryNotes);
    if (
      this.get('queries.countryName') == 'TZ' ||
      this.get('queries.countryName') == 'UG' ||
      this.get('queries.countryName') == 'GH' ||
      this.get('queries.countryName') == 'ZM' ||
      this.get('queries.countryName') == 'ZW' ||
      this.get('queries.countryName') == 'NG'
    ) {
      set(data, 'hideDeliveryMethod', true);
    }
    if (!this.controllerFor('chequeBookRequest.delivery-method-selection').get('radioValue')) {
      this.controllerFor('chequeBookRequest.delivery-method-selection').set('radioValue', this.get('deliveryMethod'));
    }
    this.controllerFor('chequeBookRequest.delivery-method-selection').set(
      'branchDetails',
      this.controllerFor('chequeBookRequest.new-request').get('branchDetails')
    );
  },
  actions: {
    displayBranchDetails: function(branch) {
      this.controller.set('selectedBranch', branch);
      set(this.currentModel, 'nextBtnEnabled', true);
    },
    deliveryMethodChange: function(radioVal) {
      if (radioVal == 'registered-branch' && !this.controller.get('selectedBranch')) {
        set(this.currentModel, 'nextBtnEnabled', false);
      } else {
        set(this.currentModel, 'nextBtnEnabled', true);
      }
    },
    gotoBack() {
      this.transitionTo('chequeBookRequest.new-request');
    },
    cancelBtn() {
      this.transitionTo('serviceRequest.new-request');
      this.get('store').unloadAll('casa');
    },
    navigateConfirm() {
      this.transitionTo('chequeBookRequest.request-confirm');
    }
  }
});
