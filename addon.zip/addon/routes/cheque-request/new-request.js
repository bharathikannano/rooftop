import EmberObject from '@ember/object';
import { htmlSafe } from '@ember/string';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';
import constants from '../../constants';
import { A } from '@ember/array';

export default Route.extend({
  store: service(),
  i18n: service(),
  adobeDataService: service(),
  axwayConfig: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  queries: service('customer-info'),
  deliveryMethod: computed(function() {
    if (
      this.get('queries.countryName') == 'TZ' ||
      this.get('queries.countryName') == 'UG' ||
      this.get('queries.countryName') == 'GH' ||
      this.get('queries.countryName') == 'ZM' ||
      this.get('queries.countryName') == 'ZW' ||
      this.get('queries.countryName') == 'NG'
    ) {
      return 'registered-branch';
    } else {
      return 'registered-address';
    }
  }),

  model() {
    /*Only for back from confirm case we can get data using peekall*/
    let casaData = this.get('store').peekAll('casa');
    casaData.set('selectAll', true);
    if (casaData && casaData.content.length > 0) {
      let checkboxSelection = false;
      let anyOneDeselected = false;
      casaData.forEach(element => {
        element.get('eligibleCasas').forEach(elementVal => {
          if (!elementVal.get('alerts')) {
            if (elementVal.get('checked')) {
              checkboxSelection = true;
            } else {
              anyOneDeselected = true;
            }
          }
        });
      });
      if (anyOneDeselected) {
        casaData.set('selectAll', true);
      } else {
        casaData.set('selectAll', false);
      }
      casaData.set('nextBtnEnabled', checkboxSelection);
    } else {
      casaData.set('nextBtnEnabled', false);
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      this.get('store')
        .queryRecord('customer', {
          filter: {
            eligibleForChequeBook: 'yes'
          }
        })
        .then(
          customersData => {
            if (customersData.get('alerts') && customersData.get('alerts').length >= 1) {
              this.controllerFor('chequeRequest').set('errorType', 'accValidationError');
              let message;
              customersData.get('alerts').forEach(alert => {
                let messageText;
                if (this.get('queries.countryName') != 'HK' && this.get('queries.countryName') != 'KE' && alert.code) {
                  messageText = alert.code + ' - ' + htmlSafe(alert.message);
                } else {
                  messageText = htmlSafe(alert.message);
                }
                if (message) message = htmlSafe(message + '<br/>' + messageText);
                else message = messageText;
              });
              this.get('rdcLoadingIndicator').hideLoadingIndicator();
              this.get('rdcModalManager')
                .showDialogModal({
                  level: 'info',
                  message,
                  acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
                  iconClass: 'service-journey-info-icon',
                  popupClass: 'service-journey-info-popup'
                })
                .then(() => {
                  this.transitionTo('serviceRequest.new-request');
                  return;
                });
            } else {
              casaData = this.get('store')
                .query('casa', {
                  filter: {
                    eligibleForChequeBook: 'yes'
                  }
                })
                .then(casas => {
                  let branchArray = A();
                  casas.forEach(element => {
                    let branchCode = element.get('branches');
                    for (let key in branchCode) {
                      let branchObject = {
                        key: key,
                        value: branchCode[key]
                      };
                      branchArray.push(branchObject);
                    }
                    if (element.get('alerts') && element.get('alerts').length > 0) {
                      this.controllerFor('chequeRequest').set('errorType', 'accValidationError');
                      this.get('rdcLoadingIndicator').hideLoadingIndicator();
                      let message;
                      element.get('alerts').forEach(alert => {
                        let messageText;
                        if (
                          this.get('queries.countryName') != 'HK' &&
                          this.get('queries.countryName') != 'KE' &&
                          alert.code
                        ) {
                          messageText = alert.code + ' - ' + htmlSafe(alert.message);
                        } else {
                          messageText = htmlSafe(alert.message);
                        }
                        if (message) message = htmlSafe(message + '<br/>' + messageText);
                        else message = messageText;
                      });
                      this.get('rdcModalManager')
                        .showDialogModal({
                          level: 'info',
                          message,
                          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
                          iconClass: 'service-journey-info-icon',
                          popupClass: 'service-journey-info-popup'
                        })
                        .then(() => {
                          this.transitionTo('serviceRequest.new-request');
                        });
                    } else {
                      let eligibleCasaArray = A();

                      element.get('eligibleCasas').forEach(elementVal => {
                        elementVal = EmberObject.create(elementVal);
                        eligibleCasaArray.push(elementVal);
                      });
                      element.set('eligibleCasas', eligibleCasaArray);
                      if (element.get('eligibleCasas').length == 1) {
                        element.get('eligibleCasas').forEach(elementVal => {
                          if (!elementVal.get('alerts')) {
                            elementVal.set('checked', true);
                          }
                        });
                        if (this.currentModel) {
                          this.currentModel.set('nextBtnEnabled', true);
                          this.currentModel.set('selectAll', false);
                        }
                      }
                      this.get('rdcLoadingIndicator').hideLoadingIndicator();
                      return casas;
                    }
                  });
                  this.controllerFor('chequeRequest.new-request').set('branchDetails', branchArray);
                });
            }
          },
          error => {
            this.send('error', error);
          }
        );
    }
    let countryNotes = this.get('i18n').t('ServiceRequest.CHEQUEBOOK.countryNotes.' + this.get('queries.countryName'))
      .string
      ? this.get('i18n').t('ServiceRequest.CHEQUEBOOK.countryNotes.' + this.get('queries.countryName'))
      : this.get('i18n').t('ServiceRequest.CHEQUEBOOK.countryNotes.default');
    casaData.set('notesText', countryNotes);
    return casaData;
  },
  afterModel(data) {
    if (constants.branchOptionFlowCountries.indexOf(this.get('queries.countryName')) != -1) {
      let radioGroup = A([
        {
          name: 'list-Values',
          value: 'registered-address',
          label: this.get('i18n').t('ServiceRequest.CHEQUEBOOK.deliveryToAddress'),
          ikon: 'radio-icon',
          disabled: false
        },
        {
          name: 'list-Values',
          value: 'registered-branch',
          label: this.get('i18n').t('ServiceRequest.CHEQUEBOOK.collectFromBranch'),
          ikon: 'radio-icon',
          disabled: false
        }
      ]);
      data.set('radioGroup', radioGroup);
      if (
        this.get('queries.countryName') == 'TZ' ||
        this.get('queries.countryName') == 'UG' ||
        this.get('queries.countryName') == 'GH' ||
        this.get('queries.countryName') == 'ZM' ||
        this.get('queries.countryName') == 'ZW' ||
        this.get('queries.countryName') == 'NG'
      ) {
        data.set('hideDeliveryMethod', true);
      }
      if (!this.controllerFor('chequeRequest.new-request').get('radioValue')) {
        this.controllerFor('chequeRequest.new-request').set('radioValue', this.get('deliveryMethod'));
      }

      this.controllerFor('chequeRequest.new-request').set('branchOptionFlow', true);
    }
    try {
      if (this.get('axwayConfig.country') == 'HK') {
        this.adobeDataService.setFormData(
          this.get('i18n').t('ServiceRequest.CHEQUEBOOK.header.title'),
          this.get('i18n').t('ServiceRequest.CHEQUEBOOK.selectAccount.title')
        );
        this.adobeDataService.setProductsData(this.get('i18n').t('ServiceRequest.LANDINGPAGE.header.title'));
      }
    } catch (e) {
      () => {};
    }
  },
  acc_label: 'Select Your Card',
  actions: {
    error: function(error) {
      try {
        if (this.get('axwayConfig.country') == 'HK') {
          this.adobeDataService.setErrorData(error);
          this.adobeDataService.formError();
        }
      } catch (e) {
        () => {};
      }
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      if (error.errors && error.errors[0].code == '1702') {
        document.location.href = config.backToiBankURL;
        return;
      }
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.controllerFor('serviceRequest').set('cancelPopup', false);
      this.controllerFor('serviceRequest').set('systemErrorPopup', true);
      let message = htmlSafe(
        this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName')).string
          ? this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName')).string
          : this.get('i18n').t('ServiceRequest.COMMON.systemError').string
      );
      let title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
      this.controllerFor('chequeRequest').set('errorType', 'systemError');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          title,
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.controllerFor('serviceRequest').set('systemErrorPopup', false);
          this.transitionTo('serviceRequest.new-request');
        });
    },
    selectAllList: function(model) {
      model.forEach(function(elementVal) {
        elementVal.get('eligibleCasas').forEach(function(element) {
          if (!element.get('alerts')) {
            if (model.selectAll) {
              element.set('checked', true);
            } else {
              element.set('checked', false);
            }
          }
        });
      });
      model.toggleProperty('selectAll');
      this.send('enableNextBtn');
    },
    enableNextBtn: function() {
      let checkboxSelected = false;
      let branchSelected = true;
      if (this.currentModel) {
        this.currentModel.forEach(function(elementVal) {
          elementVal.get('eligibleCasas').forEach(function(element) {
            if (!element.get('alerts')) {
              if (element.get('checked')) {
                checkboxSelected = true;
              }
            }
          });
        });

        if (this.controllerFor('chequeRequest.new-request').get('branchOptionFlow')) {
          if (
            this.controllerFor('chequeRequest.new-request').get('radioValue') == 'registered-branch' &&
            !this.controllerFor('chequeRequest.new-request').get('selectedBranch')
          ) {
            if (!this.get('media.isMobile')) {
              branchSelected = false;
            }
          }
        }
        if (checkboxSelected && branchSelected) {
          this.currentModel.set('nextBtnEnabled', true);
        } else {
          this.currentModel.set('nextBtnEnabled', false);
        }
      }
    },
    displayBranchDetails: function(branch) {
      this.controller.set('selectedBranch', branch);
      this.send('enableNextBtn');
      return branch;
    },
    deliveryMethodChange: function(deliveryMethod) {
      this.send('enableNextBtn');
      return deliveryMethod;
    },
    gotoBack() {
      try {
        if (this.get('axwayConfig.country') == 'HK') {
          this.adobeDataService.formStep();
          this.adobeDataService.setCtaData(this.get('i18n').t('ServiceRequest.COMMON.button.back'));
          this.adobeDataService.formCallToAction();
        }
      } catch (e) {
        () => {};
      }
      this.transitionTo('serviceRequest.new-request');
      this.get('store').unloadAll('casa');
    },
    cancelBtn() {
      this.transitionTo('serviceRequest.new-request');
      this.get('store').unloadAll('casa');
    },
    async navigateConfirm() {
      try {
        if (this.get('axwayConfig.country') == 'HK') {
          await this.adobeDataService.formStep();
          this.adobeDataService.setCtaData(this.get('i18n').t('ServiceRequest.COMMON.button.next'));
          await this.adobeDataService.formCallToAction();
        }
      } catch (e) {
        () => {};
      }
      if (!this.get('media.isMobile') || !this.controllerFor('chequeRequest.new-request').get('branchOptionFlow')) {
        this.transitionTo('chequeRequest.request-confirm');
      } else {
        this.transitionTo('chequeRequest.delivery-method-selection');
      }
    }
  }
});
