import { set } from '@ember/object';
import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';
import constants from '../../constants';
import { next } from '@ember/runloop';
export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  adobeDataService: service(),
  axwayConfig: service(),
  rdcLoadingIndicator: service(),
  queries: service('customer-info'),
  confirmBtnDisable: false,
  model: function() {
    let casaData = this.get('store').peekAll('casa');
    let selectedCasa;
    casaData.forEach(function(casaVal) {
      selectedCasa = casaVal.get('eligibleCasas').filterBy('checked');
    });
    return {
      selectedCasa: selectedCasa
    };
  },
  afterModel(data) {
    set(data, 'branchOptionFlow', this.controllerFor('chequeRequest.new-request').get('branchOptionFlow'));
    if (this.controllerFor('chequeRequest.new-request').get('branchOptionFlow')) {
      let selectedDeliveryMethod, selectedBranch;
      if (this.get('media.isMobile')) {
        selectedDeliveryMethod = this.controllerFor('chequeRequest.delivery-method-selection').get('radioValue');
        selectedBranch = this.controllerFor('chequeRequest.delivery-method-selection').get('selectedBranch');
      } else {
        selectedDeliveryMethod = this.controllerFor('chequeRequest.new-request').get('radioValue');
        selectedBranch = this.controllerFor('chequeRequest.new-request').get('selectedBranch');
      }
      if (selectedDeliveryMethod == 'registered-branch') {
        set(data, 'stepTextChange', true);
        set(data, 'selectedDeliveryMethod', this.get('i18n').t('ServiceRequest.CHEQUEBOOK.collectFromBranch'));
        set(data, 'selectedBranch', selectedBranch);
      } else {
        set(data, 'selectedDeliveryMethod', this.get('i18n').t('ServiceRequest.CHEQUEBOOK.deliveryToAddress'));
      }
    }
    try {
      if (this.get('axwayConfig.country') == 'HK') {
        this.adobeDataService.setFormData(
          this.get('i18n').t('ServiceRequest.CHEQUEBOOK.header.title'),
          this.get('i18n').t('ServiceRequest.CHEQUEBOOK.confirmAccount.title')
        );
        this.adobeDataService.setProductsData(this.get('i18n').t('ServiceRequest.LANDINGPAGE.header.title'));
      }
    } catch (e) {
      () => {};
    }
  },
  actions: {
    error: function(error) {
      try {
        if (this.get('axwayConfig.country') == 'HK') {
          this.adobeDataService.setErrorData(error);
          this.adobeDataService.formError();
        }
      } catch (e) {
        () => {};
      }
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      if (error.errors && error.errors[0].code == '1702') {
        document.location.href = config.backToiBankURL;
        return;
      }
      this.controllerFor('chequeRequest').set('errorType', 'systemError');
      let message = htmlSafe(
        this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName')).string
          ? this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName')).string
          : this.get('i18n').t('ServiceRequest.COMMON.systemError').string
      );
      let title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          title,
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.set('currentModel.systemErrorPopup', false);
          this.transitionTo('serviceRequest.new-request');
          this.get('store').unloadAll('casa');
        });
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
    },

    async gotoBack() {
      try {
        if (this.get('axwayConfig.country') == 'HK') {
          await this.adobeDataService.formStep();
          this.adobeDataService.setCtaData(
            this.get('media.isMobile') ? '' : this.get('i18n').t('ServiceRequest.COMMON.button.back')
          );
          await this.adobeDataService.formCallToAction();
        }
      } catch (e) {
        () => {};
      }
      if (!this.get('media.isMobile') || !this.controllerFor('chequeRequest.new-request').get('branchOptionFlow')) {
        this.transitionTo('chequeRequest.new-request');
      } else {
        this.transitionTo('chequeRequest.delivery-method-selection');
      }
    },
    cancelBtn() {
      this.controllerFor('chequeRequest').set('errorType', 'cancel');
      let message = this.get('i18n').t('ServiceRequest.CHEQUEBOOK.confirmCancelText');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes')
        })
        .then(() => {
          this.set('currentModel.cancelPopup', false);
          this.transitionTo('serviceRequest.new-request');
          this.get('store').unloadAll('casa');
        });
    },

    gotoNext(model) {
      try {
        if (this.get('axwayConfig.country') == 'HK') {
          this.adobeDataService.setCtaData(this.get('i18n').t('ServiceRequest.COMMON.button.confirm'));
          this.adobeDataService.formCallToAction();
          this.adobeDataService.txnSubmit();
        }
      } catch (e) {
        () => {};
      }
      set(this.currentModel, 'confirmBtnDisable', true);
      let countryName = this.get('queries.countryName');
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      let chequeDetails = [];
      model.forEach(item => {
        let pushData = {};
        pushData.accountNumber = item.get('account-number');
        pushData.accountCurrency = item.get('currency-code');
        pushData.noOfChqBooks = '1';
        pushData.deliveryChannel = 'M';
        let selectedDeliveryMethod, selectedBranchCode;
        if (this.controllerFor('chequeRequest.new-request').get('branchOptionFlow')) {
          if (this.get('media.isMobile')) {
            selectedDeliveryMethod = this.controllerFor('chequeRequest.delivery-method-selection').get('radioValue');
          } else {
            selectedDeliveryMethod = this.controllerFor('chequeRequest.new-request').get('radioValue');
          }
          if (selectedDeliveryMethod == 'registered-branch') {
            pushData.deliveryChannel = 'B';
            if (this.get('media.isMobile')) {
              selectedBranchCode = this.controllerFor('chequeRequest.delivery-method-selection').get('selectedBranch')
                .key;
            } else {
              selectedBranchCode = this.controllerFor('chequeRequest.new-request').get('selectedBranch').key;
            }
            pushData.branchCode = selectedBranchCode;
          }
        }
        if (constants.ChequeBookFeatures.leavesSelection.indexOf(this.get('queries.countryName')) != -1) {
          pushData.numberOfLeaves = item.get('chequeleafValue');
        }
        chequeDetails.push(pushData);
      });
      let data = {
        serviceType: 'CQBKPROC',
        payload: {
          operationName: 'CHQBKREQ'
        }
      };
      data.payload.chequeBookRequest = chequeDetails;
      if (this.get('queries.userGroup')) {
        data.payload.frontLineUserType = this.get('queries.userGroup');
      }
      let postVar = this.get('store').createRecord('cheque-book', data);
      postVar.save().then(
        response => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.transitionTo('chequeRequest.request-status').then(statusRoute => {
            let accNotes = statusRoute.get('i18n').t('ServiceRequest.CHEQUEBOOK.statusMsg.' + countryName).string
              ? statusRoute.get('i18n').t('ServiceRequest.CHEQUEBOOK.statusMsg.' + countryName)
              : statusRoute.get('i18n').t('ServiceRequest.CHEQUEBOOK.statusMsg.success');
            if (this.controllerFor('chequeRequest.new-request').get('branchOptionFlow')) {
              let selectedDeliveryMethod = this.controllerFor('chequeRequest.new-request').get('radioValue');
              if (selectedDeliveryMethod == 'registered-branch') {
                accNotes = statusRoute.get('i18n').t('ServiceRequest.CHEQUEBOOK.statusMsg.branchSelected');
              } else {
                accNotes = statusRoute.get('i18n').t('ServiceRequest.CHEQUEBOOK.statusMsg.addressSelected');
              }
            }

            statusRoute.currentModel.set('accText', accNotes);
            statusRoute.currentModel.set('refNum', response.get('serviceRequest.receipt-id'));
            try {
              if (this.get('axwayConfig.country') == 'HK') {
                next(() => {
                  this.adobeDataService.setProductsData(
                    this.get('i18n').t('ServiceRequest.LANDINGPAGE.header.title'),
                    '',
                    '',
                    '',
                    response.get('serviceRequest.receipt-id'),
                    this.get('i18n').t('ServiceRequest.COMMON.progress.submitted')
                  );
                  this.adobeDataService.formSubmit();
                });
              }
            } catch (e) {
              () => {};
            }
          });
        },
        error => {
          try {
            if (this.get('axwayConfig.country') == 'HK') {
              this.adobeDataService.setErrorData(error);
              this.adobeDataService.formError();
            }
          } catch (e) {
            () => {};
          }
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.send('error', error);
        }
      );
    }
  }
});
