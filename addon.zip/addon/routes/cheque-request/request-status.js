import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { set } from '@ember/object';

export default Route.extend({
  i18n: service(),
  store: service(),
  axwayConfig: service(),
  adobeDataService: service(),
  model: function() {
    let casaData = this.get('store').peekAll('casa');
    let selectedCasa;

    casaData.forEach(function(casaVal) {
      selectedCasa = casaVal.get('eligibleCasas').filterBy('checked');
      casaVal.set('eligibleCasas', selectedCasa);
    });

    return casaData;
  },
  afterModel: function(data) {
    this.controllerFor('chequeRequest').set('leftIcon', '');
    data.set('branchOptionFlow', this.controllerFor('chequeRequest.new-request').get('branchOptionFlow'));
    let selectedDeliveryMethod, selectedBranch;
    if (this.get('media.isMobile')) {
      selectedDeliveryMethod = this.controllerFor('chequeRequest.delivery-method-selection').get('radioValue');
      selectedBranch = this.controllerFor('chequeRequest.delivery-method-selection').get('selectedBranch');
    } else {
      selectedDeliveryMethod = this.controllerFor('chequeRequest.new-request').get('radioValue');
      selectedBranch = this.controllerFor('chequeRequest.new-request').get('selectedBranch');
    }
    if (selectedDeliveryMethod == 'registered-branch') {
      set(data, 'selectedDeliveryMethod', this.get('i18n').t('ServiceRequest.CHEQUEBOOK.collectFromBranch'));
      set(data, 'selectedBranch', selectedBranch);
    } else {
      set(data, 'selectedDeliveryMethod', this.get('i18n').t('ServiceRequest.CHEQUEBOOK.deliveryToAddress'));
    }
    try {
      if (this.get('axwayConfig.country') == 'HK') {
        this.adobeDataService.setFormData(
          this.get('i18n').t('ServiceRequest.CHEQUEBOOK.header.title'),
          this.get('i18n').t('ServiceRequest.COMMON.progress.submitted')
        );
        this.adobeDataService.setProductsData(this.get('i18n').t('ServiceRequest.LANDINGPAGE.header.title'));
      }
    } catch (e) {
      () => {};
    }
  },
  actions: {
    gotoStatus() {
      try {
        if (this.get('axwayConfig.country') == 'HK') {
          this.adobeDataService.setCtaData(this.get('i18n').t('ServiceRequest.COMMON.button.viewStatus'));
          this.adobeDataService.formCallToAction();
        }
      } catch (e) {
        () => {};
      }
      this.get('store').unloadAll('casa');
      this.transitionTo('serviceRequest.status');
    }
  }
});
