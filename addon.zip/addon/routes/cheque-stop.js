import { Promise as EmberPromise } from 'rsvp';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';

export default FereFormRoute.extend({
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),

  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'CHEQ_BLCK_STEP1', countryCode: this.get('axwayConfig.country'), id: 'W947' } };
    }
  }),

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
  },

  closeThisForm() {
    this.transitionTo('serviceRequest.new-request');
  },

  afterSubmit(formDatum) {
    return new EmberPromise(resolve => {
      let entityDetails = formDatum.get('additionalInfo') && formDatum.get('additionalInfo').entityDetail;

      if (!isEmpty(entityDetails)) {
        let CHQAccNo = this.get('store').peekRecord('field', 'CHQAccNo');
        let chqAcc = CHQAccNo.get('value');

        chqAcc.status = entityDetails[0] && entityDetails[0].status;
        CHQAccNo.set('value', chqAcc);
      }
      this.enableGoToNext();
      resolve();
    });
  },

  actions: {
    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        this.transitionTo('serviceRequest.new-request');
      }
    },
    closeForm() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
