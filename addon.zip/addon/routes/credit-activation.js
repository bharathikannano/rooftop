import { isNone, isBlank } from '@ember/utils';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../config/environment';
import { later } from '@ember/runloop';

export default Route.extend({
  rdcModalManager: service(),
  store: service(),
  rdcLoadingIndicator: service(),
  i18n: service(),
  queries: service('customer-info'),
  beforeModel() {
    let countryCode = this.get('queries.countryName');
    if (isNone(countryCode) || isBlank(countryCode)) {
      this.transitionTo('serviceRequest.new-request');
    } else {
      this.transitionTo('credit-activation.select');
    }
  },
  setupController(controller) {
    if (document.getElementById('view-credit-pin-change-container')) {
      later(function() {
        let element = document.getElementById('view-credit-pin-change-container');
        if (element) {
          element.scrollTop = 0;
          element.scrollLeft = 0;
        }
      }, 5);
    }
    this._super(...arguments);
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    controller.set('closeIcon', true);
  },
  actions: {
    willTransition(transition) {
      if (document.getElementById('view-credit-pin-change-container')) {
        later(function() {
          let element = document.getElementById('view-credit-pin-change-container');
          if (element) {
            element.scrollTop = 0;
            element.scrollLeft = 0;
          }
        }, 5);
      }
      this.controllerFor('credit-activation').set('closeIcon', true);
      if (transition.targetName.indexOf('credit-activation.status') != -1) {
        this.controllerFor('credit-activation').set('closeIcon', false);
      }
    },
    closePopupAction() {
      let message;
      if (this.get('media.isDesktop')) {
        message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
      } else {
        message = this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankText');
      }
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
        })
        .catch(() => {});
    },
    navigateToHelpAndServices() {
      let message = this.get('i18n').t('ServiceRequest.COMMON.backToHelpAndServicesText');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          this.transitionTo('serviceRequest.new-request');
        })
        .catch(() => {});
    }
  }
});
