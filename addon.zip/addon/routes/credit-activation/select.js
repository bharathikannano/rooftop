import { hash } from 'rsvp';
import { isNone, isBlank, isEmpty, typeOf, isEqual } from '@ember/utils';
import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';

export default Route.extend({
  store: service(),
  queries: service('customer-info'),
  i18n: service(),
  error: service('card-error-handler'),
  rdcModalManager: service(),
  idle: service('idle-ticker'),
  rdcLoadingIndicator: service(),
  countryCode: '',
  init() {
    this._super();
    this.get('store').unloadAll('credit-card');
  },
  model() {
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    this.get('rdcLoadingIndicator').showLoadingIndicator(
      this.get('i18n').t('ServiceRequest.COMMON.loadingIndicatorText'),
      'rdc-loading-indicator'
    );
    let countryCode = this.get('queries.countryName');
    if (!isNone(countryCode) && !isBlank(countryCode)) {
      countryCode = countryCode.toUpperCase();
      this.set('countryCode', countryCode);
    }
    this.get('store').unloadAll('credit-card');
    let CreditCardDetails = this.get('store')
      .query('credit-card', {
        filter: config.Filters.creditCardActivation[countryCode]
      })
      .then(
        data => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.set('creditCardStatus', 'CreditCardSuccess');
          if (data.content.length == 0) {
            this.set('creditCardStatus', 'emptyAndNoError');
          }
          return data;
        },
        error => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.errorHandler(error);
        }
      );

    return hash({
      CreditCardDetails: CreditCardDetails
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    let creditcard;

    if (!isNone(model) && !isNone(model.CreditCardDetails)) {
      creditcard = model.CreditCardDetails.content;
    }

    controller.set('cardMasking', true);
    controller.set('isCountryAsSG', false);

    if (isEqual(this.get('countryCode'), 'HK')) {
      controller.set('isCountryAsHK', true);
      controller.set('countryNotes', this.get('i18n').t('ServiceRequest.CREDITCARD.pinSetup.countryNotes.HK'));
      controller.set('notemessages', htmlSafe(controller.get('countryNotes').toString()));
    }

    if (isEqual(this.get('countryCode'), 'SG')) {
      controller.set('cardMasking', false);
      controller.set('isCountryAsSG', true);
      controller.set('countryNotes', this.get('i18n').t('ServiceRequest.CREDITCARD.pinSetup.countryNotes.SG'));
      controller.set('notemessages', htmlSafe(controller.get('countryNotes').toString()));
    }
    if (!(isBlank(creditcard) || isNone(creditcard)) || this.get('creditCardStatus') == 'CreditCardSuccess') {
      controller.set('dataAvailable', true);
    } else {
      controller.set('dataAvailable', false);
    }
    controller.set('errorPopUp', this.errorPopUp);
    controller.set('errorAlert', this.errorMessage);

    let disclaimerNotes = this.get('i18n').t(
      'ServiceRequest.CREDITCARD.activation.disclaimerNotes.' + this.get('countryCode')
    );

    if (
      !isEmpty(disclaimerNotes) &&
      !isEmpty(disclaimerNotes.string) &&
      disclaimerNotes.string.indexOf('Missing translation') == -1
    ) {
      controller.set('disclaimerNotes', disclaimerNotes);
    }
  },
  errorHandler(error) {
    this.set('creditCardStatus', 'CreditCardError');
    typeOf(error.errors) == 'undefined'
      ? this.set('CreditCardErrorcheck', 'undefined')
      : this.set('CreditCardErrorcheck', error.errors[0].code);
    this.get('error').creditCardErrorHandler(this);
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },
  actions: {
    goToBack() {
      this.get('store').unloadAll('credit-card');
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
