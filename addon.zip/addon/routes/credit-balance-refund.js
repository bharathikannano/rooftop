import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../config/environment';

export default Route.extend({
  i18n: service(),
  rdcModalManager: service(),
  store: service(),
  loaderInProgress: false,
  queries: service('customer-info'),

  setupController(controller) {
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    let bp = 'is-mobile';
    if (this.get('media.isDesktop')) {
      bp = 'is-desktop';
    } else if (this.get('media.isTablet')) {
      bp = 'is-tablet';
    } else if (this.get('media.isMobile')) {
      bp = 'is-mobile';
    }
    controller.set('bpClass', bp);
  },
  beforeModel() {
    // this.controllerFor('credit-balance-refund').set('isValid', true);
    this.transitionTo('credit-balance-refund.new-request');
  },
  deactivate() {
    //Ember.$('html').removeClass('service-request');
  },
  resetController(controller, isExiting, transition) {
    if (transition.targetName.indexOf('credit-balance-refund') == -1) {
      this.controllerFor('credit-balance-refund').set('loaderInProgress', false);
      this.controllerFor('credit-balance-refund.new-request').set('selectedFromAcc', null);
      this.controllerFor('credit-balance-refund.new-request').set('reasonSelected', null);
      if (this.controllerFor('credit-balance-refund.new-request').get('model').CreditCardDetails != undefined) {
        this.controllerFor('credit-balance-refund.new-request')
          .get('model')
          .CreditCardDetails.forEach(function(item) {
            item.set('isSelected', false);
          });
      }
    }
  },
  actions: {
    cancelProgress() {
      this.controllerFor('credit-balance-refund').set('clickCancel', true);
      let message = this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.requestCancel.content');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          this.get('store').unloadAll('credit-card');
          this.controllerFor('credit-balance-refund').set('clickCancel', false);
          this.transitionTo('serviceRequest.new-request');
        })
        .catch(() => {
          this.controllerFor('credit-balance-refund').set('clickCancel', false);
        });
    },
    closePopupAction() {
      this.controllerFor('credit-balance-refund').set('clickCancel', true);
      let message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
          this.controllerFor('credit-balance-refund').set('clickCancel', false);
        })
        .catch(() => {
          this.controllerFor('credit-balance-refund').set('clickCancel', false);
        });
    }
  }
});
