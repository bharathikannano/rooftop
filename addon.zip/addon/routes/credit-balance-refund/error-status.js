import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),

  model: function() {
    return this.controllerFor('credit-balance-refund.new-request').get('cardData');
  },

  setupController(controller, model) {
    this._super(controller, model);
    let device = this.controllerFor('credit-balance-refund').get('bpClass');
    if (device == 'is-desktop') {
      later(function() {
        document.getElementById('cbr-id').scrollIntoView();
      }, 5);
    }
    controller.set(
      'phoneBankingHotlineLinks',
      this.get('i18n').t(
        'ServiceRequest.CREDITBALANCEREFUND.phoneBankingHotline.link.' + this.get('queries.countryName')
      )
    );
    controller.set(
      'phoneBankingHotlineTxt',
      this.get('i18n').t(
        'ServiceRequest.CREDITBALANCEREFUND.phoneBankingHotline.text.' + this.get('queries.countryName')
      )
    );

    controller.set('links', htmlSafe(controller.get('phoneBankingHotlineTxt').toString()));

    controller.set(
      'contactHotline',
      this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.statusMsg.contactPhoneBankingHotline.content', {
        inter_link: controller.get('links')
      })
    );
    controller.set(
      'contactHotlineForUpdateAddress',
      this.get('i18n').t(
        'ServiceRequest.CREDITBALANCEREFUND.statusMsg.contactPhoneBankingHotline.updateAddress.content',
        { inter_link: controller.get('links') }
      )
    );
  },

  actions: {
    gotoHome() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('casa');
      this.get('store').unloadAll('cc-address');
      this.get('store').unloadAll('spv1-service-request');
      let refundToCO = this.controllerFor('credit-balance-refund.new-request').get('cardData')[0].refundToCO;
      if (refundToCO) {
        this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
        this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
        this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
      }
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
