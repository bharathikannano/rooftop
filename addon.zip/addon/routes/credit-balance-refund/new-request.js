import { htmlSafe } from '@ember/string';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  rdcLoadingIndicator: service(),
  beforeModel() {
    let scope = this;
    scope.controllerFor('serviceRequest.new-request').set('loaderInProgress', true);
  },
  model() {
    let self = this;

    let CreditCardDetails;

    let fromCardList = [];
    let toCardList = [];

    CreditCardDetails = this.get('store')
      .query('credit-card', {
        filter: {
          eligibleForCreditBalRefund: 'yes'
        }
      })
      .then(
        function(data) {
          data.forEach(function(element) {
            if (element.get('alerts') && element.get('alerts').length >= 1 && !element.get('balanceRefundflag')) {
              self.transitionTo('serviceRequest.new-request');

              let message = htmlSafe(element.get('alerts')[0].message);
              self.controllerFor('serviceRequest.new-request').set('cancelPopup', false);
              self.controllerFor('serviceRequest.new-request').set('systemErrorPopup', true);

              self
                .get('rdcModalManager')
                .showDialogModal({
                  level: 'info',
                  message,
                  acceptButtonLabel: self.get('i18n').t('ServiceRequest.COMMON.button.ok'),
                  iconClass: 'service-journey-info-icon',
                  popupClass: 'service-journey-system-error-popup'
                })
                .then(() => {
                  self.transitionTo('serviceRequest.new-request');
                });
            }

            element.set('isSelected', false);
            element.set('disableAmountText', true);
            element.set('amountEntered', '');
            element.set('errorText', false);
            element.set('maxRefundAmountErrorText', false);
            if (element.get('balanceRefundflag') == 'D') {
              fromCardList.push(element);
            } else if (element.get('balanceRefundflag') == 'C') {
              toCardList.push(element);
            }
          });
          return data;
        },
        function() {
          let message = self.get('i18n').t('ServiceRequest.COMMON.systemError');
          self
            .get('rdcModalManager')
            .showDialogModal({
              level: 'info',
              message,
              title: self.get('i18n').t('ServiceRequest.COMMON.systemError.title'),
              acceptButtonLabel: self.get('i18n').t('ServiceRequest.COMMON.button.ok'),
              iconClass: 'service-journey-system-error-icon',
              popupClass: 'service-journey-system-error-popup'
            })
            .then(() => {
              self.transitionTo('serviceRequest.new-request');
            });
        }
      );

    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(CreditCardDetails, ' ');
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    let fromCardNotesText = this.get('i18n').t(
      'ServiceRequest.CREDITBALANCEREFUND.notes.fromCard.' + this.get('queries.countryName')
    ).string
      ? this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.notes.fromCard.' + this.get('queries.countryName'))
          .string
      : this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.notes.fromCard.default').string;

    return hash({
      sacRefundList: [
        {
          value: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.selfAssisted.reason1')
            .toString(),
          toBackendValue: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.backend.selfAssisted.reason1')
            .toString(),
          id: '1'
        },
        {
          value: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.selfAssisted.reason2')
            .toString(),
          toBackendValue: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.backend.selfAssisted.reason2')
            .toString(),
          id: '2'
        },
        {
          value: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.selfAssisted.reason3')
            .toString(),
          toBackendValue: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.backend.selfAssisted.reason3')
            .toString(),
          id: '3'
        }
      ],
      flcRefundList: [
        {
          value: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.frontline.reason1')
            .toString(),
          id: '1'
        },
        {
          value: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.frontline.reason2')
            .toString(),
          id: '2'
        },
        {
          value: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.frontline.reason3')
            .toString(),
          id: '3'
        },
        {
          value: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.frontline.reason4')
            .toString(),
          id: '4'
        },
        {
          value: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.frontline.reason5')
            .toString(),
          id: '5'
        },
        {
          value: this.get('i18n')
            .t('ServiceRequest.CREDITBALANCEREFUND.selectReason.frontline.reason6')
            .toString(),
          id: '6'
        }
      ],

      ccimage: 'https://placehold.it/60x40',
      CreditCardDetails: CreditCardDetails,
      fromCardList: fromCardList,
      toCardList: toCardList,
      fromCardNotes: fromCardNotesText
    });
  },

  setupController(controller, model) {
    this._super(controller, model);
    let device = this.controllerFor('credit-balance-refund').get('bpClass');
    if (device == 'is-desktop') {
      later(function() {
        document.getElementById('cbr-id').scrollIntoView();
      }, 5);
    }
  },

  actions: {
    loading(transition) {
      let scope = this;
      transition.promise.finally(function() {
        scope.controllerFor('serviceRequest.new-request').set('loaderInProgress', false);
      });
    },
    systemErrorPopup(scope) {
      scope.transitionTo('serviceRequest.rdc-confirmpopup');
    },
    error: function(error) {
      if (error.errors && error.errors[0].code == '1702') {
        document.location.href = config.backToiBankURL;
        return;
      }
      this.controllerFor('serviceRequest').set('cancelPopup', false);
      this.controllerFor('serviceRequest').set('systemErrorPopup', true);
      let message = this.get('i18n').t('ServiceRequest.COMMON.systemError');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.controllerFor('serviceRequest').set('systemErrorPopup', false);
          this.transitionTo('serviceRequest.new-request');
        });

      this.set('loaderInProgress', false);
    },

    goToBack() {
      this.transitionTo('serviceRequest.new-request');
    },

    enableNext() {
      let self = this;
      let toCardList = this.controller.get('model').toCardList;
      let selectedCreditCardDetails = [];
      let creditCardDetails = null;
      creditCardDetails = this.controller.get('model').CreditCardDetails;
      let toCardLcy = [];
      let casaData = [];
      let refundMethod = null;

      selectedCreditCardDetails = creditCardDetails.filterBy('isSelected');

      if (selectedCreditCardDetails[0].get('alerts')) {
        self.transitionTo('credit-balance-refund.new-request');
        let message = selectedCreditCardDetails[0].get('alerts')[0].message;
        self.set('currentModel.systemErrorPopup', true);
        self.set('currentModel.cancelPopup', false);
        self.get('rdcModalManager').showDialogModal({
          level: 'info',
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-system-error-popup'
        });
      } else {
        let selectedCurrency = selectedCreditCardDetails[0].get('currencyCode');
        let selectedFromCardExAmt = parseFloat(selectedCreditCardDetails[0].get('excessAmount'));
        let selectedFromCardCustAvailCrLim = parseFloat(
          selectedCreditCardDetails[0].get('customerAvailableCreditLimit')
        );
        if (toCardList.length > 0) {
          toCardList.forEach(function(element) {
            if (self.get('queries.countryName') != 'AE' && selectedFromCardExAmt <= selectedFromCardCustAvailCrLim) {
              if (element.get('currencyCode') == selectedCurrency) {
                if ('Y' == element.get('cbrTocardBlockFlag') || 'Y' == element.get('delinquencyFlag')) {
                  toCardLcy.push(element);
                }
              }
            } else {
              if (element.get('currencyCode') == selectedCurrency) {
                toCardLcy.push(element);
              }
            }
          });
        }

        if (toCardLcy.length > 0) {
          refundMethod = 'CC';
          self.send('routeToNextPage', refundMethod, toCardLcy);
        } else {
          let isCBRASA = ['NP', 'LK', 'BD', 'BN'].indexOf(self.get('queries.countryName')) !== -1;
          if (
            isCBRASA ||
            self.get('queries.countryName') == 'AE' ||
            selectedFromCardExAmt <= selectedFromCardCustAvailCrLim
          ) {
            self.get('rdcLoadingIndicator').showLoadingIndicator(' ');
            self.get('rdcLoadingIndicator').setThemeClass('ui10');

            this.get('store')
              .query('casa', {
                filter: {
                  eligibleForCreditBalRefund: 'yes'
                }
              })
              .then(
                function(data) {
                  data.forEach(function(element) {
                    element.set('isSelected', false);
                    element.set('disableAmountText', true);
                    element.set('amountEntered', '');
                    element.set('errorText', false);
                    element.set('maxRefundAmountErrorText', false);

                    if (element.get('currencyCode') == selectedCurrency) {
                      casaData.push(element);
                    }
                  });

                  if (casaData.length > 0) {
                    refundMethod = 'CASA';
                    self.send('routeToNextPage', refundMethod, casaData);
                    self.get('rdcLoadingIndicator').hideLoadingIndicator();
                  }

                  if (refundMethod != 'CC' && refundMethod != 'CASA') {
                    if (
                      self.get('queries.countryName') == 'SG' ||
                      (self.get('queries.countryName') == 'IN' && self.get('queries.customerFlowFlag') != false)
                    ) {
                      self
                        .get('store')
                        .query('spv1-service-request', {
                          filter: {
                            eligibleForCreditBalRefund: 'yes'
                          }
                        })
                        .then(
                          function(data) {
                            if (data.content.length > 0) {
                              data.forEach(function(element) {
                                if (element.get('alerts') && element.get('alerts').length >= 1) {
                                  refundMethod = 'PENDING';
                                  self.send('routeToNextPage', refundMethod, null);
                                  self.get('rdcLoadingIndicator').hideLoadingIndicator();
                                } else {
                                  refundMethod = 'CO';
                                  self.send('routeToNextPage', refundMethod, null);
                                  self.get('rdcLoadingIndicator').hideLoadingIndicator();
                                }
                              });
                            } else {
                              refundMethod = 'CO';
                              self.send('routeToNextPage', refundMethod, null);
                              self.get('rdcLoadingIndicator').hideLoadingIndicator();
                            }
                            return data;
                          },
                          function() {
                            let message = self.get('i18n').t('ServiceRequest.COMMON.systemError');
                            self
                              .get('rdcModalManager')
                              .showDialogModal({
                                level: 'info',
                                message,
                                title: self.get('i18n').t('ServiceRequest.COMMON.systemError.title'),
                                acceptButtonLabel: self.get('i18n').t('ServiceRequest.COMMON.button.ok'),
                                iconClass: 'service-journey-info-icon',
                                popupClass: 'service-journey-system-error-popup'
                              })
                              .then(() => {
                                self.transitionTo('serviceRequest.new-request');
                                self.get('rdcLoadingIndicator').hideLoadingIndicator();
                              });
                          }
                        );
                    } else {
                      refundMethod = 'NOTSUPPORTED';
                      self.send('routeToNextPage', refundMethod, null);
                    }
                  }
                },
                function(error) {
                  if (error.errors && error.errors[0].code == '1702') {
                    document.location.href = config.backToiBankURL;
                    return;
                  }
                  let message = self.get('i18n').t('ServiceRequest.COMMON.systemError');
                  self.set('currentModel.systemErrorPopup', true);

                  self
                    .get('rdcModalManager')
                    .showDialogModal({
                      level: 'info',
                      message,
                      title: self.get('i18n').t('ServiceRequest.COMMON.systemError.title'),
                      acceptButtonLabel: self.get('i18n').t('ServiceRequest.COMMON.button.ok'),
                      iconClass: 'service-journey-info-icon',
                      popupClass: 'service-journey-system-error-popup'
                    })
                    .then(() => {
                      self.transitionTo('serviceRequest.new-request');
                    });
                }
              );
          } else {
            refundMethod = 'NOTSUPPORTED';
            self.send('routeToNextPage', refundMethod, null);
            this.transitionTo('credit-balance-refund.error-status');
          }
        }
      }
    },

    routeToNextPage(refundMethod, refundMethodData) {
      let refundToCC = false;
      let refundToCasa = false;
      let refundToCO = false;
      let errorPageForSac = false;
      let unsupportedCOCountry = false;
      let pendingAddressChange = false;

      let toCardList = null;
      let casaDetails = null;
      let addressDetails = null;
      let addressText = '';
      let userGroup = '';

      if (refundMethod == 'CC') {
        refundToCC = true;
        toCardList = refundMethodData;
      } else if (refundMethod == 'CASA') {
        refundToCasa = true;
        casaDetails = refundMethodData;
      } else if (refundMethod == 'CO') {
        refundToCO = true;
        addressDetails = refundMethodData;
      } else if (refundMethod == 'PENDING') {
        errorPageForSac = true;
        pendingAddressChange = true;
      } else if (refundMethod == 'NOTSUPPORTED') {
        errorPageForSac = true;
        unsupportedCOCountry = true;
      }

      let selectedCreditCardDetails = [];
      let refundList = null;
      if (this.get('queries.customerFlowFlag') == false) {
        refundList = this.controller.get('model').flcRefundList;
      } else {
        refundList = this.controller.get('model').sacRefundList;
      }

      let selectedReason = this.controller.get('model').selectedReason;
      let creditCardDetails = this.controller.get('model').CreditCardDetails;

      selectedCreditCardDetails = creditCardDetails.filterBy('isSelected');

      if (this.get('queries.customerFlowFlag') == false) {
        userGroup = this.get('queries.userGroup');
      }

      let pageData = [
        {
          refundReason: refundList,
          selectedCard: selectedCreditCardDetails,
          toCardList: toCardList, //lcylist
          casaDetails: casaDetails, //tbd
          selectedReason: selectedReason,
          pendingAddressChange: pendingAddressChange,
          refundToCC: refundToCC,
          refundToCasa: refundToCasa,
          refundToCO: refundToCO,
          errorPageForSac: errorPageForSac,
          address: addressDetails, //tbd,
          addressText: htmlSafe(addressText),
          unsupportedCOCountry: unsupportedCOCountry,
          userGroup: userGroup
        }
      ];

      this.controllerFor('credit-balance-refund.new-request').set('cardData', pageData);
      if (errorPageForSac) {
        this.transitionTo('credit-balance-refund.error-status');
      } else if (refundToCC || refundToCasa) {
        this.transitionTo('credit-balance-refund.refund-method');
      } else if (refundToCO) {
        this.transitionTo('credit-balance-refund.refund-amount');
      }
    }
  }
});
