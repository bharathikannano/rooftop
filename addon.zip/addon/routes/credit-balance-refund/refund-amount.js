import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  rdcLoadingIndicator: service(),
  classNames: ['rdc-cards col-lg-3'],
  classNameBindings: ['recalculateExcessBalance'],
  model: function() {
    return this.controllerFor('credit-balance-refund.new-request').get('cardData');
  },

  setupController(controller, model) {
    this._super(controller, model);
    let device = this.controllerFor('credit-balance-refund').get('bpClass');

    if (this.controller.target.currentRouteName == 'rdc-ui-eng-service-requests.credit-balance-refund.new-request') {
      this.controller.set('selectedReason', '');
      this.controller.model.forEach(function(element) {
        element.selectedCard.forEach(function(item) {
          if (item.showAddress) {
            item.showAddress = false;
          }
        });
      });
    }

    if (device == 'is-desktop') {
      later(function() {
        document.getElementById('cbr-id').scrollIntoView();
      }, 5);
    }
    let remBalance = this.controller.get('model')[0].selectedCard[0].get('excessAmount');

    let refundToCC = this.controller.get('model')[0].refundToCC;
    let refundToCasa = this.controller.get('model')[0].refundToCasa;
    let refundToCO = this.controller.get('model')[0].refundToCO;

    if (refundToCC) {
      this.controller.get('model')[0].toCardList.forEach(function(item) {
        if (item.isSelected) {
          let value = item.amountEntered;
          if (value == '' || value == undefined) {
            value = 0;
          }
          if (value % 1 === 0 && remBalance % 1 === 0) {
            remBalance = remBalance - value;
          } else {
            remBalance = (parseFloat(remBalance) - parseFloat(value)).toFixed(2);
          }

          if (!item.amountEntered) {
            controller.set('enableNext', false);
          }
        }
      });
    } else if (refundToCasa) {
      this.controller.get('model')[0].casaDetails.forEach(function(item) {
        if (item.isSelected) {
          let value = item.amountEntered;
          if (value == '' || value == undefined) {
            value = 0;
          }
          if (value % 1 === 0 && remBalance % 1 === 0) {
            remBalance = remBalance - value;
          } else {
            remBalance = (parseFloat(remBalance) - parseFloat(value)).toFixed(2);
          }

          if (!item.amountEntered) {
            controller.set('enableNext', false);
          }
        }
      });
    } else if (refundToCO) {
      let value = this.controller.get('model')[0].selectedCard[0].amountEntered;
      if (value == '' || value == undefined) {
        value = 0;
      }

      if (value % 1 === 0 && remBalance % 1 === 0) {
        remBalance = remBalance - value;
      } else {
        remBalance = (parseFloat(remBalance) - parseFloat(value)).toFixed(2);
      }

      if (!this.controller.get('model')[0].selectedCard[0].amountEntered) {
        controller.set('enableNext', false);
      }
    }

    // var remBalance = this.controllerFor('credit-balance-refund.new-request').get('cardData')[0].selectedCard[0].get('excessAmount');
    controller.get('model')[0].selectedCard[0].set('remainingbalance', remBalance);

    if (this.get('queries.countryName') == 'SG') {
      controller.set('checkaddressAllowed', true);

      if (this.get('queries.customerFlowFlag') == false) {
        controller.set('updateaddressAllowed', false);
      } else {
        controller.set('updateaddressAllowed', true);
      }
    } else {
      controller.set('checkaddressAllowed', true);
      controller.set('updateaddressAllowed', false);
    }

    controller.set(
      'updateAddressLinks',
      this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.updateAddressLinks.' + this.get('queries.countryName'))
    );
    controller.set(
      'updateAddressTxt',
      this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.updateAddress.text', {
        inter_link: controller.get('links')
      })
    );

    controller.set(
      'links',
      htmlSafe(
        `<a href="${controller.get('updateAddressLinks').toString()}" target="_self">${controller
          .get('updateAddressTxt')
          .toString()}</a>`
      )
    );

    controller.set(
      'phoneBankingHotlineLinks',
      this.get('i18n').t(
        'ServiceRequest.CREDITBALANCEREFUND.phoneBankingHotline.link.' + this.get('queries.countryName')
      )
    );
    controller.set(
      'phoneBankingHotlineTxt',
      this.get('i18n').t(
        'ServiceRequest.CREDITBALANCEREFUND.phoneBankingHotline.text.' + this.get('queries.countryName')
      )
    );

    controller.set('cclinks', htmlSafe(controller.get('phoneBankingHotlineTxt').toString()));

    controller.set(
      'contactCallCentre',
      this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.notes.addressChange', {
        inter_link: controller.get('cclinks')
      })
    );
  },

  actions: {
    goToBack() {
      let refundToCO = this.controller.get('model')[0].refundToCO;
      let refundToCC = this.controller.get('model')[0].refundToCC;
      let refundToCasa = this.controller.get('model')[0].refundToCasa;

      if (refundToCO) {
        this.transitionTo('credit-balance-refund.new-request');
        this.controller.set('selectedReason', '');
      } else {
        if (refundToCC) {
          this.controller.get('model').forEach(function(data) {
            data.toCardList.forEach(function(item) {
              if (item.isSelected) {
                item.set('amountEntered', '');
              }
            });
          });
        } else {
          if (refundToCasa) {
            this.controller.get('model').forEach(function(data) {
              data.casaDetails.forEach(function(item) {
                if (item.isSelected) {
                  item.set('amountEntered', '');
                }
              });
            });
          }
        }
        this.controller.set('selectedReason', '');
        this.transitionTo('credit-balance-refund.refund-method');
      }
    },

    redirectToDataLocker() {
      if (this.get('queries.countryName') == 'SG') {
        let self = this;
        self.set('currentModel.systemErrorPopup', false);
        self.set('currentModel.cancelPopup', true);
        self
          .get('rdcModalManager')
          .showInfoModal('redirect-datalocker-confirmation-popup', {
            customClass: 'confirmation-popup'
          })
          .then(() => {
            document.location.href = this.controller.get('updateAddressLinks');
            self.set('currentModel.cancelPopup', false);
          });
      } else {
        this.transitionTo('credit-balance-refund.error-status');
      }
    },

    focussError(element) {
      if (element.errorText) {
        document.getElementById('currencyText').classList.remove('focusedcss');
      }
    },
    recalculateExcessBalance: function(element) {
      let value = element.amountEntered;

      if (value == '' || value == undefined) {
        value = 0;
      }
      let excessAmount = this.controller.get('model')[0].selectedCard[0].get('excessAmount');
      let remainingbalance = 0;

      if (value % 1 === 0 && excessAmount % 1 === 0) {
        remainingbalance = excessAmount - value;
      } else {
        remainingbalance = (parseFloat(excessAmount) - parseFloat(value)).toFixed(2);
      }

      if (remainingbalance >= 0) {
        this.controller.get('model')[0].selectedCard[0].set('remainingbalance', remainingbalance);
        element.set('errorText', false);

        if (this.controller.get('model')[0].selectedCard[0].get('currencyCode') == 'AED' && value <= 10000) {
          element.set('maxRefundAmountErrorText', false);
        }
      } else {
        //var oldAmount = value.slice(0, -1);
        //element.set('amountEntered', oldAmount);
        this.controller.get('model')[0].selectedCard[0].set('remainingbalance', excessAmount);

        element.set('errorText', true);
      }

      this.send('validateNext');
    },

    validateReasonPicklist() {
      this.send('validateNext');
    },

    validateNext() {
      let refundToCC = this.controller.get('model')[0].refundToCC;
      let refundToCasa = this.controller.get('model')[0].refundToCasa;
      let amountValidation = false;
      let reasonValidation = false;
      let remBalance = this.controller.get('model')[0].selectedCard[0].get('excessAmount');

      if (refundToCC) {
        let toCardList = this.controller.get('model')[0].toCardList;
        toCardList.forEach(item => {
          if (item.get('isSelected')) {
            if (item.get('amountEntered') && item.get('amountEntered') != 0) {
              if (
                item.get('currencyCode') == 'AED' &&
                (parseFloat(item.get('amountEntered')) > 10000 && remBalance > parseFloat(item.get('amountEntered')))
              ) {
                amountValidation = false;
                item.set('maxRefundAmountErrorText', true);
              } else {
                if (parseFloat(item.get('amountEntered')) > parseFloat(remBalance)) {
                  // if (item.get('errorText')) {
                  amountValidation = false;
                  item.set('maxRefundAmountErrorText', false);
                  item.set('errorText', true);
                } else {
                  amountValidation = true;
                }
              }
            } else {
              amountValidation = false;
              //item.set('errorText', true);
            }
          }
        });
      } else if (refundToCasa) {
        let casaDetails = this.controller.get('model')[0].casaDetails;
        casaDetails.forEach(item => {
          if (item.get('isSelected')) {
            if (item.get('amountEntered') && item.get('amountEntered') != 0) {
              if (
                item.get('currencyCode') == 'AED' &&
                (parseFloat(item.get('amountEntered')) > 10000 && remBalance > parseFloat(item.get('amountEntered')))
              ) {
                amountValidation = false;
                item.set('maxRefundAmountErrorText', true);
              } else {
                if (parseFloat(item.get('amountEntered')) > parseFloat(remBalance)) {
                  //if (item.get('errorText')) {
                  amountValidation = false;
                  item.set('maxRefundAmountErrorText', false);
                  item.set('errorText', true);
                } else {
                  amountValidation = true;
                }
              }
            } else {
              amountValidation = false;
              //item.set('errorText', true);
            }
          }
        });
      } else {
        let amountEntered = this.controller.get('model')[0].selectedCard[0].amountEntered;
        if (amountEntered && amountEntered != 0) {
          if (parseFloat(amountEntered) > parseFloat(remBalance)) {
            //if (this.controller.get('model')[0].selectedCard[0].errorText) {
            amountValidation = false;
            this.controller.get('model')[0].selectedCard[0].set('errorText', true);
          } else {
            amountValidation = true;
          }
        } else {
          amountValidation = false;
          //this.controller.get('model')[0].selectedCard[0].set('errorText', true);
        }
      }

      if (!this.controller.get('selectedReason')) {
        reasonValidation = false;
      } else {
        reasonValidation = true;
      }

      if (amountValidation && reasonValidation) {
        this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', true);
      } else {
        this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
      }
    },

    navigateSatus() {
      this.send('validateNext');
      if (this.controllerFor('credit-balance-refund.refund-amount').get('enableNext')) {
        let self = this;

        let refundToCO = this.controller.get('model')[0].refundToCO;
        self.controller
          .get('model')[0]
          .selectedCard.set('refundReasonName', this.controller.get('selectedReason').value);
        self.controller
          .get('model')[0]
          .selectedCard.set('refundReasonBackendName', this.controller.get('selectedReason').toBackendValue);
        self.controller.get('model')[0].selectedCard.set('refundReasonId', this.controller.get('selectedReason').id);

        if (refundToCO) {
          let showAddress = this.controller.get('model')[0].selectedCard[0].get('showAddress');
          let otpValidated = this.controller.get('model')[0].selectedCard[0].get('otpValidated');

          if (this.get('queries.countryName') == 'SG' || showAddress || otpValidated) {
            this.transitionTo('credit-balance-refund.request-confirm');
          } else {
            let otpDetails = this.get('store')
              .query('credit-card', {
                filter: {
                  otpRequired: 'yes'
                }
              })
              .then(function() {
                self.controller.get('model')[0].selectedCard[0].set('otpValidated', true);
                self.transitionTo('credit-balance-refund.request-confirm');
              });
            self.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(otpDetails, ' ');
            self.get('rdcLoadingIndicator').setThemeClass('ui10');
          }
        } else {
          this.transitionTo('credit-balance-refund.request-confirm');
        }
      } else {
        //todo
      }
    },

    showAddress() {
      let showAddress = this.controller.get('model')[0].selectedCard[0].get('showAddress');
      let otpValidated = this.controller.get('model')[0].selectedCard[0].get('otpValidated');

      this.controller.get('model')[0].selectedCard[0].set('buttonStatus', true);

      let self = this;

      if (this.get('queries.countryName') == 'SG' || showAddress || otpValidated) {
        self.send('callAddressEnquiry');
      } else {
        let otpDetails = this.get('store')
          .query('credit-card', {
            filter: {
              otpRequired: 'yes'
            }
          })
          .then(function() {
            self.send('callAddressEnquiry');
          });
        self.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(otpDetails, ' ');
        self.get('rdcLoadingIndicator').setThemeClass('ui10');
      }
    },

    callAddressEnquiry() {
      let self = this;
      let addressText;

      let CCAddressDetails = self
        .get('store')
        .query('cc-address', {})
        .then(
          function(address) {
            if (address.content.length == 0) {
              self.controller.get('model')[0].selectedCard[0].set('showAddress', true);
              self.controller.get('model')[0].selectedCard[0].set('addressText', 'No address to display');
            }

            address.forEach(function(item) {
              addressText =
                (item.get('address1') == undefined ? '' : item.get('address1')) +
                (item.get('address2') == undefined ? '' : '<br/> ' + item.get('address2')) +
                (item.get('address3') == undefined ? '' : '<br/> ' + item.get('address3')) +
                (item.get('address4') == undefined ? '' : '<br/> ' + item.get('address4')) +
                (item.get('city') == undefined ? '' : ', ' + item.get('cityName')) +
                (item.get('postalCode') == undefined ? '' : '</br> ' + item.get('postalCode')) +
                (item.get('state') == undefined ? '' : '<br/> ' + item.get('state'));

              self.controller.get('model')[0].selectedCard[0].set('showAddress', true);
              self.controller.get('model')[0].selectedCard[0].set('addressText', htmlSafe(addressText));
            });
          },
          error => {
            // self.send('error', error);
            if (error.errors && error.errors[0].code == '1702') {
              document.location.href = config.backToiBankURL;
              return;
            }
            let message = self.get('i18n').t('ServiceRequest.COMMON.systemError');
            self.set('currentModel.systemErrorPopup', true);

            self.controllerFor('credit-balance-refund.refund-amount').set('errorPopUp', true);
            self
              .get('rdcModalManager')
              .showDialogModal({
                level: 'info',
                message,
                title: self.get('i18n').t('ServiceRequest.COMMON.systemError.title'),
                acceptButtonLabel: self.get('i18n').t('ServiceRequest.COMMON.button.ok'),
                iconClass: 'service-journey-system-error-icon',
                popupClass: 'service-journey-system-error-popup'
              })
              .then(() => {
                self.transitionTo('serviceRequest.new-request');
              });
          }
        );

      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(CCAddressDetails, ' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');

      // });  //Commented temporarily for testing
    }
  }
});
