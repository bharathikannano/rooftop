import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { set } from '@ember/object';
import { later } from '@ember/runloop';

export default Route.extend({
  i18n: service(),
  axwayConfig: service(),
  queries: service('customer-info'),
  classNames: ['rdc-cards col-lg-3'],
  model: function() {
    return this.controllerFor('credit-balance-refund.new-request').get('cardData');
  },

  afterModel(data) {
    let statementBalanceNotesText = this.get('i18n').t(
      'ServiceRequest.CREDITBALANCEREFUND.notes.statementBalance.' + this.get('queries.countryName')
    ).string
      ? this.get('i18n').t(
          'ServiceRequest.CREDITBALANCEREFUND.notes.statementBalance.' + this.get('queries.countryName')
        ).string
      : this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.notes.statementBalance.default').string;
    let minimumPaymentNotesText = this.get('i18n').t(
      'ServiceRequest.CREDITBALANCEREFUND.notes.minimumPayment.' + this.get('queries.countryName')
    ).string
      ? this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.notes.minimumPayment.' + this.get('queries.countryName'))
          .string
      : this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.notes.minimumPayment.default').string;
    set(data, 'statementBalanceNotes', statementBalanceNotesText);
    set(data, 'minimumPaymentNotes', minimumPaymentNotesText);
  },

  setupController(controller, model) {
    this._super(controller, model);
    // controller.set('enableNext', false);
    let device = this.controllerFor('credit-balance-refund').get('bpClass');
    if (device == 'is-desktop') {
      if (this.controller.target.currentRouteName == 'rdc-ui-eng-service-requests.credit-balance-refund.new-request') {
        this.controller.set('selectedReason', '');
      }
      later(function() {
        document.getElementById('cbr-id').scrollIntoView();
      }, 5);
    }
    let remBalance = this.controller.get('model')[0].selectedCard[0].get('excessAmount');

    let refundToCC = this.controller.get('model')[0].refundToCC;
    let refundToCasa = this.controller.get('model')[0].refundToCasa;
    let refundToCO = this.controller.get('model')[0].refundToCO;

    if (refundToCC) {
      this.controller.get('model')[0].toCardList.forEach(function(item) {
        if (item.isSelected) {
          let value = item.amountEntered;
          if (value == '' || value == undefined) {
            value = 0;
          }
          if (value % 1 === 0 && remBalance % 1 === 0) {
            remBalance = remBalance - value;
          } else {
            remBalance = (parseFloat(remBalance) - parseFloat(value)).toFixed(2);
          }
        }
      });
    } else if (refundToCasa) {
      this.controller.get('model')[0].casaDetails.forEach(function(item) {
        if (item.isSelected) {
          let value = item.amountEntered;
          if (value == '' || value == undefined) {
            value = 0;
          }
          if (value % 1 === 0 && remBalance % 1 === 0) {
            remBalance = remBalance - value;
          } else {
            remBalance = (parseFloat(remBalance) - parseFloat(value)).toFixed(2);
          }
        }
      });
    } else if (refundToCO) {
      let value = this.controller.get('model')[0].selectedCard[0].amountEntered;
      if (value == '' || value == undefined) {
        value = 0;
      }
      if (value % 1 === 0 && remBalance % 1 === 0) {
        remBalance = remBalance - value;
      } else {
        remBalance = (parseFloat(remBalance) - parseFloat(value)).toFixed(2);
      }
    }

    // var remBalance = this.controllerFor('credit-balance-refund.new-request').get('cardData')[0].selectedCard[0].get('excessAmount');
    controller.get('model')[0].selectedCard[0].set('remainingbalance', remBalance);
  },

  actions: {
    goToBack() {
      this.transitionTo('credit-balance-refund.new-request');

      let device = this.controllerFor('credit-balance-refund').get('bpClass');
      if (device == 'is-mobile') {
        this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
        this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
      } else {
        this.controllerFor('credit-balance-refund.refund-method').set('enableNext', false);
        this.controller.set('selectedReason', '');
      }
    },

    recalculateExcessBalance(balanceAmount, element) {
      if (balanceAmount == '' || balanceAmount == undefined) {
        balanceAmount = 0;
      }

      let excessAmount = this.controller.get('model')[0].selectedCard[0].get('excessAmount');
      let remainingbalance = 0;

      if (balanceAmount % 1 === 0 && excessAmount % 1 === 0) {
        remainingbalance = excessAmount - balanceAmount;
      } else {
        remainingbalance = (parseFloat(excessAmount) - parseFloat(balanceAmount)).toFixed(2);
      }

      if (remainingbalance >= 0) {
        this.controller.get('model')[0].selectedCard[0].set('remainingbalance', remainingbalance);
        element.set('errorText', false);
        if (
          (this.controller.get('model')[0].selectedCard[0].get('currencyCode') == 'AED' && balanceAmount <= 10000) ||
          (this.controller.get('model')[0].selectedCard[0].get('currencyCode') == 'BND' && balanceAmount <= 5000)
        ) {
          element.set('maxRefundAmountErrorText', false);
        }
      } else {
        //var oldAmount = element.get('amountEntered').slice(0, -1);
        //element.set('amountEntered', oldAmount)
        this.controller.get('model')[0].selectedCard[0].set('remainingbalance', excessAmount);
        element.set('errorText', true);
      }
      this.send('validateNext');
    },

    navigateSatus() {
      this.send('validateNext');
      if (this.controllerFor('credit-balance-refund.refund-method').get('enableNext')) {
        let isASA = ['VN', 'BN', 'NP', 'LK', 'BD'].indexOf(this.get('axwayConfig.country')) !== -1;
        this.controller
          .get('model')[0]
          .selectedCard.set('refundReasonName', this.controller.get('selectedReason').value);
        if (isASA) {
          this.controller
            .get('model')[0]
            .selectedCard.set('refundReasonBackendName', this.controller.get('selectedReason').toBackendValue);
        }
        this.controller
          .get('model')[0]
          .selectedCard.set('refundReasonName', this.controller.get('selectedReason').value);
        this.controller.get('model')[0].selectedCard.set('refundReasonId', this.controller.get('selectedReason').id);
        this.transitionTo('credit-balance-refund.request-confirm');
      } else {
        //todo
      }
    },

    enableAmountSection() {
      let device = this.controllerFor('credit-balance-refund').get('bpClass');
      if (device == 'is-desktop') {
        this.transitionTo('credit-balance-refund.refund-method');
      } else {
        this.transitionTo('credit-balance-refund.refund-amount');
      }
    },

    validateReasonPicklist() {
      this.send('validateNext');
    },

    validateNext() {
      let refundToCC = this.controller.get('model')[0].refundToCC;
      let refundToCasa = this.controller.get('model')[0].refundToCasa;

      let amountValidation = false;
      let reasonValidation = false;
      let remBalance = this.controller.get('model')[0].selectedCard[0].get('excessAmount');

      if (refundToCC) {
        let toCardList = this.controller.get('model')[0].toCardList;
        toCardList.forEach(item => {
          if (item.get('isSelected')) {
            if (item.get('amountEntered') && item.get('amountEntered') != 0) {
              if (
                (item.get('currencyCode') == 'BND' && parseFloat(item.get('amountEntered')) > 5000) ||
                (item.get('currencyCode') == 'AED' &&
                  parseFloat(item.get('amountEntered')) > 10000 &&
                  remBalance > parseFloat(item.get('amountEntered')))
              ) {
                amountValidation = false;
                item.set('maxRefundAmountErrorText', true);
              } else {
                if (parseFloat(item.get('amountEntered')) > parseFloat(remBalance)) {
                  // if (item.get('errorText')) {
                  amountValidation = false;
                  item.set('maxRefundAmountErrorText', false);
                  item.set('errorText', true);
                } else {
                  amountValidation = true;
                }
              }
            } else {
              amountValidation = false;
              //item.set('errorText', true);
            }
          }
        });
      } else if (refundToCasa) {
        let casaDetails = this.controller.get('model')[0].casaDetails;
        casaDetails.forEach(item => {
          if (item.get('isSelected')) {
            if (item.get('amountEntered') && item.get('amountEntered') != 0) {
              if (
                (item.get('currencyCode') == 'BND' && parseFloat(item.get('amountEntered')) > 5000) ||
                (item.get('currencyCode') == 'AED' &&
                  parseFloat(item.get('amountEntered')) > 10000 &&
                  remBalance > parseFloat(item.get('amountEntered')))
              ) {
                amountValidation = false;
                item.set('maxRefundAmountErrorText', true);
              } else {
                if (parseFloat(item.get('amountEntered')) > parseFloat(remBalance)) {
                  //if (item.get('errorText')) {
                  amountValidation = false;
                  item.set('maxRefundAmountErrorText', false);
                  item.set('errorText', true);
                } else {
                  amountValidation = true;
                }
              }
            } else {
              amountValidation = false;
              //item.set('errorText', true);
            }
          }
        });
      }

      if (!this.controller.get('selectedReason')) {
        reasonValidation = false;
      } else {
        reasonValidation = true;
      }

      if (amountValidation && reasonValidation) {
        this.controllerFor('credit-balance-refund.refund-method').set('enableNext', true);
      } else {
        this.controllerFor('credit-balance-refund.refund-method').set('enableNext', false);
      }
    },

    enableNext() {
      this.send('validateNext');
    }
  }
});
