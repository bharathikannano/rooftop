import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { later } from '@ember/runloop';

export default Route.extend({
  classNames: ['rdc-cards col-lg-3'],
  postDataForm: service('credit-balance-refund-save'),
  store: service(),
  queries: service('customer-info'),
  idle: service('idle-ticker'),
  rdcLoadingIndicator: service(),
  i18n: service(),
  rdcModalManager: service(),

  model: function() {
    return this.controllerFor('credit-balance-refund.new-request').get('cardData');
  },
  afterModel: function() {
    let pageData = this.controllerFor('credit-balance-refund.new-request').get('cardData');

    let excessAmount = pageData[0].selectedCard[0].get('excessAmount');

    let refundToCC = pageData[0].refundToCC;
    let refundToCasa = pageData[0].refundToCasa;
    let refundToCO = pageData[0].refundToCO;
    let amountEntered;
    let remainingbalance;

    if (refundToCC) {
      pageData[0].toCardList.forEach(function(item) {
        if (item.isSelected) {
          amountEntered = item.amountEntered;
          if (amountEntered % 1 === 0 && excessAmount % 1 === 0) {
            item.set('amountEntered', parseInt(amountEntered));
            remainingbalance = excessAmount - amountEntered;
          } else {
            item.set('amountEntered', parseFloat(amountEntered).toFixed(2));
            remainingbalance = (parseFloat(excessAmount) - parseFloat(amountEntered)).toFixed(2);
          }

          if (remainingbalance < 0) {
            item.set('errorText', true);
          }
        }
      });
    } else if (refundToCasa) {
      pageData[0].casaDetails.forEach(function(item) {
        if (item.isSelected) {
          amountEntered = item.amountEntered;
          if (amountEntered % 1 === 0 && excessAmount % 1 === 0) {
            item.set('amountEntered', parseInt(amountEntered));
            remainingbalance = excessAmount - amountEntered;
          } else {
            item.set('amountEntered', parseFloat(amountEntered).toFixed(2));
            remainingbalance = (parseFloat(excessAmount) - parseFloat(amountEntered)).toFixed(2);
          }

          if (remainingbalance < 0) {
            item.set('errorText', true);
          }
        }
      });
    } else if (refundToCO) {
      amountEntered = pageData[0].selectedCard[0].amountEntered;
      if (amountEntered % 1 === 0 && excessAmount % 1 === 0) {
        pageData[0].selectedCard[0].set('amountEntered', parseInt(amountEntered));
        remainingbalance = excessAmount - amountEntered;
      } else {
        pageData[0].selectedCard[0].set('amountEntered', parseFloat(amountEntered).toFixed(2));
        remainingbalance = (parseFloat(excessAmount) - parseFloat(amountEntered)).toFixed(2);
      }

      if (remainingbalance < 0) {
        pageData[0].selectedCard[0].set('errorText', true);
      }
    }

    let device = this.controllerFor('credit-balance-refund').get('bpClass');

    if (parseFloat(amountEntered) > parseFloat(excessAmount)) {
      if (device == 'is-desktop') {
        if (refundToCO) {
          this.transitionTo('credit-balance-refund.refund-amount');
          this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
        } else {
          this.transitionTo('credit-balance-refund.refund-method');
          this.controllerFor('credit-balance-refund.refund-method').set('enableNext', false);
        }
      } else {
        this.transitionTo('credit-balance-refund.refund-amount');
        this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
      }
    }
  },

  setupController(controller, model) {
    this._super(controller, model);
    let device = this.controllerFor('credit-balance-refund').get('bpClass');
    if (device == 'is-desktop') {
      later(function() {
        document.getElementById('cbr-id').scrollIntoView();
      }, 5);
    }
  },

  actions: {
    goToBack() {
      let device = this.controllerFor('credit-balance-refund').get('bpClass');
      let refundToCO = this.controller.get('model')[0].refundToCO;

      if (device == 'is-desktop') {
        if (refundToCO) {
          // this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason').name
          this.transitionTo('credit-balance-refund.refund-amount');
        } else {
          this.transitionTo('credit-balance-refund.refund-method');
        }
      } else {
        this.transitionTo('credit-balance-refund.refund-amount');
      }
    },

    validateConfirm() {
      let pageData = this.controllerFor('credit-balance-refund.new-request').get('cardData');

      let excessAmount = pageData[0].selectedCard[0].get('excessAmount');

      let refundToCC = pageData[0].refundToCC;
      let refundToCasa = pageData[0].refundToCasa;
      let refundToCO = pageData[0].refundToCO;
      let amountEntered;
      let remainingbalance;

      if (refundToCC) {
        pageData[0].toCardList.forEach(function(item) {
          if (item.isSelected) {
            amountEntered = item.amountEntered;
            if (amountEntered % 1 === 0 && excessAmount % 1 === 0) {
              remainingbalance = excessAmount - amountEntered;
            } else {
              remainingbalance = (parseFloat(excessAmount) - parseFloat(amountEntered)).toFixed(2);
            }

            if (remainingbalance < 0) {
              item.set('errorText', true);
            }
          }
        });
      } else if (refundToCasa) {
        pageData[0].casaDetails.forEach(function(item) {
          if (item.isSelected) {
            amountEntered = item.amountEntered;
            if (amountEntered % 1 === 0 && excessAmount % 1 === 0) {
              remainingbalance = excessAmount - amountEntered;
            } else {
              remainingbalance = (parseFloat(excessAmount) - parseFloat(amountEntered)).toFixed(2);
            }

            if (remainingbalance < 0) {
              item.set('errorText', true);
            }
          }
        });
      } else if (refundToCO) {
        amountEntered = pageData[0].selectedCard[0].amountEntered;
        if (amountEntered % 1 === 0 && excessAmount % 1 === 0) {
          remainingbalance = excessAmount - amountEntered;
        } else {
          remainingbalance = (parseFloat(excessAmount) - parseFloat(amountEntered)).toFixed(2);
        }

        if (remainingbalance < 0) {
          pageData[0].selectedCard[0].set('errorText', true);
        }
      }

      let device = this.controllerFor('credit-balance-refund').get('bpClass');

      if (parseFloat(amountEntered) > parseFloat(excessAmount)) {
        if (device == 'is-desktop') {
          if (refundToCO) {
            this.transitionTo('credit-balance-refund.refund-amount');
            this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
          } else {
            this.transitionTo('credit-balance-refund.refund-method');
            this.controllerFor('credit-balance-refund.refund-method').set('enableNext', false);
          }
        } else {
          this.transitionTo('credit-balance-refund.refund-amount');
          this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
        }
      }
    },

    navigateSatus(model) {
      this.send('validateConfirm');

      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');

      this.get('store').unloadAll('payment');

      let pageData = this.controller.get('model');

      let postReqData = this.get('postDataForm').callForData(pageData);

      let postData = this.get('store').createRecord('payment', postReqData);

      postData.save().then(
        response => {
          let postResData = this.get('store').peekAll('payment');
          this.controllerFor('credit-balance-refund.request-confirm').set('cardData', model);
          this.controllerFor('credit-balance-refund.request-confirm').set('cardResData', postResData);
          // this.transitionTo('credit-balance-refund.request-status');
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.transitionTo('credit-balance-refund.request-status').then(function(statusRoute) {
            statusRoute.currentModel.refNum = response.id;
          });
        },
        () => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.set('currentModel.systemErrorPopup', true);

          this.controllerFor('credit-balance-refund.request-confirm').set('errorPopUp', true);
          let message = this.get('i18n').t('ServiceRequest.COMMON.systemError'),
            title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              message,
              title,
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
              iconClass: 'service-journey-system-error-icon',
              popupClass: 'service-journey-system-error-popup'
            })
            .then(() => {
              this.controllerFor('credit-balance-refund.request-confirm').set('errorPopUp', false);
              this.get('store').unloadAll('credit-card');
              this.get('store').unloadAll('casa');
              this.get('store').unloadAll('cc-address');
              this.get('store').unloadAll('spv1-service-request');

              let device = this.controllerFor('credit-balance-refund').get('bpClass');
              let refundToCO = this.controllerFor('credit-balance-refund.new-request').get('cardData')[0].refundToCO;

              if (device == 'is-mobile') {
                this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
                this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
                this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
              } else {
                if (refundToCO) {
                  this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
                  this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
                  this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
                } else {
                  this.controllerFor('credit-balance-refund.refund-method').set('selectedReason', '');
                  this.controllerFor('credit-balance-refund.refund-method').set('selectedReason', '');
                  this.controllerFor('credit-balance-refund.refund-method').set('enableNext', false);
                }
              }

              this.transitionTo('serviceRequest.new-request');
            })
            .catch(() => {
              this.transitionTo('serviceRequest.new-request');
            });
        }
      );

      // this.transitionTo('credit-balance-refund.request-status');
    }
  }
});
