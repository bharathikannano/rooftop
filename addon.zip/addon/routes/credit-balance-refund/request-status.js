import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { later } from '@ember/runloop';

export default Route.extend({
  i18n: service(),
  queries: service('customer-info'),
  model: function() {
    this.controllerFor('credit-balance-refund').set('leftIcon', '');
    let device = this.controllerFor('credit-balance-refund').get('bpClass');
    if (device == 'is-desktop') {
      later(function() {
        document.getElementById('cbr-id').scrollIntoView();
      }, 5);
    }
    return this.controllerFor('credit-balance-refund.new-request').get('cardData');
  },
  afterModel(data) {
    let notesText = this.get('i18n').t(
      'ServiceRequest.CREDITBALANCEREFUND.statusMsg.success.' + this.get('queries.countryName')
    ).string
      ? this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.statusMsg.success.' + this.get('queries.countryName'))
      : this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.statusMsg.success');
    let notesTextCO = this.get('i18n').t(
      'ServiceRequest.CREDITBALANCEREFUND.statusMsg.success.cashierOrder.' + this.get('queries.countryName')
    ).string
      ? this.get('i18n').t(
          'ServiceRequest.CREDITBALANCEREFUND.statusMsg.success.cashierOrder.' + this.get('queries.countryName')
        )
      : this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.statusMsg.success.cashierOrder');

    data.acknowledgmentNotes = notesText;
    data.acknowledgmentNotesCO = notesTextCO;
  },

  actions: {
    gotoHome() {
      this.transitionTo('serviceRequest.status');
      let device = this.controllerFor('credit-balance-refund').get('bpClass');
      let refundToCO = this.controllerFor('credit-balance-refund.new-request').get('cardData')[0].refundToCO;

      if (device == 'is-mobile') {
        this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
        this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
        this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
      } else {
        if (refundToCO) {
          this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
          this.controllerFor('credit-balance-refund.refund-amount').set('selectedReason', '');
          this.controllerFor('credit-balance-refund.refund-amount').set('enableNext', false);
        } else {
          this.controllerFor('credit-balance-refund.refund-method').set('selectedReason', '');
          this.controllerFor('credit-balance-refund.refund-method').set('selectedReason', '');
          this.controllerFor('credit-balance-refund.refund-method').set('enableNext', false);
        }
      }
    }
  }
});
