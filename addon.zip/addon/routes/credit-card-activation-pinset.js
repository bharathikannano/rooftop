import { inject as service } from '@ember/service';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';
import config from '../config/environment';

export default FereFormRoute.extend({
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),
  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'CC_ACTIVATION', countryCode: this.get('axwayConfig.country'), id: 'W003' } };
    }
  }),

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
  },

  beforeModel() {
    this._super(...arguments);
    let url = document.location.href;
    let isBMW = url.includes('sapp=MBNK');
    this.set('isBMW', isBMW);
  },

  async beforeSubmit() {
    let cardDetail, pinData;
    let relationshipNo = await this.get('store')
      .peekRecord('field', 'RelationshipNo')
      .get('value');
    let pin = await this.get('store').peekRecord('field', 'encCardPin');
    // Checking customer - NTB or ETB
    if (relationshipNo === 'NTB' && !isEmpty(relationshipNo)) {
      cardDetail = await this.get('store')
        .peekRecord('field', 'CreditCardENo')
        .get('value');
      pinData =
        '@@encryptionStart' +
        cardDetail +
        '_-_' +
        '' +
        '_-_' +
        pin.get('value.value') +
        '_-_' +
        pin.get('value.value') +
        '_-_' +
        '' +
        '@@encryptionEnd';
    } else {
      cardDetail = await this.get('store')
        .peekRecord('field', 'CreditCardSNo')
        .get('value');
      pinData =
        '@@encryptionStart' +
        cardDetail.cardNum +
        '_-_' +
        '' +
        '_-_' +
        pin.get('value.value') +
        '_-_' +
        pin.get('value.value') +
        '_-_' +
        cardDetail.expDt +
        '@@encryptionEnd';
    }
    pin.set('value', pinData);
  },

  actions: {
    async closeForm() {
      let title = this.get('i18n').t('FERE.action.modal.quitApp.title');
      try {
        await this.get('rdcModalManager').showDialogModal({
          level: 'error',
          title,
          message: this.get('i18n').t('FERE.action.modal.quitApp.messageProgressLost'),
          acceptButtonLabel: this.get('i18n').t('FERE.action.button.YES'),
          rejectButtonLabel: this.get('i18n').t('FERE.action.button.NO')
        });
        if (window.cordova) {
          window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
        } else {
          const preloginStatus =
            !isEmpty(this.store.peekRecord('field', 'RelationshipNo')) &&
            this.store.peekRecord('field', 'RelationshipNo').value === 'NTB';
          if (this.get('axwayConfig.country') === 'PK' && preloginStatus) {
            /* For BMW PK */
            if (this.isBMW) {
              window.location.href = config.backToBMWNTBURL['PK'];
              return;
            }
            window.location.href = config.backToiBankNTBURL['PK'];
          } else {
            document.location.href = config.backToiBankURL;
          }
        }
      } catch (e) {
        return e;
      }
    },
    validateCard() {
      this.goToNextPage();
    }
  }
});
