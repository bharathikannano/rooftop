import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';
import config from '../config/environment';

export default FereFormRoute.extend({
  i18n: service(),
  axwayConfig: service(),
  session: service(),
  accessToken: computed('session', {
    get() {
      const accessToken = this.get('session.data.authenticated.access_token');
      return accessToken;
    }
  }),
  refreshToken: computed('session', {
    get() {
      const refreshToken = this.get('session.data.authenticated.refresh_token');
      return refreshToken;
    }
  }),
  beforeModel(params) {
    this.queryParams.filter.parentRefNo = params.queryParams.refNo;
    this.queryParams.filter.mobileNo = params.queryParams.mobileNumber;
  },
  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'MK_CLI', countryCode: this.get('axwayConfig.country'), id: 'W400' } };
    }
  }),

  actions: {
    closeForm() {
      let title = this.get('i18n').t('FERE.action.modal.quitApp.title');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'error',
          title,
          message: this.currentModel.receiptId
            ? this.get('i18n').t('FERE.action.modal.quitApp.messageEmailSms')
            : this.get('i18n').t('FERE.action.modal.quitApp.messageProgressLost'),
          acceptButtonLabel: this.get('i18n').t('FERE.action.button.YES'),
          rejectButtonLabel: this.get('i18n').t('FERE.action.button.NO')
        })
        .then(() => {
          if (window.cordova) {
            // Sending refresh token and access token while exit from fere to legecy screen.
            if (this.accessToken && this.refreshToken) {
              window.location.href =
                window.location.protocol +
                '//' +
                window.location.host +
                '/exit?RDC-ACCESS-TOKEN=' +
                this.accessToken +
                '&RDC-REFRESH-TOKEN=' +
                this.refreshToken;
            } else {
              window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
            }
          } else {
            document.location.href = config.backToiBankURL;
          }
        });
    }
  }
});
