/* eslint-disable no-useless-escape */

import { htmlSafe } from '@ember/string';
import { isNone, isBlank, isEqual } from '@ember/utils';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from './../../config/environment';

export default Route.extend({
  store: service(),
  i18n: service(),
  queries: service('customer-info'),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  init() {
    this._super();
    this.set('params', {});
  },
  model(params) {
    this.params = params;
  },
  setupController(controller, model) {
    this._super(controller, model);

    controller.set('isButtonDisabled', true);
    controller.set('errorMessage', '');
    controller.set('isInvalidPin', false);
    controller.set('formData', {});

    //Maxlength Pin Fields
    let countryCode = this.get('queries.countryName');
    if (!isNone(countryCode) && !isBlank(countryCode)) {
      countryCode = countryCode.toUpperCase();
      controller.set('pinLength', config.creditPinFieldLength[countryCode]);
      controller.set('countryCode', countryCode);
    }

    controller.set('cardMasking', true);
    if (isEqual(countryCode, 'SG')) {
      controller.set('cardMasking', false);
    }

    controller.set(
      'countryNotes',
      this.get('i18n').t('ServiceRequest.CREDITCARD.pinSetup.countryNotes.' + countryCode)
    );
    let getval = controller.get('countryNotes').toString();
    getval = htmlSafe(getval);
    controller.set('notemessages', getval);

    if (!isNone(this.params)) {
      controller.set('selectedCardId', this.params.selectedCardId);

      let selectedCardObject = this.get('store').peekRecord('credit-card', this.params.selectedCardId);
      controller.set('selectedCardObject', selectedCardObject);
      this.controllerFor('credit-pin-change.status').set(
        'selectedCardObject',
        JSON.parse(JSON.stringify(selectedCardObject))
      );
    }
  },
  actions: {
    goToBack() {
      this.get('store').unloadAll('credit-card');
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.transitionTo('credit-pin-change.select');
    }
  }
});
