import { inject as service } from '@ember/service';
import { isBlank, isNone } from '@ember/utils';
import Route from '@ember/routing/route';

export default Route.extend({
  i18n: service(),
  store: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  queries: service('customer-info'),
  setupController(controller, model) {
    this._super(controller, model);
    switch (controller.get('resStatus')) {
      case 'S':
        controller.set('responseVal', 'success');
        controller.set('resClass', 'success-block-lg');
        break;
      case 'F':
        controller.set('responseVal', 'failure');
        controller.set('resClass', 'warning');
        break;
      case 'I':
        controller.set('responseVal', 'incomplete');
        controller.set('resClass', 'partialwarning');
        break;
    }

    let countryCode = this.get('queries.countryName');
    if (!isNone(countryCode) && !isBlank(countryCode)) {
      countryCode = countryCode.toUpperCase();
    }
    countryCode == 'SG' ? controller.set('isCountryAsSG', true) : controller.set('isCountryAsSG', false);
    let selectedCardObject = controller.get('selectedCardObject');
    controller.set('cardNumber', selectedCardObject['cardNum']);

    let cardDesc = selectedCardObject['desc'];
    if (countryCode == 'SG') {
      if (cardDesc.includes('-')) {
        let cardName = cardDesc.split('-')[0];
        let embossedName = cardDesc.split('-')[1];
        controller.set('cardName', cardName);
        controller.set('embossedName', embossedName);
      }
    }

    controller.set('cardDesc', cardDesc);
  },

  actions: {
    resetAnotherCards() {
      this.transitionTo('credit-pin-change.select');
    }
  }
});
