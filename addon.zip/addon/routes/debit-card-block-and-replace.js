import { Promise as EmberPromise } from 'rsvp';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';

export default FereFormRoute.extend({
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),

  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'DEBIT_CARD_BLK_STEP1', countryCode: this.get('axwayConfig.country'), id: 'W342' } };
    }
  }),

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
  },

  closeThisForm() {
    this.transitionTo('serviceRequest.new-request');
  },

  afterSubmit(formDatum) {
    return new EmberPromise(resolve => {
      let entityDetails = formDatum.get('additionalInfo') && formDatum.get('additionalInfo').entityDetail;
      let debitCardNo = this.get('store').peekRecord('field', 'DebitCardNo');
      let debitCards = debitCardNo.get('value');

      if (!isEmpty(entityDetails)) {
        debitCards.forEach(function(debitCard, index) {
          let card = entityDetails.filter(entityDetail => entityDetail.entityType == debitCard.cardNumber);
          if (!isEmpty(card)) {
            debitCards[index].status = card[0].status;
          }
        });
      }

      debitCardNo.set('value', debitCards);

      resolve();
    });
  },

  actions: {
    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        this.transitionTo('serviceRequest.new-request');
      }
    },
    closeForm() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
