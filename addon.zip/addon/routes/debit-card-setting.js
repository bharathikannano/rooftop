import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../config/environment';

export default Route.extend({
  i18n: service(),
  rdcModalManager: service(),

  model() {
    this.transitionTo('debit-card-setting.select-card');
  },
  setupController(controller) {
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    controller.set('closeIcon', true);
  },
  actions: {
    closePopupAction() {
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message: this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankText'),
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
        })
        .catch(() => {});
    }
  }
});
