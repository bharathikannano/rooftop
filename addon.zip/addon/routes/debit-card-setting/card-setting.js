import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { isEmpty } from '@ember/utils';
import constant from '../../constants';
import { A } from '@ember/array';

export default Route.extend({
  store: service(),
  i18n: service(),
  queries: service('customer-info'),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  router: service(),
  cardTypeCode: A(['VP1', 'PB1']),

  model(params) {
    const constantValue = constant.dcSettings;
    return {
      params: params,
      overseasOptions: constantValue.dcSettingsRadioGroup,
      cardNotPresentOptions: constantValue.dcSettingsRadioGroup,
      atmIbftLimitDD: constantValue.atmIbftLimitOptions,
      cumulativeLimitDD: constantValue.cumulativeLimitOptions,
      optInOutDD: constantValue.optInOutOptions,
      cardMasking: true
    };
  },
  setupController(controller, model) {
    this._super(...arguments);
	let countryCode = this.get('queries.countryName');
    let curRoutename = this.get('router.currentRouteName');
    let selectedCardObject = null;
    selectedCardObject = this.get('store').peekRecord('debit-card', model.params.selectedCardId);
    if (curRoutename.indexOf('select-card') !== -1) {
      controller.setProperties({
        cumulativeLimitDisable: false,
        overseasDisable: false,
        cardNotPresentDisable: false,
        cardNotPresentTog: false,
        overseasTog: false,
        cardNotPresentValue: null,
        overseasValue: null,
        disabled: false,
        atmPOSLimit: null,
        cumulativeLimit: null,
        atmIbftLimit: null,
        isButtonDisabled: true,
        optInOutValue: null,
		optInOutDisable: false
      });
    } else {
      controller.set('isButtonDisabled', false);
    }
    if (this.cardTypeCode.includes(selectedCardObject.cardTypeCd)) {
      controller.set('atmLPOSLimitDD', constant.dcSettings.atmPosLimitOptions);
    } else {
      controller.set('atmLPOSLimitDD', constant.dcSettings.atmLimitForMLD);
    }
    controller.setProperties({
      'notemessages': this.get('i18n').t('ServiceRequest.debitCardSettings.notemessages.' + countryCode),
      'selectedCardObject': selectedCardObject
    });
  },
  _setOptInOut(optInOutValue) {
    if (!isEmpty(optInOutValue)) {
      switch (optInOutValue.id) {
        case 'optInOut1':
          this.controller.setProperties({
            cardNotPresentValue: 'Opt In',
            overseasValue: 'Opt Out'
          });
          break;
        case 'optInOut2':
          this.controller.setProperties({
            cardNotPresentValue: 'Opt Out',
            overseasValue: 'Opt In'
          });
          break;
        case 'optInOut3':
          this.controller.setProperties({
            cardNotPresentValue: 'Opt In',
            overseasValue: 'Opt In'
          });
          break;
        case 'optInOut4':
          this.controller.setProperties({
            cardNotPresentValue: 'Opt Out',
            overseasValue: 'Opt Out'
          });
          break;
      }
    }
  },
  actions: {
    goToBack() {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.transitionTo('debit-card-setting.select-card');
    },
    onSelectLimitValue(selected) {
      let cumulativeLimit,
        optInOutValue = null;
      if (!isEmpty(selected)) {
        if (selected.name.indexOf('pos') > 0) {
          if (selected.id === 'ATM_POS_100' || selected.id === 'ATM_POS_600') {
            cumulativeLimit = {
              id: 'RM0',
              value: 'RM0'
            };
            optInOutValue = {
              id: 'optInOut4',
              value: 'I would like to remain opted-out for both Card-Not-Present and Overseas transactions.'
            };
            this.controller.setProperties({
              cumulativeLimit: cumulativeLimit,
              overseasDisable: true,
              cardNotPresentDisable: true,
              cardNotPresentTog: false,
              overseasTog: false,
              cumulativeLimitDisable: true,
              optInOutDisable: true,
              optInOutValue: optInOutValue,
              cardNotPresentValue: 'Opt Out',
              overseasValue: 'Opt Out',
              radioGroupDisabled: true
            });
          } else {
            this.controller.setProperties({
              overseasDisable: false,
              cardNotPresentDisable: false,
              cumulativeLimitDisable: false,
              cardNotPresentTog: false,
              optInOutDisable: false,
              overseasTog: false,
              radioGroupDisabled: false
            });
          }
        }
        if (this.get('media.isDesktop')) {
          this._setOptInOut(this.controller.get('optInOutValue'));
        }
        this.controller.set('isButtonDisabled', false);
      }
    },

    onOptInOut() {
      this.controller.set('isButtonDisabled', false);
    },

    goToNextPage() {
	  if(isEmpty(this.controller.cardNotPresentValue) && !isEmpty(this.controller.overseasValue)) {
        this.controller.set('cardNotPresentValue', 'Opt Out');
      }
      if(isEmpty(this.controller.overseasValue) && !isEmpty(this.controller.cardNotPresentValue) ) {
        this.controller.set('overseasValue', 'Opt Out');
      }
      this.controllerFor('debit-card-setting.select-card').set('cardSetting', this.controller);
      this.transitionTo('debit-card-setting.confirmation');
    }
  }
});
