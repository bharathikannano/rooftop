import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { isEmpty } from '@ember/utils';

export default Route.extend({
  store: service(),
  i18n: service(),
  queries: service('customer-info'),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  cardErrorHandler: service(),

  setupController(controller, model) {
    this._super(controller, model);
    let cardSettingController = this.controllerFor('debit-card-setting.select-card').cardSetting;
    controller.setProperties({
      cardSetting: cardSettingController,
      cardMasking: true
    });
  },

  _payload() {
    let cardSetting = this.controller.get('cardSetting');
	if(cardSetting.cardNotPresentValue === 'Opt In' && cardSetting.overseasValue === 'Opt In') {
      this.controller.set('cardNotPresentValue', 'B');
    } else if(cardSetting.cardNotPresentValue === 'Opt In' && cardSetting.overseasValue === 'Opt Out') {
      this.controller.set('cardNotPresentValue', 'E');
    } else if(cardSetting.cardNotPresentValue === 'Opt Out' && cardSetting.overseasValue === 'Opt In') {
      this.controller.set('cardNotPresentValue', 'O');
    } else if(cardSetting.cardNotPresentValue === 'Opt Out' && cardSetting.overseasValue === 'Opt Out') {
      this.controller.set('cardNotPresentValue', 'N');
    } else {
      this.controller.set('cardNotPresentValue', null);
    }
    this.controller.setProperties({
      atmPosLimit: !isEmpty(cardSetting.atmPOSLimit) ? cardSetting.atmPOSLimit.value : null,
      posLimit: !isEmpty(cardSetting.cumulativeLimit) ? cardSetting.cumulativeLimit.value : null,
      atmIbftLimit: !isEmpty(cardSetting.atmIbftLimit) ? cardSetting.atmIbftLimit.value : null
    });
  },

  actions: {
    goToBack() {
      this.transitionTo('debit-card-setting.card-setting', this.controller.get('cardSetting').selectedCardObject.id);
    },

    navigateConfirm() {
      this._payload();
      let debitCardSetting = this.controller;
      let cardInfo = debitCardSetting.get('cardSetting');
      let postData = {
        status: 'INIT',
        serviceType: 'DEBCARSE',
        relNumber: cardInfo.selectedCardObject.relId,
        payload: {
          serviceRequests: {
            operationName: 'DCSET',
            customerDetails: {
              relationshipNo: cardInfo.selectedCardObject.relId,
              customerName: cardInfo.selectedCardObject.custShortName
            },
            debitCardSetting: {
              accountNumber: cardInfo.selectedCardObject.linkAccNum,
              debitCard: cardInfo.selectedCardObject.cardNum,
              atmPosLimit: debitCardSetting['atmPosLimit'],
              posLimit: debitCardSetting['posLimit'],
              atmIbftLimit: debitCardSetting['atmIbftLimit'],
              cardNotPresentTransaction: debitCardSetting['cardNotPresentValue'],
              currency: cardInfo.selectedCardObject.linkedAccounts[0].accCcy
            }
          }
        },
        dateOrder: '0',
        isDocAvailable: false,
        isCritical: false,
        isCemsRequest: false,
        isPartialSave: false,
        statusOrder: '0',
        isNstpRequest: 'true'
      };
      this.get('store').unloadAll('service-request');
      const debitCardSettingsPost = this.get('store')
        .createRecord('service-request', postData)
        .save()
        .then(
          item => {
            this.controllerFor('debit-card-setting.select-card').set('refNo', item.id);
            this.transitionTo('debit-card-setting.status');
          },
          error => {
            if (!isEmpty(error.errors) && !isEmpty(error.errors[0])) {
              this.set('message', this.get('i18n').t('ServiceRequest.debitCardSettings.errorMsg.title.invalidMobNo'));
              this.get('cardErrorHandler').pageErrorPopup(this);
            } else if (error.code === 'CSL-OTP-1328') {
              this.set('message', this.get('i18n').t('ServiceRequest.debitCardSettings.errorMsg.title.maxTryMobileNo'));
              this.get('cardErrorHandler').pageErrorPopup(this);
            }
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(debitCardSettingsPost);
    }
  }
});
