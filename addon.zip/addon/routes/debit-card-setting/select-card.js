import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { isEmpty } from '@ember/utils';

export default Route.extend({
  store: service(),
  queries: service('customer-info'),
  i18n: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  cardErrorHandler: service(),

  model() {
    const DCSettingFilter = {
      blkInd: 'Active',
      operationName: 'DCSETTING'
    };
    let DebitCardDetails = this.get('store')
      .query('debit-card', {
        filter: DCSettingFilter
      })
      .then(
        data => {
          this.set('debitCardStatus', 'DebitCardSuccess');
          return data;
        },
        () => {
          this.get('cardErrorHandler').systemErrorPopup(this);
        }
      );
    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(DebitCardDetails, ' ');
    return hash({
      DebitCardDetails: DebitCardDetails
    });
  },

  afterModel(data) {
    data.nocardsTitle = this.get('nocardsTitle');
    data.nocardsContent = this.get('nocardsContent');
  },

  setupController(controller, model) {
    this._super(...arguments);
    let countryCode = this.get('queries.countryName');
    if (!isEmpty(model.DebitCardDetails) && model.DebitCardDetails.get('length') > 0) {
      controller.set('dataAvailable', true);
    } else {
      controller.set('dataAvailable', false);
    }
    controller.set('notemessages', this.get('i18n').t('ServiceRequest.debitCardSettings.notemessages.' + countryCode));
  },

  actions: {
    navigateToHelpAndServices() {
      const message = this.get('i18n').t('ServiceRequest.COMMON.backToHelpAndServicesText');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          this.transitionTo('serviceRequest.new-request');
        })
        .catch(() => {});
    },

    goToBack() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
