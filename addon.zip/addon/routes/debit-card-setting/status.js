import Route from '@ember/routing/route';

export default Route.extend({
  setupController(controller, model) {
    this._super(controller, model);
    controller.setProperties({
      resClass: 'success-block-lg',
      refNo: this.controllerFor('debit-card-setting.select-card').refNo
    });
    this.controllerFor('debit-card-setting').set('closeIcon', false);
  },

  actions: {
    navigateStatus() {
      this.transitionTo('serviceRequest.status');
    }
  }
});
