import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../config/environment';

export default Route.extend({
  i18n: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  store: service(),
  queryParams: {
    replacement: {
      refreshModel: true
    }
  },
  model(params) {
    let paramsValue;
    if (params != undefined && params.replacement == 'New') paramsValue = 'New';
    else if (params != undefined && params.replacement == 'Existing') paramsValue = 'Existing';
    else paramsValue = 'cardBlock';
    return paramsValue;
  },

  setupController(controller) {
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    let thisModel = this.modelFor('debitcard-new-replacement');
    if (thisModel == 'Existing' || thisModel == 'cardBlock') {
      controller.set('titleDisplay', this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.header.title'));
    } else {
      controller.set('titleDisplay', this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.header.title1'));
    }
  },

  resetController(controller, isExiting, transition) {
    if (transition.targetName.indexOf('debitcard-new-replacement') == -1) {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.get('store').unloadAll('debit-card');
      this.get('store').unloadAll('debit-cards-type');
      this.get('store').unloadAll('service-request');
      this.get('store').unloadAll('casa');
      if (this.get('currentModel') == 'New') {
        this.controllerFor('debitcard-new-replacement.select-new-card').set('cardTypeEnable', false);
        this.controllerFor('debitcard-new-replacement.select-new-card').set('btnAddAccount', false);
      }
    }
  },

  actions: {
    didTransition() {
      if (document.querySelector('.popup-wrapper')) {
        document.querySelector('.popup-wrapper').scrollTop = 0;
      }
    },
    closePopupAction() {
      this.controller.set('clickCancel', true);
      let message;
      if (this.get('media.isDesktop')) {
        message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankBefAckText');
      } else {
        message = this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankBefAckText');
      }
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
          this.controller.set('clickCancel', false);
        })
        .catch(() => {
          this.controller.set('clickCancel', false);
        });
    }
  }
});
