import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';

export default Route.extend({
  store: service(),
  rdcLoadingIndicator: service(),
  i18n: service(),
  cardblockReplacementSave: service(),
  router: service(),

  model() {
    let replacementStatus;
    if (this.modelFor('debitcard-new-replacement') == 'Existing') {
      replacementStatus = true;
    } else {
      replacementStatus = false;
    }
    let cardData;

    let payloadData = this.get('store').peekAll('service-request');
    let accountTypesData = this.get('store').peekAll('casa');
    let cardType = this.get('store').peekAll('debit-cards-type');

    let selectedData;
    let selectedCardData;
    let selectedCardType;
    let cardNewDesign;

    if (replacementStatus) {
      if (this.modelFor('debitcard-new-replacement') == 'cardBlock') {
        cardData = this.controllerFor('card-block.status').get('cardData');
      } else {
        cardData = this.controllerFor('debitcard-new-replacement.select-existing-card').get('cardDataLinkedAcc');
      }
      selectedCardData = cardData;
    }

    payloadData.forEach(item => {
      selectedData = item.get('payload');
    });

    cardType.forEach(function(data) {
      if (data.get('isSelectedType') == 'true') {
        selectedCardType = data;
        data.data.images.forEach(data => {
          if (data.isSelected == 'selected') {
            cardNewDesign = data;
          }
        });
      }
    });

    return hash({
      accData: accountTypesData,
      selectedCardType: selectedCardType,
      selectedDebitCardRep: selectedCardData,
      checkBoxValue: selectedData.checkBoxValue,
      cardNewDesign: cardNewDesign,
      replacementStatus: replacementStatus
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    if (this.get('router.currentRouteName').indexOf('status') == -1) {
      controller.set('disableConfirm', false);
    }
  },
  actions: {
    navigateStatus: function() {
      this.controller.set('disableConfirm', true);
      this.controller.set('pageData', this.get('currentModel'));
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      this.get('store').unloadAll('service-request');
      let postData = this.get('store').createRecord(
        'service-request',
        this.get('cardblockReplacementSave').callForData(this.get('currentModel'))
      );
      postData.save().then(data => {
        this.get('currentModel').refNo = data.id;
        this.get('rdcLoadingIndicator').hideLoadingIndicator();
        this.transitionTo('debitcard-new-replacement.status');
      });
    },
    goToBack() {
      this.transitionTo('debitcard-new-replacement.select-card-face');
    }
  }
});
