import { A } from '@ember/array';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';

export default Route.extend({
  store: service(),
  model() {
    let allDebitData = this.get('store').peekAll('debit-cards-type');
    let selectedcardImages;
    allDebitData.forEach(item => {
      if (item.get('isSelectedType') == 'true') {
        selectedcardImages = item.data;
      }
    });
    return selectedcardImages.images;
  },

  setupController(controller, model) {
    this._super(controller, model);
    controller.set('replacementStatus', this.modelFor('debitcard-new-replacement') == 'Existing' ? 'true' : '');
  },

  actions: {
    navigate: function() {
      this.transitionTo('debitcard-new-replacement.confirm');
    },
    goToBack() {
      this.transitionTo('debitcard-new-replacement.select-new-card');
    },
    enableNext() {
      let modelArray = A();
      this.currentModel.forEach(item => {
        modelArray.pushObject(item);
      });
      if (modelArray.filterBy('isSelected').length == 1) {
        this.controller.set('enableNext', 'true');
      } else {
        this.controller.set('enableNext', '');
      }
    }
  }
});
