import { htmlSafe } from '@ember/string';
import { computed } from '@ember/object';
import { typeOf, isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from './../../config/environment';
export default Route.extend({
  store: service(),
  i18n: service(),
  queries: service('customer-info'),
  error: service('card-error-handler'),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  router: service(),

  model() {
    let DebitCardDetails;
    let debitCardStoreData = this.get('store').peekAll('debit-card');
    this.set('HKdebitcard', 'true');
    this.set('debitCardsDisplay', 'true');
    let chkRoutename = this.get('router.currentRouteName').indexOf('new-request') != -1 ? true : false;
    if (debitCardStoreData.content.length == 0 || chkRoutename) {
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      DebitCardDetails = this.get('store')
        .query('debit-card', {
          filter: config.replacementFilters.debitCard[this.get('queries.countryName')]
        })
        .then(
          data => {
            this.set('DebitCardErrorcheck', false);
            this.set('debitCardStatus', 'DebitCardSuccess');
            this.get('error').errorHandler(this);
            this.get('rdcLoadingIndicator').hideLoadingIndicator();
            return data;
          },
          error => {
            this.set('debitCardStatus', 'DebitCardError');
            typeOf(error.errors[0].code) == 'undefined'
              ? this.set('DebitCardErrorcheck', 'undefined')
              : this.set('DebitCardErrorcheck', error.errors[0].code);
            this.get('error').errorHandler(this);
            this.get('rdcLoadingIndicator').hideLoadingIndicator();
          }
        );
    } else {
      debitCardStoreData.content.length > 0 ? (DebitCardDetails = debitCardStoreData) : (DebitCardDetails = null);
    }
    return DebitCardDetails;
  },

  setupController(controller, model) {
    this._super(controller, model);

    controller.set(
      'links',
      computed(function() {
        return new htmlSafe(
          '<a href="' +
            this.get('countryLinks').toString() +
            '" target="_blank">' +
            this.get('countryLinksTxt').toString() +
            '</a>'
        );
      })
    );
    controller.set(
      'countryLinks',
      this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.countryLinks.' + this.get('queries.countryName'))
    );
    controller.set(
      'countryLinksTxt',
      this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.countryLinksTxt.' + this.get('queries.countryName'), {
        default: 'ServiceRequest.DEBITCARDREPLACEMENT.countryLinksTxt.default'
      })
    );
    controller.set(
      'countryNotes',
      this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.countryNotes.' + this.get('queries.countryName'), {
        inter_link: controller.get('links')
      })
    );
    let getval = controller.get('countryNotes').toString();
    let res = getval.split('<br>');
    let appendtext = '';
    for (let i = 0; i < res.length; i++) {
      appendtext += '<li>' + res[i] + '</li>';
    }
    appendtext = htmlSafe('<ul>' + appendtext + '</ul>');
    controller.set('notemessages', appendtext);
    let debitcard = this.get('store').peekAll('debit-card');
    if (debitcard.content.length > 0) {
      controller.set('dataAvailable', true);
    } else {
      controller.set('dataAvailable', false);
    }
    if (!isEmpty(this.controller.get('model'))) {
      this.controller.get('model').forEach(function(item) {
        item.set('isSelected', false);
      });
    }
  },

  actions: {
    enableNext(selectedCardData) {
      let debitCardDetails = null;
      if (this.controller.get('model') != undefined && this.controller.get('model').filterBy('isSelected').length > 0) {
        this.controller
          .get('model')
          .filterBy('isSelected')
          .forEach(data => {
            if (data.data.cardNum != selectedCardData.ccnumber) {
              data.set('isSelected', '');
            } else {
              data.set('isSelected', true);
            }
          });

        if (this.get('debitCardStatus') == 'DebitCardSuccess') {
          debitCardDetails = this.controller.get('model').filterBy('isSelected');
        } else {
          debitCardDetails = null;
        }

        this.transitionTo('debitcard-new-replacement.select-new-card');
      }
      let pageData = [
        {
          selectedDebitCard: debitCardDetails
        }
      ];
      this.controllerFor('debitcard-new-replacement.select-existing-card').set('cardData', pageData);
      this.controllerFor('debitcard-new-replacement.select-existing-card').set(
        'cardDataLinkedAcc',
        pageData[0].selectedDebitCard[0].data
      );
    },

    navigateConfirm() {
      this.get('store').unloadAll('service-request');
      this.transitionTo('debitcard-new-replacement.select-new-card');
    },

    goToBack() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
