import { A } from '@ember/array';
import { htmlSafe } from '@ember/string';
import { computed, set, get } from '@ember/object';
import { hash } from 'rsvp';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  customerInfo: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),

  model: function() {
    let cardData;
    let sltedcard;
    if (
      !isEmpty(this.modelFor('debitcard-new-replacement')) &&
      this.modelFor('debitcard-new-replacement') == 'Existing'
    ) {
      cardData = this.controllerFor('debitcard-new-replacement.select-existing-card').get('cardDataLinkedAcc');
      sltedcard = this.controllerFor('debitcard-new-replacement.select-existing-card').get('cardData');
    } else if (
      !isEmpty(this.modelFor('debitcard-new-replacement')) &&
      this.modelFor('debitcard-new-replacement') == 'cardBlock'
    ) {
      cardData = this.controllerFor('card-block.status').get('cardData');
      sltedcard = this.controllerFor('card-block.select').get('cardData');
    }
    let accountTypesData = this.get('store').peekAll('casa');
    if (accountTypesData.content.length == 0) {
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      accountTypesData = this.get('store')
        .query('casa', {
          filter: {
            eligibleCBacc: 'yes'
          }
        })
        .then(
          data => {
            this.get('rdcLoadingIndicator').hideLoadingIndicator();
            return data;
          },
          () => {
            this.get('cardErrorHandler').systemErrorPopup(this);
          }
        );
    }

    let selectedAcc = this.get('store').peekAll('service-request');
    let totalAccount = A();
    let checkBoxValue;
    if (selectedAcc.content.length == 0) {
      let totalAccountList = {
        mainTitleTxt: this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.accountIncludeTitle'),
        subTitleTxt: this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.primaryAccountTitle'),
        labelValue: this.get('i18n').t('ServiceRequest.COMMON.progress.plsselect'),
        mainTitle: 'true',
        subTitle: 'true',
        deleteOption: false,
        accountName: 'Primary',
        accountTypeFilter: 'primary',
        SelectedValue: ''
      };
      totalAccount.pushObject(totalAccountList);
      checkBoxValue = 'English';
    } else {
      selectedAcc.forEach(item => {
        totalAccount = item.get('payload.accItems');
        checkBoxValue = item.get('payload.checkBoxValue');
      });
    }

    return hash({
      sltedcard: sltedcard,
      cardData: cardData,
      accountTypesData: accountTypesData,
      accItems: totalAccount,
      checkBoxValue: checkBoxValue
    });
  },

  setupController(controller, model) {
    this._super(controller, model);
    controller.set('opName', 'DCRPLLIST');
    controller.set('label', this.get('i18n').t('ServiceRequest.CARDREPLACEMENT.cardlistHeader2'));
    if (controller.get('initialSlide') == undefined && controller.get('initialSlide') != 0) {
      controller.set('initialSlide', 0);
    }
    controller.set(
      'links',
      computed(function() {
        return new htmlSafe(
          '<a href="' +
            this.get('countryLinks').toString() +
            '" target="_blank">' +
            this.get('countryLinksTxt').toString() +
            '</a>'
        );
      })
    );
    controller.set(
      'countryLinks',
      this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.countryLinks.' + this.get('customerInfo.countryName'))
    );
    controller.set(
      'countryLinksTxt',
      this.get('i18n').t(
        'ServiceRequest.DEBITCARDREPLACEMENT.countryLinksTxt.' + this.get('customerInfo.countryName'),
        { default: 'ServiceRequest.DEBITCARDREPLACEMENT.countryLinksTxt.default' }
      )
    );
    controller.set(
      'countryNotes',
      this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.countryNotes.' + this.get('customerInfo.countryName'), {
        inter_link: controller.get('links')
      })
    );
    let getval = controller.get('countryNotes').toString();
    let res = getval.split('<br>');
    let appendtext = '';
    for (let i = 0; i < res.length; i++) {
      appendtext += '<li>' + res[i] + '</li>';
    }
    appendtext = htmlSafe('<ul>' + appendtext + '</ul>');
    controller.set('notemessages', appendtext);
    let languageOptions = {
      radioGroup: [
        {
          name: 'select-language',
          value: 'English',
          label: this.get('i18n').t('ServiceRequest.COMMON.text.english'),
          ikon: 'radio-icon',
          disabled: false
        },
        {
          name: 'select-language',
          value: 'Chinese',
          label: this.get('i18n').t('ServiceRequest.COMMON.text.chinese'),
          ikon: 'radio-icon',
          disabled: false
        }
      ]
    };
    controller.set('languageOptions', languageOptions);
    controller.set('items', model.accItems);
    controller.set('selectCardself', this);
    controller.set('isPrimary', false);
    controller.set('isNew', false);
    if (this.controller.get('items').length > 1) {
      controller.set('isPrimary', true);
    }
    controller.set('replacementStatus', this.modelFor('debitcard-new-replacement') == 'Existing' ? 'true' : '');
    if (
      this.modelFor('debitcard-new-replacement') == 'Existing' ||
      this.modelFor('debitcard-new-replacement') == 'cardBlock'
    ) {
      let existingData = model.cardData.linkedAccounts;
      controller.set('cardTypecd', model.cardData.cardTypeCd);
      let existingAccountType = {};
      let index = 0;
      if (existingData) {
        existingData.forEach(data => {
          if (data.accIndicator.toLowerCase() == 'y') {
            existingAccountType['primary'] = data.accNum;
          } else {
            index++;
            existingAccountType['secondary' + index] = data.accNum;
          }
        });
      }
      let mapIndex = index;
      let secondaryAcc = 1;
      model.accountTypesData.forEach(data => {
        if (
          data.get('blockListCat').toLowerCase() == 'primary' &&
          existingAccountType.primary == data.get('accountNumber')
        ) {
          data.set('isSelected', 'true');
          data.set('isAccType', 'Primary');
          set(this.controller.get('items')[0], 'SelectedValue', 'selected');
          set(
            this.controller.get('items')[0],
            'labelValue',
            data.get('subProductDescription') +
              ', ' +
              data.get('accountNumber') +
              ', ' +
              data.get('currencyCode') +
              ' ' +
              data.get('currentBalance') +
              ' ' +
              data.get('accountEligibility')
          );
          set(this.controller, 'btnAddAccount', true);
          if (mapIndex == 0) {
            this.accountSelectMethod();
          }
        } else if (
          data.get('blockListCat').toLowerCase() == 'supplementary' &&
          existingAccountType.primary == data.get('accountNumber')
        ) {
          data.set('isSelected', 'true');
          data.set('isAccType', 'Primary');
        }

        if (this.controller.get('existingPopulate') == undefined) {
          if (mapIndex > 0) {
            if (
              data.get('blockListCat').toLowerCase() == 'supplementary' &&
              (existingAccountType['secondary1'] == data.get('accountNumber') ||
                existingAccountType['secondary2'] == data.get('accountNumber'))
            ) {
              let ite = {
                subTitleTxt: this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.otherAccountTitle'),
                subTitle: this.controller.get('items').length == 1 ? true : false,
                labelValue:
                  data.get('subProductDescription') +
                  ', ' +
                  data.get('accountNumber') +
                  ', ' +
                  data.get('currencyCode') +
                  ' ' +
                  data.get('currentBalance') +
                  ' ' +
                  data.get('accountEligibility'),
                mainTitle: false,
                mainTitleTxt: false,
                deleteOption: true,
                accountName: 'other-account-active OtherAccount' + secondaryAcc,
                accountTypeFilter: 'supplementary',
                SelectedValue: 'selected'
              };
              data.set('isSelected', 'true');
              data.set('isAccType', 'other-account-active OtherAccount' + secondaryAcc);
              this.controller.get('items').pushObject(ite);
              this.controller.set('isPrimary', true);
              mapIndex--;
              if (secondaryAcc == 2) {
                set(this.controller, 'btnAddAccount', false);
              }
              secondaryAcc++;
              if (mapIndex == 0) {
                this.accountSelectMethod();
              }
            } else if (
              data.get('blockListCat').toLowerCase() == 'primary' &&
              (existingAccountType['secondary1'] == data.get('accountNumber') ||
                existingAccountType['secondary2'] == data.get('accountNumber'))
            ) {
              data.set('isSelected', 'true');
              data.set('isAccType', 'other-account-active OtherAccount' + secondaryAcc);
            }
          }
        }
      });
      set(this.controller, 'isNew', false);
      set(this.controller, 'cardTypeTitle', this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.replaceCardwith'));
    } else {
      controller.set('opName', 'DCNRPLLIST');
      controller.set('cardTypecd', '');
      if (get(this.controller.get('items')[0], 'SelectedValue') != 'selected') {
        set(this.controller.get('items')[0], 'SelectedValue', '');
        set(this.controller, 'btnAddAccount', false);
      }
      set(this.controller, 'isNew', true);
      set(this.controller, 'cardTypeTitle', this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.sltdebitType'));
    }
  },

  accountSelectMethod() {
    this.get('store').unloadAll('debit-cards-type');
    this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    this.set('sCcode', '');
    this.set('tCcode', '');
    this.controller.set('cardTypeEnable', false);
    set(this.controller, 'cardTypeError', false);
    let debitCardTypeFilter = {};
    this.controller.get('model').accountTypesData.forEach(item => {
      if (
        item.get('isAccType') == 'Primary' &&
        item.get('data.blockListCat').toLowerCase() == 'primary' &&
        item.get('isSelected') == 'true'
      ) {
        this.set('pProd', item.get('data.productCode'));
        this.set('pSubprod', item.get('data.subProductCode'));
        this.set('pCcode', item.get('data.currencyCode'));
      } else if (
        item.get('isAccType') == 'other-account-active OtherAccount1' &&
        item.get('data.blockListCat').toLowerCase() == 'supplementary' &&
        item.get('isSelected') == 'true'
      ) {
        this.set('sCcode', item.get('data.currencyCode'));
      }
    });

    debitCardTypeFilter = {
      operationName: this.controller.get('opName'),
      paccProd: this.get('pProd'),
      paccSubProd: this.get('pSubprod'),
      paccCcyCode: this.get('pCcode'),
      saccCcyCode: this.get('sCcode'),
      taccCcyCode: this.get('tCcode')
    };
    if (!isEmpty(this.controller.get('cardTypecd'))) {
      debitCardTypeFilter['selectedCardType'] = this.controller.get('cardTypecd');
    }
    this.get('store')
      .query('debit-cards-type', {
        filter: debitCardTypeFilter
      })
      .then(
        debitCardsType => {
          set(this.controller, 'cardTypedata', debitCardsType);
          set(this.controller, 'cardTypeEnable', true);
          let replacementCard;
          let isSelectedTypeAvailable;
          this.controller.get('cardTypedata').forEach(data => {
            if (data.get('isSelectedType') == 'true') {
              isSelectedTypeAvailable = 'true';
            }
          });

          if (isSelectedTypeAvailable == 'true') {
            this.controller.get('cardTypedata').forEach(data => {
              if (data.get('isSelectedType') == 'true') {
                replacementCard = {
                  typeDesc: data.get('typeDesc'),
                  cardImage: data.get('imgname'),
                  SelectedValue: 'selected'
                };
              }
            });
          } else {
            replacementCard = {
              typeDesc: this.get('i18n').t('ServiceRequest.COMMON.progress.plsselect'),
              cardImage: 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg',
              SelectedValue: ''
            };
          }
          this.controller.set('replacementCard', replacementCard);
          if (this.get('media.isMobile')) {
            this.controller.set('enableNext', false);
            this.send('enableNext');
          }
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          if (debitCardsType.get('length') == 0) {
            set(this.controller, 'cardTypeError', 'noActiveCards');
          }
        },
        () => {
          set(this.controller, 'cardTypeError', true);
          set(this.controller, 'cardTypeEnable', true);
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
        }
      );
  },

  actions: {
    goToBack() {
      this.get('store').unloadAll('debit-cards-type');
      this.get('store').unloadAll('service-request');
      this.get('store').unloadAll('casa');
      this.controller.set('cardTypeEnable', false);
      this.controller.set('btnAddAccount', false);
      if (this.controller.get('replacementStatus') == 'true') {
        this.transitionTo('debitcard-new-replacement.select-existing-card');
      } else {
        this.transitionTo('serviceRequest.new-request');
      }
    },

    navigateConfirm() {
      let selectedAcc = this.get('store').peekAll('service-request');
      if (selectedAcc.content.length != 0) {
        this.get('store').unloadAll('service-request');
      }

      let selectedCard = this.get('currentModel');
      this.get('store').createRecord('service-request', {
        id: '1',
        payload: {
          replacementCard: selectedCard.replacementCard,
          accItems: this.controller.get('items'),
          checkBoxValue: this.get('currentModel.checkBoxValue')
        }
      });
      this.controller.set('existingPopulate', 'existingPopulate');
      this.transitionTo('debitcard-new-replacement.select-card-face');
    },

    addAccount(itemAction) {
      if (this.controller.get('items').length < 3) {
        if (itemAction) {
          let ite = {
            subTitleTxt: this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.otherAccountTitle'),
            subTitle: this.controller.get('items').length == 1 ? true : false,
            labelValue: this.get('i18n').t('ServiceRequest.COMMON.progress.plsselect'),
            mainTitle: false,
            mainTitleTxt: false,
            deleteOption: false,
            accountName: 'other-account-active OtherAccount' + this.controller.get('items').length,
            accountTypeFilter: 'supplementary',
            SelectedValue: ''
          };
          this.controller.get('items').pushObject(ite);
          this.controller.set('btnAddAccount', false);
          this.controller.set('isPrimary', true);
        }
      }
    },

    accountSelected() {
      this.accountSelectMethod();
    },

    deleteSelectedAccountRoute(item) {
      if (item == 'enableNext') {
        this.send('enableNext');
      } else if (item == 'accountSelected') {
        this.send('accountSelected');
      } else if (item == 'enableNextAccountSelected') {
        this.send('accountSelected');
        this.send('enableNext');
      } else {
        let checkAccountName;
        if (this.controller.get('items').length == 3 && item.accountName == 'other-account-active OtherAccount1') {
          checkAccountName = true;
        }
        this.controller.get('items').removeObject(item);
        this.controller.get('items').forEach(data => {
          set(data, 'subTitle', 'true');
          if (checkAccountName && data.accountName == 'other-account-active OtherAccount2') {
            set(data, 'accountName', 'other-account-active OtherAccount1');
          } else if (checkAccountName && data.accountName == 'other-account-active OtherAccount3') {
            set(data, 'accountName', 'other-account-active OtherAccount2');
          }
        });
        this.controller.set('btnAddAccount', true);
        let accountTypesData = this.controller.get('model.accountTypesData');
        accountTypesData.forEach(itemVal => {
          if (itemVal.get('isAccType') == item.accountName) {
            itemVal.set('isSelected', 'false');
            itemVal.set('isAccType', '');
            itemVal.set('data.accountTypeFilter', '');
          }
          if (checkAccountName && itemVal.get('isAccType') == 'other-account-active OtherAccount2') {
            itemVal.set('isAccType', 'other-account-active OtherAccount1');
          } else if (checkAccountName && itemVal.get('isAccType') == 'other-account-active OtherAccount3') {
            itemVal.set('isAccType', 'other-account-active OtherAccount2');
          }
        });
        if (this.controller.get('items').length == 1) {
          this.controller.set('isPrimary', false);
        }
        this.accountSelectMethod();
      }
    },

    selectedCardType(item, slideValue) {
      let cardTypeData = this.controller.get('cardTypedata');
      cardTypeData.forEach(data => {
        if (data.get('type') == item.get('type')) {
          data.set('isSelectedType', 'true');
        } else {
          data.set('isSelectedType', '');
        }
      });
      this.controller.set('replacementCard.SelectedValue', 'selected');
      this.send('enableNext', slideValue);
    },

    enableNext(slideValue) {
      this.controller.set('initialSlide', slideValue);
      this.controller.set('cardTypeEnable', true);
      if (
        this.controller.get('replacementCard.SelectedValue') == 'selected' &&
        this.controller.get('items')[0].SelectedValue == 'selected'
      ) {
        this.controller.set('enableNext', true);
      }
    }
  }
});
