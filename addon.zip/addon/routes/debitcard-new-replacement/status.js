import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';

export default Route.extend({
  store: service(),
  i18n: service(),
  model() {
    return this.controllerFor('debitcard-new-replacement.confirm').get('pageData');
  },

  setupController(controller, model) {
    this._super(controller, model);
    this.controllerFor('debitcard-new-replacement').set('leftIcon', '');
    if (this.modelFor('debitcard-new-replacement') == 'New') {
      this.controller.set('statusMsg', this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.statusMsg.success'));
    } else {
      this.controller.set(
        'statusMsg',
        this.get('i18n').t('ServiceRequest.DEBITCARDREPLACEMENT.statusMsg.successReplacement')
      );
    }
  },

  actions: {
    viewStatus: function() {
      this.transitionTo('serviceRequest.status');
    },
    goToBack() {
      this.transitionTo('debitcard-new-replacement.confirm');
    }
  }
});
