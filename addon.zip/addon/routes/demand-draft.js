import { inject as service } from '@ember/service';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';

export default FereFormRoute.extend({
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),

  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'DEMANDDRAFT_STEP1', countryCode: this.get('axwayConfig.country'), id: 'W410' } };
    }
  }),

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
  },

  closeThisForm() {
    this.transitionTo('serviceRequest.new-request');
  },

  actions: {
    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        this.transitionTo('serviceRequest.new-request');
      }
    },
    closeForm() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
