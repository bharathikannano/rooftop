import Route from '@ember/routing/route';
import idleSession from 'rdc-ui-eng-service-requests/mixins/idle-session';
import { inject as service } from '@ember/service';
export default Route.extend(idleSession, {
  queryParams: {
    productList: {
      refreshModel: true
    }
  },
  axwayConfig: service(),
  beforeModel() {
    this._super(...arguments);
    if (this.get('axwayConfig.country') == 'CI') {
      let products = '{';
      if (localStorage.getItem('isCurrentAccountSelected') === 'true') {
        products = products + '"product1": "currentAccount"';
      }

      if (
        localStorage.getItem('isCurrentAccountSelected') === 'true' &&
        localStorage.getItem('isExcelSaverAccountSelected') === 'true'
      ) {
        products = products + ',';
      }

      if (localStorage.getItem('isExcelSaverAccountSelected') === 'true') {
        products = products + '"product2": "excelSaverAccount"';
      }

      products = products + '}';
      this.set('filterParams', products);
    }
  },
  model(params) {
    if (this.get('axwayConfig.country') != 'CI') {
      let filterParams;
      if (this.get('axwayConfig.country') == 'AE') {
        filterParams = '{ "stepName": "STEP_RTOB_CC_NTB", "id": "W489","productList":"' + params.productList + '"}';
      } else {
        filterParams = '{ "productList":"' + params.productList + '"}';
      }
      this.set('filterParams', filterParams);
    }
  },
  actions: {
    goToBack() {
      if (this.get('axwayConfig.country') == 'CI') {
        this.transitionTo('product.opening');
      } else {
        this.transitionTo('product-list.list');
      }
    },
    goToAccountOpening() {
      this.transitionTo('apply-products', {
        queryParams: {
          filter: this.get('filterParams')
        }
      });
    }
  }
});
