import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../config/environment';

export default Route.extend({
  rdcModalManager: service(),
  i18n: service(),
  store: service(),
  beforeModel() {
    this.get('store').unloadAll('rewards-account');
  },
  model() {
    this.transitionTo('dollar-reinstatement.select');
  },
  setupController(controller) {
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    controller.set('reqTitle', this.get('i18n').t('ServiceRequest.dollarReinstatement.header.title.rewardPoints'));
  },
  actions: {
    closePopupAction() {
      let message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankBefAckText');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
        });
    }
  }
});
