import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { hash } from 'rsvp';
import { isNone } from '@ember/utils';
import moment from 'moment';
export default Route.extend({
  i18n: service(),
  store: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  model() {
    let rewardsPointData = this.get('store').get('selectedData');
    return hash({
      reviewDetails: rewardsPointData
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.set('acknowledgeStatus', false);
    controller.set('disableSubmit', true);
    if (!isNone(model.reviewDetails['card-image-name'])) {
      controller.set(
        'ccimagesfromjs',
        'https://av.sc.com/configuration/content/images/' + model.reviewDetails['card-image-name'] + '.png'
      );
    }
    if (model.reviewDetails['expired-reward-points']) {
      let rewardPoints = Number(model.reviewDetails['expired-reward-points']);
      controller.set('rewardPoints', rewardPoints);
      if (rewardPoints < 500000) {
        controller.set(
          'acknowledgeLabel',
          this.get('i18n').t('ServiceRequest.dollarReinstatement.content.acknowledgeBelowLabel')
        );
      } else {
        controller.set(
          'acknowledgeLabel',
          this.get('i18n').t('ServiceRequest.dollarReinstatement.content.acknowledgeAboveLabel')
        );
      }
    }
  },
  enableSubmit() {
    if (this.controller.get('acknowledgeStatus')) {
      this.controller.set('disableSubmit', false);
    } else {
      this.controller.set('disableSubmit', true);
    }
  },
  actions: {
    goToBack() {
      this.transitionTo('dollar-reinstatement.select');
    },
    navigateConfirm() {
      const rewardsPointData = this.controller.model.reviewDetails;
      const postData = {
        status: 'INIT',
        payload: {
          serviceRequests: {
            operationName: 'DLRRINST',
            SRType: 'DLRRINST',
            serviceType: 'DLRRINST',
            customerDetails: {
              relationshipNo: rewardsPointData['rel-number']
            },
            stdDollarReinstatement: {
              amountOfExpRewardPoints: Number(rewardsPointData['expired-reward-points'])
                .toString()
                .replace(/\B(?=(\d{3})+(?!\d))/g, ','),
              cardNo: rewardsPointData['card-number'],
              cardExpiryDate: moment(rewardsPointData['expiry-date'], 'DD MMM YYYY').format('DD-MMM-YYYY')
            }
          }
        },
        relNumber: rewardsPointData['rel-number'],
        serviceType: 'DLRRINST',
        isCritical: false,
        statusOrder: 0,
        dateOrder: 0,
        isPartialSave: false
      };
      this.get('store').unloadAll('service-request');
      const rewardsPointPost = this.get('store')
        .createRecord('service-request', postData)
        .save()
        .then(
          item => {
            this.get('store').set('selectedData.srrefNo', item.id);
            this.transitionTo('dollar-reinstatement.status');
          },
          () => {
            this.get('cardErrorHandler').systemErrorPopup(this);
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(rewardsPointPost);
    },
    toggleCheckBox(event) {
      let targetCheckbox = event.target;
      if (targetCheckbox.name === 'acknowledgeContent') {
        this.controller.toggleProperty('acknowledgeStatus');
        this.enableSubmit();
      }
    },
    noCardImage(event) {
      event.target.src = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
    }
  }
});
