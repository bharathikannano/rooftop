import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../../constants';
import { hash } from 'rsvp';
import { isEmpty, isEqual } from '@ember/utils';
import { assign } from '@ember/polyfills';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  cardErrorHandler: service(),
  model() {
    let cslRequestfilters = config.reinstateRewardPoints.filters;
    let requestDetails = this.get('store')
      .query('rewards-account', { filter: cslRequestfilters })
      .then(
        data => {
          let rewardsPoint = data.filter(rewards => {
            if (rewards.rewardsPoint && rewards.rewardsPoint.length > 0) {
              let points = rewards.rewardsPoint[0]['expired-reward-points'];
              return Number(points) > 0;
            }
          });
          return rewardsPoint;
        },
        () => {
          this.get('cardErrorHandler').systemErrorPopup(this);
        }
      );
    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(requestDetails);
    return hash({
      requestDetails: requestDetails
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    if (isEqual(model.requestDetails, undefined) || model.requestDetails.length <= 0) {
      controller.set('noEligibleCardData', true);
    } else {
      controller.set('noEligibleCardData', false);
      model.requestDetails.forEach(element => {
        if (element.get('alerts') && element.get('alerts').length >= 1) {
          element.set('disableCard', true);
          element.set('errorMsg', element.get('alerts')[0].message);
        } else {
          element.set('disableCard', false);
        }
      });
      this._enableDisableNext();
    }
  },
  _enableDisableNext() {
    if (
      this.controller.get('model').requestDetails.filterBy('isSelected') !== undefined &&
      this.controller.get('model').requestDetails.filterBy('isSelected').length > 0
    ) {
      this.controller.set('disableNext', false);
    } else {
      this.controller.set('disableNext', true);
    }
  },
  actions: {
    goToBack() {
      this.get('store').unloadAll('rewards-account');
      this.transitionTo('serviceRequest.new-request');
    },
    navigateConfirm(model) {
      let cardDetails = {};
      const modalVal = model.requestDetails.filterBy('isSelected');
      if (!isEmpty(modalVal)) {
        modalVal.forEach(item => {
          let selectedValue = (rewardsPoint => ({
            rewardsPoint
          }))(item.get('rewardsPoint'));
          assign(cardDetails, selectedValue);
        });
      }
      this.get('store').set('selectedData', cardDetails.rewardsPoint[0]);
      this.transitionTo('dollar-reinstatement.review');
    },
    enableNext() {
      this._enableDisableNext();
    },
    showErrorPopup(errorMsg) {
      this.get('rdcModalManager').showDialogModal({
        level: 'info',
        message: errorMsg,
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      });
    },
    closeJourney() {
      this.get('store').unloadAll('rewards-account');
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
