import Route from '@ember/routing/route';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';

export default Route.extend({
  store: service(),
  model() {
    let rewardsPointData = this.get('store').get('selectedData');
    return hash({
      statusDetails: rewardsPointData
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.set('refNo', model.statusDetails.srrefNo);
  },
  actions: {
    viewRequest() {
      this.transitionTo('serviceRequest.status');
    }
  }
});
