import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../config/environment';
import constants from '../constants';
import { Promise as EmberPromise } from 'rsvp';
import { A } from '@ember/array';
import { isPresent, isEqual, isEmpty } from '@ember/utils';
import Ember from 'ember';
export default Route.extend({
  rdcModalManager: service(),
  i18n: service(),
  rdcLoadingIndicator: service(),
  cardErrorHandler: service(),
  store: service(),
  router: service(),
  customerInfo: service(),
  cslRequest: A(),
  captureNodata: A(),
  ebbsCountries: A(['BN', 'VN', 'NP']),
  beforeModel() {
    this._unloadData();
  },
  model(params, transition) {
    this.get('rdcLoadingIndicator').showLoadingIndicator();
    this.controllerFor('duplicate-statement').set('noData', false);
    const entityVal = transition.queryParams.entity;

    if (entityVal) {
      const getDetails = {
        entity: entityVal,
        type: transition.queryParams.type
      };
      this.controllerFor('duplicate-statement').set('statementData', getDetails);
    }
    this.captureNodata.clear();

    const custFilters =
      this.ebbsCountries.indexOf(this.get('customerInfo.countryName')) !== -1
        ? constants.duplicateStatement.filters.ASA.customerData
        : constants.duplicateStatement.filters.customerData;
    const getCustomerInfo = this.get('store')
      .queryRecord('customer', {
        filter: custFilters
      })
      .then(
        data => {
          if (isPresent(data)) {
            if (isPresent(data.custEligibleFlag) && data.custEligibleFlag === true) {
              const customeraddresses = data.customeraddresses,
                customercontacts = data.customercontacts,
                priorityCustomer = data.priorityCustomerFlag;
              if (
                isPresent(customercontacts) &&
                (isEqual(this.get('customerInfo.countryName'), 'IN') || isPresent(customeraddresses))
              ) {
                let customerCont = {
                  rtnCheck: false,
                  priorityCustomer: isPresent(priorityCustomer) ? priorityCustomer : false
                };
                if (
                  !isEqual(this.get('customerInfo.countryName'), 'IN') ||
                  constants.duplicateStatement.reviewCat.includes(
                    this.controllerFor('duplicate-statement').statementData.type
                  )
                ) {
                  customeraddresses.forEach(item => {
                    if (isEqual(item['mailing-address'], 'Y')) {
                      if (isEqual(this.get('customerInfo.countryName'), 'VN')) {
                        customerCont['address'] = `${
                          !isEmpty(item['additional-address2']) ? `${item['additional-address2']} <br>` : ''
                        } ${!isEmpty(item['additional-address1']) ? `${item['additional-address1']} <br>` : ''}
                          ${!isEmpty(item['additional-address3']) ? item['additional-address3'] : ''} ${
                          !isEmpty(item['additional-address4']) ? `${item['additional-address4']} <br>` : ''
                        }
                          ${!isEmpty(item['city-name']) ? item['city-name'] : ''}
                          ${!isEmpty(item['country-name']) ? item['country-name'] : ''}`;
                      } else {
                        customerCont['address'] = `${!isEmpty(item['address1']) ? `${item['address1']} <br>` : ''} ${
                          !isEmpty(item['city-name']) ? `${item['city-name']} <br>` : ''
                        }
                          ${!isEmpty(item['state']) ? item['state'] : ''} ${
                          !isEmpty(item['postal-code']) ? item['postal-code'] : ''
                        }`;
                      }
                      customerCont['addressToPost'] = item;
                    }
                  });
                  if (isPresent(data.risks)) {
                    data.risks.forEach(item => {
                      if (!isEmpty(item['risk-code']) && isEqual(item['risk-code'], 'RTN')) {
                        customerCont.rtnCheck = true;
                      }
                    });
                  }
                }
                customercontacts.forEach(item => {
                  if (isEqual(item['contact-classification'], 'E') && isEqual(item['primary-flag'], 'Y')) {
                    customerCont['email'] = item['contact-details'];
                  }
                });
                this.controllerFor('duplicate-statement').statementData['customerCont'] = customerCont;
              } else {
                this.captureNodata.pushObject('customerDetails');
              }
            } else {
              this.captureNodata.pushObject('customerNoteligible');
            }
          } else {
            this.captureNodata.pushObject('customerEmpty');
          }
        },
        error => {
          Ember.Logger.debug('fetching data error: ', error);
          this.captureNodata.pushObject('customerError');
          this.get('cardErrorHandler').systemErrorPopup(this);
        }
      );
    this.cslRequest.push(getCustomerInfo);
    EmberPromise.all(this.cslRequest)
      .then(() => {
        if (this.captureNodata.length > 0) {
          const errorMsg = constants.duplicateStatement.reviewCat.includes(
            this.controllerFor('duplicate-statement').statementData.type
          )
            ? 'NONDLYCC'
            : this.captureNodata.indexOf('customerNoteligible') !== -1
            ? 'customerNotEligible'
            : 'customerData';
          this.controllerFor('duplicate-statement').set(
            'noData',
            this.get('i18n').t('ServiceRequest.duplicateStatement.error.noData.' + errorMsg, {
              default: 'ServiceRequest.duplicateStatement.error.noData.default'
            })
          );
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
        } else {
          this.controllerFor('duplicate-statement').statementData.entity === 'ALL'
            ? this.replaceWith('duplicate-statement.select')
            : this.replaceWith('duplicate-statement.product');
        }
      })
      .catch(error => {
        Ember.Logger.debug('fetching data promise error: ', error);
        this.get('cardErrorHandler').systemErrorPopup(this);
        this.get('rdcLoadingIndicator').hideLoadingIndicator();
      });
  },
  setupController(controller) {
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    controller.set(
      'reqTitle',
      this.get('i18n').t(
        `ServiceRequest.duplicateStatement.title.${this.controllerFor('duplicate-statement').statementData.type}`,
        { default: 'ServiceRequest.duplicateStatement.title.common' }
      )
    );
  },
  actions: {
    goToBack() {
      this._unloadData();
      this.transitionTo('serviceRequest.new-request');
    },
    closePopupAction() {
      let message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankBefAckText');
      if (
        isEqual(this.get('customerInfo.countryName'), 'VN') &&
        this.get('router.currentRouteName').includes('status')
      ) {
        message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
      }
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
        });
    }
  },
  _unloadData() {
    this.get('store').unloadAll('customer');
    this.get('store').unloadAll('cus-contacts');
    this.get('store').unloadAll('credit-card');
    this.get('store').unloadAll('casa');
    this.get('store').unloadAll('loan');
  }
});
