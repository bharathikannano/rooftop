import Route from '@ember/routing/route';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';

export default Route.extend(quickEvent, {
  i18n: service(),
  store: service(),
  customerInfo: service(''),
  model() {
    const products = this.controllerFor('duplicate-statement').statementData.debitAccountDetails;
    return hash({
      productDetails: products,
      noData: this.get('i18n').t('ServiceRequest.duplicateStatement.error.noData.nodebitAcc')
    });
  },
  setupController(controller) {
    this._super(...arguments);
    controller.setProperties({
      currentStepName: this.getCurrentStepName(4)
    });
  },
  actions: {
    moveToNextPage(product) {
      let debitAccountlist = this.controllerFor('duplicate-statement').statementData.productReview;
      delete debitAccountlist.debitAccount;
      Object.assign(debitAccountlist, { debitAccount: product });
      this.transitionTo('duplicate-statement.confirm');
    },
    goToBack() {
      this.transitionTo('duplicate-statement.statement');
    },
    closeJourney() {
      this.get('store').unloadAll('customer');
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('casa');
      this.get('store').unloadAll('loan');
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
