import Route from '@ember/routing/route';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';
import { inject as service } from '@ember/service';
import { isEqual, isEmpty, isNone } from '@ember/utils';
import { hash } from 'rsvp';
import { A } from '@ember/array';
export default Route.extend(quickEvent, {
  i18n: service(),
  store: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  customerInfo: service(''),
  model() {
    return hash({
      reviewDetails: this.controllerFor('duplicate-statement').statementData,
      cardMasking: this.cardMasking,
      loanMaskConfig: this.loanMaskConfig,
      cardMaskConfig: this.cardMaskConfig
    });
  },
  setupController(controller) {
    this._super(...arguments);
    controller.setProperties({
      currentStepName: this.getCurrentStepName(5)
    });
  },
  actions: {
    goToBack() {
      const proCat = this.controller.model.reviewDetails.productReview;
      isEmpty(proCat.debitAccount) ||
      (A(['MY']).includes(this.get('customerInfo.countryName')) && isEqual(proCat.deliveryMode.toString(), 'email'))
        ? this.transitionTo('duplicate-statement.statement')
        : this.transitionTo('duplicate-statement.account');
    },
    navigateConfirm() {
      const productData = this.controller.model.reviewDetails.productReview;
      const postData = {
        status: 'INIT',
        payload: {
          serviceRequests: {
            operationName: 'STMTREQ',
            customerDetails: {
              relationshipNo: productData.statementAccount.id
            },
            statementRequests: {
              productType: isEqual(productData.selectedProduct.toString(), 'cccard')
                ? 'CC'
                : isEqual(productData.selectedProduct.toString(), 'account')
                ? 'AC'
                : 'LS',
              accountNo: productData.statementAccount.accountNo,
              currencyCode: isEqual(productData.selectedProduct.toString(), 'account')
                ? productData.statementAccount.currencyCode
                : null,
              fromDate: productData.startDate,
              toDate: productData.endDate,
              deliveryMode: isEqual(productData.deliveryMode.toString(), 'address') ? 'P' : 'E',
              deliveryProductType: isEmpty(productData.debitAccount)
                ? null
                : isEqual(productData.selectedProduct.toString(), 'cccard')
                ? 'CC'
                : 'AC',
              debitAccountNo: isEmpty(productData.debitAccount) ? null : productData.debitAccount.accountNo,
              DebitCurrencyCode: isEmpty(productData.debitAccount)
                ? null
                : isEmpty(productData.debitAccount.currencyCode) ||
                  !isEqual(productData.debitAccount.modelName.toString(), 'casa')
                ? null
                : productData.debitAccount.currencyCode
            }
          }
        },
        isNstpRequest: 'true',
        relNumber: productData.statementAccount.id,
        serviceType: 'STMTREQI',
        isCritical: false,
        statusOrder: 0,
        dateOrder: 0,
        isPartialSave: false
      };
      this.get('store').unloadAll('service-request');
      const statementPost = this.get('store')
        .createRecord('service-request', postData)
        .save()
        .then(
          item => {
            this.controllerFor('duplicate-statement').statementData.productReview['srrefNo'] = item.id;
            this.transitionTo('duplicate-statement.status');
          },
          error => {
            if (!isEmpty(error) && !isNone(error.errors[0]) && error.errors[0].code !== 401) {
              this.get('cardErrorHandler').systemErrorPopup(this);
            }
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(statementPost);
    }
  }
});
