import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';
import constant from '../../constants';
import { hash } from 'rsvp';
import { A } from '@ember/array';
import { isEqual, isEmpty } from '@ember/utils';
import config from '../../constants';
export default Route.extend(quickEvent, {
  store: service(),
  rdcLoadingIndicator: service(),
  i18n: service(),
  rdcModalManager: service(),
  cardErrorHandler: service(),
  customerInfo: service(),
  router: service(),
  model() {
    let curRoutename = this.get('router.currentRouteName');
    let isNotesNeeded = constant.duplicateStatement.hideNotesCountries.includes(this.get('customerInfo.countryName'));
    const getEntity = this.controllerFor('duplicate-statement').statementData;
    let products = A();
    const cslRequest =
      getEntity.entity === 'ALL'
        ? constant.duplicateStatement.cslRequest[getEntity.product.entity]
        : constant.duplicateStatement.cslRequest[getEntity.entity];
    const reqFilter = isEmpty(getEntity.type)
      ? isEqual(cslRequest, 'loan')
        ? constant.duplicateStatement.filters.productList.loans
        : constant.duplicateStatement.filters.productList.default
      : constant.duplicateStatement.filters.productList[getEntity.type];
    if ((curRoutename !== null && curRoutename.includes('index')) || curRoutename.includes('select')) {
      if (getEntity.entity === 'ALL') {
        this.get('rdcLoadingIndicator').showLoadingIndicator();
      }
      this.store
        .query(cslRequest, {
          filter: reqFilter
        })
        .then(
          data => {
            this.controller.set('pageLoaded', true);
            this.getdataValues(data).then(data => {
              products.pushObjects(data);
              this.get('rdcLoadingIndicator').hideLoadingIndicator();
            });
          },
          error => {
            if (!isEmpty(error.errors[0]) && !config.genericRequestForm.noDatastrings.includes(error.errors[0].code)) {
              this.get('cardErrorHandler').systemErrorPopup(this);
            } else {
              this.controller.set('pageLoaded', true);
            }
            this.get('rdcLoadingIndicator').hideLoadingIndicator();
          }
        );
    } else {
      products = this.currentModel.productDetails;
      this.controller.set('pageLoaded', true);
    }
    return hash({
      productDetails: products,
      selectedProduct:
        constant.duplicateStatement.product[getEntity.entity === 'ALL' ? getEntity.product.entity : getEntity.entity],
      isNotesNeeded: isNotesNeeded,
      noData: this.get('i18n').t('ServiceRequest.duplicateStatement.error.noData.' + cslRequest, {
        default: 'ServiceRequest.duplicateStatement.error.noData.default'
      }),
      noteMessage: config.duplicateStatement.reviewCat.includes(getEntity.type)
        ? this.get('i18n').t('ServiceRequest.duplicateStatement.countryNotes.CCNonDelivery', {
            default: 'ServiceRequest.duplicateStatement.countryNotes.default'
          }) 
        : this.get('i18n').t('ServiceRequest.duplicateStatement.countryNotes.default'),
      panelTitle: config.duplicateStatement.reviewCat.includes(getEntity.type)
        ? this.get('i18n').t('ServiceRequest.duplicateStatement.header.panelTitle.productNoNCC', {
            default: 'ServiceRequest.duplicateStatement.header.panelTitle.product'
          }) 
        : this.get('i18n').t('ServiceRequest.duplicateStatement.header.panelTitle.product'),
      subTitle: config.duplicateStatement.reviewCat.includes(getEntity.type)
        ? this.get('i18n').t('ServiceRequest.duplicateStatement.header.subTitle.productNoNCC', {
            default: 'ServiceRequest.duplicateStatement.header.subTitle.product'
          }) 
        : this.get('i18n').t('ServiceRequest.duplicateStatement.header.subTitle.product'),
      isShowProductHeader: config.duplicateStatement.reviewCat.includes(getEntity.type) ? false : true
    });
  },
  setupController(controller) {
    this._super(...arguments);
    const curRoutename = this.get('router.currentRouteName');
    if ((curRoutename !== null && curRoutename.includes('index')) || curRoutename.includes('select')) {
      controller.set('pageLoaded', false);
    }
    controller.setProperties({
      currentStepName: this.getCurrentStepName(2)
    });
  },
  actions: {
    moveToNextPage(product) {
      const getEntity = this.controllerFor('duplicate-statement').statementData;
      if (product.alerts) {
        const message = this.get('i18n').t('ServiceRequest.duplicateStatement.error.commonError.statmentInprogress');
        this.get('rdcModalManager').showDialogModal({
          level: 'info',
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
          iconClass: 'service-journey-system-error-icon'
        });
      } else {
        const statementAccount = {
          statementAccount: product
        };
        if (isEqual(product.segmentType, 'PRIORITY')) {
          this.controllerFor('duplicate-statement').set('statementData.customerCont.priorityCustomer', true);
        }
        this.controllerFor('duplicate-statement').set('statementData.productReview', statementAccount);
        config.duplicateStatement.reviewCat.includes(this.controllerFor('duplicate-statement').statementData.type)
          ? this.transitionTo('duplicate-statement.review')
          : this.transitionTo('duplicate-statement.statement');
      }
    },
    goToBack() {
      this.controllerFor('duplicate-statement').statementData.entity === 'ALL'
        ? this.replaceWith('duplicate-statement.select')
        : this.replaceWith('serviceRequest.new-request');
    }
  }
});