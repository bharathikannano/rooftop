import Route from '@ember/routing/route';
import { hash } from 'rsvp';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';
import { inject as service } from '@ember/service';
import { observer, get } from '@ember/object';
import { htmlSafe } from '@ember/string';
export default Route.extend(quickEvent, {
  i18n: service(),
  store: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  isConfirm: false,
  model() {
    return hash({
      reviewDetails: this.controllerFor('duplicate-statement').statementData,
      cardMasking: this.cardMasking,
      cardMaskConfig: this.cardMaskConfig
    });
  },
  setupController(controller) {
    this._super(...arguments);
    this.set('isConfirm', false);
    this.modifyScreen();
    controller.setProperties({
      headerTitle: this.get('i18n').t('ServiceRequest.duplicateStatement.header.panelTitle.card'),
      addressDetails: htmlSafe(controller.model.reviewDetails.customerCont.address),
      currentStepName: this.getCurrentStepName(3)
    });
  },
  modifyScreen() {
    this.controller.set('isConfirm', this.isConfirm);
    if (this.isConfirm) {
      this.controller.setProperties({
        currentStepName: this.getCurrentStepName(5),
        headerTitle: this.get('i18n').t('ServiceRequest.duplicateStatement.header.panelTitle.mobConfirm')
      });
    } else {
      this.controller.setProperties({
        currentStepName: this.getCurrentStepName(3),
        headerTitle: this.get('i18n').t('ServiceRequest.duplicateStatement.header.panelTitle.card')
      });
    }
  },
  actions: {
    goToBack() {
      if (!this.get('isConfirm')) {
        this.transitionTo('duplicate-statement.product');
      } else {
        this.set('isConfirm', false);
        this.modifyScreen();
      }
    },
    navigateConfirm() {
      if (this.get('isConfirm')) {
        const productData = this.controller.model.reviewDetails;
        const addressData = productData.customerCont.addressToPost;
        const postData = {
          status: 'INIT',
          isNstpRequest: 'true',
          relNumber: productData.productReview.statementAccount.id,
          serviceType: 'NONDLYCC',
          isCritical: false,
          statusOrder: 0,
          dateOrder: 0,
          isPartialSave: false,
          payload: {
            serviceRequests: {
              operationName: 'NONDLYCC',
              customerDetails: {
                relationshipNo: productData.productReview.statementAccount.id
              },
              nonDeliveryyOfCC: [
                {
                  productType: 'CCARD',
                  cardNumber: productData.productReview.statementAccount.accountNo,
                  addressType: addressData['address-type-code'],
                  address1: addressData['address1'],
                  address2: addressData['address2'],
                  address3: addressData['address3'],
                  city: addressData['city-name'],
                  state: addressData['state'],
                  country: addressData['country-code'],
                  postalCode: addressData['postal-code']
                }
              ]
            }
          }
        };
        this.get('store').unloadAll('service-request');
        const statementPost = this.get('store')
          .createRecord('service-request', postData)
          .save()
          .then(
            item => {
              this.controllerFor('duplicate-statement').statementData.productReview['srrefNo'] = item.id;
              this.transitionTo('duplicate-statement.status');
            },
            () => {
              this.get('cardErrorHandler').systemErrorPopup(this);
            }
          );
        this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(statementPost);
      } else {
        this.set('isConfirm', true);
        this.modifyScreen();
      }
    }
  }
});
