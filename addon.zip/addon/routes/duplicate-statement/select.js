import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { hash } from 'rsvp';
import { A } from '@ember/array';
import constant from '../../constants';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';

export default Route.extend(quickEvent, {
  i18n: service(),
  customerInfo: service(),
  rdcLoadingIndicator: service(),
  model() {
    let products;
    products = A([
      {
        value: this.get('i18n').t('ServiceRequest.duplicateStatement.productLabel.account'),
        entity: 'CASA'
      },
      {
        value: this.get('i18n').t('ServiceRequest.duplicateStatement.productLabel.cccard'),
        entity: 'CCARD'
      }
    ]);

    //* <- The loan is removed from the product list*/
    const noLoanctruy = ['BN', 'NP', 'VN'];
    if (noLoanctruy.indexOf(this.get('customerInfo.countryName')) === -1) {
      products.pushObject({
        value: this.get('i18n').t('ServiceRequest.duplicateStatement.productLabel.loan'),
        entity: 'LOAN'
      });
    }
    
    let ShowNotes = constant.duplicateStatement.hideNotesCountries.includes(this.get('customerInfo.countryName'));

    this.get('rdcLoadingIndicator').hideLoadingIndicator();
    return hash({
      productDetails: products,
      ShowNotes: ShowNotes
    });
  },
  setupController(controller) {
    this._super(...arguments);
    controller.setProperties({
      currentStepName: this.getCurrentStepName(1)
    });
  },
  actions: {
    goToBack() {
      this.transitionTo('serviceRequest.new-request');
    },
    moveToNextPage(product) {
      this.controllerFor('duplicate-statement').statementData['product'] = product;
      this.replaceWith('duplicate-statement.product');
    }
  }
});
