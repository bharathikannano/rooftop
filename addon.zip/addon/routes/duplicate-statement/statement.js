import Route from '@ember/routing/route';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';
import { hash } from 'rsvp';
import { A } from '@ember/array';
import constant from '../../constants';
import { Promise as EmberPromise } from 'rsvp';
import { inject as service } from '@ember/service';
import { isEqual, isEmpty, isNone } from '@ember/utils';
import { htmlSafe } from '@ember/string';
import moment from 'moment';
import { assign } from '@ember/polyfills';
import { later } from '@ember/runloop';
export default Route.extend(quickEvent, {
  rdcModalManager: service(),
  i18n: service(),
  store: service(),
  rdcLoadingIndicator: service(),
  customerInfo: service(''),
  cardErrorHandler: service(),
  cslRequest: A(),
  cslRequestError: A(),
  router: service(),
  otpCtry: A(['IN', 'MY', 'BN', 'NP', 'VN']),
  model() {
    const curRoutename = this.get('router.currentRouteName');
    const getEntity = this.controllerFor('duplicate-statement').statementData;
    const noAddressctry = A(['IN', 'BN', 'NP']);
    if ((getEntity.entity === 'ALL' ? getEntity.product.entity : getEntity.entity) === 'CCARD') {
      noAddressctry.push('VN');
    }
    let radioGroup = A([
      {
        name: 'list-Values',
        value: 'email',
        label: this.get('i18n').t('ServiceRequest.duplicateStatement.pageLabels.deliveryMode.email'),
        disabled: false
      }
    ]);
    if (noAddressctry.indexOf(this.get('customerInfo.countryName')) === -1) {
      radioGroup.pushObject({
        name: 'list-Values',
        value: 'address',
        label: this.get('i18n').t('ServiceRequest.duplicateStatement.pageLabels.deliveryMode.address'),
        disabled: false
      });
    }

    return hash({
      radioGroupDetails: radioGroup,
      curRoutename: curRoutename,
      selectedProduct:
        constant.duplicateStatement.product[getEntity.entity === 'ALL' ? getEntity.product.entity : getEntity.entity]
    });
  },
  setupController(controller) {
    this._super(...arguments);
    const getEntity = this.controllerFor('duplicate-statement').statementData;
    controller.setProperties({
      showAddressField: false,
      deliveryMode: false,
      hasStartError: false,
      hasStartErrorLabel: false,
      startDateErrorLabel: null,
      hasEndError: false,
      hasEndErrorLabel: false,
      endDateErrorLabel: null,
      isLoanWithCountry: false,
      disableDatalocker: A(['MY', 'VN']).includes(this.get('customerInfo.countryName')),
      sltproduct:
        getEntity.entity === 'ALL' ? getEntity.product.value : constant.duplicateStatement.product[getEntity.entity],
      statementYear: isEqual(this.get('customerInfo.countryName'), 'IN')
        ? 4
        : isEqual(this.get('customerInfo.countryName'), 'BN')
        ? 6
        : isEqual(this.get('customerInfo.countryName'), 'NP')
        ? 0
        : isEqual(this.get('customerInfo.countryName'), 'SG')
        ? 6
        : isEqual(this.get('customerInfo.countryName'), 'VN')
        ? 0
        : 6,
      startDateLabel: this.get('i18n').t('ServiceRequest.duplicateStatement.pageLabels.startDate').string,
      endDateLabel: this.get('i18n').t('ServiceRequest.duplicateStatement.pageLabels.endDate').string,
      showNotes: true,
      currentStepName: this.getCurrentStepName(3)
    });

    //* <- vn statement year for casa only */
    let selecProd = this.getProductName();
    if (isEqual(this.get('customerInfo.countryName'), 'VN') && isEqual(selecProd, 'account')) {
      this.controller.set('statementYear', 4);
    }
    // check validation for loan & specific country like SG
    this.controller.set('isLoanWithCountry', this.checkLoanwithCountry() ? true : false);

    if (
      isEqual(this.get('customerInfo.countryName'), 'IN') &&
      this.controller.model.selectedProduct.toString().indexOf('loan') !== -1
    ) {
      this.controller.set('loanFlag', true);
      this.controller.set('disableNext', false);
    } else {
      this.controller.set('loanFlag', false);
      this.controller.set('disableNext', true);
    }
    this.disableNextButton();
    if (this.router.currentRouteName.indexOf('product') !== -1) {
      const DefaultEmail =
        constant.duplicateStatement.defaultEmail.includes(this.get('customerInfo.countryName')) ||
        constant.duplicateStatement.defaultEmail.includes(
          `${this.get('customerInfo.countryName')}${
            getEntity.entity === 'ALL' ? getEntity.product.entity : getEntity.entity
          }`
        );
      controller.setProperties({
        startDate: null,
        endDate: null,
        radioValue: DefaultEmail ? 'email' : null,
        disableNext: this.controller.get('loanFlag') ? false : true,
        isOTPValidated: false,
        disableEndbtn: false
      });
      if (DefaultEmail) {
        later(() => {
          this.send('deliveryMethodChange', 'email');
        }, 0);
      }
    } else {
      let showAddress = false;
      if (this.get('otpCtry').indexOf(this.get('customerInfo.countryName')) !== -1) {
        showAddress = this.controller.get('isOTPValidated') ? true : false;
      } else {
        showAddress = true;
      }
      controller.setProperties({
        deliveryMode: true,
        showAddressField: showAddress
      });
    }
  },
  getProductName() {
    const getEntity = this.controllerFor('duplicate-statement').statementData;
    let selectedProd =
      getEntity.entity === 'ALL'
        ? constant.duplicateStatement.product[getEntity.product.entity]
        : constant.duplicateStatement.product[getEntity.entity];
    return selectedProd.toString();
  },
  getDuration(date) {
    const today = new Date();
    let currentDate = '';
    this.checkLoanwithCountry()
      ? (currentDate = moment(date, 'YYYY').toDate())
      : (currentDate = moment(date, 'MM/YYYY').toDate());

    let age = today.getFullYear() - currentDate.getFullYear();
    let currentMonth = isEqual(this.get('customerInfo.countryName'), 'BN') ? today.getMonth() - 1 : today.getMonth();
    const m = currentMonth - currentDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < currentDate.getDate())) {
      age--;
    }
    return age;
  },
  compareDate(date1, date2) {
    let date1_obj = '';
    let date2_obj = '';

    if (this.checkLoanwithCountry()) {
      date1_obj = moment(date1, 'YYYY').toDate();
      date2_obj = moment(date2, 'YYYY').toDate();
    } else {
      date1_obj = moment(date1, 'MM/YYYY').toDate();
      date2_obj = moment(date2, 'MM/YYYY').toDate();
    }

    if (date1_obj > date2_obj) return 1;
    else if (date1_obj < date2_obj) return -1;
    else return 0;
  },
  disableNextButton() {
    if (
      (this.controller.loanFlag ? isEmpty(this.controller.radioValue) : isEmpty(this.controller.startDate)) ||
      (this.controller.loanFlag ? isEmpty(this.controller.radioValue) : isEmpty(this.controller.endDate)) ||
      isEmpty(this.controller.radioValue) ||
      !isNone(this.controller.startDateErrorLabel) ||
      !isNone(this.controller.endDateErrorLabel)
    ) {
      this.controller.set('disableNext', true);
    } else {
      this.controller.set('disableNext', false);
    }
  },
  checkLoanWithMYCountry() {
    if (
      isEqual(this.get('customerInfo.countryName'), 'MY') &&
      this.controller.model.selectedProduct.toString().includes('loan')
    ) {
      return true;
    } else {
      return false;
    }
  },

  actions: {
    goToBack() {
      this.transitionTo('duplicate-statement.product');
    },
    deliveryMethodChange(value) {
      this.controller.set('address', value);
      let dupStatementController = this.controllerFor('duplicate-statement').statementData;
      this.controllerFor('duplicate-statement').set('statementData.productReview.deliveryMode', value);
      this.controller.setProperties({
        deliveryMode: true,
        contactDetails: htmlSafe(dupStatementController.customerCont[value]),
        addressHeader: this.get('i18n').t(`ServiceRequest.duplicateStatement.pageLabels.${value}.text`),
        mobileText: this.get('i18n').t(`ServiceRequest.duplicateStatement.pageLabels.${value}.message.text`),
        desktopText: this.get('i18n').t(`ServiceRequest.duplicateStatement.pageLabels.${value}.message.text.desktop`),
        checkButtonLabel: this.get('i18n').t(`ServiceRequest.duplicateStatement.pageLabels.${value}.check.text`),
        currentStepName: this.getCurrentStepName(3)
      });
      const curRoutename = this.controller.model.curRoutename;
      const charingCnty = A(['SG', 'MY', 'VN', 'BN']);
      isEqual(value, 'address') && isEqual(this.get('customerInfo.countryName'), 'SG')
        ? this.controller.set('hideupdateLink', true)
        : this.controller.set('hideupdateLink', false);
      //show email address by default for SG
      if (isEqual(this.get('customerInfo.countryName'), 'SG')) {
        this.send('showAddress');
      }

      if (
        isEqual(value, 'address') &&
        isEqual(this.get('customerInfo.countryName'), 'MY') &&
        dupStatementController.customerCont.rtnCheck
      ) {
        const message = this.get('i18n').t('ServiceRequest.duplicateStatement.error.noData.addressRisk');
        this.get('rdcModalManager').showDialogModal({
          level: 'info',
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
          iconClass: 'service-journey-system-error-icon'
        });
        this.controller.set('radioValue', null);
      } else {
        const getEntity = this.controllerFor('duplicate-statement').statementData;
        if (
          !isEmpty(curRoutename) &&
          (curRoutename.indexOf('product') !== -1 || isEmpty(dupStatementController.debitAccountDetails)) &&
          charingCnty.indexOf(this.get('customerInfo.countryName')) !== -1 &&
          (isEqual(this.get('customerInfo.countryName'), 'SG') ||
            isEqual(this.get('customerInfo.countryName'), 'BN') ||
            (isEqual(this.get('customerInfo.countryName'), 'VN') &&
              (getEntity.entity === 'ALL' ? getEntity.product.entity : getEntity.entity) === 'CASA') ||
            isEqual(value, 'address'))
        ) {
          if (
            isEqual(this.get('customerInfo.countryName'), 'MY') ||
            (isEqual(this.get('customerInfo.countryName'), 'VN') &&
              dupStatementController.customerCont.priorityCustomer)
          ) {
            if (!dupStatementController.customerCont.priorityCustomer) {
              const message = this.get('i18n').t('ServiceRequest.duplicateStatement.pageLabels.addressInfo');
              this.get('rdcModalManager')
                .showDialogModal({
                  level: 'info',
                  message,
                  acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
                  iconClass: 'service-journey-system-error-icon'
                })
                .then(() => {
                  this.triggerDebitaccount(dupStatementController);
                });
            }
          } else {
            this.triggerDebitaccount(dupStatementController);
          }
        }
      }
      this.disableNextButton();
    },
    navigateConfirm() {
      let statementDetails = this.controllerFor('duplicate-statement').statementData.productReview;

      if (isEqual(this.get('customerInfo.countryName'), 'IN')) {
        this.controllerFor('duplicate-statement').set(
          'statementData.productReview.deliveryMode',
          this.controller.radioValue
        );
      }
      const statementPeriod = {
        startDate: this.controller.startDate,
        endDate: this.controller.endDate,
        selectedProduct: this.controller.model.selectedProduct.toString()
      };
      delete statementDetails.startDate;
      delete statementDetails.endDate;
      delete statementDetails.selectedProduct;
      assign(statementDetails, statementPeriod);
      const noFeectry = ['IN', 'NP'];
      const getEntity = this.controllerFor('duplicate-statement').statementData;
      noFeectry.indexOf(this.get('customerInfo.countryName')) !== -1 ||
      (isEqual(this.controller.address, 'email') && isEqual(this.get('customerInfo.countryName'), 'MY')) ||
      (isEqual(this.get('customerInfo.countryName'), 'VN') &&
        (getEntity.entity === 'ALL' ? getEntity.product.entity : getEntity.entity) !== 'CASA') ||
      (isEqual(this.get('customerInfo.countryName'), 'VN') &&
        this.controllerFor('duplicate-statement').statementData.customerCont.priorityCustomer)
        ? this.transitionTo('duplicate-statement.confirm')
        : this.transitionTo('duplicate-statement.account');
    },
    async showAddress() {
      let statementDetails = this.controllerFor('duplicate-statement').statementData.productReview;
      if (this.get('otpCtry').indexOf(this.get('customerInfo.countryName')) !== -1) {
        this.get('store').unloadAll('service-request');
        const postData = {
          serviceType: 'GREQ_STMT_REQ_2FA',
          relNumber: statementDetails.statementAccount.id,
          status: 'INIT',
          payload: {
            serviceRequests: {
              operationName: 'GREQ_STMT_REQ_2FA'
            }
          }
        };
        const otpValidation = this.get('store')
          .createRecord('service-request', postData)
          .save()
          .then(
            () => {
              this.controller.set('isOTPValidated', true);
              this.controller.set('showAddressField', true);
            },
            error => {
              if (!isEmpty(error.errors) && !isEmpty(error.errors[0])) {
                this.set(
                  'message',
                  this.get('i18n').t('ServiceRequest.duplicateStatement.error.commonError.invalidMobNo')
                );
                this.get('cardErrorHandler').pageErrorPopup(this);
              } else if (error.code === 'CSL-OTP-1328') {
                this.set(
                  'message',
                  this.get('i18n').t('ServiceRequest.duplicateStatement.error.commonError.maxTryMobileNo')
                );
                this.get('cardErrorHandler').pageErrorPopup(this);
              }
            }
          );
        await this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(otpValidation);
      } else {
        this.controller.set('showAddressField', true);
      }
    },
    validateStartDate() {
      const fieldExp = this.regxLoanWithCountry();
      let startDate = this.controller.startDate;
      let endDate = this.controller.endDate;
      this.controller.setProperties({
        disableNext: true,
        hasStartError: true,
        hasStartErrorLabel: true
      });

      if (startDate || endDate) {
        if (this.getDuration(startDate) > this.controller.statementYear && startDate.length > 3) {
          this.controller.set(
            'startDateErrorLabel',
            this.get('i18n').t('ServiceRequest.duplicateStatement.error.startDate.error1')
          );
          this.vnStmtYearForCCandCasa('startDateErrorLabel', 'startDate');
        } else if (this.getDuration(startDate) < 0) {
          this.controller.set(
            'startDateErrorLabel',
            this.get('i18n').t('ServiceRequest.duplicateStatement.error.startDate.error2')
          );
        } else if (this.compareDate(startDate, endDate) === 1) {
          this.controller.set(
            'startDateErrorLabel',
            this.get('i18n').t('ServiceRequest.duplicateStatement.error.startDate.error3')
          );
        } else if (!fieldExp.test(startDate)) {
          this.controller.set(
            'startDateErrorLabel',
            this.get('i18n').t('ServiceRequest.duplicateStatement.error.default')
          );
        } else {
          this.controller.setProperties({
            disableNext: false,
            hasStartError: false,
            hasStartErrorLabel: false,
            startDateErrorLabel: null
          });
        }
      }
      this.disableNextButton();
    },
    removeVulChar() {
      let evt = window.event;
      let keys = window.event.key;
      const fieldExp = new RegExp('[^0-9/]', 'g');
      if (fieldExp.test(keys)) {
        evt.preventDefault();
        evt.defaultPrevented = true;
      } else {
        return false;
      }
    },
    addSlashChar() {
      let startDate = this.controller.startDate;
      let endDate = this.controller.endDate;
      const fieldLength = this.checkLoanwithCountry() ? 4 : 7;
      if (!this.checkLoanwithCountry()) {
        let key = event.which || event.keyCode;
        if (!(key === 8 || key === 46)) {
          if (!isEmpty(startDate) && startDate.length === 2) {
            //month should be jan or july only for MY - Loans
            if (this.checkLoanWithMYCountry()) {
              const validateMonth = startDate.toString().substring(0, 2);
              if (validateMonth !== '01' && validateMonth !== '07') {
                this.controller.set('startDate', null);
                this.controller.setProperties({
                  startDate: null,
                  endDate: null,
                  startDateErrorLabel: this.get('i18n').t(
                    'ServiceRequest.duplicateStatement.error.commonError.endDateError'
                  ),
                  hasStartError: true
                });
                return;
              }
            }
            this.controller.set('startDate', startDate + '/');
          }
          if (!isEmpty(endDate) && endDate.length === 2) {
            //month should be june or dec only for MY - Loans
            if (this.checkLoanWithMYCountry()) {
              const validateMonth = endDate.toString().substring(0, 2);
              if (validateMonth !== '06' && validateMonth !== '12') {
                this.controller.setProperties({
                  startDate: null,
                  endDate: null,
                  endDateErrorLabel: this.get('i18n').t(
                    'ServiceRequest.duplicateStatement.error.commonError.startDateError'
                  ),
                  hasEndError: true
                });
                return;
              }
            }
            this.controller.set('endDate', endDate + '/');
          }
          if (this.checkLoanWithMYCountry() && !isEmpty(startDate) && startDate.length === 7) {
            const startMonth = startDate.toString().substring(0, 2);
            if (startMonth !== '01' && startMonth !== '07') {
              this.controller.set('startDate', null);
              this.controller.setProperties({
                startDate: null,
                endDate: null,
                startDateErrorLabel: this.get('i18n').t(
                  'ServiceRequest.duplicateStatement.error.commonError.endDateError'
                ),
                hasStartError: true
              });
              return;
            }
            if (startDate.toString().substring(3, 7) !== endDate.toString().substring(3)) {
              if (this.compareDate(startDate, endDate) === 1) {
                this.controller.set(
                  'startDateErrorLabel',
                  this.get('i18n').t('ServiceRequest.duplicateStatement.error.startDate.error3')
                );
              }
            }
          }

          if (this.checkLoanWithMYCountry() && !isEmpty(endDate) && endDate.length === 7) {
            const endMonth = endDate.toString().substring(0, 2);

            if (endMonth !== '06' && endMonth !== '12') {
              this.controller.setProperties({
                startDate: null,
                endDate: null,
                endDateErrorLabel: this.get('i18n').t(
                  'ServiceRequest.duplicateStatement.error.commonError.startDateError'
                ),
                hasEndError: true
              });
              return;
            }
          }
          if (!this.checkLoanWithMYCountry() && !isEmpty(endDate) && endDate.length === 2) {
            this.controller.set('endDate', endDate + '/');
          }
        }
      }
      if (
        !isEmpty(startDate) &&
        !isEmpty(endDate) &&
        startDate.length === fieldLength &&
        endDate.length === fieldLength
      ) {
        this.send('validateEndDate');
        this.send('validateStartDate');
      }
    },
    validateEndDate() {
      const fieldExp = this.regxLoanWithCountry();
      let startDate = this.controller.startDate;
      let endDate = this.controller.endDate;
      this.controller.setProperties({
        disableNext: true,
        hasEndError: true,
        hasEndErrorLabel: true
      });
      if (startDate || endDate) {
        if (this.getDuration(endDate) > this.controller.statementYear && endDate.length > 3) {
          this.controller.set(
            'endDateErrorLabel',
            this.get('i18n').t('ServiceRequest.duplicateStatement.error.endDate.error1')
          );
          this.vnStmtYearForCCandCasa('endDateErrorLabel', 'endDate');
        } else if (this.getDuration(endDate) < 0) {
          this.controller.set(
            'endDateErrorLabel',
            this.get('i18n').t('ServiceRequest.duplicateStatement.error.endDate.error2')
          );
        } else if (this.compareDate(startDate, endDate) === 1) {
          this.controller.set(
            'endDateErrorLabel',
            this.get('i18n').t('ServiceRequest.duplicateStatement.error.endDate.error3')
          );
        } else if (!fieldExp.test(endDate)) {
          this.controller.set(
            'endDateErrorLabel',
            this.get('i18n').t('ServiceRequest.duplicateStatement.error.default')
          );
        } else {
          this.controller.setProperties({
            hasEndError: false,
            hasEndErrorLabel: false,
            endDateErrorLabel: null
          });
        }
      }
      this.disableNextButton();
    },
    updateDetails() {
      if (constant.duplicateStatement.nonDataLockerCtry.includes(this.get('customerInfo.countryName'))) {
        this.transitionTo('profileUpdate');
      } else {
        document.location.href = `/retail/customer/${this.get(
          'customerInfo.countryName'
        ).toLowerCase()}/datalocker.html#/landing?lang=en&ctry=${this.get(
          'customerInfo.countryName'
        )}&seg=EXBN&sapp=NFS`;
      }
    }
  },
  vnStmtYearForCCandCasa(dateErrorLabel, dateDescLabel) {
    let selecProd = this.getProductName();
    if (isEqual(this.get('customerInfo.countryName'), 'VN')) {
      if (isEqual(selecProd, 'account')) {
        this.controller.set(
          dateErrorLabel,
          this.get('i18n').t(`ServiceRequest.duplicateStatement.error.casa.${dateDescLabel}.error1`)
        );
      } else {
        this.controller.set(
          dateErrorLabel,
          this.get('i18n').t(`ServiceRequest.duplicateStatement.error.creditCard.${dateDescLabel}.error1`)
        );
      }
    }
  },
  checkLoanwithCountry() {
    return (
      isEqual(this.get('customerInfo.countryName'), 'SG') &&
      this.controller.model.selectedProduct.toString().indexOf('loan') !== -1
    );
  },
  regxLoanWithCountry() {
    if (this.checkLoanwithCountry()) {
      return new RegExp('^[12][0-9]{3}$', 'g');
    } else {
      return new RegExp('(0[1-9]|1[012])/[0-9]{4}$', 'g');
    }
  },
  triggerDebitaccount(dupStatementController) {
    this.get('rdcLoadingIndicator').showLoadingIndicator();
    let casaProduct = A();
    this.cslRequestError.clear();
    const cslRequest =
      dupStatementController.entity === 'ALL'
        ? constant.duplicateStatement.cslRequest[dupStatementController.product.entity]
        : constant.duplicateStatement.cslRequest[dupStatementController.entity];
    if (isEqual(cslRequest, 'credit-card')) {
      const getdebitDetailsCC = this.store
        .query('credit-card', {
          filter: constant.duplicateStatement.filters.chargeAccount
        })
        .then(
          data => {
            this.getdataValues(data).then(data => {
              casaProduct.pushObjects(data);
            });
          },
          error => {
            this.cslRequestError.pushObject(error);
          }
        );
      this.cslRequest.push(getdebitDetailsCC);
    }

    if (
      !isEqual(cslRequest, 'credit-card') ||
      (isEqual(this.get('customerInfo.countryName'), 'SG') && isEqual(cslRequest, 'credit-card'))
    ) {
      const getdebitDetails = this.store
        .query('casa', {
          filter: constant.duplicateStatement.filters.chargeAccount
        })
        .then(
          data => {
            this.getdataValues(data).then(data => {
              casaProduct.pushObjects(data);
            });
          },
          error => {
            this.cslRequestError.pushObject(error);
          }
        );
      this.cslRequest.push(getdebitDetails);
    }

    EmberPromise.all(this.cslRequest).then(() => {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      dupStatementController['debitAccountDetails'] = casaProduct;
      this.controller.set('model.curRoutename', null);
      if (this.cslRequestError.length === this.cslRequest.length) {
        this.get('cardErrorHandler').systemErrorPopup(this);
      }
    });
  }
});
