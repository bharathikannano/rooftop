import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../../constants';

export default Route.extend({
  i18n: service(),
  setupController(controller) {
    this.controllerFor('duplicate-statement').set('leftIcon', '');
    const getEntity = this.controllerFor('duplicate-statement').statementData;
    controller.setProperties({
      refNo: this.controllerFor('duplicate-statement').statementData.productReview.srrefNo,
      statusMsg: config.duplicateStatement.reviewCat.includes(getEntity.type)
        ? this.get('i18n').t('ServiceRequest.duplicateStatement.header.title.statusMsgCCNoN', {
            default: 'ServiceRequest.duplicateStatement.header.title.statusMsg'
          }) 
        : this.get('i18n').t('ServiceRequest.duplicateStatement.header.title.statusMsg'),
    });
  },
  actions: {
    checkStatus() {
      this.transitionTo('serviceRequest.status');
    },
    backToHomepage() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
