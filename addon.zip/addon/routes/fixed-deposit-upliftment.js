import Route from '@ember/routing/route';
import config from '../config/environment';
import { inject as service } from '@ember/service';

export default Route.extend({
  i18n: service(),
  rdcModalManager: service(),

  actions: {
    goToBack() {
      this.controllerFor('fixed-deposit-upliftment.new-request').back();
    },
    closePopupAction() {
      this.controller.set('clickCancel', true);
      let message;
      if (this.get('media.isDesktop')) {
        message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankBefAckText');
      } else {
        message = this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankBefAckText');
      }
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
        });
    }
  }
});
