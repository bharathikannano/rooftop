import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { isEmpty } from '@ember/utils';
import moment from 'moment';

export default Route.extend({
  queries: service('customer-info'),
  i18n: service(),
  rdcModalManager: service(),
  store: service(),
  rdcLoadingIndicator: service(),

  model() {
    return this.controllerFor('fixed-deposit-upliftment.new-request').get('flowData');
  },

  setupController(controller, model) {
    controller.setProperties({
      flowData: model
    });
    controller.set(
      'flowData.stepCounter',
      this.get('i18n').t('ServiceRequest.COMMON.progress.step' + controller.get('flowData.currentStep') + '3')
    );
  },

  actions: {
    willTransition(transition) {
      if (transition.targetName == 'rdc-ui-eng-service-requests.serviceRequest.new-request') {
        this.controller.set('flowData', null);
        this.controllerFor('fixed-deposit-upliftment.new-request').set('flowData', null);
      }
    },

    submitFdUpliftmentRequest() {
      this.submit();
    },

    back() {
      this.controllerFor('fixed-deposit-upliftment.new-request').back();
    }
  },

  submit() {
    const payload = {
      serviceType: 'TDUPLTMT',
      createdBy: this.controller.get('flowData.selectedFdAccount.relId'),
      country: this.get('queries.countryName'),
      isCritical: false,
      payload: {
        serviceRequests: {
          operationName: 'TDUPLIFTMENT',
          targetProcessID: '',
          customerDetails: {
            relationshipNo: this.controller.get('flowData.selectedFdAccount.relId')
          },
          tdUpliftment: [
            {
              journeyName: 'TDUPLIFTMENT',
              ibankingNumber: this.controller.get('flowData.selectedFdAccount.accountNumber'),
              createDate: this.getCurrentDate(),
              fdNumber: this.controller.get('flowData.selectedFdAccount.accountNumber'),
              depositBalance: this.formatBalance(this.controller.get('flowData.selectedFdAccount.balance')),
              maturityDate: this.formatDate(this.controller.get('flowData.selectedFdAccount.maturityDate')),
              accountToCredit: this.controller.get('flowData.selectedCreditAccount.accountNumber')
            }
          ]
        }
      },
      relNumber: this.controller.get('flowData.selectedFdAccount.relId'),
      status: 'INIT'
    };
    const fdsubmit = this.get('store')
      .createRecord('service-request', payload)
      .save()
      .then(data => this.showResult('success', data.id), error => this.showResult('error', error.id));
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(fdsubmit);
  },

  showResult(outcome, refNo) {
    if (isEmpty(outcome)) {
      this.controller.set('flowData.result', null);
      return;
    }
    const result = {
      success: outcome == 'success' ? true : false
    };
    this.controller.set('flowData.step', null);
    this.controller.set('flowData.result', result);

    if (!isEmpty(refNo)) {
      this.controller.set('flowData.resultRefNo', refNo);
    }
    this.transitionTo('fixed-deposit-upliftment.status');
  },

  getCurrentDate() {
    return moment().format('DD-MM-YYYY');
  },

  formatBalance(amount) {
    amount = amount.split('.');
    if (!isEmpty(amount[1]) && amount[1].length > 2 && amount[1].charAt(2) === '0') {
      amount[1] = amount[1].slice(0, 2);
    }
    return amount.join('.');
  },

  formatDate(fdDate) {
    return moment(fdDate, 'YYYY/MM/DD').format('DD-MM-YYYY');
  }
});
