import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { hash } from 'rsvp';
import { isEmpty } from '@ember/utils';
import { scheduleOnce } from '@ember/runloop';
import moment from 'moment';

export default Route.extend({
  queries: service('customer-info'),
  i18n: service(),
  rdcModalManager: service(),
  store: service(),
  rdcLoadingIndicator: service(),

  model() {
    let filters = {
      includeDealAccounts: true,
      onlyTimeDepositAccounts: true,
      operationName: 'FTDE'
    };
    return hash({ fdaccounts: this.queryAccounts(filters) });
  },

  setupController(controller, model) {
    this._super(controller, model);

    let flowData = controller.get('flowData');

    if (!isEmpty(flowData) && !isEmpty(flowData.step)) {
      if (flowData.step.selectCreditAccount === true) {
        this.listCreditAccounts();
        return;
      }
    }

    controller.setProperties({
      flowData: {
        selectedFdAccount: null,
        selectedCreditAccount: null,
        selectedFdAccountDisplay: null,
        selectedCreditAccountDisplay: null,
        step: null,
        currentStep: null,
        result: null,
        showNoAccountsMsg: null,
        resultRefNo: null,
        stepCounter: null
      }
    });

    controller.set('back', () => {
      this.goBack();
    });

    if (isEmpty(model.fdaccounts)) {
      this.showNoAccountsMsg(1);
      return;
    }

    this.goToStep(1);
  },

  actions: {
    willTransition(transition) {
      if (transition.targetName == 'rdc-ui-eng-service-requests.serviceRequest.new-request') {
        this.controller.set('flowData', null);
        try {
          this.controllerFor('fixed-deposit-upliftment.confirm').set('flowData', null);
        } catch (e) {
          return;
        }
      }
    },

    setSelectedFixedDepositAccount(account) {
      let message = this.get('i18n').t('ServiceRequest.FDUPLIFTMENT.prematurUpliftMsg');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.controllerFor('serviceRequest').set('systemErrorPopup', false);
          this.controller.set('flowData.selectedFdAccount', account);
          this.listCreditAccounts();
        });
    },

    setSelectedCreditAccount(account) {
      this.controller.set('flowData.selectedCreditAccount', account);
      this.goToStep(3);
    },

    back() {
      this.goBack();
    }
  },

  goBack() {
    const currentStep = this.controller.get('flowData.currentStep');
    if (currentStep > 1 && currentStep <= 3) {
      this.goToStep(currentStep - 1, currentStep);
    } else {
      this.transitionTo('serviceRequest.new-request');
    }
  },

  listCreditAccounts() {
    let filters = {
      operationName: 'FTDE_OAFT',
      currencyCode: this.controller.get('flowData.selectedFdAccount.currency')
    };
    this.queryAccounts(filters).then(creditAccList => {
      if (isEmpty(creditAccList)) {
        this.showNoAccountsMsg(2);
        return;
      }
      this.controller.set('model.creditAccounts', creditAccList);
      this.goToStep(2);
      scheduleOnce('afterRender', () => {
        document.querySelector('.fdu-container').scrollTop = 0;
      });
    });
  },

  showNoAccountsMsg(stepNo) {
    this.controller.set('flowData.showNoAccountsMsg', true);
    this.controller.set(
      'noAccountHeading',
      stepNo === 1
        ? this.get('i18n').t('ServiceRequest.FDUPLIFTMENT.noFDAccountHeading')
        : this.get('i18n').t('ServiceRequest.FDUPLIFTMENT.noCreditAccountHeading')
    );
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },

  goToStep(stepNo, prevStepNo) {
    this.controller.set('flowData.currentStep', stepNo);
    if (stepNo === 3) {
      this.transitionTo('fixed-deposit-upliftment.confirm');
      return;
    }
    const steps = {
      '1': { selectFdAccount: true },
      '2': { selectCreditAccount: true },
      '3': { confirmation: true }
    };

    this.controller.set('flowData.step', steps[stepNo]);
    this.controller.set(
      'flowData.stepCounter',
      this.get('i18n').t('ServiceRequest.COMMON.progress.step' + stepNo + '3')
    );
    if (!isEmpty(prevStepNo) && prevStepNo === 3) {
      this.transitionTo('fixed-deposit-upliftment.new-request');
    }
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },

  queryAccounts(filter) {
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    return this.get('rdcLoadingIndicator')
      .showLoadingIndicatorForPromise(
        this.get('store').query('casa', {
          filter: filter
        })
      )
      .then(
        data => {
          let accountsList = data.map(casaItem => {
            return {
              relId: casaItem.get('relId'),
              accountNumber: casaItem.get('accountNumber'),
              desc: casaItem.get('productDescription'),
              balance: casaItem.get('availableBalance'),
              currency: casaItem.get('currencyCode'),
              maturityDate: casaItem.get('depositMaturityDate'),
              maturityFmtDate: moment(casaItem.get('depositMaturityDate'), 'YYYY/MM/DD').format('DD MMMM YYYY')
            };
          });
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          return accountsList;
        },
        error => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          try {
            if (error.errors[0].code === 'CSL-CASA-511') {
              return [];
            } else {
              this.showRequestErrorWarning();
              return [];
            }
          } catch (e) {
            this.showRequestErrorWarning();
            return [];
          }
        }
      );
  },

  showRequestErrorWarning() {
    let message = this.get('i18n').t('ServiceRequest.FDUPLIFTMENT.systemErrorMsg');
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message,
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
        iconClass: 'service-journey-system-error-icon',
        popupClass: 'service-journey-system-error-popup'
      })
      .then(() => {
        this.controllerFor('serviceRequest').set('systemErrorPopup', false);
        this.transitionTo('serviceRequest.new-request');
      });
  }
});
