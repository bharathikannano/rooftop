import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';

export default Route.extend({
  queries: service('customer-info'),
  i18n: service(),
  rdcModalManager: service(),
  store: service(),
  rdcLoadingIndicator: service(),

  model() {
    return this.controllerFor('fixed-deposit-upliftment.confirm').get('flowData');
  },

  setupController(controller, model) {
    controller.setProperties({
      flowData: model
    });
  },

  actions: {
    viewStatus() {
      this.transitionTo('serviceRequest.status');
    }
  }
});
