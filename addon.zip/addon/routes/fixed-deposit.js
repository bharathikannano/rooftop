import { inject as service } from '@ember/service';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';
import { Promise as EmberPromise } from 'rsvp';
import { isEmpty } from '@ember/utils';

export default FereFormRoute.extend({
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),

  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'FIXEDDEPOSIT_STEP1', countryCode: this.get('axwayConfig.country'), id: 'W345' } };
    }
  }),

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
  },

  closeThisForm() {
    this.transitionTo('serviceRequest.new-request');
  },
  afterSubmit(formDatum, isFileDelete) {
    const promise = new EmberPromise(resolve => {
      let isCRSETB = formDatum.get('additionalInfo') && formDatum.get('additionalInfo').CRSETB;
      if (!isEmpty(isCRSETB) && isCRSETB) {
        resolve('CRSETB');
      } else {
        resolve();
      }
    });
    promise.then(result => {
      if (result && result.length > 0) {
        if (result === 'CRSETB') {
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'error',
              title: this.get('i18n').t('ServiceRequest.COMMON.crsMessage.title'),
              message: this.get('i18n').t('ServiceRequest.COMMON.crsMessage.CRSETB'),
              rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok')
            })
            .then(() => {
              this.set('isRetry', true);
              this.transitionTo('serviceRequest.new-request');
            })
            .catch(() => {});
        }
      } else {
        if (!isFileDelete) this.goToReceiptPage();
      }
    });
  },
  actions: {
    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        this.transitionTo('serviceRequest.new-request');
      }
    },
    closeForm() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
