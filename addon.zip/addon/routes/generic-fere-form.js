import { inject as service } from '@ember/service';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';
import config from '../config/environment';
import { isEmpty } from '@ember/utils';
import { Promise as EmberPromise } from 'rsvp';

export default FereFormRoute.extend({
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),
  store: service(),
  session: service(),
  rdcLoadingIndicator: service(),
  accessToken: computed('session', {
    get() {
      const accessToken = this.get('session.data.authenticated.access_token');
      return accessToken;
    }
  }),
  refreshToken: computed('session', {
    get() {
      const refreshToken = this.get('session.data.authenticated.refresh_token');
      return refreshToken;
    }
  }),
  beforeModel(params) {
    this._super(...arguments);
    this.get('rdcLoadingIndicator').showLoadingIndicator();
	let unwantedParams = ['ctry', 'lang', 'RDC-ACCESS-TOKEN', 'RDC-REFRESH-TOKEN'];
    Object.keys(params.queryParams).forEach(element => {
      /*
       * Removing unwanted params from form filter since it is throwing mapping error.
       * but it is required in UI to pass in header.
       */
      if (!unwantedParams.includes(element)) {
        this.queryParams.filter[element] = params.queryParams[element];
      }
    });
  },
  afterModel() {
    this._super(...arguments);
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },
  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { countryCode: this.get('axwayConfig.country') } };
    }
  }),

  /*
   * To not allow user in NG debit card issuance journey to apply for debit card if product is tier1.
   * To show alert and take them back to help and service page.
   */
  checkIfDebitCardAvailable() {
    let product = this.get('store').peekRecord('field', 'ProductClassification'),
      accountList = this.get('store').peekRecord('field', 'AccountList');

    if (!isEmpty(product) && !isEmpty(accountList) && accountList.fieldConfig.get('fieldOptions').length === 0) {
      if (product.value === 'TIER1') {
        this.get('rdcLoadingIndicator').showLoadingIndicator();
        let title = this.get('i18n').t('ServiceRequest.NG_DEBITCARD_ERROR_MAP.tier1_title'),
          message = this.get('i18n').t('ServiceRequest.NG_DEBITCARD_ERROR_MAP.tier1_message');
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'error',
            title,
            message: message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          })
          .then(() => {
            this.get('rdcLoadingIndicator').hideLoadingIndicator();
            this.closeThisForm();
          });
      }
    }
  },

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
    // To check if debitcard journey is available only if country is NG.
    if (this.get('axwayConfig.country') === 'NG') {
      this.checkIfDebitCardAvailable();
    }
  },

  // This is required to trigger display rule dynamically from additional info.
  async afterSubmit(formDatum) {
    let additionalFields = formDatum.get('additionalInfo') && formDatum.get('additionalInfo').fields;
    if (!isEmpty(additionalFields)) {
      await this.set('additionalFields', additionalFields);
      await this.send('setAdditionalFields', additionalFields);
    }
    this.enableGoToNext();
  },

  closeThisFormFromNTB() {
    let title = this.get('i18n').t('FERE.action.modal.quitApp.title');
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'error',
        title,
        message: this.currentModel.receiptId
          ? this.get('i18n').t('FERE.action.modal.quitApp.messageEmailSms')
          : this.get('i18n').t('FERE.action.modal.quitApp.messageProgressLost'),
        acceptButtonLabel: this.get('i18n').t('FERE.action.button.YES'),
        rejectButtonLabel: this.get('i18n').t('FERE.action.button.NO')
      })
      .then(() => {
        if (window.cordova) {
          // Sending refresh token and access token while exit from fere to legecy screen.
          if (this.accessToken && this.refreshToken) {
            window.location.href =
              window.location.protocol +
              '//' +
              window.location.host +
              '/exit?RDC-ACCESS-TOKEN=' +
              this.accessToken +
              '&RDC-REFRESH-TOKEN=' +
              this.refreshToken;
          } else {
            window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
          }
        } else {
          document.location.href = config.backToiBankURL;
        }
      });
  },

  closeThisForm() {
    // checking if RelationshipNo is present as relId in form data. If present then ETB or NTB.
    let relationshipNo = this.get('store').peekRecord('field', 'RelationshipNo');
    if (
      relationshipNo &&
      (relationshipNo.get('value') === null ||
        relationshipNo.get('value') === 'NTB' ||
        relationshipNo.get('value') === '')
    ) {
      this.closeThisFormFromNTB();
    } else {
      this.transitionTo('serviceRequest.new-request');
    }
  },

  actions: {
    goToNormalMode(sectionModel) {
      if (sectionModel.reviewEditAction) {
        this.transitionTo(sectionModel.reviewEditAction);
      }
    },
    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        this.closeThisForm();
      }
    },
    goToHome() {
      if (window.cordova) {
        // Sending refresh token and access token while exit from fere to legecy screen.
        if (this.accessToken && this.refreshToken) {
          window.location.href =
            window.location.protocol +
            '//' +
            window.location.host +
            '/exit?RDC-ACCESS-TOKEN=' +
            this.accessToken +
            '&RDC-REFRESH-TOKEN=' +
            this.refreshToken;
        } else {
          window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
        }
      } else {
        document.location.href = config.backToiBankURL;
      }
    },
    setAdditionalFields(fields) {
      if (fields) {
        let store = this.get('store');
        fields.forEach(item => {
          let field = store.peekRecord('field', item.id);
          if (field) {
            if (item.fieldType === 'rdc-form-select' && !isEmpty(item.newValue)) {
              let fieldOption = field.get('fieldConfig.fieldOptions').findBy('value', item.newValue);
              field.set('value', fieldOption);
            } else {
              field.set('value', item.newValue);
            }
          }
        });
      }
    },
    closeForm() {
	  // To move to home page for PL topup.
	  if (this.queryParams.filter.stepName === 'PL_TOP_UP') {
		this.send('goToHome'); 
	  } else {
		this.closeThisForm();
	  }
    },
    goToStatusEnquiry() {
      this.transitionTo('serviceRequest.status');
    },
    goToPreLogin() {
      if (this.get('axwayConfig.country') == 'CI') {
        window.PGMultiView.dismissView();
      } else if (window.cordova) {
        // Sending refresh token and access token while exit from fere to legecy screen.
        if (this.accessToken && this.refreshToken) {
          window.location.href =
            window.location.protocol +
            '//' +
            window.location.host +
            '/exit?RDC-ACCESS-TOKEN=' +
            this.accessToken +
            '&RDC-REFRESH-TOKEN=' +
            this.refreshToken;
        } else {
          window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
        }
      } else {
        document.location.href = config.backToiBankURL;
      }
    }
  },

  goToPreLogin() {
    if (this.get('axwayConfig.country') == 'CI') {
      window.PGMultiView.dismissView();
    } else {
      if (window.cordova) {
        // Sending refresh token and access token while exit from fere to legecy screen.
        if (this.accessToken && this.refreshToken) {
          window.location.href =
            window.location.protocol +
            '//' +
            window.location.host +
            '/exit?RDC-ACCESS-TOKEN=' +
            this.accessToken +
            '&RDC-REFRESH-TOKEN=' +
            this.refreshToken;
        } else {
          window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
        }
      } else {
        const preloginStatus =
          !this.store.peekRecord('field', 'RelationshipNo') ||
          this.store.peekRecord('field', 'RelationshipNo').value === 'NTB';
        if (this.get('axwayConfig.country') === 'AE' && preloginStatus) {
          window.location.href = config.backToiBankNTBURL['AE'];
        } else {
          document.location.href = config.backToiBankURL;
        }
      }
    }
  },

  onNext() {
    let bureauIndicator = this.get('store').peekRecord('field', 'BureauIndicator');
    if (bureauIndicator) {
      bureauIndicator.set('value', 'Y');
    }
    this.submitForm();
    this.controller.set('showActionSheet', false);
  }
});
