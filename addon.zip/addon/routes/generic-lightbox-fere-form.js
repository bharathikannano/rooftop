import { inject as service } from '@ember/service';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { isEmpty } from '@ember/utils';
import config from '../constants';
import moment from 'moment';
import { computed } from '@ember/object';

export default FereFormRoute.extend({
  iframeManager: service(),
  i18n: service(),
  otpManager: service(),
  customerInfo: service(),
  rdcModalManager: service(),
  axwayConfig: service(),
  beforeModel(params) {
    this._super(...arguments);
    Object.keys(params.queryParams).forEach(element => {
      /*
       * Removing ctry and lang from form filter since it is throwing mapping error.
       * but it is required in UI to pass locale in header.
       */
      if (element !== 'ctry' && element !== 'lang') {
        this.queryParams.filter[element] = params.queryParams[element];
      }
    });
  },

  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { countryCode: this.get('axwayConfig.country') } };
    }
  }),

  setupController: function(controller, model) {
    this._super(...arguments);
    const creditCardApiModel = this.get('store')
      .peekRecord('field', 'CreditCardNo')
      .get('fieldConfig')
      .get('apiModel');
    const transactionApiModel = this.get('store')
      .peekRecord('field', 'CreditTxn')
      .get('fieldConfig')
      .get('apiModel');
    this.get('store').unloadAll(creditCardApiModel);
    this.get('store').unloadAll(transactionApiModel);
    controller.set('iframeManager', this.get('iframeManager'));
    model.set('theme', 'fere-page-theme-ui1');
  },

  closeThisForm() {
    this.transitionTo('serviceRequest.new-request');
  },

  actions: {
    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        this.transitionTo('serviceRequest.new-request');
      }
    },
    closeForm() {
      this.transitionTo('serviceRequest.new-request');
    },
    goToStatusEnquiry() {
      this.transitionTo('serviceRequest.status');
    },

    transactionValidation() {
      const apiModel = this.get('store')
        .peekRecord('field', 'CreditTxn')
        .get('fieldConfig')
        .get('apiModel');
      // const apiModel = apiUrl.split('##')[0];
      let transactionsList = this.get('store').peekAll(apiModel);
      let selectedTransactions = transactionsList.filterBy('isSelected', true);
      let hiddenTransactions = transactionsList.filterBy('visible', false);
      let showAlert = false;
      let totalTxnAmount = 0;
      selectedTransactions.forEach(transaction => {
        totalTxnAmount += parseInt(transaction.actualTxnAmount, 10);
        hiddenTransactions.forEach(hiddenTransaction => {
          let hiddenTxnDate = moment(hiddenTransaction.txnDate, 'DD/MM/YYYY').toDate();
          let selectedTxnDate = moment(transaction.txnDate, 'DD/MM/YYYY').toDate();
          if (
            hiddenTxnDate >= selectedTxnDate &&
            !isEmpty(transaction.txnCode) &&
            !isEmpty(hiddenTransaction.txnCode) &&
            Math.abs(hiddenTransaction.actualTxnAmount) == Math.abs(transaction.actualTxnAmount) &&
            hiddenTransaction.merchantName === transaction.merchantName &&
            config.TRANSACTION[this.customerInfo.countryName][transaction.txnCode] &&
            config.TRANSACTION[this.customerInfo.countryName][transaction.txnCode].indexOf(
              hiddenTransaction.txnCode
            ) !== -1
          ) {
            showAlert = true;
            return;
          }
        });
      });
      this.get('store')
        .peekRecord('field', 'TotalTxnAmount')
        .set('value', totalTxnAmount);
      if (showAlert) {
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message: this.get('i18n').t('TRANSACTIONDISPUTE.reversalTransaction'),
            rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          })
          .then(() => {
            this.goToNextPage();
          });
      } else {
        this.goToNextPage();
      }
      return;
    }
  }
});
