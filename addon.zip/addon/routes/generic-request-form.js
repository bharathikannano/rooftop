import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../config/environment';
import { isEqual } from '@ember/utils';
export default Route.extend({
  rdcModalManager: service(),
  i18n: service(),
  customerInfo: service(),
  store: service(),
  rdcLoadingIndicator: service(),
  cardErrorHandler: service(),
  beforeModel(params) {
    let getDetails = {};
    this.customerInfo.set('cardData', getDetails);
    try {
      let getData = JSON.parse(params.queryParams.filter);
      getDetails = {
        entity: getData.stepName,
        type: getData.operationName,
        reqFilter: getData.reqFilter,
        reqType: getData.reqType,
        skipPage: getData.skipPage
      };
      this.set('gotoRoute', 'referral');
    } catch (e) {
      getDetails = {
        entity: params.queryParams.entity,
        type: params.queryParams.type,
        reqFilter: params.queryParams.reqFilter,
        reqType: params.queryParams.reqType,
        skipPage: params.queryParams.skipPage
      };
      this.set('gotoRoute', 'select');
    }
    this.customerInfo.set('cardData', getDetails);
    if(!isEqual(getDetails.entity,'CUSTOMER')){
      this.transitionTo('generic-request-form.' + this.get('gotoRoute'));
    } else {
      this.customerInfo.cardData['cslRequestEntity'] = 'customer';
    }
  },
  model(){
    if(isEqual(this.customerInfo.cardData.entity,'CUSTOMER')){
    const getCustomerInfo = this.get('store').queryRecord('customer',{
      filter:{
        tpSystem:'ICM'
      }
    }).then(() => {
        this.replaceWith('generic-request-form.upload');
      }).catch(() => {
        this.get('cardErrorHandler').systemErrorPopup(this);
      });
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(getCustomerInfo);
    }
  },
  setupController(controller) {
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    controller.set(
      'reqTitle',
      this.get('i18n').t('ServiceRequest.genericRequest.' + this.customerInfo.get('cardData').type + '.title', {
        default: 'ServiceRequest.genericRequest.default'
      })
    );
  },
  actions: {
    closePopupAction() {
      let message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankBefAckText');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
        });
    }
  }
});
