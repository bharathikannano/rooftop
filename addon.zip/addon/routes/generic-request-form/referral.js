import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../../constants';
import { hash } from 'rsvp';
import { isEmpty } from '@ember/utils';

export default Route.extend({
  store: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),
  customerInfo: service(),
  rdcModalManager: service(),
  i18n: service(),
  model(params, transtition) {
    const paramVal = JSON.parse(transtition.queryParams.filter);
    this.set('operationName', paramVal.operationName);
    this.set('receiptId', paramVal.sourceRefNo);
    const referralDetails = this.get('store')
      .query('referral-request', {
        filter: {
          eopstxnRefno: paramVal.eopsTxnRefNo,
          language: 'en',
          receiptId: paramVal.sourceRefNo,
          operationName: paramVal.operationName
        }
      })
      .then(data => {
        data.forEach(item => {
          this.set('relId', item.get('relId'));
        });
        return data;
      });
    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(referralDetails);
    return hash({
      referralDetails: referralDetails
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.setProperties({
      disableNext: false,
      enableTextArea: false,
      nextBtnText: this.get('i18n').t('ServiceRequest.genericRequest.header.title.referral.reply'),
      comments: '',
      txtboxLabel: this.get('i18n').t('ServiceRequest.genericRequest.header.title.label4').string
    });
  },
  __enableNext() {
    const fieldExp = new RegExp('[^a-zA-Z0-9.,#\\n ]', 'g');
    this.controller.set('comments', this.controller.get('comments').replace(fieldExp, ''));
    !isEmpty(this.controller.get('comments').trim())
      ? this.controller.set('disableNext', false)
      : this.controller.set('disableNext', true);
  },
  __removeVulchar() {
    this.customerInfo.validateKey();
    this.__enableNext();
  },
  __postData() {
    let postData = {
      status: 'INIT',
      patchRequestId: this.get('receiptId'),
      isPatchRequest: 'true',
      payload: {
        serviceRequests: {
          Comments: this.controller.get('comments').trim(),
          operationName: this.get('operationName'),
          customerDetails: {
            relationshipNo: this.get('relId')
          },
          channel: {
            subChannelId: 'IBNK',
            channelId: '04'
          }
        }
      },
      relNumber: this.get('relId'),
      serviceType: config.genericRequestForm.serviceType[this.get('operationName')].submsgId,
      isDocAvailable: this.customerInfo.get('cardData').docUpload,
      isCritical: false,
      statusOrder: 0,
      dateOrder: 0,
      isPartialSave: false
    };
    return postData;
  },
  actions: {
    goToBack() {
      this.controller.set('disableNext', false);
      if (!this.controller.get('enableTextArea')) {
        this.get('store').unloadAll('referral-request');
        this.transitionTo('serviceRequest.status');
      }
      this.controller.setProperties({
        enableTextArea: false,
        nextBtnText: this.get('i18n').t('ServiceRequest.genericRequest.header.title.referral.reply')
      });
    },
    validateTextarea() {
      this.__enableNext();
    },
    validateChar() {
      this.__removeVulchar();
    },
    navigateConfirm() {
      if (this.controller.get('enableTextArea')) {
        this.customerInfo.cardData['isReferral'] = true;
        this.get('store').unloadAll('service-request');
        const genericPost = this.get('store')
          .createRecord('service-request', this.__postData())
          .save()
          .then(
            item => {
              this.customerInfo.cardData['srrefNo'] = item.id;
              this.transitionTo('generic-request-form.status');
            },
            () => {
              this.get('cardErrorHandler').systemErrorPopup(this);
            }
          );
        this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(genericPost);
        return;
      }
      this.controller.set('enableTextArea', true);
      this.controller.set(
        'nextBtnText',
        this.get('i18n').t('ServiceRequest.genericRequest.header.title.referral.submit')
      );
      this.__enableNext();
    }
  }
});
