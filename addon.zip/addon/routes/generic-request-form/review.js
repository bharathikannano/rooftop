import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { isEmpty, isEqual, isNone } from '@ember/utils';
import config from '../../constants';
import { htmlSafe } from '@ember/string';
export default Route.extend({
  customerInfo: service(),
  store: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),
  i18n: service(),
  rdcModalManager: service(),
  setupController(controller) {
    controller.setProperties({
      dispName: this.customerInfo.get('cardData').getDesc,
      dispNum: this.customerInfo.get('cardData').getNum,
      dispComments: this.comments(this.customerInfo.get('cardData').comments),
      notemessages: this.controllerFor('generic-request-form').notemessages,
      showNotes: this.customerInfo.get('countryName') === 'SG' ? true : false
    });
    if (this.customerInfo.get('cardData').entity) {
      if (
        this.customerInfo.get('cardData').entity === 'CCARD' ||
        this.customerInfo.get('cardData').entity === 'DCARD'
      ) {
        controller.set('maskConfig', this.customerInfo.cardMaskConfig());
      } else {
        controller.set('maskConfig', this.customerInfo.loanMaskConfig());
      }
    }
    controller.set('cardMasking', this.customerInfo.cardMasking());
    let docNames = this.customerInfo.get('cardData').filename;
    if (!isEmpty(docNames)) {
      let splitdocName = docNames.toString().split(',');
      let appendDivid = '';
      splitdocName.forEach(item => {
        appendDivid += item + '<br>';
      });
      controller.set('fileName', htmlSafe(appendDivid));
    } else {
      controller.set('fileName', this.customerInfo.get('cardData').filename);
    }
    controller.set(
      'dispTitle',
      this.get('i18n').t('ServiceRequest.genericRequest.' + this.customerInfo.get('cardData').type + '.title', {
        default: 'ServiceRequest.genericRequest.default'
      })
    );
    controller.set(
      'getDatatype',
      isEqual(this.customerInfo.cardData.type, 'PLCLOSUR')
        ? this.get('i18n').t('ServiceRequest.genericRequest.header.title.PLCLOSUR')
        : this.get('i18n').t(
            'ServiceRequest.genericRequest.header.title.' + this.customerInfo.get('cardData').getDatatype,
            { default: 'ServiceRequest.genericRequest.header.title.default' }
          )
    );
    let genReq = this.controllerFor('generic-request-form');
    if (
      (genReq.get('noTextarea') && genReq.get('noDocupload')) ||
      isEqual(this.customerInfo.cardData.entity, 'CUSTOMER') ||
      isEqual(this.customerInfo.cardData.skipPage, '1')
    ) {
      controller.set('stepVal', this.get('i18n').t('ServiceRequest.COMMON.progress.step22'));
      controller.set('gotoUpload', false);
    } else {
      controller.set('stepVal', this.get('i18n').t('ServiceRequest.COMMON.progress.step33'));
      controller.set('gotoUpload', true);
    }
  },
  comments: function(text) {
    const getval = text;
    if (getval) {
      const fieldExp = new RegExp('[\\n]', 'g');
      return htmlSafe(getval.replace(fieldExp, '<br>'));
    } else {
      return false;
    }
  },
  actions: {
    goToBack() {
      this.controller.get('gotoUpload') ||
      isEqual(this.customerInfo.cardData.entity, 'CUSTOMER') ||
      isEqual(this.customerInfo.cardData.skipPage, '1')
        ? this.transitionTo('generic-request-form.upload')
        : this.transitionTo('generic-request-form.select');
    },
    navigateConfirm() {
      let appendObj = {};
      if (this.customerInfo.get('cardData').entity === ('CCARD' || 'DCARD')) {
        appendObj = {
          cardType: this.customerInfo.get('cardData').getType
        };
      } else {
        appendObj = {
          accType: this.customerInfo.get('cardData').getType,
          productCode: this.customerInfo.get('cardData').prdCode
        };
      }

      let postData = {
        status: 'INIT',
        payload: {
          serviceRequests: {
            Remarks: this.customerInfo.get('cardData').comments,
            operationName: this.customerInfo.get('cardData').type,
            SRType: this.customerInfo.get('cardData').type,
            Product: this.customerInfo.get('cardData').entity,
            AccountNumber: isEmpty(this.customerInfo.get('cardData').getNum)
              ? 'NA'
              : this.customerInfo.get('cardData').getNum,
            currencyCode:
              this.customerInfo.get('cardData').entity === 'DEPOSIT ' ||
              this.customerInfo.get('cardData').entity === 'CASA'
                ? this.customerInfo.get('cardData').curCode
                : null,
            ChatSystem: '9999999',
            serviceType: isEqual(this.customerInfo.cardData.entity, 'CUSTOMER')
              ? 'GREQOBOR'
              : config.genericRequestForm.serviceType[this.customerInfo.get('cardData').type].msgID,
            customerDetails: {
              relationshipNo: isEqual(this.customerInfo.cardData.entity, 'CUSTOMER')
                ? null
                : this.customerInfo.get('cardData').relId
            }
          }
        },
        isNstpRequest: 'true',
        isBoRequest:
          !isEmpty(this.customerInfo.cardData.reqType) && isEqual(this.customerInfo.cardData.reqType, 'NFS')
            ? true
            : false,
        relNumber: isEqual(this.customerInfo.cardData.entity, 'CUSTOMER')
          ? null
          : this.customerInfo.get('cardData').relId,
        serviceType: isEqual(this.customerInfo.cardData.entity, 'CUSTOMER')
          ? 'GREQOBOR'
          : config.genericRequestForm.serviceType[this.customerInfo.get('cardData').type].msgID,
        isDocAvailable: this.customerInfo.get('cardData').docUpload,
        isCritical: false,
        statusOrder: 0,
        dateOrder: 0,
        isPartialSave: false
      };

      if (this.customerInfo.get('cardData').docUpload) {
        const docSubmission = config.genericRequestForm.docSubmission[this.customerInfo.get('cardData').type];
        let docDetails = {
          docInfoDetails: [
            {
              documentType: !isEmpty(docSubmission)
                ? docSubmission
                : config.genericRequestForm.docSubmission['DEFAULTVALUE'],
              documentUniqueReferenceNo: this.customerInfo.get('cardData').refNo
            }
          ],
          docList: [this.customerInfo.get('cardData').refNo]
        };
        Object.assign(postData.payload.serviceRequests, docDetails);
        const documentList = {
          documentList: this.customerInfo.get('cardData').refNo
        };
        Object.assign(postData, documentList);
      }
      if (isEqual(this.customerInfo.cardData.entity, 'CUSTOMER')) {
        const genericCustomer = {
          messageReceiverAddressType: config.genericRequestForm.msgAddType[this.customerInfo.cardData.type.slice(-2)],
          messageCategory: 'I',
          messageSubject: ''
        };
        Object.assign(postData.payload.serviceRequests, genericCustomer);
      }
      if (isEqual(this.customerInfo.cardData.type, 'PLCLOSUR')) {
        const plClosure = {
          creditCardLoanClosure: {
            card: {
              cancellationReason: null
            },
            loan: [
              {
                cashOneLoan: this.customerInfo.get('cardData').getNum
              }
            ]
          }
        };
        Object.assign(postData.payload.serviceRequests, plClosure);
      }
      Object.assign(postData.payload.serviceRequests, appendObj);
      this.get('store').unloadAll('service-request');
      const genericPost = this.get('store')
        .createRecord('service-request', postData)
        .save()
        .then(
          item => {
            this.customerInfo.cardData['srrefNo'] = item.id;
            this.transitionTo('generic-request-form.status');
          },
          error => {
            if (!isEmpty(error) && !isEmpty(error.errors) && !isNone(error.errors[0]) && error.errors[0].code !== 401) {
              this.get('cardErrorHandler').systemErrorPopup(this);
            }
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(genericPost);
    }
  }
});
