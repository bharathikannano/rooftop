import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../../constants';
import { hash } from 'rsvp';
import { isEmpty, isEqual } from '@ember/utils';
export default Route.extend({
  store: service(),
  i18n: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  customerInfo: service(),
  router: service(),
  model() {
    let notesRemoveNumber = null;
    let curRoutename = this.get('router.currentRouteName'),
      requestDetails,
      CslRequestfilters;
    if (curRoutename !== null) {
      curRoutename = curRoutename.indexOf('new-request') !== -1 ? true : false;
    }
    if (curRoutename) {
      let cslRequestEntity = config.genericRequestForm.cslRequest[this.customerInfo.get('cardData').entity];
      this.customerInfo.get('cardData').entity === 'DEPOSIT'
        ? this.set('selectContent', 'deposit')
        : this.set('selectContent', cslRequestEntity);
      this.customerInfo.cardData['getDatatype'] = this.get('selectContent');
      this.customerInfo.cardData['cslRequestEntity'] = cslRequestEntity;
      this.get('store').unloadAll(cslRequestEntity);
      this.set('displayContent', cslRequestEntity);
      this.set('filterType', null);
      this.controllerFor('generic-request-form.select').set('refreshData', true);
      Object.entries(config.genericRequestForm.filterType).forEach(item => {
        item[1].filter(value => {
          if (value === this.customerInfo.get('cardData').type) {
            this.set('filterType', item[0]);
          }
        });
      });
      CslRequestfilters = !isEmpty(this.customerInfo.cardData.reqFilter)
        ? { operationName: this.customerInfo.cardData.reqFilter }
        : config.genericRequestForm.filters.values[this.get('filterType')];
      if (isEmpty(CslRequestfilters)) {
        CslRequestfilters =
          config.genericRequestForm.filters[this.get('customerInfo.countryName')][cslRequestEntity]['default'];
      }
      requestDetails = this.get('store')
        .query(cslRequestEntity, {
          filter: CslRequestfilters
        })
        .then(
          data => {
            this.set('alerts', false);
            data.forEach(item => {
              if (!isEmpty(item.alerts) && item.alerts.length >= 0) {
                this.set('alerts', true);
              }
            });
            return !config.genericRequestForm.inlineDuplicateChk.includes(this.customerInfo.cardData.type) &&
              this.get('alerts')
              ? null
              : data;
          },
          error => {
            if (
              !isEmpty(error.errors[0]) &&
              config.genericRequestForm.noDatastrings.indexOf(error.errors[0].code) === -1
            ) {
              this.set('errorRiskCode', error.errors[0].code);
              this.get('cardErrorHandler').systemErrorPopup(this);
            }
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(requestDetails);
    } else {
      this.controllerFor('generic-request-form.select').set('refreshData', false);
      requestDetails = this.customerInfo.get('requestDetails');
    }
    let genReq = this.controllerFor('generic-request-form');
    if (genReq.get('noTextarea') && genReq.get('noDocupload')) {
      this.set('stepVal', this.get('i18n').t('ServiceRequest.COMMON.progress.step12'));
    } else {
      this.set('stepVal', this.get('i18n').t('ServiceRequest.COMMON.progress.step13'));
    }

    notesRemoveNumber = config.genericRequestForm.notesNumberRemovedInCountries.includes(
      this.get('customerInfo.countryName')
    )
      ? true
      : false;

    return hash({
      notesRemoveNumber: notesRemoveNumber,
      requestDetails: requestDetails,
      stepVal: this.get('stepVal'),
      displayContent: this.get('displayContent'),
      nocardsContent: !isEqual(this.customerInfo.cardData.type, 'PLCLOSUR')
        ? this.get('i18n').t('ServiceRequest.genericRequest.errorMsg.title.' + this.get('displayContent'), {
            default: 'ServiceRequest.genericRequest.errorMsg.title.default'
          })
        : this.get('i18n').t('ServiceRequest.genericRequest.errorMsg.title.PLCLOSUR'),
      headTitle: this.get('i18n').t('ServiceRequest.genericRequest.header.panelTitle.' + this.get('selectContent'), {
        default: 'ServiceRequest.genericRequest.header.panelTitle.default'
      }),
      headContent: this.get('i18n').t('ServiceRequest.genericRequest.header.content.' + this.get('selectContent'), {
        default: 'ServiceRequest.genericRequest.header.content.default'
      }),
      hideCardCat: this.get('customerInfo.countryName') === 'SG' ? true : false,
      lable: isEqual(this.customerInfo.cardData.type, 'PLCLOSUR')
        ? this.get('i18n').t('ServiceRequest.genericRequest.header.title.labelMsgPLCLOSUR')
        : ''
    });
  },
  afterModel(data) {
    if (
      !isEmpty(data.requestDetails) &&
      !isEmpty(this.customerInfo.cardData.skipPage) &&
      isEqual(this.customerInfo.cardData.skipPage, '1')
    ) {
      this.replaceWith('generic-request-form.upload');
    }
    this.customerInfo.set('requestDetails', data.requestDetails);
  },
  setupController(controller, model) {
    this._super(controller, model);
    try {
      model.requestDetails.filterBy('isSelected').length > 0
        ? controller.set('disableNext', false)
        : controller.set('disableNext', true);
    } catch (e) {
      controller.set('disableNext', true);
    }
  },
  actions: {
    goToBack() {
      this.get('store').unloadAll('credit-card');
      this.transitionTo('serviceRequest.new-request');
    },
    navigateConfirm(model) {
      const modalVal = model.requestDetails.filterBy('isSelected');
      if (!isEmpty(modalVal)) {
        modalVal.forEach(item => {
          let cardDetails = ((getNum, getType, getDesc, prdCode, relId, curCode) => ({
            getNum,
            getType,
            getDesc,
            prdCode,
            relId,
            curCode
          }))(
            item.get('cardNum') ? item.get('cardNum') : item.get('accountNumber'),
            item.get('cardType') ? item.get('cardType') : item.get('accountType'),
            item.get('desc') ? item.get('desc') : item.get('productDescription'),
            item.get('subProductCode') ? item.get('subProductCode') : null,
            item.get('relId'),
            item.get('currencyCode') ? item.get('currencyCode') : null
          );
          Object.assign(this.customerInfo.cardData, cardDetails);
        });
      }
      if (this.controller.noDocupload && this.controller.noTextarea) {
        this.transitionTo('generic-request-form.review');
        return;
      }
      this.transitionTo('generic-request-form.upload');
    },
    enableNext() {
      if (
        this.controller.get('model').requestDetails.filterBy('isSelected') !== undefined &&
        this.controller.get('model').requestDetails.filterBy('isSelected').length > 0
      ) {
        if (
          !isEmpty(
            this.controller
              .get('model')
              .requestDetails.filterBy('isSelected')
              .filterBy('alerts')
          )
        ) {
          const message = this.get('i18n').t('ServiceRequest.genericRequest.errorMsg.content.duplicateRequest');
          this.get('rdcModalManager').showDialogModal({
            level: 'info',
            message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
            iconClass: 'service-journey-system-error-icon'
          });
          this.controller
            .get('model')
            .requestDetails.filterBy('isSelected')
            .filterBy('alerts')[0].isSelected = false;
          return;
        }
        this.controller.set('disableNext', false);
      } else {
        this.controller.set('disableNext', true);
      }
    }
  }
});
