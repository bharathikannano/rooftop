import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { isEqual } from '@ember/utils';

export default Route.extend({
  store: service(),
  rdcLoadingIndicator: service(),
  i18n: service(),
  customerInfo: service(),
  afterModel() {
    this.controllerFor('generic-request-form').set('leftIcon', '');
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },
  setupController(controller) {
    controller.set('refNo', this.customerInfo.get('cardData').srrefNo);
    controller.set(
      'StatusMsg',
      this.get('i18n').t(`ServiceRequest.genericRequest.header.title.statusMsg${this.customerInfo.cardData.entity}`, {
        default: 'ServiceRequest.genericRequest.header.title.statusMsg'
      })
    );
    controller.set('isReferral', false);
    if (this.customerInfo.get('cardData').isReferral) {
      controller.set('isReferral', true);
      controller.set(
        'StatusMsg',
        this.get('i18n').t(
          `ServiceRequest.genericRequest.header.title.statusMsgReferral${this.customerInfo.cardData.type}`,
          { default: 'ServiceRequest.genericRequest.header.title.statusMsgReferral' }
        )
      );
      return;
    }
    if (this.customerInfo.cardData.type === 'PLCLOSUR') {
      controller.set(
        'StatusMsg',
        this.get('i18n').t(`ServiceRequest.genericRequest.header.title.statusMsg${this.customerInfo.cardData.type}`, {
          default: 'ServiceRequest.genericRequest.header.title.statusMsg'
        })
      );
    }
    controller.set('dispName', this.customerInfo.get('cardData').getDesc);
    controller.set('dispNum', this.customerInfo.get('cardData').getNum);
    if (this.customerInfo.get('cardData').entity) {
      if (
        this.customerInfo.get('cardData').entity === 'CCARD' ||
        this.customerInfo.get('cardData').entity === 'DCARD'
      ) {
        controller.set('maskConfig', this.customerInfo.cardMaskConfig());
      } else {
        controller.set('maskConfig', this.customerInfo.loanMaskConfig());
      }
    }
    controller.set('cardMasking', this.customerInfo.cardMasking());
    controller.set('getDatatype', this.controllerFor('generic-request-form.review').getDatatype);
  },
  actions: {
    navigateSatus() {
      const cslRequest = this.customerInfo.get('cardData').cslRequestEntity;
      if (!this.controller.get('isReferral')) {
        this.get('store').unloadAll(cslRequest);
      }
      isEqual(cslRequest, 'customer')
        ? this.transitionTo('serviceRequest.new-request')
        : this.transitionTo('serviceRequest.status');
    }
  }
});
