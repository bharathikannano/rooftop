import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../../constants';
import { A } from '@ember/array';
import { isEmpty, isEqual } from '@ember/utils';
export default Route.extend({
  rdcFileUpload: service(),
  customerInfo: service(),
  router: service(),
  i18n: service(),
  refNo: A(),
  filename: A(),
  value: A(),
  deletedVal: A(),
  store: service(),
  setupController(controller) {
    let reqType = this.customerInfo.get('cardData').type;
    let textArea = config.genericRequestForm.texArea[this.get('customerInfo.countryName')];
    let docUpload = config.genericRequestForm.docUpload[this.get('customerInfo.countryName')];
    controller.set(
      'txtboxLabel',
      this.get('i18n').t(`ServiceRequest.genericRequest.header.title.${this.customerInfo.cardData.entity}Lbl`, {
        default: 'ServiceRequest.genericRequest.header.title.label4'
      }).string
    );
    controller.set('uploadLabel', this.get('i18n').t('ServiceRequest.genericRequest.header.title.label6').string);
    controller.set(
      'txtPlaceholder',
      this.get('i18n').t(`ServiceRequest.genericRequest.header.title.${this.customerInfo.cardData.entity}PlcHld`, {
        default: 'ServiceRequest.genericRequest.header.title.label7'
      }).string
    );
    controller.set('stepVal', (isEqual(this.customerInfo.cardData.entity,'CUSTOMER') || isEqual(this.customerInfo.cardData.skipPage,'1')) ? this.get('i18n').t('ServiceRequest.COMMON.progress.step12') : this.get('i18n').t('ServiceRequest.COMMON.progress.step23'));
    controller.set('documentType', config.genericRequestForm.docSubmission[reqType]);
    if (!isEmpty(textArea)) {
      controller.set('textArea', textArea.indexOf(reqType) !== -1);
    }
    if (!isEmpty(docUpload)) {
      controller.set('docUpload', docUpload.indexOf(reqType) !== -1);
    }

    if ((this.get('router.currentRouteName').indexOf('select') !== -1 &&
    this.controllerFor('generic-request-form.select').get('refreshData')) || this.get('router.currentRouteName').indexOf('index') !== -1 || this.get('router.currentRouteName').includes('new-request')) {
      this.refNo.clear();
      this.filename.clear();
      controller.set('disableNext', true);
      controller.set('previews', null);
      controller.set('comments', '');
      controller.set('value', A());
    }
  },
  __enableNext() {
    const fieldExp = new RegExp('[^a-zA-Z0-9.,#\\n ]', 'g');
    this.controller.set('comments', this.controller.get('comments').replace(fieldExp, ''));
    let val1 = this.controller.get('comments');
    if (this.controller.textArea && this.controller.docUpload) {
      !isEmpty(val1.trim()) && this.refNo.length > 0
        ? this.controller.set('disableNext', false)
        : this.controller.set('disableNext', true);
    } else if (this.controller.textArea) {
      !isEmpty(val1.trim()) ? this.controller.set('disableNext', false) : this.controller.set('disableNext', true);
    } else {
      this.refNo.length > 0 ? this.controller.set('disableNext', false) : this.controller.set('disableNext', true);
    }
  },
  __enableBack() {
    if (this.controller.docUpload) {
      this.refNo.length > 0 ? this.controller.set('disableBack', false) : this.controller.set('disableBack', true);
    } else {
      this.refNo.length > 0 ? this.controller.set('disableBack', false) : this.controller.set('disableBack', true);
    }
  },
  __removeVulchar() {
    this.customerInfo.validateKey();
    this.__enableNext();
  },
  __disableNext() {
    this.controller.set('disableNext', true);
  },
  __disableBack() {
    this.controller.set('disableBack', true);
  },
  actions: {
    goToBack() {
      if (isEqual(this.customerInfo.cardData.entity, 'CUSTOMER') || isEqual(this.customerInfo.cardData.skipPage,'1')) {
        this.get('store').unloadAll('customer');
        this.transitionTo('serviceRequest.new-request');
      } else {
        this.transitionTo('generic-request-form.select');
      }
    },
    navigateConfirm() {
      let comments = this.controller.get('comments');
      this.customerInfo.cardData['comments'] = comments ? comments.trim() : null;
      this.transitionTo('generic-request-form.review');
    },
    onFileupload(value) {
      this.value.pushObject(value);
      if (!value.hasError) {
        this.refNo.pushObject(value.refNo);
        this.filename.pushObject(value.filename);
        this.customerInfo.cardData['refNo'] = this.refNo;
        this.customerInfo.cardData['filename'] = this.filename;
        this.__enableNext();
        this.__enableBack();
      }
    },
    onFiledelete(value) {
      this.value.clear();
      if (value.length > 0) {
        this.value.pushObject(value);
        this.deletedVal = this.refNo;
        this.deletedVal.forEach((item, index) => {
          if (isEmpty(value.findBy('refNo', item))) {
            this.refNo.splice(index, 1);
            this.filename.splice(index, 1);
          }
        });
      } else {
        this.refNo.clear();
        this.filename.clear();
      }
      this.__enableNext();
      this.__enableBack();
    },
    validateTextarea() {
      this.__enableNext();
    },
    validateChar() {
      this.__removeVulchar();
    },
    onChangeFile() {
      this.__disableNext();
      this.__disableBack();
    },
    deletingProgress() {
      this.__disableNext();
      this.__disableBack();
    }
  }
});
