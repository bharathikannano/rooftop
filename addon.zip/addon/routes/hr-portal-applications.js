import { inject as service } from '@ember/service';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';

export default FereFormRoute.extend({
  axwayConfig: service(),

  queryParams: computed('axwayConfig', {
    get() {
      return { 
        filter: { 
          stepName: 'HRVERIFY', 
          countryCode: this.get('axwayConfig.country'), 
          id: 'W400', 
          sourceRefNo: this.controllerFor('hr-portal-dashboard').get('applicant.id'), 
          hrEmployeeId: this.controllerFor('hr-portal-dashboard').get('employeeId'),
          companyCode: this.controllerFor('hr-portal-dashboard').get('companyCode')
        } 
      };
    }
  }),

  setupController(controller){
    this._super(...arguments);
    controller.set('companyCode',this.controllerFor('hr-portal-dashboard').get('companyCode'));
    controller.set('hrEmployeeId',this.controllerFor('hr-portal-dashboard').get('employeeId'));
  },

  actions: {
    headerNavigation(selectedRoute){
      this.transitionTo(selectedRoute);
    },
    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      }
    },

    goToDashboard(){
      this.transitionTo('hr-portal-dashboard');
    },

    agentAction(action) {
      if(action === "back"){
        this.send('goToPreviousPage');
      } else if(action === "refer") {
        let field = this.get('store').peekRecord('field','statusFlag');
        if(!isEmpty(field)){
          field.set('value','R');
          this.goToNextPage();
        }
      } else if(action === "confirm") {
        let field = this.get('store').peekRecord('field','statusFlag');
        if(!isEmpty(field)){
          field.set('value','C');
          this.submitForm();
        }
      } else {
        let field = this.get('store').peekRecord('field','statusFlag');
        if(!isEmpty(field)){
          field.set('value','PROCESSING');
          this.submitForm();
        }
      }
    },
  }
});
