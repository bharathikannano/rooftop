import Route from '@ember/routing/route';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';

export default Route.extend({
  store: service(),
  rdcLoadingIndicator: service(),
  axwayConfig: service(),
  queryParams: {
    status: {
      refreshModel: true
    }
  },
  beforeModel(params) {
    this._super(...arguments);
    this.setProperties({
      companyCode: params.queryParams.CC,
      hrEmployeeId: params.queryParams.EID,
      status: 'PROCESSING',
      operationName: 'HRPORTAL',
      country: this.get('axwayConfig.country')
    });
  },
  model() {
    const promisePending = this.get('store').query('service-request', {
      filter: {
        status: this.status,
        companyCode: this.companyCode,
        hrEmployeeId: this.hrEmployeeId,
        operationName: this.operationName,
        country: this.get('axwayConfig.country')
      },
      page: {
        limit: 10,
        offset: 0
      }
    });

    return hash({
      processingGroup: promisePending
    });
  },

  afterModel(loanApplicants) {
    if(this.status === "PROCESSING"){
      loanApplicants.processingGroup.set('totalRecords', loanApplicants.processingGroup.length)
    }
    loanApplicants.processingGroup.set('companyCode',this.companyCode);
    loanApplicants.processingGroup.forEach(applicant => {
      loanApplicants.processingGroup.set('hrName',applicant.hrEmpId);
      let applicationSubmitted = applicant.additionalInfo.requestSubmitted;
      let difference_in_time = new Date().getTime() - new Date(applicationSubmitted).getTime();
      let noOfDays = difference_in_time / (1000 * 3600 * 24);
      applicant.additionalInfo.applicationSubmitted = Math.round(noOfDays);
    });
  },

  refreshModel() {
    let filterParams = this.status === 'PROCESSING' ? {
      status: this.status,
      companyCode: this.companyCode,
      hrEmployeeId: this.hrEmployeeId,
      operationName: this.operationName,
      country: this.get('axwayConfig.country')
    } : {
      status: this.status,
      companyCode: this.companyCode,
      operationName: this.operationName,
      country: this.get('axwayConfig.country')
    }
    this.get('rdcLoadingIndicator')
      .showLoadingIndicatorForPromise(
        this.get('store').query('service-request', {
          filter: filterParams,
          page: {
            limit: this.get('limit') || 10,
            offset: this.get('offset') || 0
          }
        })
      )
      .then(
        completedData => {
          this.get('currentModel').processingGroup.set('content', completedData.content);
          this.afterModel(this.get('currentModel'));
        },
        error => {
          this.send('error', error);
        }
      );
  },

  setupController(){
    this._super(...arguments);
  },

  actions: {
    headerNavigation(selectedRoute, applicant) {
      this.controllerFor('hr-portal-dashboard').set('applicant',applicant);
      this.controllerFor('hr-portal-dashboard').set('employeeId',this.hrEmployeeId);
      this.controllerFor('hr-portal-dashboard').set('companyCode',this.companyCode);
      this.transitionTo(selectedRoute);
    },

    paginationChange: function(value) {
      let offsetVal = value * 10 - 10;
      this.set('offset', offsetVal);
      this.set('limit', 10);
      this.refreshModel();
    },

    changeTab(selectedTab) {
      this.set('operationName', 'HRPORTAL');
      this.set('status', selectedTab);
      if (selectedTab === 'Approved' || selectedTab === 'Declined') {
        this.set('operationName', 'HRVERIFY');
      }
      this.refreshModel();
    }
  }
});
