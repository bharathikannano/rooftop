import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import fereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';

export default fereFormRoute.extend({
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),

  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'MK_F1', countryCode: this.get('axwayConfig.country'), id: 'W406' } };
    }
  }),

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
  },

  closeThisForm() {
    this.transitionTo('serviceRequest.new-request');
  },

  getReceiptPage() {
    let pages = this.get('store')
      .peekRecord('form', 'W406')
      .get('pages');
    let receiptPages = pages.filter(page => {
      return page.get('isReceiptPage') === true;
    });

    if (!isEmpty(receiptPages)) {
      return receiptPages[0].id;
    }
  },

  setJointAccountStatus(value) {
    let status = this.get('store').peekRecord('field', 'JointAccountStatus');
    if (status) {
      status.set('value', value);
    }
  },

  setReceiptPageMessage(fieldId, pageId) {
    let field = this.get('store').peekRecord('field', fieldId);
    if (field) {
      let message = field.get('label');
      let page = this.get('store').peekRecord('page', pageId);

      page.set('pageInformation', message);
    }
  },

  actions: {
    acceptForm() {
      this.setJointAccountStatus('accept');
      this.setReceiptPageMessage('JointAcceptMessage', 'W406-Pg10');
      this.goToNextPage();
    },

    declineForm() {
      let message = this.get('i18n').t('ServiceRequest.JOINTACCOUNT.modal.message.decline');
      let acceptButtonLabel = this.get('i18n').t('FERE.action.button.confirm');
      let rejectButtonLabel = this.get('i18n').t('FERE.action.button.cancel');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'error',
          message: message,
          acceptButtonLabel: acceptButtonLabel,
          rejectButtonLabel: rejectButtonLabel
        })
        .then(() => {
          this.setJointAccountStatus('decline');

          this.submitForm().finally(() => {
            let receiptPageId = this.getReceiptPage();
            this.setReceiptPageMessage('JointDeclineMessage', 'W406-Pg10');
            this.goToPage(receiptPageId);
          });
        });
    },

    approveForm() {
      let message = this.get('i18n').t('ServiceRequest.JOINTACCOUNT.modal.message.approve');
      let acceptButtonLabel = this.get('i18n').t('FERE.action.button.confirm');
      let rejectButtonLabel = this.get('i18n').t('FERE.action.button.cancel');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'Info',
          message: message,
          acceptButtonLabel: acceptButtonLabel,
          rejectButtonLabel: rejectButtonLabel
        })
        .then(() => {
          this.setJointAccountStatus('approve');
          this.setReceiptPageMessage('JointApproveMessage', 'W406-Pg10');
          this.goToNextPage();
        });
    },

    rejectForm() {
      let message = this.get('i18n').t('ServiceRequest.JOINTACCOUNT.modal.message.reject');
      let acceptButtonLabel = this.get('i18n').t('FERE.action.button.confirm');
      let rejectButtonLabel = this.get('i18n').t('FERE.action.button.cancel');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'error',
          message: message,
          acceptButtonLabel: acceptButtonLabel,
          rejectButtonLabel: rejectButtonLabel
        })
        .then(() => {
          this.setJointAccountStatus('reject');

          this.submitForm().finally(() => {
            let receiptPageId = this.getReceiptPage();
            this.setReceiptPageMessage('JointRejectMessage', 'W406-Pg10');
            this.goToPage(receiptPageId);
          });
        });
    },

    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        this.transitionTo('serviceRequest.new-request');
      }
    },

    closeForm() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
