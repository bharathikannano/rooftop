import { set } from '@ember/object';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';
import { htmlSafe } from '@ember/string';

export default Route.extend({
  classNames: ['rdc-cards col-lg-3'],
  postDataForm: service('cardblock-replacement-save'),
  store: service(),
  error: service('card-error-handler'),
  i18n: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  confirmBtnDisable: false,
  model: function() {
    return this.get('store')
      .peekAll('credit-card')
      .filterBy('isSelected');
  },
  afterModel: function(data) {
    data.set(
      'notesText',
      this.get('i18n').t('ServiceRequest.LOANCLOSURE.countryNotes.' + this.get('queries.countryName')).string
        ? this.get('i18n').t('ServiceRequest.LOANCLOSURE.countryNotes.' + this.get('queries.countryName'))
        : this.get('i18n').t('ServiceRequest.LOANCLOSURE.countryNotes.default')
    );
    if (!this.get('queries.customerFlowFlag')) {
      data.set('hideEditContact', true);
    }
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    if (
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'hk') ||
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'sg')
    ) {
      return controller.set('cardMasking', false);
    } else {
      return controller.set('cardMasking', true);
    }
  },
  actions: {
    noCardImage() {},
    editContact() {
      let message = this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.updateAddress.confirmation.message');
      let title = this.get('i18n').t('ServiceRequest.CREDITBALANCEREFUND.updateAddress.confirmation.title');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'info',
          message,
          title,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup card-cancellation-updatecontact'
        })
        .then(() => {
          document.location.href = config.dataLockerURL;
        });
    },
    gotoBack() {
      this.controllerFor('loan-closure.select').set('backNavigation', true);
      this.transitionTo('loan-closure.select').then(selectRoute => {
        set(selectRoute.currentModel, 'enableNext', true);
        set(selectRoute.currentModel, 'CreditCardDetails', this.currentModel.creditCardsList);
        set(selectRoute.currentModel, 'AccListt', this.currentModel.AccListt);
      });
    },
    // error: function(error) {
    //     this.get('rdcLoadingIndicator').hideLoadingIndicator();
    //     if (error.errors && error.errors[0].code == "1702") {
    //         document.location.href = config.backToiBankURL;
    //         return;
    //     }
    //     this.controllerFor('loan-closure').set('errorType', "systemError");
    //     let message = this.get('i18n').t('ServiceRequest.COMMON.systemError');
    //     let title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
    //     this.get('rdcModalManager').showDialogModal({
    //         level: "warning",
    //         title,
    //         message,
    //         acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
    //         iconClass: 'service-journey-system-error-icon',
    //         popupClass: 'service-journey-system-error-popup'
    //     }).then(() => {
    //         this.set('currentModel.systemErrorPopup', false);
    //         this.transitionTo('serviceRequest.new-request');
    //         // this.get('store').unloadAll('casa');
    //     });
    //     this.get('rdcLoadingIndicator').hideLoadingIndicator();
    // },
    navigateStatus(model) {
      set(this.currentModel, 'confirmBtnDisable', true);
      let selectedReason = model.selectedReason[0].value;
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      let ccRequest = [];
      model.selectedCards.forEach(function(item) {
        let pushData = {};
        pushData.cashOneLoan = item.get('card-num');
        ccRequest.push(pushData);
      });
      let data = {
        payload: {
          creditCardLoanClosure: {
            card: {
              cancellationReason: selectedReason
            },
            loan: []
          }
        }
      };
      data.operationName = 'CCLOANCL';
      data.payload.creditCardLoanClosure.loan = ccRequest;
      let postData = this.get('store').createRecord('credit-card', data);
      postData.save().then(
        data => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          let postResData = data;
          this.controller.set('postData', postResData);
          this.controller.set('selectedCards', this.currentModel.selectedCards);
          this.controller.set('selectedReason', model.selectedReason[0]);
          this.transitionTo('loan-closure.status');
        },
        () => {
          let message = htmlSafe(
              this.get('i18n').t('ServiceRequest.LOANCLOSURE.systemError.' + this.get('queries.countryName')).string
                ? this.get('i18n').t('ServiceRequest.LOANCLOSURE.systemError.' + this.get('queries.countryName')).string
                : this.get('i18n').t('ServiceRequest.COMMON.systemError').string
            ),
            title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              title,
              message,
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
              iconClass: 'service-journey-system-error-icon',
              popupClass: 'service-journey-system-error-popup'
            })
            .then(() => {
              this.controllerFor('card-cancellation.confirm').set('errorPopUp', false);
              this.get('store').unloadAll('credit-card');
              this.get('store').unloadAll('debit-card');
              this.transitionTo('serviceRequest.new-request');
            })
            .catch(() => {
              this.transitionTo('serviceRequest.new-request');
            });
        }
      );
    }
  }
});
