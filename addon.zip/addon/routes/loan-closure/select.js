import { typeOf } from '@ember/utils';
import EmberObject, { set } from '@ember/object';
import { hash } from 'rsvp';
import { A } from '@ember/array';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from './../../config/environment';
import { htmlSafe } from '@ember/string';

export default Route.extend({
  store: service(),
  queries: service('customer-info'),
  i18n: service(),
  error: service('card-error-handler'),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  mobileNumber: null,

  init() {
    this._super();
    this.set('reasonValues', {
      default: ['CCCRSN01', 'CCCRSN02', 'CCCRSN03', 'CCCRSN04', 'CCCRSN05', 'CCCRSN06', 'CCCRSN07'],
      SG: ['CCCRSN01', 'CCCRSN02', 'CCCRSN03', 'CCCRSN04', 'CCCRSN05', 'CCCRSN06', 'CCCRSN07']
    });
  },

  model() {
    this.set('cards', config.cards != 'credit' ? 'true' : '');
    this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    let accountList = A();
    let reasonCountryList = this.get('reasonValues')[this.get('queries.countryName')]
      ? this.get('reasonValues')[this.get('queries.countryName')]
      : this.get('reasonValues')['default'];
    reasonCountryList.forEach(reasonCode => {
      accountList.push({
        value: this.get('i18n').t(
          'ServiceRequest.LOANCLOSURE.selectreason.' + reasonCode + '.' + this.get('queries.countryName')
        ).string
          ? this.get('i18n').t(
              'ServiceRequest.LOANCLOSURE.selectreason.' + reasonCode + '.' + this.get('queries.countryName')
            ).string
          : this.get('i18n').t('ServiceRequest.LOANCLOSURE.selectreason.' + reasonCode + '.default').string,
        id: reasonCode
      });
    });
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
    let showAccounts = false;
    if (this.controller && this.controller.backNavigation) {
      showAccounts = true;
      this.controllerFor('loan-closure.select').set('backNavigation', false);
    } else {
      if (this.controller) this.controller.set('selectedReason', null);
    }
    return hash({
      AccListt: accountList,
      showAccounts: showAccounts,
      notesText: this.get('i18n').t('ServiceRequest.LOANCLOSURE.countryNotes.' + this.get('queries.countryName')).string
        ? this.get('i18n').t('ServiceRequest.LOANCLOSURE.countryNotes.' + this.get('queries.countryName'))
        : this.get('i18n').t('ServiceRequest.LOANCLOSURE.countryNotes.default')
    });
  },
  actions: {
    loading(transition) {
      transition.promise.finally(() => {
        this.controllerFor('serviceRequest').set('loaderInProgress', false);
      });
    },
    displayCardDetails(account) {
      this.set('currentModel.enableNext', false);
      if (typeOf(account) != 'undefined') {
        this.currentModel.AccListt.forEach(function(reasonVal) {
          if (reasonVal.id != account.id) {
            reasonVal.isSelected = false;
          }
        });
        this.controller.set('selectedReason', account);
        account.isSelected = true;
        let reasonSelected = this.controller.get('selectedReason.id');
        this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
        this.get('rdcLoadingIndicator').setThemeClass('ui10');
        this.get('store')
          .query('credit-card', {
            filter: {
              operationName: 'ccLoanClosure',
              reasonCode: reasonSelected
            }
          })
          .then(
            data => {
              let cardDetailsObj = A();

              data.forEach(CardDetails => {
                this.set('mobileNumber', CardDetails.get('mobileNumber'));
                if (CardDetails.get('alerts') && CardDetails.get('alerts').length) {
                  this.transitionTo('loan-closure.error-handler').then(errorRoute => {
                    errorRoute.currentModel.alertMessage = CardDetails.get('alerts');
                  });
                } else {
                  if (CardDetails.get('eligibleCreditCards') && CardDetails.get('eligibleCreditCards').length) {
                    CardDetails.get('eligibleCreditCards').forEach(function(element) {
                      element = EmberObject.create(element);
                      element.set('checked', false);
                      if (element['eligible-loan-account'] && element['eligible-loan-account'].totalNoOfInstallment) {
                        let numberOfYears = parseInt(element['eligible-loan-account']['totalNoOfInstallment']) / 12;
                        let remainingInstallments = element['eligible-loan-account']['remainingUnbilled'];
                        element.set('numberOfYears', numberOfYears);
                        element.set('remainingInstallments', remainingInstallments);
                      }
                      cardDetailsObj.push(element);
                    });
                  } else {
                    this.transitionTo('loan-closure.error-handler').then(errorRoute => {
                      errorRoute.currentModel.errorTitle = this.get('i18n').t(
                        'ServiceRequest.LOANCLOSURE.noCardsHeading'
                      ).string;
                      errorRoute.currentModel.errorSubject = this.get('i18n').t(
                        'ServiceRequest.LOANCLOSURE.noCardsMessage'
                      ).string;
                    });
                  }
                }
              });

              this.set('currentModel.CreditCardDetails', cardDetailsObj);
              this.set('currentModel.CreditCardDetails.selectAll', true);
              this.set('currentModel.showAccounts', true);
              this.get('rdcLoadingIndicator').hideLoadingIndicator();
            },
            error => {
              this.send('error', error);
            }
          );
      }
      this.controller.set('selectedReason', account);

      return account;
    },
    error: function(error) {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      if (error.errors && error.errors[0].code == '1702') {
        document.location.href = config.backToiBankURL;
        return;
      }
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.controllerFor('serviceRequest').set('cancelPopup', false);
      this.controllerFor('serviceRequest').set('systemErrorPopup', true);
      let message = htmlSafe(
        this.get('i18n').t('ServiceRequest.LOANCLOSURE.systemError.' + this.get('queries.countryName')).string
          ? this.get('i18n').t('ServiceRequest.LOANCLOSURE.systemError.' + this.get('queries.countryName')).string
          : this.get('i18n').t('ServiceRequest.COMMON.systemError').string
      );
      let title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
      this.controllerFor('loan-closure').set('errorType', 'systemError');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          title,
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.controllerFor('serviceRequest').set('systemErrorPopup', false);
          this.transitionTo('serviceRequest.new-request');
        });
    },
    enableNext() {
      if (this.get('currentModel').CreditCardDetails.filterBy('checked').length > 0) {
        this.set('currentModel.enableNext', true);
      } else {
        this.set('currentModel.enableNext', false);
      }
    },
    gotoBack() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
      this.controller.set('selectedReason', null);
      this.transitionTo('serviceRequest.new-request');
    },

    navigateConfirm() {
      let selectedReason = this.get('currentModel.AccListt').filterBy('isSelected');
      let selectedCards = this.get('currentModel').CreditCardDetails.filterBy('checked');
      let creditCardsList = this.get('currentModel').CreditCardDetails;
      let mobileNumber = this.get('mobileNumber');
      let accListt = this.get('currentModel').AccListt;
      this.transitionTo('loan-closure.confirm').then(confirmRoute => {
        selectedReason.forEach(reason => {
          let selectedReasonConfirmText = this.get('i18n').t(
            'ServiceRequest.LOANCLOSURE.confirmReason.' + reason.id + '.' + this.get('queries.countryName')
          ).string
            ? this.get('i18n').t(
                'ServiceRequest.LOANCLOSURE.confirmReason.' + reason.id + '.' + this.get('queries.countryName')
              ).string
            : this.get('i18n').t('ServiceRequest.LOANCLOSURE.confirmReason.' + reason.id + '.default').string;
          set(reason, 'value', selectedReasonConfirmText);
        });
        confirmRoute.currentModel.set('selectedReason', selectedReason);
        confirmRoute.currentModel.set('selectedCards', selectedCards);
        confirmRoute.currentModel.set('creditCardsList', creditCardsList);
        confirmRoute.currentModel.set('AccListt', accListt);
        confirmRoute.currentModel.set('mobileNumber', mobileNumber);
      });
    }
  }
});
