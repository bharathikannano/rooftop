import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';

export default Route.extend({
  i18n: service(),
  store: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),

  model: function() {
    this.set('resSuccessCount', 0);
    this.set('resFailureCount', 0);
    return hash({
      selectedCards: this.controllerFor('loan-closure.confirm').get('selectedCards'),
      postData: this.controllerFor('loan-closure.confirm').get('postData'),
      selectedReason: this.controllerFor('loan-closure.confirm').get('selectedReason')
    });
  },
  afterModel(data) {
    this.controllerFor('loan-closure').set('leftIcon', '');
    this.set('resRefNo', data.postData.data.serviceRequest['receipt-id']);
    if (data.selectedCards != null) {
      /*Setting confirmation message text */
      data.selectedCards.forEach(item => {
        item.cardStatus = this.get('i18n').t('ServiceRequest.COMMON.progress.success');
        item.statuscolor = 'bgcolor-green';
      });
    }
  },

  setupController(controller, model) {
    this._super(controller, model);
    controller.set('responseVal', 'success');
    controller.set('resClass', 'success-block-lg');
    controller.set('resValTmp', this.get('i18n').t('ServiceRequest.COMMON.progress.' + controller.get('responseVal')));
    controller.set(
      'resContentTmp',
      this.get('i18n').t('ServiceRequest.LOANCLOSURE.statusMsg.' + controller.get('responseVal'), {
        refNo: controller.get('resRefNo')
      })
    );
    controller.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    if (
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'hk') ||
      (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'sg')
    ) {
      return controller.set('cardMasking', false);
    } else {
      return controller.set('cardMasking', true);
    }
  },

  actions: {
    gotoStatus() {
      this.transitionTo('serviceRequest.status');
    },
    navigateSatus() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
      this.transitionTo('serviceRequest.status.status-detail');
    }
  }
});
