import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import constants from '../constants';
import { isNone } from '@ember/utils';
import { alias } from '@ember/object/computed';
import CryptoJS from 'cryptojs';
import config from 'rdc-ui-eng-service-requests/config/environment';

export default Route.extend({
  rdcModalManager: service(),
  store: service(),
  i18n: service(),
  queries: service('customer-info'),
  COUNTRYCONFIG: constants.COUNTRYCONFIG,
  country: alias('queries.countryName'),
  init() {
    this._super(...arguments);
    this._parseHREF();
  },
  setupController(controller) {
    this._super(...arguments);
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    controller.set('rightIcon', this.get('queries.hideClose') === 'Y' ? '' : 'sc-icon uxlab-icon-sc-s-cross');
    controller.set('navTitleText', this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.journeyHeader'));
  },

  actions: {
    closePopupAction() {
      let message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          this.transitionTo('serviceRequest.new-request');
          this.controller.set('clickCancel', false);
        });
    }
  },
  _without_loadn_cards(data) {
    //loan card number start with 9, filter with out loan card
    return data.filter(item => item.get('cardNum').indexOf('9') != 0);
  },

  _encryptCardNum(data) {
    data.forEach(item => {
      item.set('cardNumEncrypted', CryptoJS.SHA256(item.get('cardNum')).toString());
    });
    return data;
  },
  _only_MC_and_Visa(data) {
    data.forEach(item => {
      let cardType = item.get('cardType');
      let allCardType = item.get('allCardType') ? item.get('allCardType').toUpperCase() : cardType.toUpperCase();
      if (!isNone(allCardType) && (allCardType.indexOf('VISA') !== -1 || allCardType.indexOf('MASTERCARD') !== -1)) {
        item.set('mcOrVisa', true);
      } else {
        item.set('mcOrVisa', false);
      }
    });
    return data;
  },
  _only_have_supplementary_card(data) {
    this.set('onlyHaveSupplementaryCard', data.length === data.filter(item => item.get('primaryFlag') !== 'Y').length);
    return data;
  },
  _setCreditCardStatus(data) {
    this.set('creditCardStatus', data && data.length == 0 ? 'emptyAndNoError' : 'CreditCardSuccess');
  },
  _setDebitCardStatus(data) {
    this.set('debitCardStatus', data && data.length == 0 ? 'emptyAndNoError' : 'DebitCardSuccess');
  },
  _filterValidCards(data) {
    return data.filter(item => item.get('cardNum'));
  },
  _queryCreditCards() {
    let type = 'CreditCard';
    let countryCode = this.get('queries.countryName');
    let CreditCardDetails = this.get('store')
      .query('credit-card', {
        filter: config.cardSettingsFilters.creditCard[countryCode]
      })
      .then(
        data => {
          data = this._encryptCardNum(data);
          data = this._only_MC_and_Visa(data);
          data = this._without_loadn_cards(data);
          data = this._only_have_supplementary_card(data);
          this._setCreditCardStatus(data);
          this.controllerFor('manage-card-usage.card-management').set('ccList', data);
          return data;
        },
        error => {
          this.errorHandler(error);
        }
      );
    return CreditCardDetails;
  },
  _queryDebitCards() {
    let type = 'DebitCard';
    let countryCode = this.get('queries.countryName');
    let DebitCardDetails = this.get('store')
      .query('debit-card', {
        filter: config.cardSettingsFilters.debitCard[countryCode]
      })
      .then(
        data => {
          data = this._encryptCardNum(data);
          data = this._filterValidCards(data);
          this._setDebitCardStatus(data);
          this.controllerFor('manage-card-usage.card-management').set('dcList', data);
          return data;
        },
        error => {
          this.errorHandler(error);
        }
      );
    return DebitCardDetails;
  },
  _parseHREF(srcURL = document.location.href) {
    if (srcURL) {
      srcURL = srcURL.split('?')[1];
      if (srcURL) {
        srcURL = srcURL.split('&');
        let countryCode, langId;
        srcURL.forEach(item => {
          if (item.indexOf('ctry') !== -1) {
            countryCode = item.split('=')[1];
          } else if (item.indexOf('lang') !== -1) {
            langId = item.split('=')[1];
          }
        });
        if (countryCode) {
          this.set('queries.countryName', countryCode.toUpperCase());
        }
        if (langId) {
          this.set('queries.langId', langId);
        }
      }
    }
  }
});
