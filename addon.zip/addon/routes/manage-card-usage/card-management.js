/* eslint-disable no-useless-escape */
import RSVP from 'rsvp';
import { inject as service } from '@ember/service';
import Route from '../manage-card-usage';
import { A } from '@ember/array';

export default Route.extend({
  store: service(),
  i18n: service(),
  customerInfo: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),

  init() {
    this._super();
    this.setProperties({
      params: {},
      settingOptions: this.get('COUNTRYCONFIG')
    });
  },
  _getCardAttr(obj, attr) {
    return obj.get(attr);
  },

  _call_error_up(msg = this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.ERROR')) {
    this.get('rdcModalManager').showDialogModal({
      level: 'error',
      message: msg,
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },
  beforeModel() {
    this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
    this.set('settingOptions', this.get('COUNTRYCONFIG'));
  },
  setupController(controller, model) {
    this._super(...arguments);
    controller.set(
      'model.toolTipMessage',
      model.cardSettings.tmpblock
        ? this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.DTMPTOOLTIP')
        : this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.ESTMPTOOLTIP')
    );
    controller.set('needSaveButton', null);
    controller.set('saveButtonStatus', null);
    let country = this.get('country');
    controller.set('country', country);
    controller.set('rightIcon', this.get('queries.hideClose') === 'Y' ? '' : 'sc-icon uxlab-icon-sc-s-cross');
    let cardType = model.defaultSettingObj.cardType;
    let card = model.cards.filter(card => card.get('cardNum') === model['cardNumber']);
    if (card.length) {
      model.selectedCardObject = card[0];
      if (cardType == 'CreditCard') {
        controller.set('showPrimary', true);
        model.cardType = this._getCardAttr(card[0], 'allCardType').replace(/mastercard/gi, 'MasterCard');
        model.defaultSettingObj['cardSchemes'] = model.cardType.split(',');
      } else {
        controller.set('showPrimary', false);
      }
    }
    this.get('rdcLoadingIndicator').hideLoadingIndicator(' ');
  },

  _getSettingObj(cardNumEncrypted, cardType) {
    return {
      id: cardNumEncrypted,
      isN: true,
      tmpblock: false,
      countries: A(),
      cardType: cardType
    };
  },

  model(params) {
    let cardSelected;
    let cardManageController = this.controllerFor('manage-card-usage.card-management');
    let countryCode = this.customerInfo['countryName'];
    if (params.cardNumEncrypted.indexOf('Card') > 0) {
      cardSelected = params;
    } else if (this.get('currentModel.cardDetailStr')['cardNumEncrypted'].indexOf('Card') > 0) {
      cardSelected = this.get('currentModel.cardDetailStr');
    } else {
      cardSelected = this.get('currentModel.cardSelected');
    }
    let store = this.get('store'),
      cardNumEncrypted = cardSelected.cardNumEncrypted.split('#')[0],
      defaultSettingObj,
      return404Obj,
      rsvpObj;
    let cardTypeStr = cardSelected.cardNumEncrypted.split('#')[1];
    let cardNumber = cardSelected.cardNumEncrypted.split('#')[2];
    let cardSettingFilter = {
      cardNumber: cardNumEncrypted
    };
    let cards = cardTypeStr == 'CreditCard' ? cardManageController.get('ccList') : cardManageController.get('dcList');
    store.unloadAll('card-setting');
    defaultSettingObj = this._getSettingObj(cardNumEncrypted, cardTypeStr);
    return404Obj = data => {
      if (data && data.errors && data.errors[0].status === 404) {
        let msg = this.get('i18n').t('ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-301');
        this._call_error_up(msg);
        this.transitionTo('manage-card-usage.index');
      } else if (data && data.errors && data.errors[0].code) {
        let msg = this.get('i18n').t('ServiceRequest.COMMON.genericError.' + countryCode);
        this._call_error_up(msg);
        this.transitionTo('manage-card-usage.index');
      } else {
        let msg =
          data && data.errors
            ? data.errors[0].detail
            : 'Your request is terminated and will be navigated back for card selection';
        this._call_error_up(msg);
        this.transitionTo('manage-card-usage.index');
      }
    };
    rsvpObj = {
      defaultSettingObj,
      tmpBlockTxt: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.ESTMPBLOCK'),
      cardNumber: cardNumber,
      cardType: cardTypeStr,
      cards,
      cardSelected: cardSelected,
      cardDetailStr: params,
      cardSettings: store
        .queryRecord('card-setting', { id: cardTypeStr, filter: cardSettingFilter })
        .then(data => {
          return data;
        })
        .catch(return404Obj)
    };
    return RSVP.hash(rsvpObj);
  },
  actions: {
    openTermsAndConditionsPopup() {
      let message = this.get('i18n').t('ServiceRequest.COMMON.termsAndConditions'),
        title = this.get('i18n').t('ServiceRequest.COMMON.termsAndConditions.title');
      this.get('rdcModalManager').showDialogModal({
        popupClass: 'terms-conditions-popup',
        level: 'warning',
        message,
        title,
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.close')
      });
    }
  }
});
