import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';

export default Route.extend({
  i18n: service(),
  cp: null,
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),

  _call_error_up() {
    this.get('rdcModalManager').showDialogModal({
      level: 'error',
      message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.ERROR'),
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },
  _goBack() {
    this.transitionTo(
      'manage-card-usage.card-management',
      this.controller.model.selectedCardObject.get('cardNumEncrypted')
    );
  },
  _rollbackSettings() {
    let cs = this.controller.model.cardSettings;
    let currentController = this.controller;
    currentController.setProperties({
      atmTog: cs.get('atmblock')
    });
  },

  setupController() {
    this._super(...arguments);
    let cParent = this.controllerFor('manage-card-usage.card-management');
    let cs = this.controller.model.cardSettings;
    let currentController = this.controller;
    currentController.setProperties({
      atmTog: cs.get('atmblock'),
      toolTipText: cs.get('atmblock')
        ? this.get('i18n').t('ServiceRequest.ESCARDCONTROL.atmTransactionPage.atmBlockDisableContent')
        : this.get('i18n').t('ServiceRequest.ESCARDCONTROL.atmTransactionPage.atmBlockEnableContent')
    });
    this.set('cp', cParent);
    cParent.setProperties({
      navTitleText: this.get('i18n').t('ServiceRequest.ESCARDCONTROL.cardLimitTitle.atmTransaction'),
      needSaveButton: false,
      saveButtonStatus: false
    });
  },

  model() {
    return this.modelFor('manage-card-usage.card-management');
  },

  _save() {
    let cp = this.get('cp');
    let modelParent = this.controller.model;
    let cardSettings = modelParent.cardSettings;
    cardSettings.setProperties({
      atmblock: this.controller.get('atmTog'),
      csId: cardSettings.csId,
      action: 'atmTransaction'
    });
    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(
      cardSettings.save().then(
        () => {
          cardSettings.set('isN', false);
          cp.set('saveButtonStatus', false);
          this.transitionTo('manage-card-usage.success-summary', {
            queryParams: {
              selectedCardObject: JSON.stringify(this.context.selectedCardObject)
            }
          });
        },
        () => {
          this.transitionTo('manage-card-usage.failure-summary');
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
        }
      )
    );
  },
  _call_pop_up(tmpON) {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: tmpON
          ? this.get('i18n').t('ServiceRequest.ESCARDCONTROL.atmTransactionPage.atmBlockEnableContent')
          : this.get('i18n').t('ServiceRequest.ESCARDCONTROL.atmTransactionPage.atmBlockDisableContent'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this._save();
      })
      .catch(() => {
        this._rollbackSettings();
      });
  },
  actions: {
    tog() {
      let tmpON = this.controller.get('atmTog');
      this._call_pop_up(tmpON);
    },

    goToBack() {
      this._goBack();
    }
  }
});
