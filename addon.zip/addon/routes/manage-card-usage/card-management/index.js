import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { later } from '@ember/runloop';
import { A } from '@ember/array';

export default Route.extend({
  rdcModalManager: service(),
  i18n: service(),
  rdcLoadingIndicator: service(),
  customerInfo: service(),
  blockCodeFilter: A(['W', 'H']),

  _rollbackSettings() {
    let parentMod = this.controller.model;
    let cs = parentMod.cardSettings;
    const TMP = 'tmpblock';
    if (cs.get('isN')) {
      let changedAttrs = cs.changedAttributes();
      if (Object.keys(changedAttrs).includes(TMP)) {
        cs.set(TMP, false);
      }
    } else {
      parentMod.cardSettings.rollbackAttributes();
    }
  },
  _setDefaultSchemes() {
    let mod = this.controller.model.cardSettings;
    mod.set(
      'cardSchemes',
      this.controller.model['selectedCardObject']
        .get('cardType')
        .replace(/mastercard/gi, 'MasterCard')
        .split(',')
    );
  },
  _setSuccessStatus(bl) {
    this.get('cp').setProperties({
      needPopMsg: bl,
      hasButton: 'noButton',
      showMsgTxt: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.settingsSaved'),
      msgIconClass: 'uxlab-icon-sc-s-secure-private'
    });
  },
  _showSuccessMsg() {
    this._setSuccessStatus(true);
    this._destroySuccessMsg();
  },
  _destroySuccessMsg() {
    later(() => {
      this._setSuccessStatus(false);
    }, 4000);
  },
  _save() {
    let mod = this.controller.model.cardSettings;
    mod.setProperties({
      cardType: this.currentModel.cardType.indexOf('Debit') != -1 ? 'DebitCard' : 'CreditCard',
      action: 'TemporaryBlock',
      csId: mod.csId
    });
    this.controller.set(
      'model.toolTipMessage',
      mod.tmpblock
        ? this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.DTMPTOOLTIP')
        : this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.ESTMPTOOLTIP')
    );
    if (mod.cardType == 'CreditCard') {
      this._setDefaultSchemes();
    }
    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(
      mod.save().then(
        () => {
          this.set('clickCancel', false);
          this._showSuccessMsg();
        },
        error => {
          let ref, ref1;
          if (
            error &&
            (typeof error !== 'undefined' && error !== null ? error.errors : void 0) &&
            +(typeof error !== 'undefined' && error !== null
              ? (ref = error.errors) != null
                ? (ref1 = ref[0]) != null
                  ? ref1.status
                  : void 0
                : void 0
              : void 0) === 404
          ) {
            mod.set('isN', true);
            mod.set('isError', false);
            mod.setProperties(this.controller.model.defaultSettingObj);
            this._showSuccessMsg();
          } else {
            this._call_error_up();
            this._rollbackSettings();
          }
        }
      )
    );
  },
  _call_error_up() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'error',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.ERROR'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this._rollbackSettings();
      });
  },
  _call_pop_up(tmpON) {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: tmpON
          ? this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.ESTMPTOOLTIP')
          : this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.DTMPTOOLTIP'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this._save();
      })
      .catch(() => {
        this._rollbackSettings();
      });
  },
  _setCPTitleAndButton(cParent, title) {
    cParent.setProperties({
      navTitleText: title,
      needApplyButton: null,
      saveButtonStatus: null,
      needSaveButton: null
    });
    return cParent;
  },
  setupController(controller) {
    this._super(...arguments);
    let blockCodeFilter = this.get('blockCodeFilter');
    let tempBlockFlag = true;
    let navTitleText = this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.journeyHeader');
    let cParent = this._setCPTitleAndButton(controller, navTitleText);
    tempBlockFlag = blockCodeFilter.includes(this.controller.get('model').selectedCardObject.blockCode) ? false : true;
    this.controller.set('tempBlockFlag', tempBlockFlag);
    this.set('cp', cParent);
    this._setSuccessStatus(false);
  },
  model() {
    return this.modelFor('manage-card-usage.card-management');
  },
  actions: {
    goToBack() {
      this.set('currentModel.cardDetailStr.cardNumEncrypted', '');
      this.transitionTo('manage-card-usage.index');
    },
    tog() {
      let parentMod = this.controller.model,
        tmpON = parentMod.cardSettings.get('tmpblock');
      this._call_pop_up(tmpON);
    },
    redirectToTransactionLimit: function(routeInfo) {
      if (typeof routeInfo != 'undefined' && routeInfo.length > 0) {
        this.transitionTo(routeInfo);
      }
    }
  }
});
