import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import Route from '@ember/routing/route';

export default Route.extend({
  i18n: service(),
  cp: null,
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  rangeStep: '1000',
  customerInfo: service(),
  _call_error_up() {
    this.get('rdcModalManager').showDialogModal({
      level: 'error',
      message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.ERROR'),
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },

  _call_pop_up() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.notSaveConfirm'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
        this._rollbackSettings();
        this._goBack();
      });
  },

  _getAttrsChanged() {
    let modelParent = this.controller.model;
    let currentController = this.controller;
    if (
      modelParent['cardSettings']['countryblock'] !== currentController['setOverseasTog'] ||
      modelParent['cardSettings']['dailylimit'] !== Number(currentController['selectedValue'])
    ) {
      return true;
    } else {
      return false;
    }
  },

  _goBack() {
    let cp = this.get('cp');
    cp.set('needSaveButton', false);
    this.get('rdcLoadingIndicator').hideLoadingIndicator(' ');
    this.transitionTo(
      'manage-card-usage.card-management',
      this.controller.model.selectedCardObject.get('cardNumEncrypted')
    );
  },

  _rollbackSettings() {
    let parentMod = this.controller.model;
    parentMod.cardSettings.rollbackAttributes();
  },

  _setDefaultSchemes() {
    let mod = this.controller.model.cardSettings;
    mod.set(
      'cardSchemes',
      this.controller.model.selectedCardObject
        .get('cardType')
        .replace(/mastercard/gi, 'MasterCard')
        .split(',')
    );
  },

  limitNullCheck(limitValue) {
    if (limitValue !== 0) {
      return limitValue.replace(/^0+/, '');
    } else {
      return limitValue;
    }
  },

  _formatAmount(value) {
    let formattedAmt = parseFloat(value)
      .toFixed(2)
      .replace(/(\d)(?=(\d{2})+\d\.)/g, '$1,');
    return formattedAmt;
  },

  setupController(controller, model) {
    this._super(...arguments);

    let modelValue = model.cardSettings;
    let currencyFormat = '';
    let cParent = this.controllerFor('manage-card-usage.card-management');
    if (this.customerInfo.countryName === 'IN') {
      currencyFormat = 'Rs.';
    }
    controller.setProperties({
      cardSettings: modelValue,
      minValue: 0,
      rangeStep: this.get('rangeStep'),
      selectedValue: modelValue['overseaslimit'],
      maxValue:
        modelValue['cardType'].toLowerCase().indexOf('credit') != -1
          ? model.selectedCardObject['creditLimit']
          : modelValue['cardlimit'],
      fromValue: this._formatAmount(modelValue['overseaslimit']),
      cardLimit:
        modelValue['cardType'].toLowerCase().indexOf('credit') != -1
          ? this._formatAmount(model.selectedCardObject['creditLimit'])
          : this._formatAmount(modelValue['cardlimit']),
      shouldDisable: !modelValue['countryblock'],
      setOverseasTog: modelValue['countryblock'],
      currencyCode: model.selectedCardObject['currencyCode'],
      currencyFormat: currencyFormat,
      showError: false,
      toolTipText: modelValue['countryblock']
        ? this.get('i18n').t('ServiceRequest.ESCARDCONTROL.overseasTransactionPage.overseasNotificationsDisableContent')
        : this.get('i18n').t('ServiceRequest.ESCARDCONTROL.overseasTransactionPage.overseasNotificationsEnableContent')
    });
    controller.set('cardLimitLength', controller.get('maxValue').toString().length);
    this.set('cp', cParent);
    cParent.setProperties({
      navTitleText: this.get('i18n').t('ServiceRequest.ESCARDCONTROL.cardLimitTitle.overseasTransaction'),
      needSaveButton: true,
      saveButtonStatus: false
    });
  },

  model() {
    return this.modelFor('manage-card-usage.card-management');
  },

  _save() {
    let cp = this.get('cp');
    let modelParent = this.controller.model;
    let cardSettings = modelParent.cardSettings;
    cardSettings.setProperties({
      countryblock: this.controller.get('setOverseasTog'),
      cardType: this.currentModel.cardType.indexOf('Debit') != -1 ? 'DebitCard' : 'CreditCard',
      overseaslimit: Number(this.controller.get('selectedValue')),
      csId: cardSettings.csId,
      action: 'overseasTransaction'
    });
    if (cardSettings.cardType === 'CreditCard') {
      this._setDefaultSchemes();
    }
    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(
      cardSettings.save().then(
        () => {
          cardSettings.set('isN', false);
          cp.set('saveButtonStatus', false);
          this.transitionTo('manage-card-usage.success-summary', {
            queryParams: {
              selectedCardObject: JSON.stringify(this.context.selectedCardObject)
            }
          });
        },
        () => {
          this.transitionTo('manage-card-usage.failure-summary');
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
        }
      )
    );
  },

  actions: {
    onSelectedRange(returnedValue) {
      let modelVal = this.controller.model;
      this.controller.set('fromValue', this._formatAmount(returnedValue));
      this.controller.set('showError', false);
      let cp = this.get('cp');
      if (
        Number(returnedValue) > Number(this.controller.get('maxValue')) ||
        modelVal.cardSettings.overseaslimit === Number(returnedValue)
      ) {
        cp.set('saveButtonStatus', false);
      } else {
        cp.set('saveButtonStatus', true);
      }
    },

    setOverseasLimit() {
      let cp = this.get('cp');
      if (this.controller.get('setOverseasTog')) {
        this.controller.setProperties({
          toolTipText: this.get('i18n').t(
            'ServiceRequest.ESCARDCONTROL.overseasTransactionPage.overseasNotificationsDisableContent'
          ),
          shouldDisable: false
        });
      } else {
        this.controller.setProperties({
          selectedValue: this.currentModel.cardSettings.overseaslimit,
          fromValue: this._formatAmount(this.currentModel.cardSettings.overseaslimit),
          shouldDisable: true,
          toolTipText: this.get('i18n').t(
            'ServiceRequest.ESCARDCONTROL.overseasTransactionPage.overseasNotificationsEnableContent'
          )
        });
      }
      if (
        this.currentModel.cardSettings.countryblock !== this.controller.get('setOverseasTog') ||
        this.controller.get('selectedValue') !== this.currentModel.cardSettings.overseaslimit
      ) {
        cp.set('saveButtonStatus', true);
      } else {
        cp.set('saveButtonStatus', false);
      }
    },

    saveSetting() {
      let cp = this.get('cp');
      let message = null;
      if (
        Number(this.controller.selectedValue % 1000 !== 0) ||
        Number(this.controller.selectedValue) > Number(this.controller.maxValue) ||
        isEmpty(this.controller.selectedValue)
      ) {
        this.controller.set('showError', true);
        this.controller.set(
          'errorMessage',
          this.get('i18n').t('ServiceRequest.ESCARDCONTROL.cardLimitTitle.multipleMsg')
        );
        cp.set('saveButtonStatus', false);
      } else {
        if (this.controller.get('selectedValue') !== this.controller.get('cardSettings').overseaslimit) {
          message =
            this.get('i18n').t('ServiceRequest.ESCARDCONTROL.overseasTransactionPage.requestedInfo') +
            this.controller.get('selectedValue');
        } else if (this.controller.get('setOverseasTog')) {
          message = this.get('i18n').t(
            'ServiceRequest.ESCARDCONTROL.overseasTransactionPage.overseasNotificationsEnableContent'
          );
        } else {
          message = this.get('i18n').t(
            'ServiceRequest.ESCARDCONTROL.overseasTransactionPage.overseasNotificationsDisableContent'
          );
        }
        this.controller.set('showError', false);
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message: message,
            rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          })
          .then(() => {
            this._save();
          });
      }
    },

    goToBack() {
      if (this._getAttrsChanged()) {
        this._call_pop_up();
      } else {
        this._goBack();
      }
    },

    limitCheck() {
      let cp = this.get('cp');
      if (isEmpty(this.controller.get('selectedValue')) || Number(this.controller.get('selectedValue') === 0)) {
        this.controller.set('selectedValue', 0);
      } else if (Number(this.controller.get('selectedValue')) > Number(this.controller.get('maxValue'))) {
        cp.set('saveButtonStatus', false);
        this.controller.set('showError', true);
        this.controller.set(
          'errorMessage',
          this.get('i18n').t('ServiceRequest.ESCARDCONTROL.cardLimitTitle.dailylimitErrMsg')
        );
      } else if (
        Number(this.controller.get('selectedValue')) < Number(this.controller.get('maxValue')) &&
        Number(this.controller.get('selectedValue')) !== Number(this.currentModel.cardSettings.overseaslimit)
      ) {
        cp.set('saveButtonStatus', true);
        this.controller.set('showError', false);
      } else {
        cp.set('saveButtonStatus', false);
        this.controller.set('showError', false);
      }

      this.controller.set('fromValue', this._formatAmount(this.controller.get('selectedValue')));
      this.controller.set('selectedValue', this.limitNullCheck(this.controller.get('selectedValue')));
    }
  }
});
