import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';

const LOADING = 'rdcLoadingIndicator';

export default Route.extend({
  i18n: service(),
  cp: null,
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  rangeStep: '1000',
  customerInfo: service(),

  _call_pop_up() {
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.notSaveConfirm'),
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        this.get(LOADING).showLoadingIndicator();
        this._rollbackSettings();
        this._goBack();
      });
  },

  _call_error_up() {
    this.get('rdcModalManager').showDialogModal({
      level: 'error',
      message: this.get('i18n').t('ServiceRequest.CREDITCARD.cardSetting.NOTICE.ERROR'),
      acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
      iconClass: 'service-journey-info-icon',
      popupClass: 'service-journey-info-popup'
    });
  },

  _goBack() {
    let cp = this.get('cp');
    cp.set('needSaveButton', false);
    this.get(LOADING).hideLoadingIndicator(' ');
    this.transitionTo(
      'manage-card-usage.card-management',
      this.controller.model.selectedCardObject.get('cardNumEncrypted')
    );
  },

  _getAttrsChanged() {
    let modelParent = this.controller.model;
    let currentController = this.controller;
    if (
      modelParent['cardSettings']['tokenizedblock'] !== currentController['setTokenizedTog'] ||
      modelParent['cardSettings']['dailylimit'] !== currentController['selectedDailyLimitValue'] ||
      modelParent['cardSettings']['overseaslimit'] !== currentController['selectedPerTxnLimitValue']
    ) {
      return true;
    } else {
      return false;
    }
  },
  _rollbackSettings() {
    let parentMod = this.controller.model;
    parentMod.cardSettings.rollbackAttributes();
  },

  _setDefaultSchemes() {
    let mod = this.controller.model.cardSettings;
    mod.set(
      'cardSchemes',
      this.controller.model.selectedCardObject
        .get('cardType')
        .replace(/mastercard/gi, 'MasterCard')
        .split(',')
    );
  },

  _formatAmount(value) {
    let formattedAmt = parseFloat(value)
      .toFixed(2)
      .replace(/(\d)(?=(\d{2})+\d\.)/g, '$1,');
    return formattedAmt;
  },
  _checkSaveStatus() {
    let cp = this.get('cp');
    let dailyValueFlag =
      Number(this.controller.get('selectedDailyLimitValue')) === this.controller.get('cardSettings')['dailylimit']
        ? true
        : false;
    let perTxnValueFlag =
      Number(this.controller.get('selectedPerTxnLimitValue')) ===
      this.controller.get('cardSettings')['transactionlimit']
        ? true
        : false;
    if (dailyValueFlag && perTxnValueFlag) {
      cp.set('saveButtonStatus', false);
    } else if (this.controller.get('showDailyLimitError') || this.controller.get('showPerTxnError')) {
      cp.set('saveButtonStatus', false);
    } else {
      cp.set('saveButtonStatus', true);
    }
  },
  _checkDailyLimit() {
    if (
      isEmpty(this.controller.get('selectedDailyLimitValue')) ||
      Number(this.controller.get('selectedDailyLimitValue') == 0)
    ) {
      this.controller.set('selectedDailyLimitValue', 0);
    } else if (Number(this.controller.get('selectedDailyLimitValue')) > Number(this.controller.get('maxValue'))) {
      this.controller.set('showDailyLimitError', true);
      this.controller.set(
        'errorDailyLimit',
        this.get('i18n').t('ServiceRequest.ESCARDCONTROL.cardLimitTitle.dailylimitErrMsg')
      );
    } else if (
      Number(this.controller.get('selectedDailyLimitValue')) < Number(this.controller.get('maxValue')) &&
      Number(this.controller.get('selectedDailyLimitValue')) !== this.controller.get('cardSettings')['dailylimit']
    ) {
      this.controller.set('showDailyLimitError', false);
    } else {
      this.controller.set('showDailyLimitError', false);
    }
    this.controller.set(
      'fromValueDailyLimitSlider',
      this._formatAmount(this.controller.get('selectedDailyLimitValue'))
    );
    this.controller.set('selectedDailyLimitValue', this.limitNullCheck(this.controller.get('selectedDailyLimitValue')));
  },
  _checkPerTxnLimit() {
    if (
      isEmpty(this.controller.get('selectedPerTxnLimitValue')) ||
      Number(this.controller.get('selectedPerTxnLimitValue') === 0)
    ) {
      this.controller.set('selectedPerTxnLimitValue', 0);
    } else if (Number(this.controller.get('selectedPerTxnLimitValue')) > Number(this.controller.get('maxValue'))) {
      this.controller.set('showPerTxnError', true);
      this.controller.set(
        'errorPerTxnMessage',
        this.get('i18n').t('ServiceRequest.ESCARDCONTROL.cardLimitTitle.dailylimitErrMsg')
      );
    } else if (
      Number(this.controller.get('selectedPerTxnLimitValue')) < Number(this.controller.get('maxValue')) &&
      Number(this.controller.get('selectedPerTxnLimitValue')) !==
        this.controller.get('cardSettings')['transactionlimit']
    ) {
      this.controller.set('showPerTxnError', false);
    } else {
      this.controller.set('showPerTxnError', false);
    }
    this.controller.set(
      'fromValuePerTxnLimitSlider',
      this._formatAmount(this.controller.get('selectedPerTxnLimitValue'))
    );
    this.controller.set(
      'selectedPerTxnLimitValue',
      this.limitNullCheck(this.controller.get('selectedPerTxnLimitValue'))
    );
  },
  setupController() {
    this._super(...arguments);
    let currencyFormat = '';
    let cParent = this.controllerFor('manage-card-usage.card-management');
    let modelValue = this.currentModel.cardSettings;
    let currentController = this.controller;
    if (this.customerInfo.countryName === 'IN') {
      currencyFormat = 'Rs.';
    }
    currentController.setProperties({
      cardSettings: modelValue,
      minValue: 0,
      rangeStep: this.get('rangeStep'),
      selectedDailyLimitValue: modelValue.get('dailylimit'),
      selectedPerTxnLimitValue: modelValue.get('transactionlimit'),
      fromValueDailyLimitSlider: this._formatAmount(modelValue.get('dailylimit')),
      fromValuePerTxnLimitSlider: this._formatAmount(modelValue.get('transactionlimit')),
      maxValue:
        modelValue['cardType'].toLowerCase().indexOf('credit') != -1
          ? this.currentModel.selectedCardObject['creditLimit']
          : modelValue['cardlimit'],
      cardLimit:
        modelValue['cardType'].toLowerCase().indexOf('credit') != -1
          ? this._formatAmount(this.currentModel.selectedCardObject['creditLimit'])
          : this._formatAmount(modelValue['cardlimit']),
      shouldDisable: !modelValue.get('tokenizedblock'),
      setTokenizedTog: modelValue.get('tokenizedblock'),
      currencyCode: this.currentModel.selectedCardObject['currencyCode'],
      currencyFormat: currencyFormat,
      showPerTxnError: false,
      toolTipText: modelValue['tokenizedblock']
        ? this.get('i18n').t(
            'ServiceRequest.ESCARDCONTROL.tokenizedTransactionPage.tokenizedNotificationsDisableContent'
          )
        : this.get('i18n').t(
            'ServiceRequest.ESCARDCONTROL.tokenizedTransactionPage.tokenizedNotificationsEnableContent'
          )
    });
    currentController.set('cardLimitLength', currentController.get('maxValue').toString().length);
    this.set('cp', cParent);
    cParent.setProperties({
      navTitleText: this.get('i18n').t('ServiceRequest.ESCARDCONTROL.cardLimitTitle.tokenizedTransaction'),
      needSaveButton: true,
      saveButtonStatus: false
    });
  },

  model() {
    return this.modelFor('manage-card-usage.card-management');
  },

  _save() {
    let cp = this.get('cp');
    let modelParent = this.controller.model;
    let cardSettings = modelParent.cardSettings;
    cardSettings.setProperties({
      tokenizedblock: this.controller.get('setTokenizedTog'),
      dailylimit: Number(this.controller.get('selectedDailyLimitValue')),
      transactionlimit: Number(this.controller.get('selectedPerTxnLimitValue')),
      csId: cardSettings.csId,
      action: 'tokenizedTransaction'
    });
    if (cardSettings.cardType === 'CreditCard') {
      this._setDefaultSchemes();
    }
    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(
      cardSettings.save().then(
        () => {
          cardSettings.set('isN', false);
          cp.set('saveButtonStatus', false);
          this.transitionTo('manage-card-usage.success-summary', {
            queryParams: {
              selectedCardObject: JSON.stringify(this.context.selectedCardObject)
            }
          });
        },
        () => {
          this.transitionTo('manage-card-usage.failure-summary');
          this.get(LOADING).hideLoadingIndicator(' ');
        }
      )
    );
  },

  limitNullCheck(limitValue) {
    if (limitValue !== 0) {
      return limitValue.replace(/^0+/, '');
    } else {
      return limitValue;
    }
  },

  actions: {
    onSelectedDailyRange(value) {
      let cp = this.get('cp');
      this.controller.set('showDailyLimitError', false);
      this.controller.set('selectedDailyLimitValue', value);
      this.controller.set('fromValueDailyLimitSlider', this._formatAmount(value));
      if (
        this.currentModel.cardSettings.tokenizedblock == this.controller.get('setTokenizedTog') &&
        Number(this.controller.get('selectedDailyLimitValue')) ==
          Number(this.get('currentModel').cardSettings.dailylimit) &&
        Number(this.controller.get('selectedPerTxnLimitValue')) ==
          Number(this.get('currentModel').cardSettings.transactionlimit)
      ) {
        cp.set('saveButtonStatus', false);
      } else {
        cp.set('saveButtonStatus', true);
      }
    },

    onSelectedPerTxnRange(value) {
      let cp = this.get('cp');
      this.controller.set('showPerTxnError', false);
      this.controller.set('selectedPerTxnLimitValue', value);
      this.controller.set('fromValuePerTxnLimitSlider', this._formatAmount(value));
      if (
        this.currentModel.cardSettings.tokenizedblock == this.controller.get('setTokenizedTog') &&
        Number(this.controller.get('selectedDailyLimitValue')) ==
          Number(this.get('currentModel').cardSettings.dailylimit) &&
        Number(this.controller.get('selectedPerTxnLimitValue')) ==
          Number(this.get('currentModel').cardSettings.transactionlimit)
      ) {
        cp.set('saveButtonStatus', false);
      } else {
        cp.set('saveButtonStatus', true);
      }
    },

    setTokenizedLimit() {
      let cp = this.get('cp');
      if (!this.controller.get('setTokenizedTog')) {
        if (this.currentModel.cardSettings.tokenizedblock == this.controller.get('setTokenizedTog')) {
          cp.set('saveButtonStatus', false);
        } else {
          cp.set('saveButtonStatus', true);
        }
        this.controller.setProperties({
          selectedDailyLimitValue: this.currentModel.cardSettings.dailylimit,
          fromValueDailyLimitSlider: this._formatAmount(this.currentModel.cardSettings.dailylimit),
          selectedPerTxnLimitValue: this.currentModel.cardSettings.transactionlimit,
          fromValuePerTxnLimitSlider: this._formatAmount(this.currentModel.cardSettings.transactionlimit),
          shouldDisable: true,
          toolTipText: this.get('i18n').t(
            'ServiceRequest.ESCARDCONTROL.tokenizedTransactionPage.tokenizedNotificationsEnableContent'
          )
        });
      } else {
        this.controller.setProperties({
          shouldDisable: false,
          toolTipText: this.get('i18n').t(
            'ServiceRequest.ESCARDCONTROL.tokenizedTransactionPage.tokenizedNotificationsDisableContent'
          )
        });

        if (
          this.currentModel.cardSettings.tokenizedblock == this.controller.get('setTokenizedTog') &&
          Number(this.currentModel.cardSettings.dailylimit) == Number(this.controller.get('selectedDailyLimitValue')) &&
          Number(this.currentModel.cardSettings.transactionlimit) ==
            Number(this.controller.get('selectedPerTxnLimitValue'))
        ) {
          cp.set('saveButtonStatus', false);
        } else {
          cp.set('saveButtonStatus', true);
        }
      }
    },

    saveSetting() {
      let cp = this.get('cp');
      let message = null;
      if (Number(this.controller.selectedDailyLimitValue % 1000 != 0)) {
        this.controller.set('showDailyLimitError', true);
        this.controller.set(
          'errorDailyLimit',
          this.get('i18n').t('ServiceRequest.ESCARDCONTROL.cardLimitTitle.multipleMsg')
        );
        cp.set('saveButtonStatus', false);
        return;
      }
      if (Number(this.controller.selectedPerTxnLimitValue % 1000 != 0)) {
        this.controller.set('showPerTxnError', true);
        this.controller.set(
          'errorPerTxnMessage',
          this.get('i18n').t('ServiceRequest.ESCARDCONTROL.cardLimitTitle.multipleMsg')
        );
        cp.set('saveButtonStatus', false);
        return;
      }

      if (
        Number(this.controller.get('selectedDailyLimitValue')) >=
        Number(this.controller.get('selectedPerTxnLimitValue'))
      ) {
        if (
          this.controller.get('selectedDailyLimitValue') !== this.controller.get('cardSettings').dailylimit ||
          this.controller.get('selectedPerTxnLimitValue') !== this.controller.get('cardSettings').transactionlimit
        ) {
          message =
            this.get('i18n').t('ServiceRequest.ESCARDCONTROL.tokenizedTransactionPage.requestedPerTxnInfo') +
            this.controller.get('selectedPerTxnLimitValue') +
            this.get('i18n').t('ServiceRequest.ESCARDCONTROL.tokenizedTransactionPage.requestedDailyInfo') +
            this.controller.get('selectedDailyLimitValue');
        } else if (this.controller.get('setTokenizedTog')) {
          message = this.get('i18n').t(
            'ServiceRequest.ESCARDCONTROL.tokenizedTransactionPage.tokenizedNotificationsEnableContent'
          );
        } else {
          message = this.get('i18n').t(
            'ServiceRequest.ESCARDCONTROL.tokenizedTransactionPage.tokenizedNotificationsDisableContent'
          );
        }
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message: message,
            rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.confirm'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          })
          .then(() => {
            this._save();
          });
      } else {
        this.controller.set('showPerTxnError', true);
        this.controller.set(
          'errorPerTxnMessage',
          this.get('i18n').t('ServiceRequest.ESCARDCONTROL.cardLimitTitle.greaterLimitMsg')
        );
        cp.set('saveButtonStatus', false);
      }
    },

    goToBack() {
      if (this._getAttrsChanged()) {
        this._call_pop_up();
      } else {
        this._goBack();
      }
    },
    limitCheck(valueId) {
      switch (valueId) {
        case 'dailyLimit':
          this._checkDailyLimit();
          this._checkSaveStatus();
          break;
        case 'transactionLimit':
          this._checkPerTxnLimit();
          this._checkSaveStatus();
          break;
        default:
      }
    }
  }
});
