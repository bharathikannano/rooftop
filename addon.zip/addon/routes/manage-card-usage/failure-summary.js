import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';

export default Route.extend({
  rdcLoadingIndicator: service(),

  actions: {
    goToManageCard() {
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.transitionTo('manage-card-usage.index');
    }
  }
});
