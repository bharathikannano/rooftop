import { hash } from 'rsvp';
import { isNone, isBlank } from '@ember/utils';
import { inject as service } from '@ember/service';
import Route from '../manage-card-usage';
import { typeOf } from '@ember/utils';

export default Route.extend({
  store: service(),
  i18n: service(),
  error: service('card-error-handler'),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  onlyHaveSupplementaryCard: true,
  init() {
    this._super();
    this.get('store').unloadAll('credit-card');
  },
  _setNoCardsHT() {
    this.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.nocard.header'));
    this.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.nocard.content'));
  },
  model() {
    this._setNoCardsHT();
    this.get('store').unloadAll('credit-card');
    this.get('store').unloadAll('debit-card');

    this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
    let CreditCardDetails = this._queryCreditCards();
    let DebitCardDetails = this._queryDebitCards();
    return hash({ CreditCardDetails, DebitCardDetails });
  },
  afterModel(data) {
    data.nocardsTitle = this.get('nocardsTitle');
    data.nocardsContent = this.get('nocardsContent');
  },
  setupController(controller, model) {
    this._super(controller, model);
    let creditcard;
    if (!isNone(model) && !isNone(model.CreditCardDetails)) {
      creditcard = model.CreditCardDetails;
    }
    if (!(isBlank(creditcard) || isNone(creditcard)) || this.get('creditCardStatus') == 'CreditCardSuccess') {
      if (!this.get('onlyHaveSupplementaryCard')) {
        controller.set('dataAvailable', true);
      }
    } else {
      controller.set('dataAvailable', false);
      controller.set('needApplyButton', true);
    }
    this.get('rdcLoadingIndicator').hideLoadingIndicator(' ');
  },
  errorHandler(error) {
    this.set('creditCardStatus', 'CreditCardError');
    typeOf(error.errors) == 'undefined'
      ? this.set('CreditCardErrorcheck', 'undefined')
      : this.set('CreditCardErrorcheck', error.errors[0].code);
  },
  actions: {
    goToBack() {
      this.get('store').unloadAll('credit-card');
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
