import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';

export default Route.extend({
  rdcLoadingIndicator: service(),
  queries: service('customer-info'),

  beforeModel(transition) {
    let currentController = this.controllerFor('manage-card-usage.success-summary');
    currentController.set('selectedCardObject', JSON.parse(transition.queryParams.selectedCardObject));
  },

  setupController(controller) {
    this._super(...arguments);
    let currentController = this.controllerFor('manage-card-usage.success-summary');
    currentController.setProperties({
      desc: controller['selectedCardObject']['desc'],
      cardImageURL:
        'https://av.sc.com/configuration/content/images/' + controller['selectedCardObject']['cardImageName'] + '.png',
      cardNum: controller['selectedCardObject']['cardNum'],
      isPrimary: controller['selectedCardObject']['primaryFlag'] == 'Y' ? 'PRIMARY' : 'SECONDARY',
      cardNoMaskConfig: this.get('queries').cardMaskConfig()
    });
  },

  actions: {
    goToManageCard() {
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.transitionTo('manage-card-usage.index');
    }
  }
});
