import FEREPageRoute from 'rdc-ui-adn-fere/routes/fere-route/fere-page';

export default FEREPageRoute.extend({});