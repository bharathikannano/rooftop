import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../config/environment';
import { isEqual } from '@ember/utils';
import EmberObject from '@ember/object';
import { hash } from 'rsvp';

export default Route.extend({
  rdcModalManager: service(),
  i18n: service(),
  store: service(),
  beforeModel() {
    this.get('store').unloadAll('credit-card');
    this.get('store').unloadAll('debit-card');
  },
  model(params, transition) {
    return hash({
      entity: transition.queryParams ? transition.queryParams.entity : null
    });
  },
  setupController(controller, model) {
    controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
    controller.set('reqTitle', this.get('i18n').t('ServiceRequest.posLimit.default'));
    if (isEqual(model.entity, 'ALL')) {
      let product = EmberObject.create({
        value: this.get('i18n').t('ServiceRequest.posLimit.pageLabels.all'),
        entity: model.entity
      });
      this.get('store').set('selectedObject', EmberObject.create({}));
      this.get('store').set('selectedObject.selectedProduct', product);
      this.transitionTo('pos-limit.all-products');
    } else {
      this.transitionTo('pos-limit.select');
    }
  },
  actions: {
    closePopupAction() {
      let message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankBefAckText');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          message,
          rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        })
        .then(() => {
          document.location.href = config.backToiBankURL;
        });
    }
  }
});
