import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { htmlSafe } from '@ember/string';
import { A } from '@ember/array';
import { assign } from '@ember/polyfills';
import { isEmpty, isEqual } from '@ember/utils';
import { hash } from 'rsvp';
import config from '../../constants';
import EmberObject from '@ember/object';
import { Promise as EmberPromise } from 'rsvp';
export default Route.extend({
  queries: service('customer-info'),
  i18n: service(),
  store: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  cardErrorHandler: service(),
  model() {
    const posLimitData = this.get('store').get('selectedObject');
    const selectedProduct = htmlSafe(posLimitData.selectedProduct.value);
    const selectedEntity = posLimitData.selectedProduct.entity;
    let requestDetails = [];
    let comboData;
    this.get('rdcLoadingIndicator').showLoadingIndicator('');
    config.posLimit.filters[selectedEntity][this.get('queries.countryName')].forEach((cslRequestfilters, index) => {
      requestDetails[index] = this.get('store')
        .query(config.posLimit.filters.entity[selectedEntity][index], { filter: cslRequestfilters })
        .then(
          data => {
            if (isEqual(config.posLimit.filters.entity[selectedEntity][index], 'credit-card')) {
              comboData = data.filter(card => {
                return isEqual(card.comboFlag, 'Y');
              });
            } else {
              comboData = data;
            }
            return comboData;
          },
          () => {}
        );
    });
    let promises = [requestDetails[0], requestDetails[1]];
    EmberPromise.all(promises).then(
      data => {
        if (data.every(this.isUndefined)) {
          this.get('cardErrorHandler').systemErrorPopup(this);
        }
        this.get('rdcLoadingIndicator').hideLoadingIndicator();
      },
      () => {
        this.get('cardErrorHandler').systemErrorPopup(this);
        this.get('rdcLoadingIndicator').hideLoadingIndicator();
      }
    );
    return hash({
      posLimitData: posLimitData,
      selectedProduct: selectedProduct,
      selectedEntity: selectedEntity,
      requestDetails: requestDetails[0],
      requestDetails1: requestDetails[1]
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    let concatModel = A();
    let conRequestDetails = A();
    concatModel.pushObject([model.requestDetails].concat([model.requestDetails1]));
    if (concatModel && concatModel.length > 0) {
      concatModel.forEach(modelData => {
        if (modelData && modelData.length > 0) {
          modelData.forEach(specificData => {
            if (specificData && specificData.length > 0) {
              specificData.forEach(item => {
                conRequestDetails.pushObject(item);
              });
            }
          });
        }
      });
    }
    controller.set('requestDetails', conRequestDetails);
    if (isEqual(controller.get('requestDetails'), undefined) || controller.get('requestDetails').length <= 0) {
      controller.set('noEligibleCardData', true);
    } else {
      controller.setProperties({
        noEligibleCardData: false,
        posLimitData: model.posLimitData.posLimit ? model.posLimitData.posLimit : null,
        atmLimitData: model.posLimitData.atmLimit ? model.posLimitData.atmLimit : null
      });
      if (controller.get('requestDetails') && controller.get('requestDetails').length > 0) {
        controller.get('requestDetails').forEach(element => {
          element.set('posLimitFlag', true);
          if (!element.get('currencyCode')) {
            let accounts = element.get('linkedAccounts').find(item => item.accCcy);
            element.set('currencyCode', accounts.accCcy);
          }
          if (element.get('alerts') && element.get('alerts').length >= 1) {
            element.set('disableCard', true);
            element.set('errorMsg', element.get('alerts')[0].message);
          } else {
            element.set('disableCard', false);
          }
        });
      }
    }
    this._enableDisableNext();
  },
  _enableDisableNext() {
    if (
      this.controller.get('requestDetails').filterBy('isSelected') !== undefined &&
      this.controller.get('requestDetails').filterBy('isSelected').length > 0
    ) {
      this.controller.set('disableNext', true);
    } else {
      this.controller.set('disableNext', false);
    }
  },
  isUndefined(element) {
    return isEqual(typeof element, 'undefined');
  },
  actions: {
    goToBack() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
      if (isEqual(this.controller.model.selectedEntity, 'ALL')) {
        this.transitionTo('serviceRequest.new-request');
      } else {
        this.transitionTo('pos-limit.select');
      }
    },
    closeJourney() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
      this.transitionTo('serviceRequest.new-request');
    },
    showModalPopup() {
      if (
        this.controller.get('requestDetails').filterBy('isSelected') !== undefined &&
        this.controller.get('requestDetails').filterBy('isSelected').length > 0
      ) {
        let cardDetails = EmberObject.create({});
        const modalVal = this.controller.get('requestDetails').filterBy('isSelected');
        if (!isEmpty(modalVal)) {
          modalVal.forEach(item => {
            let selectedValue = ((
              cardNum,
              cardImageName,
              desc,
              currencyCode,
              expDt,
              cardStatus,
              custShortName,
              cardEmboserName,
              linkedAccounts,
              relId
            ) => ({
              cardNum,
              cardImageName,
              desc,
              currencyCode,
              expDt,
              cardStatus,
              custShortName,
              cardEmboserName,
              linkedAccounts,
              relId
            }))(
              item.get('cardNum'),
              item.get('cardImageName'),
              item.get('desc'),
              item.get('currencyCode'),
              item.get('expDt'),
              item.get('cardStatus'),
              item.get('custShortName'),
              item.get('cardEmboserName'),
              item.get('linkedAccounts'),
              item.get('relId')
            );
            if (selectedValue.currencyCode) {
              this.controller.set('currencyCode', selectedValue.currencyCode);
            } else {
              let accounts = selectedValue.linkedAccounts.find(item => item.accCcy);
              this.controller.set('currencyCode', accounts.accCcy);
            }
            assign(cardDetails, selectedValue);
          });
        }
        this.get('store').set('selectedObject.selectedCard', cardDetails);
        const currencyCode = this.controller.get('currencyCode');
        let posLimit = A();
        const atmLimit = '4000';
        config.posLimit.filters['posLimits'][this.get('queries.countryName')].forEach(limit => {
          posLimit.pushObject({
            name: 'pos-limit',
            value: currencyCode + ' ' + limit,
            label: currencyCode + ' ' + limit.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
          });
        });

        this.get('rdcModalManager')
          .showCustomModal('limit-pop-up', {
            title: this.get('i18n').t('ServiceRequest.posLimit.pageLabels.dailyPOSLimit'),
            showCrossIcon: true,
            data: {
              radioGroup: posLimit,
              selectedCardObject: this.get('store').get('selectedObject').selectedCard,
              cardMasking: this.get('queries').cardMasking(),
              limitNotes: this.get('i18n').t('ServiceRequest.posLimit.pageLabels.limitNotes')
            }
          })
          .then(data => {
            this.controller.set('posLimitData', data.split(' ')[1]);
            this.controller.set('atmLimitData', atmLimit);
            this.get('store').set('selectedObject.posLimit', this.controller.get('posLimitData'));
            this.get('store').set('selectedObject.atmLimit', this.controller.get('atmLimitData'));
            this.transitionTo('pos-limit.confirm');
          })
          .catch(() => {});
      } else {
        this.controller.set('disableNext', false);
      }
    },
    navigateConfirm() {
      this.transitionTo('pos-limit.confirm');
    }
  }
});
