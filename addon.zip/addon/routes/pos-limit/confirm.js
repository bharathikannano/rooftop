import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { hash } from 'rsvp';
import moment from 'moment';
import { isEqual, isEmpty } from '@ember/utils';

export default Route.extend({
  i18n: service(),
  store: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  model() {
    const posLimitData = this.get('store').get('selectedObject');
    const selectedCard = posLimitData.selectedCard;
    const selectedProduct = posLimitData.selectedProduct;
    return hash({
      reviewDetails: posLimitData,
      selectedEntity: selectedProduct.entity,
      selectedCardObject: selectedCard,
      currencyCode: selectedCard.currencyCode
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.set('selectedProduct', model.reviewDetails.selectedProduct.value.string);
    controller.set('cardMasking', this.get('queries').cardMasking());
    controller.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
  },
  actions: {
    error(error) {
      if (error.name !== 'OTPCancelledError') {
        this.get('cardErrorHandler').systemErrorPopup(this);
      }
    },
    goToBack() {
      if (isEqual(this.controller.get('model').selectedEntity, 'ALL')) {
        this.transitionTo('pos-limit.all-products');
      } else {
        this.transitionTo('pos-limit.product');
      }
    },
    navigateConfirm() {
      let cardType;
      const posLimitData = this.controller.model.reviewDetails;
      if (isEqual(posLimitData.selectedProduct.entity, 'DCARD')) {
        cardType = posLimitData.selectedCard.desc.indexOf('ATM') !== -1 ? 'ATMC' : 'DEBITCARD';
      } else {
        cardType = 'CMBC';
      }
      const postData = {
        serviceType: 'POSLMTUT',
        relNumber: posLimitData.selectedCard.relId,
        status: 'INIT',
        payload: {
          serviceRequests: {
            operationName: 'POSLMTUT',
            customerDetails: {
              relationshipNo: posLimitData.selectedCard.relId,
              customerName: isEqual(posLimitData.selectedProduct.entity, 'CMBC')
                ? posLimitData.selectedCard.custShortName
                : posLimitData.selectedCard.cardEmboserName
            },
            posLimitUpdate: [
              {
                productType: 'DCARD',
                cardType: cardType,
                cardNumber: posLimitData.selectedCard.cardNum,
                cardCurrency: posLimitData.selectedCard.currencyCode,
                cardStatus: posLimitData.selectedCard.cardStatus,
                cardExpiryDate: moment(posLimitData.selectedCard.expDt, 'MMYY').format('MM-YY'),
                cardPosTxnLimit: Number(posLimitData.posLimit).toString(),
                cardWithdrawlLimit: isEqual(posLimitData.selectedCard.currencyCode, 'SGD')
                  ? Number(posLimitData.atmLimit).toString()
                  : '999999999'
              }
            ]
          }
        },
        statusOrder: 0,
        dateOrder: 0,
        isCritical: false,
        isCemsRequest: false,
        isDocAvailable: false
      };
      this.get('store').unloadAll('service-request');
      const posLimitPostData = this.get('store')
        .createRecord('service-request', postData)
        .save()
        .then(
          item => {
            this.get('store').set('selectedObject', posLimitData);
            this.get('store').set('selectedObject.srrefNo', item.id);
            this.transitionTo('pos-limit.status');
          },
          error => {
            if (!isEmpty(error.errors) && !isEmpty(error.errors[0])) {
              this.set('message', this.get('i18n').t('ServiceRequest.posLimit.errorMsg.invalidMobNo'));
              this.get('cardErrorHandler').pageErrorPopup(this);
            } else if (isEqual(error.code, 'CSL-OTP-1328')) {
              this.set('message', this.get('i18n').t('ServiceRequest.posLimit.errorMsg.maxTryMobileNo'));
              this.get('cardErrorHandler').pageErrorPopup(this);
            }
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(posLimitPostData);
    }
  }
});
