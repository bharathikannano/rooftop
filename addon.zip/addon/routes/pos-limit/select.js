import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { A } from '@ember/array';
import EmberObject from '@ember/object';
export default Route.extend({
  i18n: service(),
  store: service(),
  setupController(controller) {
    let products = A();
    this._super(controller);
    products.addObject({
      value: this.get('i18n').t('ServiceRequest.posLimit.pageLabels.debitCard'),
      entity: 'DCARD'
    });
    products.addObject({
      value: this.get('i18n').t('ServiceRequest.posLimit.pageLabels.comboCard'),
      entity: 'CMBC'
    });
    controller.set('productDetails', products);
  },
  actions: {
    goToBack() {
      this.transitionTo('serviceRequest.new-request');
    },
    moveToNextPage(product) {
      this.get('store').set('selectedObject', EmberObject.create({}));
      this.get('store').set('selectedObject.selectedProduct', product);
      this.replaceWith('pos-limit.product');
    }
  }
});
