import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { hash } from 'rsvp';

export default Route.extend({
  store: service(),
  queries: service('customer-info'),
  model() {
    const posLimitData = this.get('store').get('selectedObject');
    const selectedCard = posLimitData.selectedCard;
    const selectedProduct = posLimitData.selectedProduct;
    return hash({
      statusDetails: posLimitData,
      selectedEntity: selectedProduct.entity,
      selectedCardObject: selectedCard,
      currencyCode: selectedCard.currencyCode
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.set('refNo', model.statusDetails.srrefNo);
    controller.set('selectedProduct', model.statusDetails.selectedProduct.value.string);
    controller.set('cardMasking', this.get('queries').cardMasking());
    controller.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
  },
  actions: {
    viewRequest() {
      this.transitionTo('serviceRequest.status');
    }
  }
});
