import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { isEmpty, isNone } from '@ember/utils';
import config from '../../config/environment';
import { hash } from 'rsvp';

export default Route.extend({
  store: service(),
  rdcLoadingIndicator: service(),
  axwayConfig: service(),
  i18n: service(),
  rdcModalManager: service(),
  queryParams: {
    newAccountOpening: {
      // Adding a new query param to send MK_F5 stepname..
      refreshModel: true
    },
    assetOnboarding: {
      // Adding a new query param to diff between assetonboarding and CASA onboarding for ETB scenario..
      refreshModel: true
    },
    sourceRefNo: {
      refreshModel: true
    }
  },

  model(params) {
    const sourceRefNo = params.sourceRefNo;
    this.get('rdcLoadingIndicator').showLoadingIndicator();
    let category = this.get('store').peekAll('product-catalogue');
    if (isEmpty(category)) {
      category = this.get('store').query('product-catalogue', {});
    }
    return hash({
      category: category,
      sourceRefNo: sourceRefNo
    });
  },

  afterModel(data, params) {
    // hiding the loader after model data is fetched..
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
    let categoryController = this.controllerFor('product-list.category');
    // Setting the meta to controller variable so that we can use peekrecord in model.
    if (!isEmpty(data.category.meta)) {
      this.controllerFor('product-list.list').set('productMeta', data.category.meta);
      categoryController.set('productMeta', data.category.meta);
    }

    let products,
      cartProduct,
      selectedCartProduct,
      selectedProducts = [];
    // (ZIBUKA) For removing the hardbundled item and making it not selected to prevent from soft bundling.
    data.category.forEach(category => {
      if (params.queryParams && params.queryParams.products) {
        products = params.queryParams.products.split(',');
        products.forEach(product => {
          cartProduct = product.split('~');
          category.products.forEach(product => {
            selectedCartProduct = product.id === cartProduct[1] ? product : null;
            if (selectedCartProduct) {
              selectedCartProduct.set('selected', true);
              selectedProducts.push(selectedCartProduct);
            }
            this.controllerFor('product-list.list').set('selectedItemCount', selectedProducts.length);
          });
        });
      }
    });

    // Condition for NG ETB flow based on products and meta key respectively.
    if (this.get('axwayConfig').country === 'NG') {
      // Checking if ETB account opening is allowed for the logged in customer.
      if (
        !isEmpty(categoryController.productMeta['etb-account-opening']) &&
        categoryController.productMeta['etb-account-opening'] === false
      ) {
        let message = this.get('i18n').t('ngBvnFlow.etbAccountOpeningFailure.message');
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message,
            acceptButtonLabel: this.get('i18n').t('ngBvnFlow.etbAccountOpeningFailure.buttonText'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          })
          .then(() => {
            this.send('goBack');
          });
        return;
      }
    }

    // For checking the restricted category.
    if (!isEmpty(categoryController.productMeta['restricted-category'])) {
      this.controllerFor('product-list.list').set(
        'restrictedCategory',
        categoryController.productMeta['restricted-category']
      );
    }

    // Adding a new query param to send MK_F5 stepname..
    if (params && params.queryParams && params.queryParams.newAccountOpening) {
      this.set('newAccountOpening', params.queryParams.newAccountOpening);
      this.controllerFor('product-list.list').set('newAccountOpening', params.queryParams.newAccountOpening);
    }

    if (!isEmpty(params.queryParams.assetOnboarding)) {
      this.set('axwayConfig.assetOnboarding', params.queryParams.assetOnboarding == 'true' ? true : false);
    }
  },

  setupController(controller, model) {
    this._super(controller, model);
    // default action sheet properties.
    controller.setProperties({
      hasCloseBtn: true,
      autoHeight: true
    });
    // To show ICDD disclosure page for staff Assist channel.
    if (
      !isEmpty(this.get('axwayConfig.staffId')) &&
      !isEmpty(this.get('axwayConfig.assetOnboarding')) &&
      this.get('axwayConfig.assetOnboarding') === true &&
      config.isAfricanCtry.includes(this.get('axwayConfig.country'))
    ) {
      controller.setProperties({
        showActionSheet: true,
        actionSheetLabel: this.get('i18n').t('productSummary.productList.icdd_disclosure.actionSheetLabel'),
        hasCloseBtn: false,
        autoHeight: false,
        staticPopup: 'icdd-disclosure',
        bpClass: 'icdd-actionsheet'
      });
    }

    if (this.media.isDesktop) {
      controller.set('bpClass', !isEmpty(controller.bpClass) ? `${controller.bpClass} is-desktop` : 'is-desktop');
    }
    let showCart = this.controllerFor('product-list.list').get('showCartBtn')
      ? this.controllerFor('product-list.list').get('showCartBtn')
      : false;
    let selectedItemCount = this.controllerFor('product-list.list').get('selectedItemCount')
      ? this.controllerFor('product-list.list').get('selectedItemCount')
      : 0;
    this.set('productListController', this.controllerFor('product-list.list'));
    let selectedProducts = [];
    model.category.forEach(category => {
      category.products.filterBy('selected').forEach(prod => {
        selectedProducts.push(prod);
      });
    });
    // setting default controller variable
    if (!isEmpty(this.get('axwayConfig.assetOnboarding')) && this.get('axwayConfig.assetOnboarding') === true) {
      controller.set('assetOnboarding', true);
    } else {
      controller.set('assetOnboarding', false);
    }
    this.set('selectedProducts', selectedProducts);
    this.controller.set('catalogueList', model);
    this.controller.set('showCartBtn', showCart);
    this.controller.set('selectedItemCount', selectedItemCount);
  },

  showCart() {
    let selectedProducts = [];
    let catalogueList = this.controller.get('catalogueList').category;
    catalogueList.forEach(category => {
      category.products.filterBy('selected').forEach(prod => {
        selectedProducts.push(prod);
      });
    });
    this.set('selectedProducts', selectedProducts);
    this.controller.set('selectedItemCount', selectedProducts.length);
    let showCartFlag = selectedProducts.length ? true : false;
    this.controller.set('showCartBtn', showCartFlag);
    if (!selectedProducts.length) {
      this.controller.set('showActionSheet', false);
    }
  },
  actions: {
    closeCart() {
      this.set('showCartDetails', false);
      this.controller.set('showActionSheet', false);
      this.controller.set('actionSheetLabel', '');
    },
    onCartSelection() {
      this.set('showCartDetails', true);
      this.controller.set('showActionSheet', true);
      this.controller.set('actionSheetLabel', this.get('i18n').t('productSummary.productList.cartHeader'));
      this.controller.set('staticPopup', 'cart-details');
    },

    onProductSelection(product, category) {
      let filteredProd = category.products.filterBy('id', product.id)[0];
      if (filteredProd) {
        filteredProd.toggleProperty('selected');
      }
      this.showCart();
    },

    onApply() {
      this.set('showCartDetails', false);
      this.controller.set('showActionSheet', false);
      this.controller.set('actionSheetLabel', '');
      this.productListController.set('hasPersonalLoan', false);
      this.productListController.set('hasCreditCard', false);
      this.productListController.set('hasOverDraft', false);

      let selectedProducts = this.get('selectedProducts');
      selectedProducts.forEach(selectedProd => {
        selectedProd.set('showDelete', true);
        if (selectedProd.category === 'PL') {
          this.controller.set('selectedCardType', 'PL');
          this.productListController.set('hasPersonalLoan', true);
        }

        if (selectedProd.category === 'CC') {
          this.controller.set('selectedCardType', 'CC');
          this.productListController.set('hasCreditCard', true);
        }

        if (selectedProd.category === 'OD') {
          this.controller.set('selectedCardType', 'OD');
          this.productListController.set('hasOverDraft', true);
        }
      });
      this.send('onLoanTypeSelection');
    },

    onLoanTypeSelection: function(loanType) {
      if (loanType) {
        this.controller.set('showActionSheet', false);
        this.controller.set('actionSheetLabel', '');
        this.productListController.set('loanType', loanType);
      }

      // Setting the axway variable 'ETBAccountOpening' to true inorder to call the stepName MK_F5 in apply-products.js..
      if (!isEmpty(this.get('newAccountOpening')) && this.get('newAccountOpening') === 'true') {
        this.set('axwayConfig.ETBAccountOpening', true);
      }

      let selectedProdCategory = this.get('selectedProducts').map(prd => prd.category);

      // To force the user to select a current account if asset products are selected.
      if (
        this.controller.assetOnboarding === true &&
        (selectedProdCategory.includes('CC') ||
          selectedProdCategory.includes('PL') ||
          selectedProdCategory.includes('OD')) &&
        !selectedProdCategory.includes('CA') &&
        isEmpty(this.get('newAccountOpening'))
      ) {
        this.transitionTo('assetAccountSelection');
        return;
      }

      this.transitionTo('start-application');
    },

    goBack() {
      if (this.get('queries.countryName') === 'CI') {
        if (!isNone(window.PGMultiView)) {
          window.PGMultiView.dismissView();
        } else {
          this.get('iframeManager').close();
        }
        this.transitionTo('serviceRequest.new-request');
      } else {
        window.location.href = config.backToiBankURL;
      }
    },
    // set the ICCD disclosure value to controller value.
    setIccdDisclosureValue() {
      let [awarePSA, awarePEP, awareSANC, awareADV] = [...arguments];
      let listController = this.controllerFor('product-list.list');
      if (!isEmpty(this.controllerFor('product-list.list'))) {
        listController.setProperties({
          awarePSA: awarePSA,
          awarePEP: awarePEP,
          awareSANC: awareSANC,
          awareADV: awareADV
        });
      }
      this.controller.set('showActionSheet', false);
    },

    categoryItemDisable(category) {
      if (category.categoryDisabled) {
        let message = this.get('i18n').t('productSummary.productList.categoryDisableDescription'),
          title = this.get('i18n').t('productSummary.productList.categoryDisableTitle');
        this.get('rdcModalManager').showDialogModal({
          level: 'warning',
          title,
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
          iconClass: 'asset-onboarding-info-icon',
          popupClass: 'asset-onboarding-theme',
          customClass: 'theme2'
        });
      } else if (category.products.length === 0) {
        let message = this.get('i18n').t('productSummary.productList.categoryNoProductsDescription'),
          title = this.get('i18n').t('productSummary.productList.categoryNoProductsTitle');
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.gotoHelpAndServices'),
            rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
            iconClass: 'asset-onboarding-info-icon',
            popupClass: 'asset-onboarding-theme',
            customClass: 'theme2 no-bg-btns'
          })
          .then(() => {
            this.transitionTo('serviceRequest.new-request');
          })
          .catch(() => {
            this.transitionTo('product-list.category');
          });
      } else {
        // For restricting the user to select CC product if he has only savings account in ETB journey..
        if (
          !isEmpty(this.controller.get('productMeta.restrict-cc')) &&
          this.controller.get('productMeta.restrict-cc') == true &&
          (category.id === 'CC' || category.id === 'PL' || category.id === 'OD')
        ) {
          let message = this.get('i18n').t('productSummary.productList.restrictCCMessage');
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              message,
              acceptButtonLabel: 'OK',
              iconClass: 'asset-onboarding-info-icon',
              popupClass: 'service-journey-info-popup asset-onboarding-theme',
              customClass: 'theme2'
            })
            .then(() => {})
            .catch(() => {});
          return;
        }
        // defaulting the bundling flag.
        this.controllerFor('product-list.list').set('bundlingCurrentAccount', false);
        let qryPrms = { categoryId: category.id, sourceRefNo: this.currentModel.sourceRefNo };
        this.transitionTo('product-list.list', { queryParams: qryPrms });
      }
    }
  }
});
