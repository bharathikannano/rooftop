import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { hash } from 'rsvp';
import { set } from '@ember/object';
import CordovaPluginWrapper from 'rdc-ui-eng-service-requests/mixins/cordova-plugin-wrapper';
import { isEmpty } from '@ember/utils';

export default Route.extend(CordovaPluginWrapper, {
  pluginName: 'Onboarding',
  queryParams: {
    productId: {
      refreshModel: true
    }
  },
  axwayConfig: service(),
  rdcAjax: service(),
  store: service(),
  rdcLoadingIndicator: service(),
  firebaseAnalytics: service(),
  setupController: function(controller, model) {
    this._super(...arguments);
    this.controller.set('showActionSheet', false);
    let catalogueList = this.get('store').peekAll('product-catalogue');
    controller.set('catalogueList', catalogueList);
    catalogueList.forEach(category => {
      let filteredProd = category.products.filterBy('id', model.productDetail.id)[0];
      if (filteredProd) {
        set(model.productDetail, 'selectable', filteredProd.selectable);
        set(model.productDetail, 'selected', filteredProd.selected);
      }
    });
    this.showCart();
    let documents = [];
    let nonDocuments = [];
    model.productDetail.eligibility.forEach(eligibilityCriteria => {
      eligibilityCriteria.criteria.forEach(criterium => {
        if (criterium.criteriaTitle === 'Documents Required') {
          criterium.conditions.forEach(condition => {
            documents.push(condition);
          });
        } else {
          criterium.conditions.forEach(condition => {
            nonDocuments.push(condition);
          });
        }
      });
    });
    this.controller.set('documents', documents);
    this.controller.set('nonDocuments', nonDocuments);
    controller.set('iframeManager', this.get('iframeManager'));
    this.controller.set(
      'customClass',
      this.get('axwayConfig.country').toLowerCase() === 'ng' ? 'ng-product-details' : ''
    );
  },
  showCart: function() {
    let catalogueList = this.controller.get('catalogueList');
    let selectedProducts = [];
    catalogueList.forEach(category => {
      category.products.filterBy('selected').forEach(prod => {
        selectedProducts.push(prod);
      });
    });
    this.set('selectedProducts', selectedProducts);
    this.controller.set('selectedItemCount', selectedProducts.length);
    let showCartFlag = selectedProducts.length ? true : false;
    this.controller.set('showCartBtn', showCartFlag);
    if (!selectedProducts.length) {
      this.controller.set('showActionSheet', false);
    }
  },
  queries: service('customer-info'),
  model(params) {
    this.get('rdcLoadingIndicator').showLoadingIndicator();
    let path = 'https://av.sc.com/configuration/product-details-',
      countryCode = this.get('axwayConfig.country').toLowerCase(),
      host = window.location.host.indexOf('sit') != -1 || window.location.host.indexOf('uat') != -1 ? '-test' : '';
    let productDetail = this.get('rdcAjax')
      .request(path + countryCode + host + '.json')
      .then(response => {
        if (response) {
          this.store.pushPayload(response);
        }
        return this.store.peekAll('product-detail').filterBy('id', params.productId)[0];
      });
    const category = this.get('store').query('product-catalogue', {});
    return hash({
      productDetail: productDetail,
      category: category
    });
  },
  afterModel() {
    // hiding the loader after model data is fetched..
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },
  actions: {
    goBack() {
      this.controllerFor('product-list.list').set('retainSelection', true);
      this.transitionTo('product-list.list');
    },
    onApply: function() {
      this._exec('getOnboardingStatus').then(onboardingStatus => {
        if (onboardingStatus != 20 || onboardingStatus != 30) {
          let selectedProductsName = this.get('selectedProducts').map(function(el) {
            return el.get('productName');
          });
          this.firebaseAnalytics.logEvent('ntb_product_selection', { product_selected: selectedProductsName });
        }
      });

      let selectedProdCategory = this.get('selectedProducts').map(prd => prd.category);
      this.get('selectedProducts').forEach(selectedProd => {
        let catList = this.currentModel.category;
        if (selectedProd.category === 'PL') {
          this.controller.set('selectedCardType', 'PL');
          this.controller.set('hasPersonalLoan', true);
        }

        if (selectedProd.category === 'CC' && this.get('axwayConfig').country === 'KE') {
          this.controller.set('selectedCardType', 'CC');
          this.controller.set('hasCreditCard', true);
        }

        selectedProd.set('showDelete', true);
        if (selectedProdCategory.includes('CC')) {
          if (selectedProdCategory.includes('CA')) {
            if (selectedProd.category === 'CC' && !isEmpty(selectedProd.bundleProductId)) {
              let bundleProductId = catList
                .filterBy('id', catList.content[0].id)[0]
                .products.filterBy('id', selectedProd.bundleProductId);
              bundleProductId[0].set('showDelete', false);
            } else if (selectedProd.category === 'CA' && selectedProd.selected) {
              selectedProd.set('showDelete', false);
            }
          } else {
            if (selectedProd.bundleCategoryId) {
              let bundleCategory = catList.filterBy('id', selectedProd.bundleCategoryId);
              if (!isEmpty(bundleCategory) && !bundleCategory[0].products.filterBy('selected').length) {
                bundleCategory[0].products.filterBy('id', selectedProd.bundleProductId)[0].set('selected', true);
                bundleCategory[0].products.filterBy('id', selectedProd.bundleProductId)[0].set('showDelete', false);
                bundleCategory[0].products.filterBy('id', selectedProd.bundleProductId)[0].set('isHardBundle', true);
              } else if (bundleCategory && bundleCategory[0].products.filterBy('selected').length == 1) {
                bundleCategory[0].products.filterBy('selected')[0].set('showDelete', false);
              }
            } else if (
              isEmpty(selectedProd.bundleCategoryId) &&
              !isEmpty(catList.filterBy('id', catList.content[0].id)[0]) &&
              selectedProd.category === 'CC'
            ) {
              let bundleProductId = catList
                .filterBy('id', catList.content[0].id)[0]
                .products.filterBy('id', selectedProd.bundleProductId);
              if (!isEmpty(bundleProductId) && !bundleProductId[0].selected) {
                bundleProductId[0].set('selected', true);
                bundleProductId[0].set('showDelete', false);
                bundleProductId[0].set('isHardBundle', true);
              } else if (!isEmpty(bundleProductId)) {
                bundleProductId[0].set('showDelete', false);
              }
            }
          }
        }
      });
      this.transitionTo('start-application');
    },
    onProductSelection(product) {
      let catalogueList = this.controller.get('catalogueList');
      catalogueList.forEach(category => {
        let filteredProd = category.products.filterBy('id', product.id)[0];
        if (filteredProd) {
          filteredProd.toggleProperty('selected');
          this.currentModel.productDetail.toggleProperty('selected');
        }
      });
      this.showCart();
    },
    closeCart() {
      this.set('showCartDetails', false);
      this.controller.set('showActionSheet', false);
    },
    onCartSelection() {
      this.set('showCartDetails', true);
      this.controller.set('showActionSheet', true);
      this.controller.set('staticPopup', 'cart-details');
    }
  }
});
