import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { isEmpty } from '@ember/utils';
import { A } from '@ember/array';
import { isNone } from '@ember/utils';
import { hash } from 'rsvp';
import { set } from '@ember/object';
import CordovaPluginWrapper from 'rdc-ui-eng-service-requests/mixins/cordova-plugin-wrapper';
import config from '../../config/environment';

export default Route.extend(CordovaPluginWrapper, {
  pluginName: 'Onboarding',
  store: service(),
  sessionManager: service(),
  selectedProducts: A(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  showCartDetails: false,
  sourceRefNo: null,
  axwayConfig: service(),
  i18n: service(),
  customerInfo: service(),
  firebaseAnalytics: service(),
  session: service(),
  showCategoryWise: false,
  queryParams: {
    sourceRefNo: {
      refreshModel: true
    },
    products: {
      refreshModel: true
    },
    productList: {
      refreshModel: true
    },
    channel: {
      refreshModel: true
    },
    categoryId: {
      refreshModel: true
    },
    newAccountOpening: {
      refreshModel: true
    },
    staffId: {
      refreshModel: true
    },
    flow: {
      refreshModel: true
    }
  },

  model(params) {
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    this.get('rdcLoadingIndicator').showLoadingIndicator();
    const sourceRefNo = params.sourceRefNo;

    if (params.channel) {
      this.customerInfo.set('channelId', params.channel);
    }
    let requestType = null;
    if (params.flow && params.flow === 'web') {
      this.set('axwayConfig.zibukaWebFlow', true);
      requestType = 'ZIBUKA';
    } else if (params.flow === 'nGen') {
      this.set('axwayConfig.nGenFlow', true);
    }
    let category = this.get('store').peekAll('product-catalogue');
    if (isEmpty(category)) {
      if (!isEmpty(requestType)) {
        category = this.get('store').query('product-catalogue', {
          filter: {
            requestType: requestType
          }
        });
      } else {
        category = this.get('store').query('product-catalogue', {});
      }
    }
    if (this.get('customerInfo.customerId') && this.get('customerInfo.customerId').includes('productList')) {
      params.productList = this.customerInfo.customerId.split('-')[1];
    }
    if (params && params.productList) {
      this.set('productList', params.productList);
    }
    if (params && params.newAccountOpening) {
      this.set('newAccountOpening', params.newAccountOpening);
    }
    return hash({
      category: category,
      sourceRefNo: sourceRefNo
    });
  },
  afterModel(data, params) {
    let listController = this.controllerFor('product-list.list');

    // To make the products other than account opening selectable false for KE NTB.
    if (
      this.get('axwayConfig').country === 'KE' &&
      (!isEmpty(this.get('axwayConfig.assetOnboarding')) && this.get('axwayConfig.assetOnboarding') === false)
    ) {
      data.category.forEach(category => {
        if (category.id !== 'ACD') {
          category.products.forEach(prod => {
            if (prod.selectable === true) {
              prod.set('selectable', false);
            }
          });
        }
      });
    }

    // Below block executes if coming from category layout.
    if (params.queryParams.categoryId) {
      this.set('categoryId', params.queryParams.categoryId);
      this.set('showCategoryWise', true);
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      // For restricting the category wise selection limit..
      let selectedCategory = data.category.filterBy('id', params.queryParams.categoryId)[0];
      // productMeta will be populated in the category route.
      selectedCategory.categoryWiseSelection =
        listController.productMeta['select-count'][selectedCategory.id.toLowerCase()] ||
        listController.productMeta['select-count'].max;

      // TO check if only 1 product is available in category.
      let isSingleProduct = selectedCategory.products && selectedCategory.products.length === 1 ? true : false;
      set(selectedCategory, 'isSingleProduct', isSingleProduct);

      return;
    }

    // Setting the meta to controller variable so that we can use peekrecord in model.
    if (!isEmpty(data.category.meta)) {
      listController.set('productMeta', data.category.meta);
    }
    // Condition for NG NTB / ETB flow based on products and meta key respectively.
    if (this.get('axwayConfig').country === 'NG') {
      // Checking if ETB account opening is allowed for the logged in customer.
      if (
        !isEmpty(listController.productMeta['etb-account-opening']) &&
        listController.productMeta['etb-account-opening'] == false
      ) {
        let message = this.get('i18n').t('ngBvnFlow.etbAccountOpeningFailure.message');
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message,
            acceptButtonLabel: this.get('i18n').t('ngBvnFlow.etbAccountOpeningFailure.buttonText'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          })
          .then(() => {
            this.send('goBack');
          });
        return;
      }
      // Checking if Accounts & Deposits category has more than one selectable product.
      let filterCategory = 'ACD',
        instantProductCode = '504';
      let availableProduct = data.category.findBy('id', filterCategory).products.filterBy('selectable', true);
      /* Checking if the product to be selected is only 1 and the product code is "504".
          Since NTB for NG will have only 504 has selectable product. */
      if (availableProduct.length === 1 && availableProduct.firstObject.get('id') === instantProductCode) {
        set(data.category.firstObject.products.firstObject, 'selected', true);
        this.get('rdcLoadingIndicator').hideLoadingIndicator();
        this.transitionTo('start-application');
        return;
      }
    }
    // For checking the restricted category.
    if (!isEmpty(listController.productMeta['restricted-category'])) {
      this.set('restrictedCategory', listController.productMeta['restricted-category']);
    }
    this.set('onLoadSelectedProducts', A());
    if (params.queryParams && params.queryParams.products) {
      let products = params.queryParams.products.split(',');
      products.forEach(product => {
        let selectedProd = {
          categoryCode: product.split('~')[0],
          productId: product.split('~')[1],
          subProductTypeCode: product.split('~')[2]
        };
        this.get('onLoadSelectedProducts').pushObject(selectedProd);
      });
    }

    let catList = data.category;
    if (this.get('productList') && (!this.controller || !this.controller.get('retainSelection'))) {
      let products = this.get('productList').split(',');
      products.forEach(product => {
        let appliedProduct = product.split('~');
        let selectedCategory = catList.findBy('id', appliedProduct[0]);
        if (selectedCategory) {
          let selectedProd = selectedCategory.products.findBy('id', appliedProduct[1]);
          if (selectedProd) {
            selectedProd.set('selected', true);
          } else {
            let message = this.get('i18n').t('productSummary.productList.productAlreadyExist');
            this.get('rdcModalManager')
              .showDialogModal({
                level: 'warning',
                message,
                acceptButtonLabel: 'Yes',
                rejectButtonLabel: 'No',
                iconClass: 'service-journey-info-icon',
                popupClass: 'service-journey-info-popup'
              })
              .then(() => {})
              .catch(() => {
                this.send('goBack');
              });
          }
        }
      });
    }
    this.set('hasRewardType', false);
    let preSelectedProducts = this.get('onLoadSelectedProducts');
    catList.forEach(category => {
      category.categoryWiseSelection =
        listController.productMeta['select-count'][category.id.toLowerCase()] ||
        listController.productMeta['select-count'].max;
      let isSingleProduct = category.products && category.products.length === 1 ? true : false;
      set(category, 'isSingleProduct', isSingleProduct);
      category.products.forEach(prod => {
        if (prod.productRewardType) {
          this.set('hasRewardType', true);
        }
        if (this.controller && !this.controller.get('retainSelection')) {
          set(prod, 'selected', false);
        }
        if (preSelectedProducts.length) {
          let preSelectedProduct = preSelectedProducts.filterBy('productId', prod.id);
          if (
            preSelectedProduct.length &&
            preSelectedProduct[0].productId === prod.id &&
            preSelectedProduct[0].categoryCode === prod.category &&
            (preSelectedProduct[0].subProductTypeCode === '0' ||
              (preSelectedProduct[0].subProductTypeCode !== '0' &&
                preSelectedProduct[0].subProductTypeCode === prod.subProductTypeCode))
          ) {
            set(prod, 'selected', true);
          }
        }
      });
    });
    if (this.controller) {
      this.controller.set('retainSelection', false);
    }
    let selectedProducts = [];
    catList.forEach(category => {
      category.products.filterBy('selected').forEach(prod => {
        selectedProducts.push(prod);
      });
    });
    this.set('selectedProducts', selectedProducts);
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.set('showCategoryWise', this.get('showCategoryWise'));
    controller.set('hasRewardType', this.get('hasRewardType'));

    // default action sheet properties.
    controller.setProperties({
      hasCloseBtn: true,
      autoHeight: true
    });
    // To show ICDD disclosure page for staff Assist channel.
    if (
      isEmpty(controller.awarePSA) &&
      !isEmpty(this.get('axwayConfig.staffId')) &&
      !isEmpty(this.get('axwayConfig.assetOnboarding')) &&
      this.get('axwayConfig.assetOnboarding') === true &&
      config.isAfricanCtry.includes(this.get('axwayConfig.country'))
    ) {
      controller.setProperties({
        showActionSheet: true,
        actionSheetLabel: this.get('i18n').t('productSummary.productList.icdd_disclosure.actionSheetLabel'),
        hasCloseBtn: false,
        autoHeight: false,
        staticPopup: 'icdd-disclosure',
        listingClass: 'icdd-actionsheet'
      });
    }

    // To default the bundling property.
    if (isEmpty(controller.bundlingCurrentAccount) || controller.bundlingCurrentAccount !== true) {
      controller.set('bundlingCurrentAccount', false);
    }
    if (this.get('showCategoryWise')) {
      let selectedCategory = model.category.filterBy('id', this.get('categoryId'));
      this.controller.set('selectedCategory', selectedCategory[0]);
    }
    let selectedProducts = [];
    model.category.map(pro => {
      pro.products.filterBy('selected').map(prod => {
        selectedProducts.push(prod);
      });
    });
    // setting default controller variable
    if (!isEmpty(this.get('axwayConfig.assetOnboarding')) && this.get('axwayConfig.assetOnboarding') === true) {
      controller.set('assetOnboarding', true);
    } else {
      controller.set('assetOnboarding', false);
    }
    this.set('selectedProducts', selectedProducts);
    controller.set('multiSelectCount', controller.productMeta['select-count'].max);
    controller.set('applicationSummary', controller.productMeta['application-info']);
    let multiSelect = controller.get('multiSelectCount') > 1 ? true : false;
    controller.set('multiSelect', multiSelect);
    controller.set('selectedItemCount', this.get('selectedProducts').length);
    let showCartFlag = this.get('selectedProducts').length ? true : false;
    controller.set('showCartBtn', showCartFlag);
    controller.set('model', model);
    if (this.media.isDesktop) {
      this.controller.set(
        'listingClass',
        !isEmpty(this.controller.listingClass)
          ? `${this.controller.listingClass} is-desktop listing`
          : 'is-desktop listing'
      );
    } else {
      this.controller.set(
        'listingClass',
        !isEmpty(this.controller.listingClass) ? `${this.controller.listingClass} listing` : 'listing'
      );
    }
  },
  actions: {
    closeCart() {
      this.set('showCartDetails', false);
      this.controller.set('showActionSheet', false);
      this.controller.set('actionSheetLabel', '');
    },
    insuranceBanner(data) {
      this.controller.setProperties({
        showActionSheet: true,
        staticPopup: 'rdc-banner',
        bannerData: data,
        hasCloseBtn: false,
        listingClass: 'rdc-banner'
      });
    },
    closeInsuranceBanner() {
      this.controller.set('showActionSheet', false);
    },
    onProductSelection: function(selectedProduct, category) {
      let catList = this.currentModel.category;
      let selectedProdCategory = catList.filterBy('id', category.id)[0];
      let categoryWiseSelectedProducts = [];
      category.products.filterBy('selected').forEach(prod => {
        categoryWiseSelectedProducts.push(prod);
      });
      // Selection restrictions start...
      if (!selectedProduct.selected) {
        // To allow only 1 product selection for category other than ACD.
        if (
          (config.isAfricanCtry.includes(this.get('axwayConfig.country')) &&
            category.categoryWiseSelection == 1 &&
            categoryWiseSelectedProducts.length) ||
          (this.controller.get('hasRewardType') &&
            category.categoryWiseSelection <= categoryWiseSelectedProducts.length)
        ) {
          let title = this.get('i18n').t('ServiceRequest.COMMON.validation.categoryRestrictionAsset.title');
          let message = this.get('i18n').t('ServiceRequest.COMMON.validation.categoryRestrictionAsset.message');
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              title,
              message,
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.changeSelection'),
              rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.accountUpgradeNo'),
              iconClass: 'asset-onboarding-question-icon',
              popupClass: 'service-journey-info-popup asset-onboarding-theme',
              customClass: 'theme2 no-bg-btns'
            })
            .then(() => {
              // To unselect the previously selected and re-selected the currently selected.
              let categoryIdArr =
                selectedProdCategory.id === 'ACD' ? ['SA', 'CA', 'FD'] : [`${selectedProdCategory.id}`];
              let selectedCCProduct = this.get('selectedProducts').filter(prod => {
                if (categoryIdArr.indexOf(prod.category) !== -1) {
                  return prod;
                }
              });
              let selectedCatProducts = selectedProdCategory.products;
              // Taking the first object of the array as only one product can be always selected in a category.
              let selectionChangingProduct = selectedCatProducts.filterBy('id', selectedProduct.id)[0];
              selectionChangingProduct.toggleProperty('selected');
              selectedCCProduct[0].toggleProperty('selected');
              let selectedProducts = [];
              catList.forEach(category => {
                category.products.filterBy('selected').forEach(prod => {
                  selectedProducts.push(prod);
                });
              });
              this.set('selectedProducts', selectedProducts);
            });
          return;
        } else if (
          (category.categoryWiseSelection == 1 && categoryWiseSelectedProducts.length) ||
          category.categoryWiseSelection <= categoryWiseSelectedProducts.length
        ) {
          let message =
            this.get('i18n').t('ServiceRequest.COMMON.validation.allowedApply_1') +
            category.categoryWiseSelection +
            this.get('i18n').t('ServiceRequest.COMMON.validation.productSelectionValidation') +
            this.get('i18n').t('ServiceRequest.COMMON.validation.productSelectionValidation_2');
          if (
            this.get('axwayConfig.zibukaWebFlow') &&
            (selectedProduct.category === 'CA' || selectedProduct.category === 'SA')
          ) {
            message = this.get('i18n').t('ServiceRequest.COMMON.validation.zibukaCASAValidation');
          }
          this.get('rdcModalManager').showDialogModal({
            level: 'warning',
            message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.iUnderstand'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup',
            customClass: 'theme2'
          });
          return;
        } else if (this.controller.get('multiSelectCount') <= this.get('selectedProducts').length) {
          let message =
            this.get('i18n').t('ServiceRequest.COMMON.validation.only') +
            this.controller.get('multiSelectCount') +
            this.get('i18n').t('ServiceRequest.COMMON.validation.overallMaxValidation');
          // TO show new styled modal popup for assetOnboarding and africa countries..
          if (
            config.isAfricanCtry.includes(this.get('axwayConfig.country')) &&
            this.controller.assetOnboarding === true
          ) {
            this.get('rdcModalManager').showDialogModal({
              level: 'warning',
              message,
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.iUnderstand'),
              iconClass: 'asset-onboarding-info-icon',
              popupClass: 'service-journey-info-popup asset-onboarding-theme',
              customClass: 'theme2'
            });
          } else {
            this.get('rdcModalManager').showDialogModal({
              level: 'warning',
              message,
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.iUnderstand'),
              iconClass: 'service-journey-info-icon',
              popupClass: 'service-journey-info-popup'
            });
          }
          return;
        }
      }

      /* The below condition is to restrict the combinational product selection for ZIBUKA (Assets),
       * depending on the "restricted-category" key sent in meta.
       * Allowing only if meta value is present and any product is selected before.
       */

      //  Condition start ..
      let restrictedCategory = this.get('restrictedCategory') || this.controller.get('restrictedCategory');
      if (!isEmpty(restrictedCategory) && !isEmpty(this.get('selectedProducts'))) {
        // Getting the already selected product catagory as Array..
        let selectedProductCategoryArr = this.get('selectedProducts').map(prod => {
          return prod.category;
        });
        /* Pushing the selected product also in the array if not available..
         * If available, then removing the product from the array..
         */
        if (selectedProductCategoryArr.includes(selectedProduct.category)) {
          selectedProductCategoryArr = selectedProductCategoryArr.filter(value => value !== selectedProduct.category);
        } else {
          selectedProductCategoryArr.push(selectedProduct.category);
        }
        let combArr = restrictedCategory,
          canRestrict = false;
        // Looping the restricted category array to validate.
        combArr.forEach(cat => {
          let innerCombArr = cat.split('+');
          // validating only if the number of combinations mentioned is satisfied and product is already not selected.
          if (!canRestrict && selectedProductCategoryArr.length === innerCombArr.length) {
            canRestrict = selectedProductCategoryArr.every(AlrdySelProdCat => innerCombArr.includes(AlrdySelProdCat));
          }
        });

        // restricting if the selected producted is restricted in meta by showing alert.
        if (canRestrict) {
          let message = this.get('i18n').t('ServiceRequest.COMMON.validation.categoryRestriction.message');
          this.get('rdcModalManager').showDialogModal({
            level: 'warning',
            message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.iUnderstand'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          });
          return;
        }
      }
      //  Condition end ..
      // selection restrictions end.
      let selectedCatProducts = selectedProdCategory.products;
      let selectionChangingProduct = selectedCatProducts.filterBy('id', selectedProduct.id)[0];
      selectionChangingProduct.toggleProperty('selected');
      let selectedProducts = [];
      catList.forEach(category => {
        category.products.filterBy('selected').forEach(prod => {
          selectedProducts.push(prod);
        });
      });
      this.set('selectedProducts', selectedProducts);
      this.controller.set('selectedItemCount', selectedProducts.length);
      let showCartFlag = selectedProducts.length ? true : false;
      this.controller.set('showCartBtn', showCartFlag);
      if (!selectedProducts.length) {
        this.controller.set('showActionSheet', false);
        this.controller.set('actionSheetLabel', '');
      }
    },

    goToListPage: function() {
      this.controller.set('selectedProducts', this.get('selectedProducts'));
      this.transitionTo('product-list.category');
    },

    onApply: function() {
      this.set('showCartDetails', false);
      this.controller.set('showActionSheet', false);
      this.controller.set('actionSheetLabel', '');
      this.controller.set('hasPersonalLoan', false);
      this.controller.set('hasCreditCard', false);
      this.controller.set('hasOverDraft', false);

      this.get('selectedProducts').forEach(selectedProd => {
        selectedProd.set('showDelete', true);
        if (selectedProd.category === 'PL') {
          this.controller.set('selectedCardType', 'PL');
          this.controller.set('hasPersonalLoan', true);
        }

        if (selectedProd.category === 'CC') {
          this.controller.set('selectedCardType', 'CC');
          this.controller.set('hasCreditCard', true);
        }

        if (selectedProd.category === 'OD') {
          this.controller.set('selectedCardType', 'OD');
          this.controller.set('hasOverDraft', true);
        }
      });
      this.send('onLoanTypeSelection');
    },

    // set the ICCD disclosure value to controller value.
    setIccdDisclosureValue() {
      let [awarePSA, awarePEP, awareSANC, awareADV] = [...arguments];
      console.log(awarePSA, awarePEP, awareSANC, awareADV);
      this.controller.setProperties({
        awarePSA: awarePSA,
        awarePEP: awarePEP,
        awareSANC: awareSANC,
        awareADV: awareADV
      });
      this.controller.set('showActionSheet', false);
    },

    onLoanTypeSelection: function(loanType) {
      if (loanType) {
        this.controller.set('showActionSheet', false);
        this.controller.set('actionSheetLabel', '');
        this.controller.set('loanType', loanType);
      }

      // Setting the axway variable "ETBAccountOpening" to true inorder to call the stepName MK_F5 in apply-products.js..
      if (!isEmpty(this.get('newAccountOpening')) && this.get('newAccountOpening') === 'true') {
        this.set('axwayConfig.ETBAccountOpening', true);
      }

      let selectedProdCategory = this.get('selectedProducts').map(prd => prd.category);

      // To force the user to select a current account if asset products are selected.
      if (
        this.controller.assetOnboarding === true &&
        (selectedProdCategory.includes('CC') ||
          selectedProdCategory.includes('PL') ||
          selectedProdCategory.includes('OD')) &&
        !selectedProdCategory.includes('CA') &&
        isEmpty(this.get('newAccountOpening'))
      ) {
        this.transitionTo('assetAccountSelection');
        return;
      }

      this.transitionTo('start-application');
      this._exec('getOnboardingStatus').then(onboardingStatus => {
        if (onboardingStatus != 20 || onboardingStatus != 30) {
          let selectedProductsName = this.get('selectedProducts').map(function(el) {
            return el.get('productName');
          });
          this.firebaseAnalytics.logEvent('ntb_product_selection', { product_selected: selectedProductsName });
        }
      });
    },

    onCartSelection() {
      this.set('showCartDetails', true);
      this.controller.set('actionSheetLabel', this.get('i18n').t('productSummary.productList.cartHeader'));
      this.controller.set('showActionSheet', true);
      this.controller.set('staticPopup', 'cart-details');
      this.controller.set('hasCloseBtn', true);
    },
    goBack() {
      if (this.get('queries.countryName') == 'CI') {
        if (!isNone(window.PGMultiView)) {
          window.PGMultiView.dismissView();
        } else {
          this.get('iframeManager').close();
        }
        this.transitionTo('serviceRequest.new-request');
      } else {
        window.location.href =
          window.location.protocol + '//' + window.location.host + '/retail/api/security/v1/ssoRequest';
      }
    }
  }
});
