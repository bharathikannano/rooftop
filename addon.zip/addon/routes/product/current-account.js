import Route from '@ember/routing/route';
import idleSession from 'rdc-ui-eng-service-requests/mixins/idle-session';

export default Route.extend(idleSession, {
  actions: {
    goBack() {
      this.transitionTo('product.opening');
    },
    goToFereForm() {
      this.transitionTo('accountOpening');
    }
  }
});
