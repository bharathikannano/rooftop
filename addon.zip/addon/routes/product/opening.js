import { isNone,isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';
import idleSession from 'rdc-ui-eng-service-requests/mixins/idle-session';
import checkMaintenance from 'rdc-ui-eng-service-requests/mixins/check-maintenance';

export default Route.extend(idleSession, checkMaintenance, {
  iframeManager: service(),
  queries: service('customer-info'),
  i18n: service(),
  rdcModalManager: service(),
  queryParams: {
    existingCustomer: {
      refreshModel: true
    }
  },
  beforeModel(params) {
    // For restricting the product selection to only 1 product during ETB flow only.
    if (!isEmpty(params.queryParams) && !isEmpty(params.queryParams.existingCustomer)) {
      this.controllerFor('product.opening').set('isExistingCustomer', true);
    }
    localStorage.removeItem('isCurrentAccountSelected');
    localStorage.removeItem('isExcelSaverAccountSelected');
    this.controllerFor('product.opening').set('isCurrentAccountSelected', false);
    this.controllerFor('product.opening').set('isExcelSaverAccountSelected', false);

    let srcURL = document.location.href;
    if (srcURL) {
      srcURL = srcURL.split('?')[1];
      if (srcURL) {
        srcURL = srcURL.split('&');
        let countryCode;
        srcURL.forEach(item => {
          if (item.indexOf('ctry') != -1) {
            countryCode = item.split('=')[1];
          }
        });

        if (countryCode) this.get('queries').setcountryName(countryCode);
      }
    }
  },
  setupController(controller, model) {
    this._super(controller, model);

    controller.set('isCurrentAccountSelected', false);
    controller.set('isExcelSaverAccountSelected', false);
    // default flag for isExistingCustomer if it is not already set to true.
    if (controller.get('isExistingCustomer') !== true) {
      controller.set('isExistingCustomer', false);
    }
    // default flag for maintenance.
    controller.set('isMaintenance', false);
  },

  closePopupAction() {
    let message;
    this.controllerFor('product.opening').set('errorType', 'cancel');
    if (this.get('media.isDesktop')) {
      message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
    } else {
      message = this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankText');
    }
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message,
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        document.location.href = config.backToiBankURL;
      });
  },

  actions: {
    selectedAccount(type) {
      let showProductRestrict = false, controller = this.controllerFor('product.opening');
      /* TO check if the application is under maintanence.
       * This check is used to alert the user by just changing a flag in JSON file.
       */
      this.checkMaintenance().then(isUnderMaintanence => {
        controller.set('isMaintenance', isUnderMaintanence);
      });

      if (type === 'CurrentAccount') {
        if (controller.get('isExistingCustomer') === true && controller.get('isExcelSaverAccountSelected') === true) {
          showProductRestrict = true;
        } else {
          controller.toggleProperty('isCurrentAccountSelected');
          localStorage.setItem(
            'isCurrentAccountSelected',
            controller.get('isCurrentAccountSelected')
          );
        }
      }
      if (type === 'ExcelSaverAccount') {
        if (controller.get('isExistingCustomer') === true && controller.get('isCurrentAccountSelected') === true) {
          showProductRestrict = true;
        } else {
          controller.toggleProperty('isExcelSaverAccountSelected');
          localStorage.setItem(
            'isExcelSaverAccountSelected',
            controller.get('isExcelSaverAccountSelected')
          );
        }
      }

      // For restricting the product selection to only 1 product during ETB flow only.
      if (showProductRestrict) {
        let message =
            this.get('i18n').t('ServiceRequest.COMMON.validation.allowedApply_1') +
            '1' +
            this.get('i18n').t('ServiceRequest.COMMON.validation.productSelectionValidation');
        this.get('rdcModalManager').showDialogModal({
          level: 'warning',
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.iUnderstand'),
          iconClass: 'service-journey-info-icon',
          popupClass: 'service-journey-info-popup'
        });
      }
    },
    goBack() {
      if (this.get('queries.countryName') == 'CI') {
        if (!isNone(window.PGMultiView)) {
          window.PGMultiView.dismissView();
        } else {
          this.get('iframeManager').close();
        }
        this.transitionTo('serviceRequest.new-request');
      } else {
        this.closePopupAction();
      }
    },
    checkout() {
      if (this.controller.isMaintenance) {
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'error',
            title: this.get('i18n').t('ServiceRequest.COMMON.maintanence.title'),
            message: this.get('i18n').t('ServiceRequest.COMMON.maintanence.message'),
            acceptButtonLabel: this.get('i18n').t('generic.ok')
          })
          .then(() => {
            // Nothing to handle here..
          });
        return;
      }
      this.transitionTo('disclaimer');
    },
    goToCurrentAccountDetails() {
      this.transitionTo('product.current-account');
    },
    goToExcelSaverAccountDetails() {
      this.transitionTo('product.excel-saver-account');
    },
    goToFixedDepositDetails() {
      this.transitionTo('product.fixed-deposit');
    }
  }
});
