import { inject as service } from '@ember/service';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';
import { isEmpty } from '@ember/utils';
import { Promise as EmberPromise } from 'rsvp';

export default FereFormRoute.extend({
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),

  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'STEP_1', countryCode: this.get('axwayConfig.country'), id: 'W255' } };
    }
  }),

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
  },

  closeThisForm() {
    this.transitionTo('serviceRequest.new-request');
  },
  afterSubmit(formDatum, isFileDelete) {
    const promise = new EmberPromise(resolve => {
      let isCRSETB = formDatum.get('additionalInfo') && formDatum.get('additionalInfo').CRSETB,
        isCRSNTB = formDatum.get('additionalInfo') && formDatum.get('additionalInfo').CRSNTB;
      if (!isEmpty(isCRSETB) && isCRSETB) {
        resolve('CRSETB');
      } else if (!isEmpty(isCRSNTB) && isCRSNTB) {
        resolve('CRSNTB');
      } else {
        resolve();
      }
    });
    promise.then(result => {
      if (result && result.length > 0) {
        if (result === 'CRSETB' || result === 'CRSNTB') {
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'error',
              title: this.get('i18n').t('ServiceRequest.COMMON.crsMessage.title'),
              message: this.get('i18n').t('ServiceRequest.COMMON.crsProfielUpdate.' + result),
              rejectButtonLabel:
                result === 'CRSNTB'
                  ? this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest')
                  : this.get('i18n').t('ServiceRequest.COMMON.button.cancel'),
              acceptButtonLabel:
                result === 'CRSNTB'
                  ? this.get('i18n').t('ServiceRequest.COMMON.button.close')
                  : this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
              customClass: 'custom-crs-class'
            })
            .then(() => {
              if (result !== 'CRSNTB') {
                this.set('isRetry', true);
                this.transitionTo('serviceRequest.new-request');
              }
            })
            .catch(() => {
              if (result === 'CRSNTB') {
                this.set('isRetry', true);
                this.transitionTo('serviceRequest.new-request');
              }
            });
        }
      } else {
        if (!isFileDelete) this.goToReceiptPage();
      }
    });
  },
  actions: {
    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        this.transitionTo('serviceRequest.new-request');
      }
    },
    closeForm() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
