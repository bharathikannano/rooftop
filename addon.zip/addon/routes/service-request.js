import { isNone } from '@ember/utils';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../config/environment';
import $ from 'jquery';
import { htmlSafe } from '@ember/string';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  iframeManager: service(),
  queries: service('customer-info'),
  setupController: function(controller) {
    if (this.get('queries.countryName') == 'CI') {
      controller.set('leftIcon', 'uxlab-icon-sc-s-mobile-back-button');
      controller.set('rightIcon', '');
    } else {
      controller.set('leftIcon', '');
      let rightIcon = this.get('queries.hideClose') === 'Y' ? '' : 'sc-icon uxlab-icon-sc-s-cross';
      controller.set('rightIcon', rightIcon);
    }
    controller.set('totalActiveCount', null);
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
  },

  actions: {
    closePopupAction() {
      this.controllerFor('serviceRequest').set('cancelPopup', true);
      let message;
      if (!this.get('queries.customerFlowFlag')) {
        message = htmlSafe(this.get('i18n').t('ServiceRequest.COMMON.closeWindowText'));
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup frontline-close-alert'
          })
          .then(() => {
            this.controllerFor('serviceRequest').set('cancelPopup', false);
          })
          .catch(() => {
            this.controllerFor('serviceRequest').set('cancelPopup', false);
          });
      } else {
        if (this.get('media.isDesktop')) {
          message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
        } else {
          message = this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankText');
        }
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
            rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          })
          .then(() => {
            if (window.cordova) {
              $.ajax({
                url:
                  window.location.protocol +
                  '//' +
                  window.location.host +
                  '/retail/api/security/v1/ssoRequest?killSession=Y',
                complete: function() {
                  window.location.href =
                    window.location.protocol + '//' + window.location.host + '/retail/api/security/v1/ssoRequest';
                }
              });
            } else {
              document.location.href = config.backToiBankURL;
            }
            this.controllerFor('serviceRequest').set('cancelPopup', false);
          })
          .catch(() => {
            this.controllerFor('serviceRequest').set('cancelPopup', false);
          });
      }
    },
    surfaceClick() {
      if (this.controllerFor('serviceRequest.new-request')) {
        this.controllerFor('serviceRequest.new-request').set('filteredAccordionArticles', []);
        this.controllerFor('serviceRequest.new-request').set('filteredSearchText', null);
      }
    },
    goToBack() {
      if (!isNone(window.PGMultiView)) {
        window.PGMultiView.dismissView();
      } else {
        this.get('iframeManager').close();
      }
    }
  }
});
