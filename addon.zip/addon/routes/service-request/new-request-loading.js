import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';

export default Route.extend({
  rdcLoadingIndicator: service(),
  renderTemplate() {
    this.rdcLoadingIndicator.showLoadingIndicator();
    this._super.apply(this, arguments);
  }
});
