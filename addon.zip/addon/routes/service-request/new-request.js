import { schedule, later } from '@ember/runloop';
import { set } from '@ember/object';
import { hash } from 'rsvp';
import { inject as service } from '@ember/service';
import checkMaintenance from 'rdc-ui-eng-service-requests/mixins/check-maintenance';
import Route from '@ember/routing/route';
import config from '../../config/environment';
import constants from '../../constants';
import { htmlSafe } from '@ember/string';
import { isEmpty } from '@ember/utils';

export default Route.extend(checkMaintenance, {
  store: service(),
  fap: service(),
  i18n: service(),
  axwayConfig: service(),
  serviceJourneyEntries: service('service-journey-entries'),
  breadcrumbService: service(),
  rdcModalManager: service(),
  idle: service('idle-ticker'),
  queries: service('customer-info'),
  session: service('session'),
  basicAdditionalValParam: false,
  additionVerificationNeeded: false,
  SSOTokenFlag: false,
  pointTo: null,
  queryParams: {
    pointTo: {
      refreshModel: true
    }
  },
  rdcLoadingIndicator: service(),
  adobeDataService: service(),
  renderTemplate() {
    this._super();
    try {
      let data = {
        id: '',
        title: 'new request'
      };
      this.get('adobeDataService').pageView_fere(data);
    } catch (e) {}
  },

  beforeModel() {
    /* TO check if the application is under maintanence.
     * This check is used to alert the user by just changing a flag in JSON file.
     */
    this.checkMaintenance().then(isUnderMaintanence => {
      if (isUnderMaintanence) {
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'error',
            title: this.get('i18n').t('ServiceRequest.COMMON.maintanence.title'),
            message: this.get('i18n').t('ServiceRequest.COMMON.maintanence.message'),
            acceptButtonLabel: this.get('i18n').t('generic.ok')
          })
          .then(() => {
            document.location.href = config.backToiBankURL;
          });
      }
    });

    let srcURL = decodeURIComponent(document.location.href);
    if (srcURL) {
      srcURL = srcURL.split('?')[1];
      if (srcURL) {
        srcURL = srcURL.split('#')[0];
        if (srcURL) {
          srcURL = srcURL.split('&');
          let customerId,
            countryCode,
            channelId,
            langId,
            sso,
            userId,
            cvUrlStatus,
            cvUrlType,
            cvUrlTime,
            journeyTransition,
            deeplinkOptions,
            redirParam,
            redirTimeout,
            targetRoute,
            hideClose;
          srcURL.forEach(item => {
            if (item.indexOf('userData') != -1) {
              let customerIdName = item.split('=')[1];
              let userDataArray = customerIdName.split(',');
              customerId = userDataArray[0];
              userDataArray.shift();
              deeplinkOptions = userDataArray.toString();
            } else if (item.indexOf('staffId') != -1) {
              let staffDetails = item.split('=')[1];
              if (staffDetails) {
                this.set('axwayConfig.staffId', staffDetails);
              }
            } else if (item.indexOf('assetOnboarding') != -1) {
              let assetOnboarding = item.split('=')[1];
              if (assetOnboarding == 'true') {
                this.set('axwayConfig.assetOnboarding', true);
              } else {
                this.set('axwayConfig.assetOnboarding', false);
              }
            } else if (item.indexOf('ctry') != -1) {
              countryCode = item.split('=')[1];
            } else if (item.indexOf('sapp') != -1) {
              channelId = item.split('=')[1];
            } else if (item.indexOf('lang') != -1) {
              langId = item.split('=')[1];
            } else if (item.indexOf('userId') != -1) {
              userId = item.split('=')[1];
            } else if (item.indexOf('cvUrlStatus') != -1) {
              cvUrlStatus = item.split('=')[1];
            } else if (item.indexOf('cvUrlType') != -1) {
              this.set('basicAdditionalValParam', true);
              cvUrlType = item.split('=')[1];
            } else if (item.indexOf('cvUrlTime') != -1) {
              cvUrlTime = item.split('=')[1];
            } else if (item.indexOf('RedirPageId') != -1) {
              journeyTransition = item.split('=')[1];
            } else if (item.indexOf('RedirParam') != -1) {
              redirParam = item.split('=')[1];
            } else if (item.indexOf('RedirTimeout') != -1) {
              redirTimeout = item.split('=')[1];
            } else if (item.indexOf('targetRoute') != -1) {
              targetRoute = item.split('=')[1];
            } else if (item.indexOf('hideClose') != -1) {
              hideClose = item.split('=')[1];
            }
          });
          if (customerId) this.set('queries.customerId', customerId);
          if (deeplinkOptions) this.set('queries.deepLinkOptions', deeplinkOptions);
          if (countryCode) this.set('queries.countryName', countryCode);
          if (channelId) this.set('queries.channel', channelId);
          if (langId) this.set('queries.langId', langId);
          if (sso) this.get('queries').setSSO(sso);
          if (userId) this.get('queries').setuserId(userId);
          if (countryCode) this.get('queries').setcountryName(countryCode);
          if (channelId) this.get('queries').setchannel(channelId);
          if (cvUrlStatus) this.set('queries.cvUrlStatus', cvUrlStatus);
          if (cvUrlType) this.set('queries.cvUrlType', cvUrlType);
          if (cvUrlTime) this.set('queries.cvUrlTime', cvUrlTime);
          if (journeyTransition) this.set('queries.journeyTransition', journeyTransition);
          if (redirParam) this.set('queries.redirParam', redirParam);
          if (redirTimeout) this.set('queries.redirTimeout', redirTimeout);
          if (hideClose) this.set('queries.hideClose', hideClose);
          if (targetRoute) this.set('queries.targetRoute', targetRoute);
        }
      }
    }

    if (this.get('queries.countryName') && this.get('queries.countryName').toLowerCase() == 'hk') {
      if (this.get('queries.langId').toLowerCase() != 'en') {
        this.get('queries.langId').toLowerCase() == 'zh_hk'
          ? this.set('i18n.locale', 'zh-hk')
          : this.set('i18n.locale', 'zh-cn');
      }
    }
    /* RESETTING CASA */
    this.get('store').unloadAll('casa');
    if (this.get('queries.targetRoute') && !this.get('queries.journeyTransitionCompleted')) {
      let queryParams = {};
      for (let pair of new URLSearchParams(window.location.search)) {
        queryParams[pair[0]] = pair[1];
      }
      this.transitionTo(this.get('queries.targetRoute'), { queryParams: queryParams });
      this.set('queries.journeyTransitionCompleted', true);
      return this._super.apply(...arguments);
    }
  },
  model(params) {
    this.set('pointTo', null);
    this.controllerFor('serviceRequest').set('activePage', constants.createRequestBreadcrumbActive);
    if (params && params.pointTo) {
      this.set('pointTo', params.pointTo);
    }
    let basicAddDetailsVal;
    let customersData;

    if (this.get('basicAdditionalValParam')) {
      /*Customer entity call */
      customersData = this.get('store').peekAll('customer');

      customersData = this.get('store').queryRecord('customer', {});
      /*Cvd Call call */
      basicAddDetailsVal = this.get('store').peekAll('customer-verification-static-detail');

      if (!basicAddDetailsVal.content.length) {
        basicAddDetailsVal = this.get('store').query('customer-verification-static-detail', {
          filter: {
            cvUrlStatus: this.get('queries.cvUrlStatus'),
            cvUrlType: this.get('queries.cvUrlType'),
            cvUrlTime: this.get('queries.cvUrlTime')
          },
          include: 'sr-details'
        });
      }
    }
    let menuVal = this.get('store').peekAll('service-requests-category');
    return hash({
      country: this.get('queries.countryName'),
      menuData: menuVal.content.length
        ? menuVal
        : this.get('store').query('service-requests-category', {
            filter: {
              menuList: this.get('queries.deepLinkOptions')
            }
          }),
      basicAddDetails: basicAddDetailsVal,
      customersData: customersData
    });
  },
  afterModel(data) {
    let thisObj = this,
      newAccountOpening = false;
    try {
      this.get('adobeService').addScriptTag();
    } catch (e) {}
    if (
      (!this.get('queries.journeyTransition') && !this.get('queries.targetRoute')) ||
      this.get('queries.journeyTransitionCompleted')
    ) {
      schedule('afterRender', this, function() {
        this.send('afterRenderEvent');
      });
    }
    this.controllerFor('service-request').set('basicAdditionalValParam', this.get('basicAdditionalValParam'));
    if (this.get('basicAdditionalValParam')) {
      let userGroup;
      let message;

      data.basicAddDetails.forEach(childNode => {
        userGroup = childNode.data.userGroup;
        if (childNode.data.errorCode) {
          message = htmlSafe(childNode.data.errorDescription);
          thisObj
            .get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              message,
              acceptButtonLabel: thisObj.get('i18n').t('ServiceRequest.COMMON.button.ok'),
              iconClass: 'service-journey-system-error-icon',
              popupClass: 'service-journey-system-error-popup'
            })
            .then(() => {
              thisObj.transitionTo('serviceRequest.status');
            });
        }
      });
      thisObj.set('queries.staffAssistDetail', data.basicAddDetails);
      thisObj.set('queries.userGroup', userGroup);
      thisObj.controllerFor('serviceRequest').set('customerFlowFlag', false);
      thisObj.set('queries.customerFlowFlag', false);
      thisObj.set('queries.customersData', data.customersData);
    } else {
      thisObj.controllerFor('serviceRequest').set('customerFlowFlag', true);
      thisObj.set('queries.customerFlowFlag', true);
    }
    thisObj.get('rdcLoadingIndicator').hideLoadingIndicator();
    /* CVD service call for frontline /branch */
    if (data.menuData.content.length) {
      data.menuData.forEach(menus => {
        if (menus.get('categoryName') == constants.breadCrumbsCategory) {
          this.get('breadcrumbService').set('breadcrumbEntries', menus.get('menuItems'));
        } else if (menus.get('categoryName') == constants.tabCategory) {
          menus.get('menuItems').forEach(tabItems => {
            if (tabItems['menu-item-id'] == constants.createRequestTabActive) {
              this.controllerFor('serviceRequest').set('createTabDisplay', true);
            } else if (tabItems['menu-item-id'] == constants.statusTabActive) {
              this.controllerFor('serviceRequest').set('statusTabDisplay', true);
            }
          });
          if (!this.controllerFor('serviceRequest').get('createTabDisplay')) {
            this.transitionTo('serviceRequest.status');
          }
        } else if (menus.get('categoryName') == constants.mostPopularCategory) {
          set(data, 'mostPopularRequests', menus.get('menuItems'));
        } else if (menus.get('categoryName') == constants.dropdownCategory) {
          let dropdownData = menus.get('menuItems').filter(function(dropdownItems) {
            if (dropdownItems['menu-items'] && dropdownItems['menu-items'].length) return dropdownItems;
          });
          set(data, 'otherServiceLinks', dropdownData);
        } else if (menus.get('categoryName') == constants.usefulLinksCategory) {
          set(data, 'usefulLinks', menus.get('menuItems'));
        } else if (menus.get('categoryName').toLowerCase() === 'banner') {
          if (!isEmpty(menus.get('menuItems'))) {
            this.controllerFor('serviceRequest').set('landingPageAlert', menus.get('menuItems'));
          }
        }
        if (this.get('queries.journeyTransition') && !this.get('queries.journeyTransitionCompleted')) {
          this.set('queries.journeyTransitionCompleted', true);
          let redirp = constants[this.get('queries.journeyTransition')];
          /* For NG & KE, the product selection page should be redirected to product-list.category..
           * THis can be removed once all the countries are migrated to this new design..
           */
          if (this.get('queries.journeyTransition') === 'APPLYPRODUCTS' && this.get('axwayConfig').country === 'NG') {
            redirp = constants[`${this.get('queries.journeyTransition')}_CATEGORY`];
            // For sending the queryparam to category route for routing to MK_F5 stepname for KE ETB (ZIBUKA).
            if (this.get('axwayConfig').country === 'KE') {
              newAccountOpening = true;
            }
          }
          let redirpa = this.get('queries.redirParam');
          let redirt = this.get('queries.redirTimeout');
          redirpa = redirpa ? redirpa.split(',') : [];
          // For sending the queryparam to category route for routing to MK_F5 stepname for KE ETB (ZIBUKA).
          if (newAccountOpening) {
            this.transitionTo(redirp, { queryParams: { newAccountOpening: true } });
          } else if (redirt) {
            later(() => {
              this.transitionTo.apply(this, [redirp, ...redirpa]);
            }, +redirt);
          } else {
            this.transitionTo.apply(this, [redirp, ...redirpa]);
          }
        }
      });
    } else {
      this.controllerFor('serviceRequest').set('createTabDisplay', false);
      this.transitionTo('serviceRequest.status');
    }
  },
  actions: {
    afterRenderEvent: function() {
      if (this.get('pointTo') && document.getElementById(this.get('pointTo'))) {
        document.getElementById(this.get('pointTo')).scrollIntoView();
        this.set('pointTo', null);
      }

      if (document.getElementById('tab-create-request'))
        document.getElementById('tab-create-request').className += ' active';
      if (
        this.currentModel.otherServiceLinks.length == 1 &&
        this.currentModel.otherServiceLinks[0]['menu-items'].length == 1
      )
        this.send('validateCvd', this.currentModel.otherServiceLinks[0]['menu-items'][0]['menu-item-id']);
    },
    error: function() {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.controllerFor('serviceRequest').set('systemErrorPopup', true);
      let message = this.get('i18n').t('ServiceRequest.COMMON.systemError');
      let title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          title,
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.controllerFor('serviceRequest').set('systemErrorPopup', false);
          this.transitionTo('serviceRequest.new-request');
        });
    },
    proceedClick(route, hrefUrl, params, subMenuId) {
      if (!route) {
        document.location.href = hrefUrl;
      } else {
        if (params) {
          let queryObj = {};
          let queryParams = params.split('|');
          queryParams.forEach(element => {
            queryObj[element.split(':')[0]] = element.split(':')[1];
          });
          this.transitionTo(route, { queryParams: queryObj });
        } else {
          if (this.get('basicAdditionalValParam')) {
            if (
              this.controllerFor('service-request.new-request').get('selectedFeeType') &&
              this.controllerFor('service-request.new-request').get('selectedFeeType')[0] == subMenuId
            ) {
              this.transitionTo(route);
            } else {
              this.send('validateCvd', subMenuId);
            }
          } else {
            this.transitionTo(route);
          }
        }
      }
    },
    addDetails: function(key) {
      this.controller.set('selectedAddVerification', key);
      this.send('mandatoryCheckAddBasic');
      this.set('queries.selectedAddVerification', this.controller.get('selectedAddVerification'));
    },
    basicDetails: function(key) {
      this.controller.set('selectedBasicVerification', key);
      this.send('mandatoryCheckAddBasic');
      this.set('queries.selectedBasicVerification', this.controller.get('selectedBasicVerification'));
    },
    mandatoryCheckAddBasic: function() {
      let basicVal = false;
      let AddVal = false;

      if (this.currentModel.addVerifyMandatary) {
        if (
          this.controller.get('selectedAddVerification') &&
          this.controller.get('selectedAddVerification').key != ''
        ) {
          basicVal = true;
        } else {
          basicVal = false;
        }
      } else {
        basicVal = true;
      }
      if (this.currentModel.basicVerifyMandatary) {
        if (
          this.controller.get('selectedBasicVerification') &&
          this.controller.get('selectedBasicVerification').key != ''
        ) {
          AddVal = true;
        } else {
          AddVal = false;
        }
      } else {
        AddVal = true;
      }

      if (basicVal && AddVal) {
        this.set('additionVerificationNeeded', false);
      } else {
        this.set('additionVerificationNeeded', true);
      }
      set(this.currentModel, 'additionVerificationNeeded', this.get('additionVerificationNeeded'));
    },
    willTransition: function() {
      if (document.getElementById('tab-create-request')) {
        document.getElementById('tab-create-request').classList.remove('active');
      }
    },
    validateCvd(subMenuId) {
      if (this.get('basicAdditionalValParam')) {
        let addVerifyMandatary = false;
        let basicVerifyMandatary = false;
        let selectedFeeType = [];
        this.controller.set('selectedAddVerification', '');
        this.controller.set('selectedBasicVerification', '');
        if (this.currentModel.basicAddDetails) {
          this.currentModel.basicAddDetails.forEach(childNode => {
            if (!childNode.data.errorCode) {
              childNode.get('srDetails').forEach(canonicalStateVal => {
                if (canonicalStateVal.id == subMenuId) {
                  if (canonicalStateVal.get('addVerifyMandatary') == 'Y') {
                    addVerifyMandatary = true;
                  }
                  if (canonicalStateVal.get('basicVerifyMandatary') == 'Y') {
                    basicVerifyMandatary = true;
                  }

                  if (childNode.get('basicVerification').length == 1) {
                    set(this.controller, 'selectedBasicVerification', childNode.get('basicVerification')[0]);
                    this.set('queries.selectedBasicVerification', this.controller.get('selectedBasicVerification'));
                  }
                  if (childNode.get('additionalVerification').length == 1) {
                    set(this.controller, 'selectedAddVerification', childNode.get('additionalVerification')[0]);
                    this.set('queries.selectedAddVerification', this.controller.get('selectedAddVerification'));
                  }
                  selectedFeeType.push(subMenuId);
                }
              });
            }
          });
        }
        if (!basicVerifyMandatary && !addVerifyMandatary) {
          this.set('currentModel.additionVerificationNeeded', false);
        } else {
          this.set('currentModel.additionVerificationNeeded', true);
        }
        this.set('currentModel.basicAddDetailsFlag', true);
        this.set('currentModel.addVerifyMandatary', addVerifyMandatary);
        this.set('currentModel.basicVerifyMandatary', basicVerifyMandatary);
        this.send('mandatoryCheckAddBasic');
        this.controllerFor('service-request.new-request').set('selectedFeeType', selectedFeeType);
        later(function() {
          document.getElementById('cvd-Item-Id').scrollIntoView();
        }, 5);
      }
    }
  }
});
