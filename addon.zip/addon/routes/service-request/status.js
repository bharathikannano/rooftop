/* eslint-disable complexity */
import { A } from '@ember/array';
import { schedule } from '@ember/runloop';
import { hash } from 'rsvp';
import { computed } from '@ember/object';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import config from '../../config/environment';
import constants from '../../constants';
import { Promise as EmberPromise } from 'rsvp';
import { isEqual } from '@ember/utils';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  queries: service('customer-info'),
  idle: service('idle-ticker'),
  router: service(),
  creditCardData: null,
  debitCardData: null,
  statusActiveData: null,
  debitCardDataLoaded: false,
  creditCardDataLoaded: false,
  offset: 0,
  footerText: computed({
    get() {
      return this.get('i18n').t('ServiceRequest.STATUSENQUIRY.statusOfRecords.' + this.get('queries.countryName'))
        .string
        ? this.get('i18n').t('ServiceRequest.STATUSENQUIRY.statusOfRecords.' + this.get('queries.countryName'))
        : this.get('i18n').t('ServiceRequest.STATUSENQUIRY.statusOfRecords');
    }
  }),
  limit: computed('media.isMobile', {
    get() {
      if (this.get('media.isMobile')) return 5;
      else return 10;
    }
  }),
  country: service('customer-info'),
  queryParams: {
    limit: {
      refreshModel: true
    },
    offset: {
      refreshModel: true
    }
  },
  model() {
    this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
    this.get('rdcLoadingIndicator').setThemeClass('ui10');
    //this.get('idle').resetTimer();
    if (!this.get('statusActiveData') || this.get('offset') <= 0)
      this.set(
        'statusActiveData',
        this.get('store').query('service-request', {
          filter: {
            'service-requests': {
              status: {
                EQ: 'PROCESSING'
              }
            }
          },
          sort: 'statusOrder,-dateOrder'
        })
      );
    const promiseProcessing = this.get('statusActiveData');
    const promiseCompleted = this.get('store').query('service-request', {
      filter: {
        'service-requests': {
          status: {
            NEQ: 'PROCESSING'
          }
        }
      },
      page: {
        limit: this.get('limit'),
        offset: this.get('offset')
      },
      sort: 'statusOrder,-dateOrder'
    });
    this.controllerFor('serviceRequest').set('activePage', constants.statusBreadcrumbActive);

    return hash({
      processingGroup: promiseProcessing,
      completedGroup: promiseCompleted
    });
  },
  afterModel(statusdetails) {
    let processCreditReq, processDebitReq, completeCreditReq, completeDebitReq;
    if (statusdetails) {
      if (!this.get('media.isMobile') && this.get('offset') >= 10) {
        statusdetails.processingGroup = null;
      } else {
        statusdetails.processingGroup.forEach(statusRecords => {
          statusRecords.set('serviceTypeValue', statusRecords.get('serviceTypeEn'));
          statusRecords.set('operationName', statusRecords.additionalInfo.OperationName);
          statusRecords.get('payload').products.forEach(str => {
            statusRecords.set('subProduct', str.subProductType);
            if (
              (str.productType && str.productType.toUpperCase() == 'CREDIT CARD') ||
              (str.productType && str.productType.toUpperCase() == 'DEBIT CARD') ||
              (str.productType && str.productType.toUpperCase() == 'CREDIT CARD LOAN ACCOUNT') ||
              (str.productType && str.productType.toUpperCase() == 'ATM CARD') ||
              (str.productType && str.productType.toUpperCase() == 'COMBO CARD') ||
              (str.productCategory && str.productCategory.toUpperCase() == 'CCFEEWAIVER')
            ) {
              statusRecords.set('cardBlockFlag', true);
              if (isEqual(statusRecords.get('operationName'), 'POSLMTUT')) {
                str.operationName = 'POSLMTUT';
              }
              if (!this.get('creditCardDataLoaded')) {
                this.set('creditCardDataLoaded', true);
                processCreditReq = this.get('store')
                  .findAll('credit-card')
                  .then(
                    data => {
                      this.set('creditCardData', data);
                    },
                    () => {}
                  );
              }
              if (!this.get('debitCardDataLoaded')) {
                if (config.cards != 'credit') {
                  this.set('debitCardDataLoaded', true);
                  processDebitReq = this.get('store')
                    .findAll('debit-card')
                    .then(
                      data => {
                        this.set('debitCardData', data);
                      },
                      () => {}
                    );
                }
              }
            }
          });
        });
      }

      statusdetails.completedGroup.forEach(statusRecords => {
        statusRecords.set('serviceTypeValue', statusRecords.get('serviceTypeEn'));
        statusRecords.set('operationName', statusRecords.additionalInfo.OperationName);
        statusRecords.get('payload').products.forEach(str => {
          statusRecords.set('subProduct', str.subProductType);
          if (
            (str.productType && str.productType.toUpperCase() == 'CREDIT CARD') ||
            (str.productType && str.productType.toUpperCase() == 'DEBIT CARD') ||
            (str.productType && str.productType.toUpperCase() == 'CREDIT CARD LOAN ACCOUNT') ||
            (str.productType && str.productType.toUpperCase() == 'ATM CARD') ||
            (str.productType && str.productType.toUpperCase() == 'COMBO CARD') ||
            (str.productCategory && str.productCategory.toUpperCase() == 'CCFEEWAIVER')
          ) {
            statusRecords.set('cardBlockFlag', true);
            if (isEqual(statusRecords.get('operationName'), 'POSLMTUT')) {
              str.operationName = 'POSLMTUT';
            }
            if (!this.get('creditCardDataLoaded')) {
              this.set('creditCardDataLoaded', true);
              completeCreditReq = this.get('store')
                .findAll('credit-card')
                .then(
                  data => {
                    this.set('creditCardData', data);
                  },
                  () => {}
                );
            }
            if (!this.get('debitCardDataLoaded')) {
              if (config.cards != 'credit') {
                this.set('debitCardDataLoaded', true);
                completeDebitReq = this.get('store')
                  .findAll('debit-card')
                  .then(
                    data => {
                      this.set('debitCardData', data);
                    },
                    () => {}
                  );
              }
            }
          }
        });
      });
    }
    let promises = [processCreditReq, processDebitReq, completeCreditReq, completeDebitReq];
    EmberPromise.all(promises).finally(() => {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
    });
    if (this.get('offset') > 0 && !statusdetails.processingGroup) {
      statusdetails.showNoActive = false;
    } else statusdetails.showNoActive = true;

    statusdetails.footerText = this.get('i18n').t(
      'ServiceRequest.STATUSENQUIRY.statusOfRecords.' + this.get('queries.countryName')
    ).string
      ? this.get('i18n').t('ServiceRequest.STATUSENQUIRY.statusOfRecords.' + this.get('queries.countryName'))
      : this.get('i18n').t('ServiceRequest.STATUSENQUIRY.statusOfRecords');
    schedule('afterRender', this, function() {
      this.send('afterRenderEvent');
    });
  },
  resetController() {
    this.get('store').unloadAll('credit-card');
    this.get('store').unloadAll('debit-card');
    this.set('offset', 0);
    this.set('creditCardDataLoaded', false);
    this.set('debitCardDataLoaded', false);
  },
  actions: {
    afterRenderEvent: function() {
      if (this.currentModel && this.currentModel.processingGroup) {
        this.controllerFor('serviceRequest').set(
          'totalActiveCount',
          this.currentModel.processingGroup.meta.activeRecordsCount
        );
        this.controller.set('operatorChannel', this.currentModel.processingGroup.meta.operatorChannel);
      }
    },
    error: function() {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.controllerFor('serviceRequest').set('systemErrorPopup', true);
      try {
        this.controllerFor('chequeRequest').set('errorType', 'systemError');
      } catch (e) {
        this.send('error', e);
      }
      let message = this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName'), {
        default: 'ServiceRequest.COMMON.systemError'
      });
      if (
        this.get('router.currentRouteName').indexOf('card-block') != -1 ||
        this.get('router.currentRouteName').indexOf('card-replacement') != -1
      ) {
        if (this.get('router.currentRouteName').indexOf('card-block') != -1) {
          message = this.get('i18n').t('ServiceRequest.COMMON.genericError.' + this.get('queries.countryName') + 'CB', {
            default: 'ServiceRequest.COMMON.genericError.' + this.get('queries.countryName')
          });
        } else {
          message = this.get('i18n').t('ServiceRequest.COMMON.genericError.' + this.get('queries.countryName') + 'CR', {
            default: 'ServiceRequest.COMMON.genericError.' + this.get('queries.countryName')
          });
        }
      }
      let title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          title,
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.controllerFor('serviceRequest').set('systemErrorPopup', false);
          this.controllerFor('serviceRequest').set('statusActive', false);
          this.controllerFor('serviceRequest').set('newActive', true);
          this.transitionTo('serviceRequest.new-request');
        });
    },
    resetVariables: function() {
      if (this.get('media.isMobile')) this.set('limit', 5);
      else this.set('limit', 10);
    },
    statusShowDetail: function(status) {
      let scope = this;
      let statusDescriptionHideIconDisplay = true;
      if (status.get('payload').products.length <= 0) {
        status.set('custFlag', true);
      }
      status.get('payload').products.forEach(str => {
        if (
          (str.productType && str.productType.toUpperCase() == 'CREDIT CARD') ||
          (str.productType && str.productType.toUpperCase() == 'DEBIT CARD') ||
          (str.productType && str.productType.toUpperCase() == 'CREDIT CARD LOAN ACCOUNT') ||
          (str.productType && str.productType.toUpperCase() == 'ATM CARD') ||
          (str.productType && str.productType.toUpperCase() == 'COMBO CARD') ||
          (str.productCategory && str.productCategory.toUpperCase() == 'CCFEEWAIVER')
        ) {
          let creditCards = A();
          let debitCards = A();
          status.get('payload').products.forEach(function(statusRecords) {
            statusRecords.ccimagesfromjs = 'rdc-ui-adn-components/assets/svg/icons/sr-no-card.svg';
            if (statusRecords.status == 'FAILED' || statusRecords.status == 'REJECTED') {
              statusDescriptionHideIconDisplay = false;
            }
            if (
              (statusRecords.productType && statusRecords.productType.toUpperCase() == 'CREDIT CARD') ||
              (statusRecords.productType && statusRecords.productType.toUpperCase() == 'CREDIT CARD LOAN ACCOUNT') ||
              (statusRecords.productType && statusRecords.productType.toUpperCase() == 'COMBO CARD') ||
              (str.productCategory && str.productCategory.toUpperCase() == 'CCFEEWAIVER')
            ) {
              if (scope.get('creditCardData')) {
                scope.get('creditCardData').forEach(function(creditCardList) {
                  if (creditCardList.get('cardNum') == statusRecords.accountNumber) {
                    statusRecords.cardImageName = creditCardList.get('cardImageName');
                    let cardName = creditCardList.get('cardImageName');
                    statusRecords.descCode = creditCardList.get('descCode');
                    statusRecords.cardType = 'Credit Card';
                    if (cardName.length > 0) {
                      statusRecords.ccimagesfromjs =
                        'https://av.sc.com/configuration/content/images/' + cardName + '.png';
                    }
                    statusRecords.desc = creditCardList.get('desc');

                    return;
                  }
                });
              }
              creditCards.push(statusRecords);
            } else if (
              (statusRecords.productType && statusRecords.productType.toUpperCase() == 'DEBIT CARD') ||
              (statusRecords.productType && statusRecords.productType.toUpperCase() == 'ATM CARD')
            ) {
              if (scope.get('debitCardData')) {
                scope.get('debitCardData').forEach(function(debitCardList) {
                  if (debitCardList.get('cardNum') == statusRecords.accountNumber) {
                    statusRecords.cardImageName = debitCardList.get('cardImageName');
                    statusRecords.descCode = debitCardList.get('descCode');
                    statusRecords.cardType = 'Debit Card';
                    let cardName = debitCardList.get('cardImageName');
                    if (cardName.length > 0) {
                      statusRecords.ccimagesfromjs =
                        'https://av.sc.com/configuration/content/images/' + cardName + '.png';
                    }
                    statusRecords.desc = debitCardList.get('desc');

                    return;
                  }
                });
              }
              debitCards.push(statusRecords);
            }
          });
          if (creditCards.length >= 1) status.set('creditCardGroup', creditCards);
          if (debitCards.length >= 1) status.set('debitCardGroup', debitCards);
        } else {
          status.get('payload').products.forEach(function(statusRecords) {
            if (statusRecords.status == 'FAILED' || statusRecords.status == 'REJECTED') {
              statusDescriptionHideIconDisplay = false;
            }
            if (statusRecords.productType && statusRecords.productType.toLowerCase() == 'customer') {
              status.set('custFlag', true);
            }
          });
        }
        status.set('statusDescriptionHideIconDisplay', statusDescriptionHideIconDisplay);
      });
    },
    statusMobPagination: function(value) {
      this.set('limit', value.mobileLimit);
      this.set('offset', this.get('offset'));
      this.get('rdcLoadingIndicator')
        .showLoadingIndicatorForPromise(
          this.get('store').query('service-request', {
            filter: {
              'service-requests': {
                status: {
                  NEQ: 'PROCESSING'
                }
              }
            },
            page: {
              limit: this.get('limit'),
              offset: this.get('offset')
            },
            sort: 'statusOrder,-dateOrder'
          })
        )
        .then(
          completedData => {
            this.get('currentModel').completedGroup.set('content', completedData.content);
          },
          error => {
            this.send('error', error);
          }
        );
      this.refresh();
    },
    paginationChange: function(value) {
      let offsetVal = value * 10 - 10;
      this.set('offset', offsetVal);
      this.set('limit', 10);
      this.get('rdcLoadingIndicator')
        .showLoadingIndicatorForPromise(
          this.get('store').query('service-request', {
            filter: {
              'service-requests': {
                status: {
                  NEQ: 'PROCESSING'
                }
              }
            },
            page: {
              limit: this.get('limit'),
              offset: this.get('offset')
            },
            sort: 'statusOrder,-dateOrder'
          })
        )
        .then(
          completedData => {
            this.get('currentModel').completedGroup.set('content', completedData.content);
          },
          error => {
            this.send('error', error);
          }
        );
    },
    willTransition: function(transition) {
      if (!(transition.intent.name == 'rdc-ui-eng-service-requests.serviceRequest.status')) {
        this.send('resetVariables');
      }
    }
  }
});
