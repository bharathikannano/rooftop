import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { hash } from 'rsvp';
import { isEmpty } from '@ember/utils';
import { A } from '@ember/array';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';

export default Route.extend(quickEvent, {
  i18n: service(),
  cardErrorHandler: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  store: service(),
  queries: service('customer-info'),

  model() {
    return hash({
      reviewDetails: this.controllerFor('signature-update.select-product').signatureData,
      fileName: this.controllerFor('signature-update.select-product').signatureData.fileDetails.previews[0]
        .previewfilename
    });
  },
  setupController(controller) {
    this._super(...arguments);
    let countryCd = this.get('queries').countryName;
    controller.setProperties({
      maskConfig: this.get('queries').loanMaskConfig(),
      countryCd: countryCd,
      cardMasking: countryCd !== 'SG' ? true : false
    });
  },
  actions: {
    error(error) {
      if (error.name !== 'OTPCancelledError') {
        this.get('cardErrorHandler').systemErrorPopup(this);
      }
    },

    navigateTo() {
      this.send('goToPage', 'signature-update.review-signature');
    },

    navigateConfirm() {
      let controller = this.controller.get('model').reviewDetails;
      let signatureUpdate = A([]);
      let serviceRequest = null;
      let accounts = controller.selectedCards;
      if (this.controller.countryCd === 'SG') {
        accounts.forEach(item => {
          let selectedValue = ((productType, accountNo, CurrencyCode) => ({
            productType,
            accountNo,
            CurrencyCode
          }))(item.depositProductCode ? 'TD' : 'CASA', item.getNum, item.currencyCode);
          signatureUpdate.pushObject(selectedValue);
        });
        signatureUpdate.pushObject({ isDocAvailable: 'Y' });
        serviceRequest = {
          operationName: 'SIGNUPDT',
          customerDetails: {
            relationshipNo: controller.selectedCards[0].relId,
            customerName: controller.selectedCards[0].custName
          },
          signatureUpdate: signatureUpdate,
          docInfoDetails: [
            {
              documentType: 'T0308',
              documentUniqueReferenceNo: controller.refNo[0]
            }
          ],
          docList: [[controller.refNo[0]]]
        };
      } else {
        serviceRequest = {
          operationName: 'SIGNUPDT',
          AccountNumber: controller.selectedCards[0].getNum,
          customerDetails: {
            relationshipNo: controller.selectedCards[0].relId,
            customerName: controller.selectedCards[0].custName
          },
          signatureUpdate: {
            productType: 'CASA',
            accountNo: controller.selectedCards[0].getNum,
            isDocAvailable: 'Y'
          },
          docInfoDetails: [
            {
              documentType: 'T0308',
              documentUniqueReferenceNo: controller.refNo[0]
            }
          ],
          docList: [[controller.refNo[0]]]
        };
      }
      let postData = {
        status: 'INIT',
        payload: {
          serviceRequests: serviceRequest
        },
        documentList: [controller.refNo[0]],
        relNumber: controller.selectedCards[0].relId,
        serviceType: 'SIGNUPDT',
        isDocAvailable: 'Y',
        isCritical: false,
        statusOrder: 0,
        dateOrder: 0,
        isPartialSave: false
      };
      this.get('store').unloadAll('service-request');
      const signaturePost = this.get('store')
        .createRecord('service-request', postData)
        .save()
        .then(
          item => {
            this.controllerFor('signature-update.select-product').set('srrefNo', item.id);
            this.transitionTo('signature-update.status');
          },
          error => {
            if (!isEmpty(error.errors) && !isEmpty(error.errors[0])) {
              this.set('message', this.get('i18n').t('ServiceRequest.signatureUpdate.errorMsg.title.invalidMobNo'));
              this.get('cardErrorHandler').pageErrorPopup(this);
            } else if (error.code === 'CSL-OTP-1328') {
              this.set('message', this.get('i18n').t('ServiceRequest.signatureUpdate.errorMsg.title.maxTryMobileNo'));
              this.get('cardErrorHandler').pageErrorPopup(this);
            }
          }
        );
      this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(signaturePost);
    }
  }
});
