import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { hash } from 'rsvp';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';
import { isEmpty } from '@ember/utils';

export default Route.extend(quickEvent, {
  queries: service('customer-info'),

  model() {
    const signatureData = this.controllerFor('signature-update.select-product').signatureData.fileDetails;
    return hash({
      preview: signatureData.previews[0].preview,
      countryCode: this.get('queries').countryName
    });
  },

  actions: {
    navigateTo(routeName) {
      if (isEmpty(routeName)) {
        routeName = 'signature-update.upload-signature';
      }
      this.send('goToPage', routeName);
    }
  }
});
