import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import constants from '../../constants';
import { hash } from 'rsvp';
import { isEmpty } from '@ember/utils';
import { A } from '@ember/array';
import config from 'rdc-ui-eng-service-requests/config/environment';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';

export default Route.extend(quickEvent, {
  store: service(),
  i18n: service(),
  customerInfo: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  router: service(),
  cardErrorHandler: service(),
  bonusSaverFilters: A(['337', '338', '514']),

  model() {
    let countryCode = this.get('customerInfo').countryName;
    let requestDetails = this.get('store')
      .query('casa', {
        filter: config.signUpdateFilters[countryCode]
      })
      .then(
        data => {
          return data;
        },
        () => {
          this.get('cardErrorHandler').systemErrorPopup(this);
        }
      );
    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(requestDetails);
    return hash({
      requestDetails: requestDetails,
      nocardsContent: this.get('i18n').t('ServiceRequest.signatureUpdate.errorMsg.title.casa'),
      countryCode: countryCode
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    try {
      let savingAccountDetails,
        timeAccountDetails = null;
      let curRoutename = this.get('router.currentRouteName');
      let getDetails = {};
      if (curRoutename !== null && curRoutename.indexOf('new-request') !== -1) {
        controller.set('signatureData', getDetails);
      }
      model.requestDetails.filterBy('isSelected').length > 0
        ? controller.set('disableNext', false)
        : controller.set('disableNext', true);
      controller.setProperties({
        displayContent: 'casa',
        selectedValue: null
      });
      if (model.countryCode === 'SG') {
        timeAccountDetails = this.tdAccountSeg(model.requestDetails);
        savingAccountDetails = this.casaAccountSeg(model.requestDetails);
        let bonusAccounts = model.requestDetails.filter(account => {
          return this.bonusSaverFilters.includes(account.productCode) && account.currencyCode.indexOf('SGD') !== -1;
        });
        bonusAccounts.forEach((item, i) => {
          savingAccountDetails.pushObject(item);
        });
        let eligibleAccFlag = savingAccountDetails.length > 0 || timeAccountDetails.length > 0 ? true : false;
        if (eligibleAccFlag) {
          controller.setProperties({
            savingAccount: savingAccountDetails,
            timeAccount: timeAccountDetails,
            selectAll: this.get('i18n').t('ServiceRequest.COMMON.text.selectAll'),
            multipleSelect: true,
            selectAccountLbl:
              savingAccountDetails.length === 0
                ? this.get('i18n').t('ServiceRequest.signatureUpdate.header.title.accountSelectLabel')
                : null
          });
        } else {
          delete this.controller.model.requestDetails;
        }
      } else {
        savingAccountDetails = model.requestDetails.filter(account => {
          return account;
        });
        controller.setProperties({
          savingAccount: savingAccountDetails,
          selectAll: false,
          multipleSelect: false
        });
      }
    } catch (e) {
      controller.set('disableNext', true);
    }
  },
  tdAccountSeg(accounts) {
    let tdProdCodeFilter = constants.signatureUpdate.prodCodeForTD;
    let tdAccountDetails = accounts.filter(account => {
      return account.depositProductCode && tdProdCodeFilter.includes(account.depositProductCode);
    });
    return tdAccountDetails;
  },
  casaAccountSeg(accounts) {
    let tdProdCodeFilter = constants.signatureUpdate.prodCodeForCASA;
    let operatingInsFilter = constants.signatureUpdate.operatingInsCASA;
    let casaDetails = accounts.filter(account => {
      return (
        !account.depositProductCode &&
        tdProdCodeFilter.includes(account.productCode) &&
        operatingInsFilter.includes(account.operatingInstructions)
      );
    });
    return casaDetails;
  },
  actions: {
    navigateTo() {
      this.get('store').unloadAll('casa');
      this.send('goToPage', 'serviceRequest.new-request');
    },
    navigateConfirm(model) {
      let cardDetails = A();
      const modalVal = model.requestDetails.filterBy('isSelected');
      if (!isEmpty(modalVal)) {
        if (modalVal.length > 30 && model.countryCode === 'SG') {
          let message = this.get('i18n').t('ServiceRequest.signatureUpdate.errorMsg.title.cardLimitMsg');
          this.get('rdcModalManager').showDialogModal({
            level: 'info',
            message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.ok'),
            iconClass: 'service-journey-info-icon',
            popupClass: 'service-journey-info-popup'
          });
        } else {
          modalVal.forEach(item => {
            let selectedValue = ((getNum, getDesc, relId, custName, depositProductCode, currencyCode) => ({
              getNum,
              getDesc,
              relId,
              custName,
              depositProductCode,
              currencyCode
            }))(
              item.get('accountNumber'),
              item.get('productDescription'),
              item.get('relId'),
              item.get('ownerName'),
              item.get('depositProductCode'),
              item.get('currencyCode')
            );
            cardDetails.pushObject(selectedValue);
          });
          this.controller.set('signatureData.selectedCards', cardDetails);
          this.transitionTo('signature-update.verify-signature');
        }
      }
    },
    enableNext() {
      if (
        this.controller.get('model').requestDetails.filterBy('isSelected') !== undefined &&
        this.controller.get('model').requestDetails.filterBy('isSelected').length > 0
      ) {
        this.controller.set('disableNext', false);
      } else {
        this.controller.set('disableNext', true);
      }
    }
  }
});
