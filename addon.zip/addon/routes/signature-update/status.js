import Route from '@ember/routing/route';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';
import { inject as service } from '@ember/service';

export default Route.extend(quickEvent, {
  customerInfo: service(),

  setupController(controller) {
    let refNo = this.controllerFor('signature-update.select-product').srrefNo;
    controller.setProperties({
      refNo: refNo,
      countryFlag: this.customerInfo.countryName !== 'SG' ? true : false
    });
	this.controllerFor('signature-update').set('leftIcon', '');
  },

  actions: {
    navigateStatus() {
      this.send('goToPage', 'serviceRequest.status');
    }
  }
});
