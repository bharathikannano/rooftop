import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';

export default Route.extend(quickEvent, {
  i18n: service(),
  rdcFileUpload: service(),
  refNo: A(),
  filename: A(),
  value: A(),
  preview: A(),
  customerInfo: service(),
  deletedVal: A(),
  allowSuffix: A(['jpg', 'jpeg', 'png']),
  dispFlag: true,

  setupController(controller) {
    this._super(...arguments);
    let signatureData = this.controllerFor('signature-update.select-product').signatureData.fileDetails;
    if (!isEmpty(signatureData)) {
      if (signatureData['previews'].length === 1 && !signatureData.previews[0].hasError) {
        this.set('dispFlag', false);
      } else {
        this.set('dispFlag', true);
      }
    } else {
      this.set('dispFlag', true);
    }
    controller.setProperties({
      disableNext: this.get('dispFlag'),
      disableBack: false,
      previews: !isEmpty(signatureData) ? signatureData['previews'] : null,
      value: !isEmpty(signatureData) ? this.value : A(),
      documentType: 'T0308',
      allowSuffix: this.allowSuffix,
      countryCode: this.get('customerInfo').countryName,
      uploadLabel: this.get('media.isMobile')
        ? this.get('i18n').t('ServiceRequest.signatureUpdate.header.title.fileUploadLabelMobile')
        : this.get('i18n').t('ServiceRequest.signatureUpdate.header.title.fileUploadLabelDesktop')
    });
  },
  __enableBack() {
    this.controller.set('disableBack', false);
  },
  __enableNext() {
    this.refNo.length > 0 ? this.controller.set('disableNext', false) : this.controller.set('disableNext', true);
  },
  __disableNext() {
    this.controller.set('disableNext', true);
  },
  __disableBack() {
    this.controller.set('disableBack', true);
  },
  _resetFileUpload() {
    if (this.controller.previews.length === 0) {
      this.controller.set('previews', A());
      this.controller.set('value', A());
    }
  },
  actions: {
    onFileupload(value) {
      let signatureData = this.controllerFor('signature-update.select-product').signatureData;
      this.value.pushObject(value);
      if (!value.hasError) {
        this.refNo.pushObject(value.refNo);
        this.filename.pushObject(value.previewfilename);
        this.preview.pushObject(value.preview);
        signatureData['refNo'] = this.refNo;
        signatureData['filename'] = this.filename;
        signatureData['preview'] = this.preview;
        signatureData['value'] = this.value;
        this.__enableNext();
        this.__enableBack();
      } else {
        this.__disableNext();
      }
    },
    onFiledelete() {
      this.value.clear();
      this.refNo.clear();
      this.filename.clear();
      this.preview.clear();
      this._resetFileUpload();
      this.__enableNext();
      this.__enableBack();
    },
    onChangeFile() {
      this.__disableBack();
      this.__disableNext();
    },
    deletingProgress() {
      this._resetFileUpload();
      this.__disableBack();
      this.__disableNext();
      if (
        this.controller.previews.length === 1 &&
        !this.controller.previews[0].hasError &&
        this.controller.previews[0].completedPercentage === 100
      ) {
        this.__enableNext();
        this.__enableBack();
      } else {
        this.__enableBack();
      }
    },

    navigateTo(routeName) {
      let successFileUpload = this.controller.previews.filter(account => {
        return !account.hasError && account.completedPercentage !== 100;
      });

      if (isEmpty(routeName)) {
        routeName = 'signature-update.verify-signature';
      }
      this.controllerFor('signature-update.select-product').set('signatureData.fileDetails', this.controller);
      if (!(successFileUpload.length > 0)) {
        this.send('goToPage', routeName);
      }
    }
  }
});
