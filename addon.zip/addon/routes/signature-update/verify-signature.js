import Route from '@ember/routing/route';
import quickEvent from 'rdc-ui-eng-service-requests/mixins/quick-event';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import { hash } from 'rsvp';

export default Route.extend(quickEvent, {
  customerInfo: service(),

  model() {
    return hash({
      countryCode: this.get('customerInfo').countryName
    });
  },

  actions: {
    navigateTo(routeName) {
      if (isEmpty(routeName)) {
        routeName = 'signature-update.select-product';
      }
      this.send('goToPage', routeName);
    }
  }
});
