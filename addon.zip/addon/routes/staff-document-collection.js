import fereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';
import config from '../config/environment';
import { isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';

export default fereFormRoute.extend({
  axwayConfig: service(),
  iframeManager: service(),
  otpManager: service(),
  rdcLoadingIndicator: service(),
  store: service(),
  i18n: service(),
  queryParams: {
    flow: {
      refreshModel: true
    }
  },
  beforeModel(params) {
    this._super(...arguments);
    // Setting the flow from params to set the header content in Nav bar.
    this.controllerFor('staff-document-collection').setProperties({
      flow: params.queryParams.flow,
      data: JSON.parse(params.queryParams.data)
    });
  },
  queryParams: computed('axwayConfig', {
    get() {
      return {
        filter: {
          stepName: 'AGT_RUN',
          countryCode: this.get('axwayConfig.country'),
          id: 'W400',
          staffId: this.get('axwayConfig.staffId'),
          staffLocation: 'ABC'
        }
      };
    }
  }),
  afterModel() {
    this._super(...arguments);
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },
  actions: {
    // Going back to staff assist landing page.
    goBack() {
      this.get('rdcLoadingIndicator').showLoadingIndicator();
      this.transitionTo('staff-document-dashboard');
    },
    // To quit the page.
    closePage() {
      window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
    }
  }
});
