import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { hash } from 'rsvp';
import EmberObject from '@ember/object';
import { isEmpty } from '@ember/utils';

export default Route.extend({
  rdcLoadingIndicator: service(),
  axwayConfig: service(),
  store: service(),

  model() {
    let data = this.get('store').query('service-request', {
      filter: {
        status: 'PENDING',
        staffId: this.get('axwayConfig.staffId'),
        operationName: 'DOCENQ'
      }
    });
    return hash({
      data: data
    });
  },
  afterModel() {
    this._super(...arguments);
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },
  setupController(controller, model) {
    this._super(...arguments);
    // Setting the data to array for displaying the 1st page data and other default values.
    controller.setProperties({
      pendingData: isEmpty(model.data) ? [] : model.data.map(item => item),
      current_page: 1,
      records_per_page: 10
    });
    // TO set the total no.of pages
    controller.set('totalPages', Math.ceil(model.data.length / controller.records_per_page));
    // To initate pagination.
    this._changePage(controller.current_page);
  },
  // To change page during pagination.
  _changePage(page) {
    // returning if model data is empty.
    if (isEmpty(this.currentModel.data)) {
      return;
    }

    // Validate page
    if (page < 1) page = 1;
    if (page > this.controller.totalPages) page = this.controller.totalPages;

    // Filtering the data for showing page wise.
    let pageWiseArray = this.currentModel.data.slice(
      (page - 1) * this.controller.records_per_page,
      page * this.controller.records_per_page
    );

    this.controller.set('pendingData', pageWiseArray);
    this.controller.set('pageNumber', page);

    // Enabling disabling next and prev button based on condition.
    if (page === 1) {
      this.controller.set('hidePrev', true);
    } else {
      this.controller.set('hidePrev', false);
    }

    if (page === this.controller.totalPages) {
      this.controller.set('hideNext', true);
    } else {
      this.controller.set('hideNext', false);
    }
  },
  actions: {
    // Going back to staff assist landing page.
    goBack() {
      this.get('rdcLoadingIndicator').showLoadingIndicator();
      this.transitionTo('staff-product-category');
    },
    // To quit the page.
    closePage() {
      window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
    },
    // TO Move to document collection journey.
    moveToDocumentCollection(flow, data) {
      // Re-directing to the main journey based on the flow type.
      // passing the req params to show in the terminate flow component.
      this.get('rdcLoadingIndicator').showLoadingIndicator();
      let reqObj = EmberObject.create({
        id: data.id,
        status: data.status,
        additionalInfo: {
          customerName: data.additionalInfo.customerName,
          employerName: data.additionalInfo.employerName
        }
      });
      this.transitionTo('staff-document-collection', {
        queryParams: {
          flow: flow,
          data: JSON.stringify(reqObj),
          // Below to pass the queryparam directly to form call.
          filter: JSON.stringify({
            flowType: flow,
            eopsTxnRefNo: data.hostReceiptId,
            sourceRefNo: data.id
          })
        }
      });
    },
    // On click of prev button
    prevPage() {
      if (this.controller.current_page > 1) {
        this.controller.set('current_page', this.controller.current_page - 1);
        this._changePage(this.controller.current_page);
      }
    },
    // On click of next button
    nextPage() {
      if (this.controller.current_page < this.controller.totalPages) {
        this.controller.set('current_page', this.controller.current_page + 1);
        this._changePage(this.controller.current_page);
      }
    }
  }
});
