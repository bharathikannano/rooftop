import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import config from '../config/environment';
import { isEmpty } from '@ember/utils';
export default Route.extend({
  customerInfo: service(),
  axwayConfig: service(),
  i18n: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  prodCategory: null,
  queryParams: {
    staffName: {
      refreshModel: true
    },
    prodCategory: {
      refreshModel: true
    }
  },
  validateProductSelection(categoryId) {
    if (this.prodCategory.includes(categoryId)) {
      return true;
    } else {
      return false;
    }
  },
  model(params) {
    this.controllerFor('staff-product-category').setProperties({
      staffName: params.staffName,
      staffId: this.get('axwayConfig.staffId')
    });
    let today = new Date();
    let loginDateTime =
      today.getDate() +
      ' ' +
      today.toLocaleString('default', { month: 'short' }) +
      ' ' +
      today.getFullYear() +
      ', ' +
      today.toLocaleTimeString([], { hour12: true, hour: '2-digit', minute: '2-digit' });
    this.controllerFor('staff-product-category').set('loginDateTime', loginDateTime);
    let prodCatArray = [];
    if (params.prodCategory) {
      prodCatArray = params.prodCategory.split(',');
    }
    this.set('prodCategory', prodCatArray);
  },
  setupController: function(controller) {
    this._super(...arguments);
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
    // To find if the journey is for Africa or other country.
    controller.set('isAfricanCountry', config.isAfricanCtry.includes(this.get('axwayConfig.country')));
  },
  actions: {
    closePage() {
      window.location.href = window.location.protocol + '//' + window.location.host + '/exit';
    },
    closeActionSheet() {
      this.controller.set('showActionSheet', false);
    },
    onProductSelection(categoryId) {
      if (this.validateProductSelection(categoryId)) {
        if (categoryId === 'CC') {
          this.transitionTo('product-list.list');
        } else {
          this.set('axwayConfig.staffEligibilityCheck', true);
          let filterParams = '{ "productList":"' + categoryId + '","stepName":"MK_EC" }';
          this.transitionTo('apply-products', {
            queryParams: {
              filter: filterParams
            }
          });
        }
      } else {
        this.controller.set('showActionSheet', true);
      }
    },
    // For Africa staff assist which includes the document collection step.
    onSelectForAfrica(flow) {
      if (flow === 'NTB') {
        let message = this.get('i18n').t('ServiceRequest.StaffProductCategory.ntbAttestationMessage');
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'warning',
            message,
            acceptButtonLabel: this.get('i18n').t('ServiceRequest.StaffProductCategory.ntbAttestationButtonLabel'),
            iconClass: 'asset-onboarding-info-icon',
            popupClass: 'asset-onboarding-theme',
            customClass: 'theme2'
          })
          .then(() => {
            // Moving to category if AssetOnboarding is true.
            if (!isEmpty(this.get('axwayConfig.assetOnboarding')) && this.get('axwayConfig.assetOnboarding') === true) {
              this.transitionTo('product-list.category');
            } else {
              this.transitionTo('product-list.list');
            }
          });
      } else if (flow === 'DOC') {
        // handling the document flow section.
        this.get('rdcLoadingIndicator').showLoadingIndicator();
        this.transitionTo('staff-document-dashboard');
      }
    }
  }
});
