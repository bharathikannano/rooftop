import Route from '@ember/routing/route';
import { isEmpty } from '@ember/utils';
import { A } from '@ember/array';
import idleSession from 'rdc-ui-eng-service-requests/mixins/idle-session';
import checkMaintenance from 'rdc-ui-eng-service-requests/mixins/check-maintenance';
import config from '../config/environment';
import fetch from 'fetch';
import { inject as service } from '@ember/service';

const LOADING = 'rdcLoadingIndicator';

export default Route.extend(idleSession, checkMaintenance, {
  store: service(),
  axwayConfig: service(),
  i18n: service(),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  queries: service('customer-info'),
  firebaseAnalytics: service(),
  queryParams: {
    productList: {
      refreshModel: true
    }
  },
  beforeModel() {
    this._super(...arguments);
    if (this.get('axwayConfig.country') == 'CI') {
      let products = '{';
      if (localStorage.getItem('isCurrentAccountSelected') === 'true') {
        products = products + '"product1": "currentAccount"';
      }

      if (
        localStorage.getItem('isCurrentAccountSelected') === 'true' &&
        localStorage.getItem('isExcelSaverAccountSelected') === 'true'
      ) {
        products = products + ',';
      }

      if (localStorage.getItem('isExcelSaverAccountSelected') === 'true') {
        products = products + '"product2": "excelSaverAccount"';
      }

      products = products + '}';
      this.set('filterParams', products);
    }
  },
  model() {
    this.get('rdcLoadingIndicator').showLoadingIndicator();
    let categories = this.get('store').peekAll('product-catalogue');
    if (isEmpty(categories)) {
      categories = this.get('store').query('product-catalogue', {});
    }
    return categories;
  },
  afterModel() {
    // hiding the loader after model data is fetched..
    this.get('rdcLoadingIndicator').hideLoadingIndicator();
  },
  setupController(controller, model) {
    this._super(controller, model);
    controller.setProperties({
      enableStartApplication: true,
      hasCreditCard: false,
      hasPersonalLoan: false,
      hasOverDraft: false,
      assetOnboarding: false,
      hasRewardType: false
    });
    if (!isEmpty(this.get('axwayConfig.assetOnboarding')) && this.get('axwayConfig.assetOnboarding') === true) {
      controller.set('assetOnboarding', true);
    }
    /*To hide Autosave informative text to user when there is no save in between pages */
    if (this.get('axwayConfig.zibukaWebFlow')) {
      controller.set('hideAutoSave', true);
    }
    // To check if CC or PL or OD product is selected by checking the list routes controller variable.
    if (!isEmpty(this.controllerFor('product-list.list'))) {
      if (this.controllerFor('product-list.list').hasCreditCard === true) {
        controller.set('hasCreditCard', true);
      } else if (this.controllerFor('product-list.list').hasPersonalLoan === true) {
        controller.set('hasPersonalLoan', true);
      } else if (this.controllerFor('product-list.list').hasOverDraft === true) {
        controller.set('hasOverDraft', true);
      }
      if (this.controllerFor('product-list.list').hasRewardType === true) {
        controller.set('hasRewardType', true);
      }
    }
    controller.setProperties({
      isAssetProduct: controller.hasOverDraft || controller.hasPersonalLoan || controller.hasCreditCard,
      catalogueList: model,
      bureauConsentvalue: false
    });
    let catList = this.currentModel;
    let selectedProductsWithEligibility = [];
    let selectedProducts = [];
    controller.set('showDelete', true);
    this.setEligibility(catList);
    this.controller.setProperties({
      showActionSheet: false,
      isMaintenance: false
    });

    /* TO check if the application is under maintanence.
     * This check is used to alert the user by just changing a flag in JSON file.
     */
    this.checkMaintenance().then(isUnderMaintanence => {
      controller.set('isMaintenance', isUnderMaintanence);
    });

    catList.forEach(category => {
      category.products.filterBy('selected').forEach(prod => {
        selectedProducts.push(prod);
        if (prod.eligibility && prod.eligibility.length) {
          selectedProductsWithEligibility.push(prod);
        }
      });
    });
    if (selectedProducts.length === 1) {
      selectedProducts[0].set('showDelete', false);
    }
    if (this.get('axwayConfig.country') === 'NG') {
      // TO get Start application data for NG.
      this.getNgData(controller);
      controller.setProperties({
        isNGInstantAccount: selectedProducts.length == 1 && selectedProducts[0].get('id') == '504',
        ngAccountType: null,
        actions: {
          closeAccountActionSheet() {
            this.setProperties({
              showActionSheet: false,
              staticPopup: '',
              ngAccountType: null
            });
          }
        }
      });
    } else {
      controller.setProperties({
        isNGInstantAccount: false,
        actions: {
          closeAccountActionSheet() {
            //  Nothing to handle here.
          }
        }
      });
    }
    // For checking if ETB CASA.
    if (
      !isEmpty(this.get('axwayConfig.ETBAccountOpening')) &&
      this.get('axwayConfig.ETBAccountOpening') === true &&
      selectedProducts.length == 1 &&
      !controller.isAssetProduct
    ) {
      controller.set('isETBCASA', true);
    } else {
      controller.set('isETBCASA', false);
    }

    let hasEligibility = selectedProductsWithEligibility && selectedProductsWithEligibility.length ? true : false;
    controller.set('hasEligibility', hasEligibility);
    let applicationSummaryData = this.controllerFor('product-list.list').get('applicationSummary');
    controller.set('applicationSummaryData', applicationSummaryData);
  },

  async getNgData(controller) {
    this.get(LOADING).showLoadingIndicator(' ');
    let path = 'https://av.sc.com/configuration/ng-start-application',
      host = window.location.host.indexOf('sit') != -1 || window.location.host.indexOf('uat') != -1 ? '-test' : '';
    let response = await fetch(path + host + '.json');
    let ngData = await response.json();

    controller.set('ngData', ngData);
    this.get(LOADING).hideLoadingIndicator(' ');
  },

  setEligibility: function(catList) {
    let documents = [];
    let nonDocuments = [];
    let keepTheseReady = [];
    catList.forEach(category => {
      category.products.filterBy('selected').forEach(prod => {
        // selectedProducts.push(prod);
        if (prod.eligibility && prod.eligibility.length) {
          prod.eligibility.forEach(eligibilityCriteria => {
            eligibilityCriteria.criteria.forEach(criterium => {
              // To prevent documents required from showing for KE ETB if selected product is CC.
              let criteriaTitle = criterium.criteriaTitle
                .toLowerCase()
                .split(' ')
                .join('');
              if (criteriaTitle.includes('documentsrequired')) {
                criterium.conditions.forEach(condition => {
                  documents.push(condition);
                });
              } else if (criteriaTitle.includes('keeptheseready')) {
                criterium.conditions.forEach(condition => {
                  keepTheseReady.push(condition);
                });
              } else {
                criterium.conditions.forEach(condition => {
                  nonDocuments.push(condition);
                });
              }
            });
          });
        }
      });
    });
    documents = documents.filter(function(item, pos) {
      return documents.indexOf(item) == pos;
    });
    keepTheseReady = keepTheseReady.filter(function(item, pos) {
      return keepTheseReady.indexOf(item) == pos;
    });
    nonDocuments = nonDocuments.filter(function(item, pos) {
      return nonDocuments.indexOf(item) == pos;
    });
    this.controller.set('documents', documents);
    this.controller.set('keepTheseReady', keepTheseReady);
    this.controller.set('nonDocuments', nonDocuments);
  },

  formFilterParam: function(product) {
    let productString = '';
    if (product.get('category')) {
      productString = productString + product.get('category');
    }
    if (product.id) {
      productString = productString + '~' + product.id;
    }
    if (product.get('subProductTypeCode')) {
      productString = productString + '~' + product.get('subProductTypeCode');
    } else {
      productString = productString + '~' + '0';
    }
    if (product.get('productType')) {
      this.queries.setProductType(product.get('productType'));
      productString = productString + '~' + product.get('productType');
    }
    if (product.get('isHardBundle')) {
      productString = productString + '~' + 'ihb';
    }
    return productString;
  },
  actions: {
    // setting the bureau consent to controller variable
    bureauConsentCheck(evt, value) {
      this.controller.set('bureauConsentvalue', value);
    },
    goToBack() {
      if (this.get('axwayConfig.country') == 'CI') {
        this.transitionTo('product.opening');
      } else {
        /* Resetting the query param for the selected product */
        let productString = '';
        let catalogueList = this.controller.get('catalogueList');
        catalogueList.forEach(category => {
          category.products.filterBy('selected').forEach(data => {
            if (data.isHardBundle) {
              return;
            }
            if (data.get('category')) {
              productString = productString + data.get('category');
            }
            if (data.id) {
              productString = productString + '~' + data.id;
            }
            if (data.get('subProductTypeCode')) {
              productString = productString + '~' + data.get('subProductTypeCode') + ',';
            } else {
              productString = productString + '~' + '0' + ',';
            }
          });
        });
        this.controllerFor('product-list.list').set('retainSelection', false);
        this.transitionTo('product-list.list', { queryParams: { products: productString } });
      }
    },
    exitStartApplication() {
      // This is applicable only for NG. Since there is only one product and no product selection page.
      window.location.href = config.backToiBankURL;
    },
    goToApplyProducts() {
      let catList = this.currentModel;
      let selectedProducts = [];
      catList.forEach(category => {
        category.products.filterBy('selected').forEach(prod => {
          selectedProducts.push(prod);
        });
      });

      this.controller.set('selectedProducts', selectedProducts);
      if (this.get('axwayConfig.country') === 'AE') {
        selectedProducts = A(selectedProducts);
        if (selectedProducts.filterBy('feesAndCharges.content').length) {
          this.controller.set('showActionSheet', true);
          if (this.media.isDesktop) {
            this.controller.set('customClass', 'is-desktop fees-charge-action-sheet');
          }
          this.controller.set('staticPopup', 'fees-and-charges');
          return;
        }
      }
      this.send('transitionToApplyProducts', selectedProducts);
    },

    transitionToApplyProducts(selectedProducts) {
      if (this.controller.isMaintenance) {
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'error',
            title: this.get('i18n').t('ServiceRequest.COMMON.maintanence.title'),
            message: this.get('i18n').t('ServiceRequest.COMMON.maintanence.message'),
            acceptButtonLabel: this.get('i18n').t('generic.ok')
          })
          .then(() => {
            this.send('goToBack');
          });
        return;
      }

      let productListString = '';

      selectedProducts.forEach(product => {
        if (productListString.length) {
          productListString = productListString + ',' + this.formFilterParam(product);
        } else {
          productListString = productListString + this.formFilterParam(product);
        }
      });
      if (window.cordova) {
        this.firebaseAnalytics.logEvent('Enter_Screen_1');
      }
      let filterParams;
      if (this.get('axwayConfig.country') != 'CI') {
        //  TO check if sourceRefNo is present in either list / category.
        let sourceRefNo =
          this.controllerFor('product-list.list').get('model.sourceRefNo') ||
          this.controllerFor('product-list.category').get('model.sourceRefNo');
        if (!isEmpty(sourceRefNo)) {
          filterParams =
            '{ "productList":"' + productListString + '","eventType":"MODIFY", "sourceRefNo":"' + sourceRefNo + '"}';
        } else {
          filterParams = '{ "productList":"' + productListString + '"}';
        }
        // For sending the bureau consent in the filter params if assetOnboarding..
        if (this.controller.assetOnboarding) {
          let params = JSON.parse(filterParams);
          params['bureauConsent'] = this.controller.bureauConsentvalue;
          filterParams = JSON.stringify(params);
        }

        // For sending the ICCD disclosure flags to filter params.
        if (!isEmpty(this.controllerFor('product-list.list'))) {
          let listController = this.controllerFor('product-list.list');
          if (
            !isEmpty(listController.awarePSA) &&
            !isEmpty(listController.awarePEP) &&
            !isEmpty(listController.awareSANC) &&
            !isEmpty(listController.awareADV)
          ) {
            let params = JSON.parse(filterParams);
            params['awarePSA'] = listController.awarePSA;
            params['awarePEP'] = listController.awarePEP;
            params['awareSANC'] = listController.awareSANC;
            params['awareADV'] = listController.awareADV;
            filterParams = JSON.stringify(params);
          }
        }
      }
      /*
       * If country is NG and product code other than 504,
       * then ETB account opening. So redirecting to apply-products by setting a new variable in axway config.
       * This will inturn be re-directed to MK_F5 based on the axway variable.
       */
      if (this.get('axwayConfig.country') === 'NG' && !this.controller.isNGInstantAccount) {
        this.set('axwayConfig.ETBAccountOpening', true);
      }
      this.transitionTo('apply-products', {
        queryParams: {
          filter: filterParams
        }
      });
    },
    showAccountInfo(accountType) {
      this.controller.setProperties({
        showActionSheet: true,
        staticPopup: 'ng-account-information',
        ngAccountType: accountType
      });
    },
    removeProduct(product) {
      product.toggleProperty('selected');
      let catList = this.currentModel;
      let selectedProducts = [];
      catList.forEach(category => {
        category.products.filterBy('selected').forEach(prod => {
          selectedProducts.push(prod);
        });
      });
      if (selectedProducts.length === 1) {
        selectedProducts[0].set('showDelete', false);
      }
      if (!selectedProducts.length) {
        this.controllerFor('product-list.list').set('showCartBtn', false);
        this.controller.set('enableStartApplication', false);
        this.transitionTo('product-list.list');
      }
      this.setEligibility(catList);
    }
  }
});
