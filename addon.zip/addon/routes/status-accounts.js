import { isNone } from '@ember/utils';
import { Promise as EmberPromise } from 'rsvp';
import { inject as service } from '@ember/service';
import Route from '@ember/routing/route';
import { copy } from '@ember/object/internals';
import { isEmpty } from '@ember/utils';
import idleSession from 'rdc-ui-eng-service-requests/mixins/idle-session';

export default Route.extend(idleSession, {
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  iframeManager: service(),
  axwayConfig: service(),
  queryParams: {
    mobileNo: {
      refreshModel: true
    }
  },

  model(params) {
    let mobileNo = params['mobileNo'] || '';

    let promise = new EmberPromise((resolve, reject) => {
      this.get('store')
        .query('service-request', {
          filter: {
            'service-requests': {
              status: {
                EQ: 'PROCESSING'
              }
            },
            mobileNo: mobileNo,
            country: this.get('axwayConfig.country')
          },
          sort: 'statusOrder,-dateOrder'
        })
        .then(
          ServiceRequest => {
            resolve(ServiceRequest);
          },
          error => {
            reject(error);
          }
        );
    });

    return this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(promise);
  },

  setupController: function(controller, model) {
    this._super(...arguments);
    /*
     * To override the referral resume data for Auth verification for ZIBUKA project.
     * Then overriding the eventtype of the referral resume data and setting the authEventType value to eventType.
     */
    model.forEach(expandedData => {
      // TO clone the already existing object and override it.
      let authVerifyResumeData = {};
      if (expandedData.get('referralResumeData')) {
        authVerifyResumeData = copy(JSON.parse(expandedData.get('referralResumeData')), true);
        if (!isEmpty(expandedData.get('additionalInfo.autheventType'))) {
          // Getting the autheventType from additionalInfo and setting as eventType.
          authVerifyResumeData.eventType = expandedData.get('additionalInfo.autheventType');
          // Changing the stepName if autheventType is present in additionalInfo.
          authVerifyResumeData.stepName = 'AUTH_REFERRAL';
        }
      }
      // returning as stringified value.
      controller.set('authVerifyResumeData', JSON.stringify(authVerifyResumeData));
    });
  },

  actions: {
    goBack() {
      if (!isNone(window.PGMultiView)) {
        window.PGMultiView.dismissView();
      } else {
        this.get('iframeManager').close();
      }

      this.transitionTo('statusTracking');
    }
  }
});
