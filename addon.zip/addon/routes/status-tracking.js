import Route from '@ember/routing/route';
import { isNone, isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import checkMaintenance from 'rdc-ui-eng-service-requests/mixins/check-maintenance';
import config from '../config/environment';

export default Route.extend(checkMaintenance, {
  iframeManager: service(),
  queries: service('customer-info'),
  i18n: service(),
  rdcModalManager: service(),
  axwayConfig: service(),
  beforeModel() {
    /* TO check if the application is under maintanence.
     * This check is used to alert the user by just changing a flag in JSON file.
     */
    this.checkMaintenance().then(isUnderMaintanence => {
      if (isUnderMaintanence) {
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'error',
            title: this.get('i18n').t('ServiceRequest.COMMON.maintanence.title'),
            message: this.get('i18n').t('ServiceRequest.COMMON.maintanence.message'),
            acceptButtonLabel: this.get('i18n').t('generic.ok')
          })
          .then(() => {
            document.location.href = config.backToiBankURL;
          });
      }
    });

    let srcURL = document.location.href;
    if (srcURL) {
      srcURL = srcURL.split('?')[1];
      if (srcURL) {
        srcURL = srcURL.split('&');
        let countryCode;
        srcURL.forEach(item => {
          if (item.indexOf('ctry') != -1) {
            countryCode = item.split('=')[1];
          }
        });

        if (countryCode) this.get('queries').setcountryName(countryCode);
      }
    }
  },
  closePopupAction() {
    let message;
    if (this.get('media.isDesktop')) {
      message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
    } else {
      message = this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankText');
    }
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message,
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        document.location.href = config.backToiBankURL;
      });
  },
  validate() {
    let regexp = this.controllerFor('status-tracking').get('regexp');
    let exp = new RegExp(regexp);

    this.controllerFor('status-tracking').set('hasError', true);
    this.controllerFor('status-tracking').set(
      'errorLabel',
      this.get('i18n').t('ServiceRequest.TRACKRESUME.mobileNumberLable')
    );
    if (isEmpty(this.controllerFor('status-tracking').get('phoneNumber'))) {
      this.controllerFor('status-tracking').set(
        'errorLabel',
        this.get('i18n').t('ServiceRequest.TRACKRESUME.mobileNumberError')
      );
    } else if (exp.test(this.controllerFor('status-tracking').get('phoneNumber'))) {
      this.controllerFor('status-tracking').set('hasError', false);
      this.controllerFor('status-tracking').set('errorLabel', '');
      return true;
    }

    return false;
  },
  actions: {
    goBack() {
      if (this.get('queries.countryName') == 'CI') {
        if (!isNone(window.PGMultiView)) {
          window.PGMultiView.dismissView();
        } else {
          this.get('iframeManager').close();
        }
      } else {
        this.closePopupAction();
      }
    },

    checkStatus() {
      if (this.validate()) {
        this.transitionTo('statusAccounts', {
          queryParams: {
            mobileNo: this.controllerFor('status-tracking').get('phoneNumber')
          }
        });
      }
    }
  }
});
