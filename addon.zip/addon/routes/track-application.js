import { isNone, isEmpty } from '@ember/utils';
import { inject as service } from '@ember/service';
import config from '../config/environment';
import checkMaintenance from 'rdc-ui-eng-service-requests/mixins/check-maintenance';
import Route from '@ember/routing/route';

export default Route.extend(checkMaintenance, {
  iframeManager: service(),
  queries: service('customer-info'),
  i18n: service(),
  rdcModalManager: service(),
  axwayConfig: service(),
  beforeModel() {
    /* TO check if the application is under maintanence.
     * This check is used to alert the user by just changing a flag in JSON file.
     */
    this.checkMaintenance().then(isUnderMaintanence => {
      if (isUnderMaintanence) {
        this.get('rdcModalManager')
          .showDialogModal({
            level: 'error',
            title: this.get('i18n').t('ServiceRequest.COMMON.maintanence.title'),
            message: this.get('i18n').t('ServiceRequest.COMMON.maintanence.message'),
            acceptButtonLabel: this.get('i18n').t('generic.ok')
          })
          .then(() => {
            document.location.href = config.backToiBankURL;
          });
      }
    });

    let srcURL = document.location.href;
    if (srcURL) {
      srcURL = srcURL.split('?')[1];
      if (srcURL) {
        srcURL = srcURL.split('&');
        let countryCode;
        srcURL.forEach(item => {
          if (item.indexOf('ctry') != -1) {
            countryCode = item.split('=')[1];
          } else if (item.indexOf('channel') != -1) {
            this.set('queries.channelId', item.split('=')[1]);
          }
        });

        if (countryCode) this.get('queries').setcountryName(countryCode);
      }
    }
  },
  closePopupAction() {
    let message;
    if (this.get('media.isDesktop')) {
      message = this.get('i18n').t('ServiceRequest.COMMON.backToiBankText');
    } else {
      message = this.get('i18n').t('ServiceRequest.COMMON.backToMobileBankText');
    }
    this.get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message,
        rejectButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.no'),
        acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.yes'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-info-popup'
      })
      .then(() => {
        document.location.href = config.backToiBankURL;
      });
  },
  validate() {
    let regexp = this.controllerFor('track-application').get('regexp');
    let exp = new RegExp(regexp);

    this.controllerFor('track-application').set('hasError', true);
    this.controllerFor('track-application').set(
      'errorLabel',
      this.get('i18n').t('ServiceRequest.TRACKRESUME.mobileNumberLable')
    );
    if (isEmpty(this.controllerFor('track-application').get('phoneNumber'))) {
      this.controllerFor('track-application').set(
        'errorLabel',
        this.get('i18n').t('ServiceRequest.TRACKRESUME.mobileNumberError')
      );
    } else if (exp.test(this.controllerFor('track-application').get('phoneNumber'))) {
      this.controllerFor('track-application').set('hasError', false);
      this.controllerFor('track-application').set('errorLabel', '');
      return true;
    }

    return false;
  },
  actions: {
    goBack() {
      if (this.get('queries.countryName') == 'CI') {
        if (!isNone(window.PGMultiView)) {
          window.PGMultiView.dismissView();
        } else {
          this.get('iframeManager').close();
        }
      } else {
        this.closePopupAction();
      }
    },
    resumeApplication() {
      if (this.validate()) {
        let filterParams;
        filterParams = JSON.stringify({
          stepName: 'MK_F1',
          countryCode: this.get('axwayConfig.country'),
          id: 'W400',
          eventType: 'RESUME',
          mobileNo: this.controllerFor('track-application').get('phoneNumber')
        });
        this.transitionTo('apply-products', {
          queryParams: {
            filter: filterParams
          }
        });
      }
    },

    trackApplication() {
      if (this.validate()) {
        this.transitionTo('statusAccounts', {
          queryParams: {
            mobileNo: this.controllerFor('track-application').get('phoneNumber')
          }
        });
      }
    }
  }
});
