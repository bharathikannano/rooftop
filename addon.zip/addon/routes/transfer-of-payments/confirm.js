import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { set } from '@ember/object';
import { A } from '@ember/array';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  queries: service('customer-info'),
  rdcLoadingIndicator: service(),
  rdcModalManager: service(),
  confirmBtnDisable: false,

  callForData(pageData) {
    let selectedFromCard = pageData.selectedFromCard;
    let selectedToCardArray = A();
    pageData.selectedToCard.forEach(item => {
      if (item) {
        selectedToCardArray.push(item);
      }
    });
    let selectedToCard = selectedToCardArray[0];
    set(pageData, 'selectedToCard', selectedToCardArray[0]);
    let today = new Date();
    let currDate =
      today.getFullYear() +
      '-' +
      (today.getMonth() + 1) +
      '-' +
      today.getDate() +
      'T' +
      today.getHours() +
      ':' +
      today.getMinutes() +
      ':' +
      today.getSeconds() +
      '.' +
      today.getMilliseconds();

    let postData = {
      paymentType: 'OAFT',
      subPaymentType: 'TOP',
      settlementType: 'CC',
      paymentScheme: 'eOps',
      txnCur: selectedFromCard.get('currencyCode'),
      txnAmount: selectedToCard.amountEntered,
      dtTransfer: currDate,
      dbtAccName: selectedFromCard.get('desc'),
      dbtAccNumber: selectedFromCard.get('cardNum'),
      dbtAccCur: selectedFromCard.get('currencyCode'),
      dbtAccType: 'CC',
      cdtAccName: selectedToCard.description,
      cdtAccNumber: selectedToCard.cardNumber,
      cdtAccCur: selectedToCard.currencyCode,
      cdtAccType: 'CC'
    };
    return postData;
  },

  model() {
    return this.controllerFor('transfer-of-payments.display-to-card').get('modelData');
  },
  afterModel(modelData) {
    let selectedCardList = [];
    modelData.topToCardList.forEach(data => {
      let testObj;
      if (data.amountEntered) {
        testObj = {
          cardNumber: data.get('cardNum'),
          description: data.get('desc'),
          amountEntered: data.get('amountEntered'),
          currencyCode: data.get('currencyCode')
        };
      }
      selectedCardList.push(testObj);
    });
    set(modelData, 'selectedToCard', selectedCardList);
  },
  setupController(controller, model) {
    this._super(controller, model);
    let device = this.controllerFor('transfer-of-payments').get('bpClass');
    if (!(device == 'is-mobile')) {
      later(function() {
        document.getElementById('top-id').scrollIntoView();
      }, 5);
    }
    controller.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    if (this.get('queries.countryName') == 'HK' || this.get('queries.countryName') == 'SG') {
      return controller.set('cardMasking', false);
    } else {
      return controller.set('cardMasking', true);
    }
  },
  actions: {
    gotoBack() {
      this.transitionTo('transfer-of-payments.display-to-card');
    },
    setControllerProperties(model, postResData) {
      this.controller.set('cardData', model);
      this.controller.set('cardResData', postResData);
    },
    gotoNext(model) {
      set(this.currentModel, 'confirmBtnDisable', true);
      this.get('rdcLoadingIndicator').showLoadingIndicator(' ');
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      let fromCard = this.currentModel.selectedFromCard;
      let pageData = this.controller.get('model');
      let postReqData = this.callForData(pageData);
      let toCard = this.currentModel.selectedToCard;
      let topToCardList = this.currentModel.topToCardList;
      let postData = this.get('store').createRecord('payment', postReqData);
      postData.save().then(
        response => {
          let postResData = this.get('store').peekAll('payment');
          this.send('setControllerProperties', model, postResData);
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.transitionTo('transfer-of-payments.status-result').then(function(statusRoute) {
            statusRoute.currentModel.refNum = response.id;
            statusRoute.currentModel.fromCard = fromCard;
            statusRoute.currentModel.toCard = toCard;
            statusRoute.currentModel.topToCardList = topToCardList;
          });
        },
        () => {
          this.get('rdcLoadingIndicator').hideLoadingIndicator();
          this.set('currentModel.systemErrorPopup', true);
          this.controllerFor('transfer-of-payments.confirm').set('errorPopUp', true);
          let message = this.get('i18n').t('ServiceRequest.COMMON.systemError'),
            title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
          this.get('rdcModalManager')
            .showDialogModal({
              level: 'warning',
              message,
              title,
              acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
              iconClass: 'service-journey-system-error-icon',
              popupClass: 'service-journey-system-error-popup'
            })
            .then(() => {
              this.controllerFor('transfer-of-payments.confirm').set('errorPopUp', false);
              this.get('store').unloadAll('credit-card');
              this.transitionTo('serviceRequest.new-request');
            })
            .catch(() => {
              this.transitionTo('serviceRequest.new-request');
            });
        }
      );
    }
  }
});
