import Route from '@ember/routing/route';
import { htmlSafe } from '@ember/string';
import { inject as service } from '@ember/service';
import { set } from '@ember/object';
import { hash } from 'rsvp';
import config from '../../config/environment';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  rdcModalManager: service(),
  rdcLoadingIndicator: service(),
  queries: service('customer-info'),
  nextBtnEnabled: true,
  model() {
    let self = this;
    let CreditCardDetails;
    let fromCardList = [];
    let toCardList = [];
    CreditCardDetails = this.get('store')
      .query('credit-card', {
        filter: {
          eligibleForTransferOfPayments: 'yes'
        }
      })
      .then(
        function(data) {
          if (data.content.length <= 0) {
            self.transitionTo('transfer-of-payments.no-card');
          } else if (data.content.length == 1) {
            data.forEach(element => {
              if (
                element.get('alerts') &&
                element.get('alerts').length >= 1 &&
                !element.get('paymentTransferFromCard') &&
                !element.get('paymentTransferToCard')
              ) {
                self.transitionTo('serviceRequest.new-request');

                let message = htmlSafe(element.get('alerts')[0].message);
                self.controllerFor('serviceRequest.new-request').set('cancelPopup', false);
                self.controllerFor('serviceRequest.new-request').set('systemErrorPopup', true);

                self
                  .get('rdcModalManager')
                  .showDialogModal({
                    level: 'info',
                    message,
                    acceptButtonLabel: self.get('i18n').t('ServiceRequest.COMMON.button.ok'),
                    iconClass: 'service-journey-info-icon',
                    popupClass: 'service-journey-system-error-popup'
                  })
                  .then(() => {
                    self.transitionTo('serviceRequest.new-request');
                  });
              }
            });
          }
          data.forEach(function(element) {
            element.set('isSelected', false);
            element.set('disableAmountText', true);
            element.set('amountEntered', '');

            if (element.get('paymentTransferFromCard')) {
              if (
                element.get('alerts') ||
                parseFloat(element.get('minimumAmountdue')) > parseFloat(element.get('totalCredits'))
              ) {
                element.set('disableFromCard', true);
              } else {
                element.set('disableFromCard', false);
              }

              if (parseFloat(element.get('statementBalance')) > parseFloat(element.get('totalCredits'))) {
                element.set('disableStatementBal', true);
              } else {
                element.set('disableStatementBal', false);
              }

              fromCardList.push(element);
            }
            if (element.get('paymentTransferToCard')) {
              toCardList.push(element);
            }
          });
          return data;
        },
        error => {
          this.send('error', error);
        }
      );
    this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(CreditCardDetails, ' ');
    this.get('rdcLoadingIndicator').setThemeClass('ui10');

    return hash({
      CreditCardDetails: CreditCardDetails,
      fromCardList: fromCardList,
      toCardList: toCardList
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    let device = this.controllerFor('transfer-of-payments').get('bpClass');
    if (!(device == 'is-mobile')) {
      later(function() {
        document.getElementById('top-id').scrollIntoView();
      }, 5);
    }
  },
  actions: {
    error: function(error) {
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      if (error.errors && error.errors[0].code == '1702') {
        document.location.href = config.backToiBankURL;
        return;
      }
      this.get('rdcLoadingIndicator').hideLoadingIndicator();
      this.controllerFor('serviceRequest').set('cancelPopup', false);
      this.controllerFor('serviceRequest').set('systemErrorPopup', true);
      let message = this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName')).string
        ? this.get('i18n').t('ServiceRequest.COMMON.systemError.' + this.get('queries.countryName')).string
        : this.get('i18n').t('ServiceRequest.COMMON.systemError').string;
      let title = this.get('i18n').t('ServiceRequest.COMMON.systemError.title');
      this.controllerFor('chequeRequest').set('errorType', 'systemError');
      this.get('rdcModalManager')
        .showDialogModal({
          level: 'warning',
          title,
          message,
          acceptButtonLabel: this.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
          iconClass: 'service-journey-system-error-icon',
          popupClass: 'service-journey-system-error-popup'
        })
        .then(() => {
          this.controllerFor('serviceRequest').set('systemErrorPopup', false);
          this.transitionTo('serviceRequest.new-request');
        });
    },
    enableNext(flag) {
      if (flag) {
        set(this.currentModel.fromCardList, 'nextBtnEnabled', true);
      } else {
        set(this.currentModel.fromCardList, 'nextBtnEnabled', false);
      }
    },
    gotoBack() {
      this.transitionTo('serviceRequest.new-request');
    },
    cancelBtn() {
      this.transitionTo('serviceRequest.new-request');
    },
    navigateConfirm(model) {
      let fromCardListSelected = this.get('currentModel').fromCardList;
      let selectedFromCard;
      fromCardListSelected.forEach(function(selectedCard) {
        if (selectedCard.isSelected) {
          selectedFromCard = selectedCard;
          set(model, 'selectedFromCard', selectedFromCard);
        }
      });
      this.controllerFor('transfer-of-payments.display-from-card').set('modelData', model);
      this.transitionTo('transfer-of-payments.display-to-card');
    }
  }
});
