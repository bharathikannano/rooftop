import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';
import { set } from '@ember/object';
import { later } from '@ember/runloop';

export default Route.extend({
  store: service(),
  i18n: service(),
  queries: service('customer-info'),
  nextBtnEnabled: true,
  expanded: false,

  model() {
    return this.controllerFor('transfer-of-payments.display-from-card').get('modelData');
  },
  afterModel(modelData) {
    let topToCardList = [];
    modelData.toCardList.forEach(data => {
      if (modelData.selectedFromCard.get('cardNum') == data.get('cardNum')) {
        set(data, 'toShowCard', false);
      } else {
        set(data, 'toShowCard', true);
        topToCardList.push(data);
      }
    });

    set(modelData, 'topToCardList', topToCardList);

    if (modelData.selectedFromCard) {
      if (modelData.selectedFromCard.isSelected) {
        if (modelData.selectedFromCard.madSelected) {
          set(
            modelData.selectedFromCard,
            'selectedAmount',
            modelData.selectedFromCard.get('totalCredits') - modelData.selectedFromCard.get('minimumAmountdue')
          );
          set(
            modelData.topToCardList,
            'selectedAmount',
            modelData.selectedFromCard.get('totalCredits') - modelData.selectedFromCard.get('minimumAmountdue')
          );
        } else {
          set(
            modelData.selectedFromCard,
            'selectedAmount',
            modelData.selectedFromCard.get('totalCredits') - modelData.selectedFromCard.get('statementBalance')
          );
          set(
            modelData.topToCardList,
            'selectedAmount',
            modelData.selectedFromCard.get('totalCredits') - modelData.selectedFromCard.get('statementBalance')
          );
        }
      }
    }
  },
  setupController(controller, model) {
    this._super(controller, model);
    let device = this.controllerFor('transfer-of-payments').get('bpClass');
    if (!(device == 'is-mobile')) {
      later(function() {
        document.getElementById('top-id').scrollIntoView();
      }, 5);
    }
    model.topToCardList.forEach(function(element) {
      if (element.toCardSelected) {
        let userToCardAmount = element.amountEntered;
        let totalCredit = model.topToCardList.selectedAmount;
        let remainingbalance = 0;

        if (userToCardAmount % 1 === 0 && totalCredit % 1 === 0) {
          remainingbalance = totalCredit - userToCardAmount;
        } else {
          remainingbalance = (parseFloat(totalCredit) - parseFloat(userToCardAmount)).toFixed(2);
        }

        if (remainingbalance >= 0) {
          model.selectedFromCard.set('selectedAmount', remainingbalance);
        } else {
          model.selectedFromCard.set('selectedAmount', model.topToCardList.selectedAmount);
        }
      }
    });

    controller.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    if (this.get('queries.countryName') == 'HK' || this.get('queries.countryName') == 'SG') {
      return controller.set('cardMasking', false);
    } else {
      return controller.set('cardMasking', true);
    }
  },
  actions: {
    enableNext() {
      if (this.currentModel.topToCardList) {
        let enableNext = false;
        this.currentModel.topToCardList.forEach(data => {
          if (data.toCardSelected) {
            if (data.amountEntered && data.errorText == false) {
              enableNext = true;
            } else {
              enableNext = false;
            }
          }
        });
        if (enableNext) {
          set(this.currentModel.topToCardList, 'nextBtnEnabled', true);
        } else {
          set(this.currentModel.topToCardList, 'nextBtnEnabled', false);
        }
      } else {
        set(this.currentModel.topToCardList, 'nextBtnEnabled', false);
      }
    },
    gotoBack() {
      this.transitionTo('transfer-of-payments.display-from-card');
    },
    cancelBtn() {
      this.transitionTo('serviceRequest.new-request');
    },
    navigateConfirm(model) {
      this.controllerFor('transfer-of-payments.display-to-card').set('modelData', model);
      this.transitionTo('transfer-of-payments.confirm');
    },
    onExpand() {
      set(this.currentModel.topToCardList, 'expanded', !this.currentModel.topToCardList.expanded);
    }
  }
});
