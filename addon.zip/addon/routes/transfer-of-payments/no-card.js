import Route from '@ember/routing/route';
import { inject as service } from '@ember/service';

export default Route.extend({
  store: service(),
  i18n: service(),
  actions: {
    gotoBack() {
      this.get('store').unloadAll('credit-card');
      this.get('store').unloadAll('debit-card');
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
