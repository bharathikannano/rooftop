import Route from '@ember/routing/route';
import { hash } from 'rsvp';
import { set } from '@ember/object';
import { inject as service } from '@ember/service';
import { later } from '@ember/runloop';

export default Route.extend({
  i18n: service(),
  store: service(),
  queries: service('customer-info'),

  model() {
    return hash({
      refNum: '1234'
    });
  },
  setupController(controller, model) {
    this._super(controller, model);
    let device = this.controllerFor('transfer-of-payments').get('bpClass');
    if (!(device == 'is-mobile')) {
      later(function() {
        document.getElementById('top-id').scrollIntoView();
      }, 5);
    }
    controller.set('cardNoMaskConfig', this.get('queries').cardMaskConfig());
    if (this.get('queries.countryName') == 'HK' || this.get('queries.countryName') == 'SG') {
      return controller.set('cardMasking', false);
    } else {
      return controller.set('cardMasking', true);
    }
  },
  actions: {
    clearData() {
      set(this.currentModel, 'refNum', '');
      this.controller.set('modelData', '');
    },
    gotoStatus() {
      this.get('store').unloadAll('credit-card');
      this.send('clearData');
      this.controllerFor('transfer-of-payments.display-from-card').set('modelData', '');
      this.transitionTo('serviceRequest.status');
    }
  }
});
