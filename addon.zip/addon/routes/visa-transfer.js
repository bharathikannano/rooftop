/* globals errorCallback,cancelCallback,Checkout,completeCallback */
/*eslint no-global-assign: "warn"*/
import { inject as service } from '@ember/service';
import FereFormRoute from 'rdc-ui-adn-fere/routes/fere-route';
import { computed } from '@ember/object';
import { Promise as EmberPromise } from 'rsvp';

window.errorCallback = function(error) {
  this.get('rdcLoadingIndicator').hideLoadingIndicator();
  let errorMessage = error.cause + ' - ' + error.explanation;
  this.store.peekRecord('field', 'ResponseStatus').set('value', errorMessage);
  this.submitForm();
};

window.cancelCallback = function() {
  this.get('rdcLoadingIndicator').hideLoadingIndicator();
  this.store.peekRecord('field', 'ResponseStatus').set('value', 'cancel');
  this.submitForm();
};

window.completeCallback = function(resultIndicator) {
  this.get('rdcLoadingIndicator').hideLoadingIndicator();
  resultIndicator === this.successIndicator
    ? this.store.peekRecord('field', 'ResponseStatus').set('value', 'success')
    : this.store.peekRecord('field', 'ResponseStatus').set('value', 'failure');
  this.submitForm();
};

export default FereFormRoute.extend({
  iframeManager: service(),
  otpManager: service(),
  axwayConfig: service(),
  rdcLoadingIndicator: service(),
  successIndicator: '',
  isScriptInjected: false,
  init() {
    this._super();
    completeCallback = completeCallback.bind(this);
    cancelCallback = cancelCallback.bind(this);
    errorCallback = errorCallback.bind(this);
  },

  injectPlugin(params) {
    let scriptAttrs = JSON.parse(params);
    let scriptTagElement = document.createElement(`script`);
    Object.keys(scriptAttrs).forEach(attrs => {
      scriptTagElement.setAttribute(attrs, scriptAttrs[attrs]);
    });
    return document.head.appendChild(scriptTagElement);
  },

  queryParams: computed('axwayConfig', {
    get() {
      return { filter: { stepName: 'MK_OpsMkr', countryCode: this.get('axwayConfig.country'), id: 'W388' } };
    }
  }),

  setupController: function(controller) {
    this._super(...arguments);
    controller.set('iframeManager', this.get('iframeManager'));
    if (!this.isScriptInjected) {
      this.injectPlugin(
        '{"src":"' +
          this.get('store').peekRecord('field', 'checkoutScriptUrl').value +
          '","data-error":"errorCallback","data-cancel":"cancelCallback","data-complete":"completeCallback"}'
      );
      this.set('isScriptInjected', true);
    }
  },

  closeThisForm() {
    this.transitionTo('serviceRequest.new-request');
  },

  beforeSubmit() {
    return new EmberPromise(resolve => {
      let operationName = this.get('store').peekRecord('field', 'OperationName');
      let value = '';

      if (this.get('currentDisplayPage').id === 'W388-Pg1') value = 'mpgssessionID';

      operationName.set('value', value);
      resolve();
    });
  },

  actions: {
    pullFund() {
      this.get('rdcLoadingIndicator').showLoadingIndicator();
      this.get('rdcLoadingIndicator').setThemeClass('ui10');
      let reciptID = this.store.peekRecord('formDatum', this.currentModel.receiptId);
      let additionalInfo = reciptID.additionalInfo;
      let checkoutSessionId = additionalInfo['session-id'];
      this.set('successIndicator', additionalInfo['success-indicator']);
      Checkout.configure({
        merchant: this.store.peekRecord('field', 'MerchantID').value,
        session: {
          id: checkoutSessionId
        },
        order: {
          reference: this.store.peekRecord('field', 'RetrievalReferenceNo').value,
          amount: this.store.peekRecord('field', 'TxnAmount').value,
          currency: this.store.peekRecord('field', 'TxnCurrencyCode').value,
          description: this.store.peekRecord('field', 'Description').value,
          id: this.store.peekRecord('field', 'RetrievalReferenceNo').value
        },
        interaction: {
          merchant: {
            name: 'SCB',
            address: {
              line1: '200 Sample St',
              line2: '1234 Example Town'
            },
            logo: 'https://av.sc.com/corp-en/content/images/standardchartered@2x.png'
          },
          locale: this.get('axwayConfig.language'),
          displayControl: {
            billingAddress: 'HIDE'
          }
        }
      });
      Checkout.showLightbox();
    },
    goToBack() {
      if (this.get('previousPage') != null && this.get('currentDisplayPage').get('isReceiptPage') === false) {
        this.goToPage(this.get('previousPage.id'));
      } else {
        this.transitionTo('serviceRequest.new-request');
      }
    },
    closeForm() {
      this.transitionTo('serviceRequest.new-request');
    }
  }
});
