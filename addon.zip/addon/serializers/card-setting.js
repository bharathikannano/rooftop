import DS from 'ember-data';
import { A } from '@ember/array';
import constants from '../constants';
import EmberObject from '@ember/object';

const [B, AM, N, TMP, TMPB, SET, CLM, DL, DLM, OLM, TLM, ATMB, TKTB, VSB] = [
  'blocked',
  'amount',
  'notification',
  'tmpblock',
  'temporaryBlock',
  'settings',
  'cardlimit',
  'dailylimit',
  'domesticlimit',
  'overseaslimit',
  'transactionlimit',
  'atmblock',
  'tokenizedblock',
  'visible'
];
const [TRANSL, TRANSLA, TRANSLB, TRANSLN, GLOMINAMT, TRANSVSB] = [
  'transactionLimit',
  'translimitamount',
  'translimitblock',
  'translimitnotify',
  'globalminimumamount',
  'transactionlimitvisibility'
];
const GLOMINAMTBACK = 'globalMinimumAmount';

const [PC, PCB, PCE, PCC, PCPS, PCVSB] = [
  'paymentChannels',
  'paychannelblock',
  'onlineecommerce',
  'contactless',
  'physicalsale',
  'paymentchannelvisibility'
];
const [PCEBACK, PCPSBACK] = ['ecommerce', 'physicalSale'];

const [CC, CCB, CCA, CCE, CCT, CCGAS, CCG, CCH, CCVSB] = [
  'controlledCategories',
  'categoriesblock',
  'accessories',
  'entertainment',
  'travel',
  'gas',
  'groceries',
  'household',
  'controlledcategoryvisibility'
];

const [CL, CLCB, CLNF, CLCNS, CLSCP, AT, TKT, CLVSB] = [
  'overseasTransactions',
  'countryblock',
  'countrynotify',
  'countries',
  'scope',
  'atmTransactions',
  'tokenizedTransactions',
  'countrylimitvisibility'
];

const FIELDSMAP = {
  tmpBlock: 'temporaryBlock',
  transactionLimit: 'transactionLimit',
  paymentChannels: 'paymentChannels',
  controlledCategories: 'controlledCategories',
  countryLimits: CL
};

const [EVOT, EVTT, EV, IL, TKDL, TKCL] = [
  'existingvalueot',
  'existingvaluett',
  'existingvalue',
  'internationallimit',
  'tokenizeddomesticlimit',
  'tokenizedcardlimit'
];

export default DS.JSONAPISerializer.extend({
  _getOptsList() {
    let setOpt = this._getAllCountryOpts(),
      countryName = this.get('queries.countryName') || 'AE';
    return setOpt[countryName] ? setOpt[countryName] : null;
  },
  _getOptsListObj() {
    return this._getOptsList().availableSettings;
  },
  _getDeleteOptsArray() {
    let optsList = EmberObject.create(this._getOptsListObj());
    let optsNameList = A();
    let keys = Object.keys(optsList);
    for (let i = 0; i < keys.length; i++) {
      if (!optsList[keys[i]]) {
        optsNameList.pushObject(keys[i]);
      }
    }
    return optsNameList;
  },
  _getAllCountryOpts() {
    return constants.COUNTRYCONFIG;
  },
  _cleanFields(attributes) {
    let fields = this._getDeleteOptsArray();
    fields.forEach(item => {
      delete attributes[SET][FIELDSMAP[item]];
    });
    return attributes;
  },
  normalize(modelClass, data) {
    let ref;
    if (
      typeof data !== 'undefined' && data !== null ? ((ref = data.attributes) != null ? ref.settings : void 0) : void 0
    ) {
      if (!ref[SET]) {
        ref[SET] = {};
      }
      if (TMPB in ref[SET]) {
        ref[TMP] = ref[SET][TMPB][B];
      }
      if (TRANSL in ref[SET]) {
        ref[TRANSLN] = ref[SET][TRANSL][N];
        ref[TRANSLA] = ref[SET][TRANSL][AM];
        ref[TRANSLB] = ref[SET][TRANSL][B];
        ref[GLOMINAMT] = ref[SET][TRANSL][GLOMINAMTBACK];
        ref[TRANSVSB] = ref[SET][TRANSL][VSB];
      }
      if (PC in ref[SET]) {
        ref[PCB] = ref[SET][PC][B];
        ref[PCE] = ref[SET][PC][PCEBACK];
        ref[PCC] = ref[SET][PC][PCC];
        ref[PCPS] = ref[SET][PC][PCPSBACK];
        ref[PCVSB] = ref[SET][PC][VSB];
      }
      if (CC in ref[SET]) {
        ref[CCB] = ref[SET][CC][B];
        ref[CCA] = ref[SET][CC][CCA];
        ref[CCE] = ref[SET][CC][CCE];
        ref[CCT] = ref[SET][CC][CCT];
        ref[CCGAS] = ref[SET][CC][CCGAS];
        ref[CCG] = ref[SET][CC][CCG];
        ref[CCH] = ref[SET][CC][CCH];
        ref[CCVSB] = ref[SET][CC][VSB];
      }

      if (CLM in ref[SET]) {
        ref[CLM] = ref[SET][CLM];
      }

      if (AT in ref[SET]) {
        ref[ATMB] = ref[SET][AT][B];
      }

      if (TKT in ref[SET]) {
        ref[TKTB] = ref[SET][TKT][B];
        ref[TLM] = ref[SET][TKT][TLM];
        ref[DL] = ref[SET][TKT][DL];
        ref[EVTT] = ref[SET][TKT][EV];
        ref[IL] = ref[SET][TKT][IL];
        ref[TKDL] = ref[SET][TKT][DLM];
        ref[TKCL] = ref[SET][TKT][CLM];
      }

      if (CL in ref[SET]) {
        ref[CLCB] = ref[SET][CL][B];
        ref[CLNF] = ref[SET][CL][N];
        ref[DLM] = ref[SET][CL][DLM];
        ref[OLM] = ref[SET][CL][OLM];
        ref[CLM] = ref[SET][CL][CLM];
        ref[EVOT] = ref[SET][CL][EV];
        if (ref[SET][CL][CLCNS]) {
          ref[CLCNS] = A(ref[SET][CL][CLCNS]);
        } else {
          ref[CLCNS] = A([]);
        }
        ref[CLSCP] = ref[SET][CL][CLSCP];
        ref[CLVSB] = ref[SET][CL][VSB];
      }
      delete ref[SET];
    }
    return this._super(...arguments);
  },
  serialize() {
    let json = this._super(...arguments),
      ref = json.data.attributes;
    ref[SET] = {};
    if (TMP in ref) {
      ref[SET][TMPB] = {};
      ref[SET][TMPB][B] = ref[TMP];
    }
    if (TRANSLN in ref || TRANSLA in ref || TRANSLB in ref) {
      ref[SET][TRANSL] = {};
      ref[SET][TRANSL][N] = ref[TRANSLN];
      ref[SET][TRANSL][AM] = ref[TRANSLA] ? +ref[TRANSLA].replace(/,/g, '') : 0;
      ref[SET][TRANSL][B] = ref[TRANSLB];
    }

    if (PCB in ref || PCE in ref || PCC in ref || PCPS in ref) {
      ref[SET][PC] = {};
      ref[SET][PC][B] = ref[PCB];
      ref[SET][PC][PCEBACK] = ref[PCE];
      ref[SET][PC][PCC] = ref[PCC];
      ref[SET][PC][PCPSBACK] = ref[PCPS];
    }
    if (CCB in ref || CCA in ref || CCE in ref || CCT in ref || CCGAS in ref || CCG in ref || CCH in ref) {
      ref[SET][CC] = {};
      ref[SET][CC][B] = ref[CCB];
      ref[SET][CC][CCA] = ref[CCA];
      ref[SET][CC][CCE] = ref[CCE];
      ref[SET][CC][CCT] = ref[CCT];
      ref[SET][CC][CCGAS] = ref[CCGAS];
      ref[SET][CC][CCG] = ref[CCG];
      ref[SET][CC][CCH] = ref[CCH];
    }

    if (CLCB in ref || CLNF in ref || CLCNS in ref || CLSCP in ref) {
      ref[SET][CL] = {};
      ref[SET][CL][B] = ref[CLCB];
      ref[SET][CL][N] = ref[CLNF];
      ref[SET][CL][CLCNS] = ref[CLCNS];
      ref[SET][CL][CLSCP] = ref[CLSCP];
    }

    if (OLM in ref || DLM in ref) {
      ref[SET][CL][OLM] = ref[OLM];
      ref[SET][CL][DLM] = ref[DLM];
      ref[SET][CL][DL] = ref[DL];
      ref[SET][CL][CLM] = ref[CLM];
      ref[SET][CL][EV] = ref[EVOT];
    }

    if (ATMB in ref) {
      ref[SET][AT] = {};
      ref[SET][AT][B] = ref[ATMB];
    }

    if (TKTB in ref) {
      ref[SET][TKT] = {};
      ref[SET][TKT][B] = ref[TKTB];
      ref[SET][TKT][TLM] = ref[TLM];
      ref[SET][TKT][DL] = ref[DL];
      ref[SET][TKT][EV] = ref[EVTT];
      ref[SET][TKT][IL] = ref[IL];
      ref[SET][TKT][DLM] = ref[TKDL];
      ref[SET][TKT][CLM] = ref[TKCL];
    }

    if (!ref['card-type']) {
      ref['card-type'] = 'CreditCard';
    }
    delete ref[TMP];
    delete ref[TRANSLN];
    delete ref[TRANSLA];
    delete ref[TRANSLB];
    delete ref[PCB];
    delete ref[PCE];
    delete ref[PCC];
    delete ref[PCPS];
    delete ref[CCB];
    delete ref[CCA];
    delete ref[CCE];
    delete ref[CCT];
    delete ref[CCGAS];
    delete ref[CCG];
    delete ref[CCH];
    delete ref[CLCB];
    delete ref[CLNF];
    delete ref[CLSCP];
    delete ref[CLCNS];
    delete ref[DL];
    delete ref[DLM];
    delete ref[ATMB];
    delete ref[TKTB];
    delete ref[OLM];
    delete ref[EVOT];
    delete ref[EVTT];
    delete ref[CLM];
    delete ref[IL];
    delete ref[TKDL];
    delete ref[TKCL];
    delete ref[TLM];
    this._cleanFields(ref);
    return json;
  }
});
