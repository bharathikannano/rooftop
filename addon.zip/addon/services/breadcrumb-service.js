import { computed } from '@ember/object';
import Service, { inject as service } from '@ember/service';

export default Service.extend({
  i18n: service(),
  breadcrumbEntries: computed(function() {
    return [
      {
        'menu-item-id': '100001',
        'menu-item-name': this.get('i18n')
          .t('ServiceRequest.LANDINGPAGE.tabText.createRequest')
          .toString(),
        'action-url': 'serviceRequest.new-request',
        'menu-items': []
      },
      {
        'menu-item-id': '100002',
        'menu-item-name': this.get('i18n')
          .t('ServiceRequest.LANDINGPAGE.tabText.status')
          .toString(),
        'action-url': 'serviceRequest.status',
        'menu-items': []
      },
      {
        'menu-item-id': '100003',
        'menu-item-name': this.get('i18n')
          .t('ServiceRequest.LANDINGPAGE.help&usefulLinks')
          .toString(),
        'action-url': 'serviceRequest.new-request',
        'query-param': 'help-and-useful-links',
        'menu-items': []
      }
    ];
  })
});
