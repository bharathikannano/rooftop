/* eslint-disable no-useless-escape */

import { isEmpty } from '@ember/utils';
import Service, { inject as service } from '@ember/service';

export default Service.extend({
  i18n: service(),
  customerInfo: service(),
  init() {
    this._super();
    this.set('errorList', [
      { key: 'CSL-CC-301', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-301' },
      { key: 'CSL-CC-302', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-302' },
      { key: 'CSL-CC-303', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-303' },
      { key: 'CSL-CC-304', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-304' },
      { key: 'CSL-CC-305', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-305' },
      { key: 'CSL-CC-306', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-306' },
      { key: 'CSL-CC-307', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-307' },
      { key: 'CSL-CC-308', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-308' },
      { key: 'CSL-CC-309', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-309' },
      { key: 'CSL-CC-310', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-310' },
      { key: 'CSL-CC-311', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-311' },
      { key: 'CSL-CC-312', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-312' },
      { key: 'CSL-CC-313', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-313' },
      { key: 'CSL-CC-314', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-314' },
      { key: 'CSL-CC-315', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-315' },
      { key: 'CSL-CC-316', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-316' },
      { key: 'CSL-CC-422', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-422' },
      { key: 'CSL-CC-423', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-423' },
      { key: 'CSL-CC-409', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-409' },
      { key: 'CSL-CC-417', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-417' },
      { key: 'CSL-CC-407', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-407' },
      { key: 'CSL-CC-416', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-416' },
      { key: 'CSL-CC-415', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-415' },
      { key: 'CSL-CC-405', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-405' },
      { key: 'CSL-CC-414', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-414' },
      { key: 'CSL-CC-404', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-404' },
      { key: 'CSL-CC-413', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-413' },
      { key: 'CSL-CC-403', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-403' },
      { key: 'CSL-CC-412', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-412' },
      { key: 'CSL-CC-402', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-402' },
      { key: 'CSL-CC-411', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-411' },
      { key: 'CSL-CC-401', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-401' },
      { key: 'CSL-CC-410', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-410' },
      { key: 'CSL-CC-418', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-418' },
      { key: 'CSL-OTP-1024', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-OTP-1024' },
      { key: 'CSL-OTP-1026', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-OTP-1026' },
      { key: 'CSL-OTP-1328', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-OTP-1328' },
      { key: 'CSL-SEC-519', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-SEC-519' },
      { key: '1308', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.1308' },
      { key: '1307', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.1307' },
      { key: 'CSL-CC-324', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-324' },
      { key: 'CSL-CC-325', value: 'ServiceRequest.CREDITCARD_ERROR_MAP.CSL-CC-325' }
    ]);
  },
  errorHandler(scope) {
    let creditCardCSL = 'ERR_CSL_CREDIT_CARDS_CUSTOMER_NOT_FOUND';
    let debitCardCSL = 'ERR_CSL_DEBIT_CARDS_CUSTOMER_NOT_FOUND';
    let debitCardCSL202 = 'CSL-DEBIT-CARD-202';
    let debitCardsCSL202 = 'ERR_CSL_DEBIT_CARDS_202';
    let debitCardsCSL218 = 'ERR_CSL_DEBIT_CARDS_218';
    let msgContent =
      this.get('customerInfo.countryName') == 'SG' || this.get('customerInfo.countryName') == 'MY'
        ? this.get('customerInfo.countryName') + '.content'
        : 'content';
    if (scope.get('CreditCardErrorcheck') || scope.get('DebitCardErrorcheck')) {
      if (scope.get('creditCardsDisplay') == 'true' && scope.get('debitCardsDisplay') == 'true') {
        if (
          scope.get('creditCardStatus') != 'CreditCardSuccess' &&
          scope.get('debitCardStatus') != 'DebitCardSuccess'
        ) {
          if (
            scope.get('CreditCardErrorcheck') == creditCardCSL &&
            (scope.get('DebitCardErrorcheck') == debitCardCSL ||
              scope.get('DebitCardErrorcheck') == debitCardCSL202 ||
              scope.get('DebitCardErrorcheck') == debitCardsCSL202 ||
              scope.get('DebitCardErrorcheck') == debitCardsCSL218)
          ) {
            scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.nocard.header'));
            scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.nocard.' + msgContent));
          } else {
            this.systemErrorPopup(scope);
          }
        } else {
          if (
            (scope.get('debitCardDataLength') == 0 && scope.get('CreditCardErrorcheck') == creditCardCSL) ||
            (scope.get('creditCardDataLength') == 0 &&
              (scope.get('DebitCardErrorcheck') == debitCardCSL ||
                scope.get('DebitCardErrorcheck') == debitCardCSL202 ||
                scope.get('DebitCardErrorcheck') == debitCardsCSL202 ||
                scope.get('DebitCardErrorcheck') == debitCardsCSL218))
          ) {
            scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.nocard.header'));
            scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.nocard.' + msgContent));
          } else if (scope.get('CreditCardErrorcheck') == creditCardCSL) {
            scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.credit.header'));
            scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.credit.' + msgContent));
          } else if (
            scope.get('DebitCardErrorcheck') == debitCardCSL ||
            scope.get('DebitCardErrorcheck') == debitCardCSL202 ||
            scope.get('DebitCardErrorcheck') == debitCardsCSL202 ||
            scope.get('DebitCardErrorcheck') == debitCardsCSL218
          ) {
            scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.debit.header'));
            scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.debit.' + msgContent));
          } else {
            scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.errorcard.header'));
            this.get('customerInfo.countryName') == 'AE'
              ? scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.errorcard.content.AE'))
              : this.get('customerInfo.countryName') == 'VN'
              ? scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.errorcard.content.VN'))
              : scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.errorcard.content'));
          }
        }
      } else {
        if (scope.get('creditCardsDisplay') == 'true') {
          if (scope.get('CreditCardErrorcheck') == creditCardCSL) {
            scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.credit.header'));
            scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.credit.' + msgContent));
          } else {
            this.systemErrorPopup(scope);
          }
        } else {
          if (
            scope.get('DebitCardErrorcheck') == debitCardCSL ||
            scope.get('DebitCardErrorcheck') == debitCardCSL202 ||
            scope.get('DebitCardErrorcheck') == debitCardsCSL202 ||
            scope.get('DebitCardErrorcheck') == debitCardsCSL218
          ) {
            scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.debit.header'));
            scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.debit.' + msgContent));
          } else {
            this.systemErrorPopup(scope);
          }
        }
      }
    } else if (scope.get('creditCardsDisplay') == 'true' && scope.get('debitCardsDisplay') == 'true') {
      if (scope.get('debitCardDataLength') > 0 && scope.get('creditCardDataLength') == 0) {
        scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.credit.header'));
        scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.credit.' + msgContent));
      } else if (scope.get('debitCardDataLength') == 0 && scope.get('creditCardDataLength') > 0) {
        scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.debit.header'));
        scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.debit.' + msgContent));
      }
    }
  },

  creditCardErrorHandler(scope) {
    if (scope.get('creditCardStatus') != 'CreditCardSuccess') {
      if (scope.get('creditCardStatus') == 'emptyAndNoError') {
        scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.errorcard.header'));
        scope.set(
          'nocardsContent',
          this.get('customerInfo.countryName') == 'VN'
            ? this.get('i18n').t('ServiceRequest.COMMON.errorcard.content.VN')
            : this.get('i18n').t('ServiceRequest.COMMON.errorcard.content')
        );
      } else if (scope.get('CreditCardErrorcheck') == 'ERR_CSL_CREDIT_CARDS_CUSTOMER_NOT_FOUND') {
        scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.credit.header'));
        scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.credit.content'));
      } else if (scope.get('creditCardStatus') == 'CreditCardError') {
        scope.set('nocardsTitle', this.get('i18n').t('ServiceRequest.COMMON.credit.header'));
        scope.set('nocardsContent', this.get('i18n').t('ServiceRequest.COMMON.credit.content'));
        let errorPath = this.getError(scope.CreditCardErrorcheck);
        if (errorPath.length > 0) {
          let errorMsg = errorPath[0].value;
          scope.set('message', this.get('i18n').t(errorMsg));
          this.pageErrorPopup(scope);
        } else {
          this.systemErrorPopup(scope);
        }
      }
    } else {
      let errorPath = this.getError(scope.CreditCardErrorcheck);
      if (errorPath.length > 0) {
        let errorMsg = errorPath[0].value;
        scope.set('errorMessage', this.get('i18n').t(errorMsg));
      } else {
        this.systemErrorPopup(scope);
      }
    }
  },

  getError: function(errorCode) {
    let objError = this.get('errorList').filter(option => {
      return option.key == errorCode;
    });
    return objError;
  },

  systemErrorPopup(scope) {
    let countryCode = this.get('customerInfo.countryName');
    let errorRiskCode = (scope.get('errorRiskCode') ? scope.get('errorRiskCode') : null);
    let message = scope.get('i18n').t('ServiceRequest.COMMON.genericError.' + countryCode),
      title = scope.get('i18n').t('ServiceRequest.COMMON.systemError.title');
    if (scope.routeName == 'card-block.select') {
      message = scope.get('i18n').t('ServiceRequest.COMMON.genericError.' + countryCode + 'CB', {
        default: 'ServiceRequest.COMMON.genericError.' + countryCode
      });
    } else if (
      scope.routeName === 'card-replacement.select' ||
      scope.routeName === 'credit-activation' ||
      scope.routeName === 'credit-pin-change'
    ) {
      message = scope.get('i18n').t('ServiceRequest.COMMON.genericError.' + countryCode + 'CR', {
        default: 'ServiceRequest.COMMON.genericError.' + countryCode
      });
    }else if (errorRiskCode && errorRiskCode === "CSL-CASA-527") {
      message = scope.get('i18n').t(`ServiceRequest.COMMON.genericError.${countryCode}RISK`, {
        default: `ServiceRequest.COMMON.genericError.${countryCode}`
      });
    }
    scope
      .get('rdcModalManager')
      .showDialogModal({
        level: 'warning',
        message,
        title,
        acceptButtonLabel: scope.get('i18n').t('ServiceRequest.COMMON.button.cancelrequest'),
        iconClass: 'service-journey-info-icon',
        popupClass: 'service-journey-system-error-popup'
      })
      .then(() => {
        if (isEmpty(scope.transitionTo)) {
          scope.transitionToRoute('serviceRequest.new-request');
        } else {
          scope.transitionTo('serviceRequest.new-request');
        }
      })
      .catch(() => {
        if (isEmpty(scope.transitionTo)) {
          scope.transitionToRoute('serviceRequest.new-request');
        } else {
          scope.transitionTo('serviceRequest.new-request');
        }
      });
  },

  pageErrorPopup(scope) {
    let title = scope.get('i18n').t('ServiceRequest.COMMON.systemError.title');
    let message = scope.get('message');
    scope
      .get('rdcModalManager')
      .showDialogModal({
        level: 'error',
        message,
        title,
        acceptButtonLabel: scope.get('i18n').t('ServiceRequest.COMMON.button.ok'),
        iconClass: 'service-journey-system-error-icon',
        popupClass: 'service-journey-system-error-popup'
      })
      .then(() => {})
      .catch(() => {});
  }
});
