import { isEmpty } from '@ember/utils';
import Service, { inject as service } from '@ember/service';

export default Service.extend({
  queries: service('customer-info'),
  routing: service('-routing'),

  callForData(model) {
    let creditCardBlock = [];
    let debitCardBlockUnBlock = [];
    let creditCardMemoBlock = [];
    let relType = '';
    let relId = '';
    let operationName = '';
    let isCritical = '';
    let serviceType = '';
    let africanCty = ['KE', 'BW', 'GH', 'UG', 'ZM', 'ZW', 'TZ', 'NG'];
    if (this.get('routing.currentRouteName') == 'rdc-ui-eng-service-requests.card-block.confirm') {
      operationName = 'CARDBLK';
      isCritical = 'true';
      africanCty.indexOf(this.get('queries.countryName')) != -1
        ? (serviceType = 'CARDPRO')
        : (serviceType = 'CARDPROC');
    } else if (
      this.get('routing.currentRouteName') == 'rdc-ui-eng-service-requests.debitcard-new-replacement.confirm'
    ) {
      if (!isEmpty(model) && isEmpty(model.selectedDebitCardRep)) {
        (operationName = 'CARDISSUE'), (isCritical = 'false');
        serviceType = 'CRDISSUE';
      } else {
        (operationName = 'DCCARDREPLACE'), (isCritical = 'false');
        serviceType = 'CARDRPL';
      }
    } else {
      this.get('queries.countryName').toLowerCase() == 'hk'
        ? (operationName = 'CCCARDREPLACE')
        : (operationName = 'CARDREPLACE');
      isCritical = 'false';
      serviceType = 'CARDRPL';
    }

    if (!isEmpty(model[0]) && !isEmpty(model[0].selectedCard)) {
      model[0].selectedCard.forEach((item, index) => {
        relType = item.data.relType;
        relId = item.data.relId;
        let embosserInfo;
        if (
          this.get('queries.countryName') !== 'VN' &&
          this.get('routing.currentRouteName') != 'rdc-ui-eng-service-requests.card-block.confirm' &&
          item.data.cardEmbossingInfos != undefined
        ) {
          let embosserInfoData = [];
          item.data.cardEmbossingInfos.forEach((data, index) => {
            embosserInfoData[index] = {
              issueNum: data['issue-num'],
              embosserName: data['embosser-name'],
              cardSeqNum: data['card-sequence-num']
            };
          });
          embosserInfo = embosserInfoData;
        } else if (
          this.get('queries.countryName') === 'VN' &&
          this.get('routing.currentRouteName') === 'rdc-ui-eng-service-requests.card-block.confirm' &&
          item.data.cardEmbossingInfos !== undefined
        ) {
          let embosserInfoData = [];
          item.data.cardEmbossingInfos.forEach((data, index) => {
            embosserInfoData[index] = {
              embosserName: data['embosser-name']
            };
          });
          embosserInfo = embosserInfoData;
        }
        creditCardBlock[index] = {
          cardNumber: item.data.cardNum,
          currBlockCode: item.data.blockCode,
          cardExpiryDate: item.data.expDt,
          reasonCode: model[0].selectedReasonId,
          cardVariant: item.data.variant,
          franchise: item.data.franchise,
          embosserInfo: embosserInfo
        };
        creditCardMemoBlock[index] = {
          cardNumber: item.data.cardNum
        };
      });
    }

    if (!isEmpty(model[0]) && !isEmpty(model[0].selectedDebitCard)) {
      model[0].selectedDebitCard.forEach(function(item, index) {
        relType = item.data.relType;
        relId = item.data.relId;
        debitCardBlockUnBlock[index] = {
          debitCardNumber: item.data.cardNum,
          cardSequenceNo: item.data.cardSeq,
          transactionSequenceNo: '',
          reasonCode: model[0].selectedReasonId,
          cardProductType: item.data.cardTypeCd
        };
      });
    }

    if (!isEmpty(model) && !isEmpty(model.accData)) {
      let item = [];
      !isEmpty(model.selectedDebitCardRep) ? (item = model.selectedDebitCardRep) : '';
      let primaryAccountNumber,
        subsidaryAccountNumber1,
        subsidaryAccountNumber2,
        primaryAccountType,
        subsidaryprimaryAccountType1,
        subsidaryprimaryAccountType2;
      model.accData.forEach(data => {
        relType = data.get('relType');
        relId = data.get('relId');
        if (!isEmpty(data.get('isAccType'))) {
          data.get('isAccType') == 'Primary'
            ? ((primaryAccountNumber = data.get('accountNumber')), (primaryAccountType = data.get('productCode')))
            : '';
          data.get('isAccType') == 'other-account-active OtherAccount1'
            ? ((subsidaryAccountNumber1 = data.get('accountNumber')),
              (subsidaryprimaryAccountType1 = data.get('productCode')))
            : '';
          data.get('isAccType') == 'other-account-active OtherAccount2'
            ? ((subsidaryAccountNumber2 = data.get('accountNumber')),
              (subsidaryprimaryAccountType2 = data.get('productCode')))
            : '';
        }
      });

      debitCardBlockUnBlock = {
        debitCardNumber: item.cardNum,
        cardSequenceNo: item.cardSeq,
        transactionSequenceNo: '',
        cardType: isEmpty(model.selectedDebitCardRep) ? '' : model.selectedDebitCardRep.cardTypeCd,
        cardProductType: model.selectedCardType.data.type,
        cardSubType: model.cardNewDesign['sub-type'] == 'N/A' ? '' : model.cardNewDesign['sub-type'],
        primaryAccountNumber: primaryAccountNumber,
        subsidiaryAccountNumber1: subsidaryAccountNumber1,
        subsidiaryAccountNumber2: subsidaryAccountNumber2,
        primaryAccountType: primaryAccountType,
        subsidiaryAccountType1: subsidaryprimaryAccountType1,
        subsidiaryAccountType2: subsidaryprimaryAccountType2,
        cardLanguageCode: model.checkBoxValue == 'Chinese' ? 'C' : 'E'
      };
    }

    return {
      isCritical: isCritical,
      serviceType: serviceType,
      createdBy: relId,
      country: this.get('queries.countryName'),
      payload: {
        serviceRequests: {
          operationName: operationName,
          targetProcessID: '',
          customerDetails: {
            relationshipType: relType,
            relationshipNo: relId
          },
          creditCardBlock,
          creditCardMemoBlock,
          debitCardBlockUnBlock
        }
      },
      retryCount: 0,
      relNumber: relId,
      status: 'INIT'
    };
  }
});
