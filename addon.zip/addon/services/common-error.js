import Service from '@ember/service';

export default Service.extend({
  init() {
    this._super();
    this.set('errorList', [
      { key: '1406', value: 'ServiceRequest.COMMONERROR.CSL-1406' },
      { key: '1344', value: 'ServiceRequest.COMMONERROR.CSL-1344' },
      { key: '1328', value: 'ServiceRequest.COMMONERROR.CSL-1328' },
      { key: '1320', value: 'ServiceRequest.COMMONERROR.CSL-1320' },
      { key: '1318', value: 'ServiceRequest.COMMONERROR.CSL-1318' },
      { key: '1303', value: 'ServiceRequest.COMMONERROR.CSL-1303' },
      { key: '1302', value: 'ServiceRequest.COMMONERROR.CSL-1302' },
      { key: '1304', value: 'ServiceRequest.COMMONERROR.CSL-1304' },
      { key: '1252', value: 'ServiceRequest.COMMONERROR.CSL-1252' },
      { key: '1225', value: 'ServiceRequest.COMMONERROR.CSL-1225' },
      { key: '1200', value: 'ServiceRequest.COMMONERROR.CSL-1200' },
      { key: '1212', value: 'ServiceRequest.COMMONERROR.CSL-1212' },
      { key: '1211', value: 'ServiceRequest.COMMONERROR.CSL-1211' },
      { key: '1034', value: 'ServiceRequest.COMMONERROR.CSL-1034' },
      { key: '1032', value: 'ServiceRequest.COMMONERROR.CSL-1032' },
      { key: '1702', value: 'ServiceRequest.COMMONERROR.CSL-1702' }
    ]);
  },
  //Get Error path
  getError: function(errorCode) {
    let objError = this.get('errorList').filter(option => {
      return option.key == errorCode;
    });
    return objError;
  }
});
