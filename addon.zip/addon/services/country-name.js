import Service from '@ember/service';

export default Service.extend({
  countryName: 'IN',
  customerId: '0199385223199368',
  requestId: '458567456745',
  contentType: 'text/plain',
  channel: 'CEMS'
});
