import { isNone, isEmpty } from '@ember/utils';
import Service, { inject as service } from '@ember/service';

export default Service.extend({
  queries: service('customer-info'),
  store: service(),
  global: window,
  init() {
    this._super();
    this.setProperties({
      encryptionInput: {},
      creditCardPostData: {},
      pinChangePostData: {},
      needs: ['application']
    });
  },
  cardnumberMasking(params) {
    let maskLength = Math.abs(params[1].showFirst + params[1].showLast - 16);
    let maskX = new Array(maskLength + 1).join('X');
    let cardNum = params[0].split('');
    cardNum.splice(params[1].showFirst, maskLength, maskX);
    cardNum = cardNum.join('');
    return cardNum;
  },
  getFormData(selectedCardObject, formData) {
    let obj = {
      showFirst: 6,
      showLast: 4
    };
    if (!isNone(selectedCardObject) && !isNone(formData)) {
      //Prepare Encryption Combination for Encrypting Property (encCardPin & encCardInfo)
      if (!isEmpty(selectedCardObject)) {
        this.encryptionInput['enterPin'] = formData.enterPin;
        this.encryptionInput['reEnterPin'] = formData.reEnterPin;
        this.encryptionInput['cardNumber'] = selectedCardObject.get('cardNum');
        this.encryptionInput['oldPin'] = '';
        this.encryptionInput['cardExpiryDate'] = '20140202';
        this.encryptionInput['cardEmbossedName'] = selectedCardObject.get('embossedName') || '';
        this.encryptionInput['dob'] = '';
        this.encryptionInput['cvv'] = '';
        this.encryptionInput['nric'] = '';
        this.encryptionInput['creditLimit'] = '';
      }
    }

    if (!isNone(this.encryptionInput)) {
      //Apply Pattern for sensitive fields(encCardPin & encCardInfo)
      let encyrptedFields = this.applyPatternForPinAndCardInfo(this.encryptionInput);

      //Preparing Form data
      this.creditCardPostData.operationName = 'CCPINACTV';
      this.creditCardPostData.cardNum = this.cardnumberMasking([selectedCardObject.get('cardNum'), obj]);
      this.creditCardPostData.cardProductType = selectedCardObject.get('cardProductType');
      this.creditCardPostData.embossedName = selectedCardObject.get('embossedName') || '';

      this.pinChangePostData = {};
      this.pinChangePostData['sequence-number'] = selectedCardObject.get('sequenceNumber');
      this.pinChangePostData['enc-card-pin'] = encyrptedFields.encCardPin;
      this.pinChangePostData['enc-card-info'] = encyrptedFields.encCardInfo;
      this.pinChangePostData['card-type'] = 'CREDIT';
      this.pinChangePostData['card-activation-flag'] = 'Yes';
    }
    this.creditCardPostData['customerId'] = selectedCardObject['id'];
    return { creditCardPostData: this.creditCardPostData, pinChangePostData: this.pinChangePostData };
  },

  applyPatternForPinAndCardInfo(encryptionInput) {
    let pinToEncrypt =
      '@@encryptionStart' +
      encryptionInput.cardNumber +
      '_-_' +
      encryptionInput.oldPin +
      '_-_' +
      encryptionInput.enterPin +
      '_-_' +
      encryptionInput.reEnterPin +
      '_-_' +
      encryptionInput.cardExpiryDate +
      '@@encryptionEnd';
    let cardToEncrypt =
      '@@encryptionStart' +
      encryptionInput.cardNumber +
      '_-_' +
      encryptionInput.dob +
      '_-_' +
      encryptionInput.cardExpiryDate +
      '_-_' +
      encryptionInput.cvv +
      '_-_' +
      encryptionInput.nric +
      '_-_' +
      encryptionInput.cardEmbossedName +
      '_-_' +
      encryptionInput.creditLimit +
      '@@encryptionEnd';

    return {
      encCardPin: pinToEncrypt,
      encCardInfo: cardToEncrypt
    };
  }
});
