import { A } from '@ember/array';
import { isEmpty } from '@ember/utils';
import Service, { inject as service } from '@ember/service';

export default Service.extend({
  queries: service('customer-info'),

  callForData(pageData) {
    //pageData= this.controllerFor('credit-balance-refund.request-confirm').get('cardData')[0];
    let selectedFromCard = pageData[0].selectedCard[0];

    let today = new Date();
    let currDate =
      today.getFullYear() +
      '-' +
      (today.getMonth() + 1) +
      '-' +
      today.getDate() +
      'T' +
      today.getHours() +
      ':' +
      today.getMinutes() +
      ':' +
      today.getSeconds() +
      '.' +
      today.getMilliseconds();

    let postData = {
      paymentType: 'OAFT',
      subPaymentType: 'CCBR',
      settlementType: '',
      paymentScheme: 'eOps',
      txnCur: selectedFromCard.get('currencyCode'),
      txnAmount: '',
      dtTransfer: currDate,
      pop: 'excess amount in my card',
      dbtAccName: selectedFromCard.get('desc'),
      dbtAccNumber: selectedFromCard.get('cardNum'),
      dbtAccCur: selectedFromCard.get('currencyCode'),
      dbtAccType: 'CC',
      cdtAccName: '',
      cdtAccNumber: '',
      cdtAccCur: '',
      cdtAccType: '',
      excessAmount: selectedFromCard.get('excessAmount'),
      reasonToRefund: pageData[0].selectedCard.refundReasonBackendName,
      otherReason: '',
      frtlnUserType: pageData[0].userGroup
    };

    if (pageData[0].refundToCC) {
      let selectedCardArray = A();
      pageData[0].toCardList.forEach(item => {
        selectedCardArray.push(item);
      });
      let selectedToCard = selectedCardArray.filterBy('isSelected');
      postData.txnAmount = selectedToCard[0].get('amountEntered');
      postData.cdtAccName = selectedToCard[0].get('desc');
      postData.cdtAccNumber = selectedToCard[0].get('cardNum');
      postData.cdtAccCur = selectedToCard[0].get('currencyCode');
      postData.cdtAccType = 'CC';
      postData.settlementType = 'CC';
    } else if (pageData[0].refundToCasa) {
      let selectedCasaArray = A();
      pageData[0].casaDetails.forEach(item => {
        selectedCasaArray.push(item);
      });
      let selectedCasa = selectedCasaArray.filterBy('isSelected');
      postData.txnAmount = selectedCasa[0].get('amountEntered');
      if (!isEmpty(selectedCasa[0].get('productDescription'))) {
        postData.cdtAccName = selectedCasa[0].get('productDescription');
      } else {
        postData.cdtAccName = selectedCasa[0].get('subProductDescription');
      }
      postData.cdtAccNumber = selectedCasa[0].get('accountNumber');
      postData.cdtAccCur = selectedCasa[0].get('currencyCode');
      postData.cdtAccType = 'CASA';
      postData.settlementType = 'CASA';
    } else if (pageData[0].refundToCO) {
      postData.txnAmount = selectedFromCard.get('amountEntered');
      postData.settlementType = 'CORD';
    }
    return postData;
  }
});
