import Service, { inject as service } from '@ember/service';

export default Service.extend({
  queries: service('customer-info'),

  callForData(pageData) {
    let requestType = '';
    let feeType = '';
    let reason = '';
    let frontlineNotes = '';
    let credicardRequest = [];
    let creditCardTransactionsReversl = [];
    let frontLineUserType = '';
    let basicVerification = '';
    let addnVerification = '';

    if (pageData[0] != null) {
      if (pageData[0].requestType == 'REVERSAL') {
        pageData[0].selectedCardData.forEach((cardDetails, index) => {
          cardDetails.selectedTransDetails.forEach((trasnsactionSelected, indexVal) => {
            creditCardTransactionsReversl[indexVal] = {
              'txn-ref-no': '',
              'origin-txn-amt': trasnsactionSelected.data.originTxnAmt,
              'transaction-amount': trasnsactionSelected.data.transactionFlag
                ? trasnsactionSelected.data.transacOrgnAmount
                : trasnsactionSelected.data.transactionAmount,
              'partialrev-txn-amt': trasnsactionSelected.data.partialrevTxnAmt,
              'partialrev-txn-date': '',
              desc: trasnsactionSelected.data.desc,
              'txn-date': trasnsactionSelected.data.txnDate,
              'txn-code': trasnsactionSelected.data.txnCode,
              'sequence-number': '',
              'batch-number': '',
              'fee-sub-type-code': trasnsactionSelected.data.feeSubTypeCode,
              'equivalent-reward-points': {
                rewardsPoints:
                  !pageData[0].customerFlowFlag && trasnsactionSelected.data.equivalentRewardPoints
                    ? trasnsactionSelected.data.equivalentRewardPoints.rewardsPoints
                    : ''
              },
              'tp-txn-ref-no': trasnsactionSelected.data.tpTxnRefNo,
              'is-discount-transaction': trasnsactionSelected.data.isDiscountTransaction
            };
            if (this.get('queries.countryName') === 'BN') {
              creditCardTransactionsReversl[indexVal]['primary-supp-ind'] = trasnsactionSelected.data.primarySuppInd
                ? trasnsactionSelected.data.primarySuppInd
                : '';
            }
          });
          credicardRequest[index] = {
            'card-num': cardDetails.cardNumber,
            'card-type': cardDetails.cardType,
            'currency-code': cardDetails.currencyCode,
            rewardpointdemption: cardDetails.rewardPointRedepmtion,
            'block-code': cardDetails.blockCode,
            'available-customer-rewardpoint': cardDetails.availableCustomerRewardpoint,
            'card-eligibility': {
              cardEligibilityFlag: cardDetails.eligibleFlag,
              eligibilityOverrideFlag: cardDetails.overRideFlag
            },
            'is-mask-card-no': cardDetails.maskFlag ? 'Y' : 'N',
            'card-reward-category': cardDetails.cardRewardCategory,
            'card-groupable-fee-types': cardDetails.cardGroupableFeeTypes,
            'historical-txn-count': cardDetails.historicalTxnCount,
            'grp-acc-num': cardDetails.grpAccNum,

            cardtransactions: creditCardTransactionsReversl
          };
          creditCardTransactionsReversl = [];
        });
        requestType = pageData[0].requestType;
        feeType = pageData[0].postingData[0].feeTypeID;
        reason = pageData[0].reasonSelected;
        frontlineNotes = pageData[0].notes;
        frontLineUserType = this.get('queries.userGroup');
        addnVerification = this.get('queries.selectedAddVerification')
          ? this.get('queries.selectedAddVerification').key
          : '';
        basicVerification = this.get('queries.selectedBasicVerification')
          ? this.get('queries.selectedBasicVerification').key
          : '';
      }

      if (pageData[0].reversalcharge == 'CHARGE') {
        pageData[0].selectedCardData.forEach((cardDetails, index) => {
          let creditCardTransactionsCharge = [];
          creditCardTransactionsCharge[0] = {
            'txn-ref-no': '',
            'origin-txn-amt': '',
            'partialrev-txn-amt': '',
            'transaction-amount': cardDetails.textData,
            'partialrev-txn-date': '',
            desc: '',
            'txn-date': '',
            'txn-code': '',
            'sequence-number': '',
            'batch-number': '',
            'equivalent-reward-points': {
              rewardsPoints: ''
            },
            'tp-txn-ref-no': cardDetails.tpTxnRefNo
          };

          credicardRequest[index] = {
            'card-num': cardDetails.cardNumber,
            'card-type': cardDetails.cardType,
            'currency-code': cardDetails.currencyCode,
            rewardpointdemption: cardDetails.rewardPointRedepmtion,
            'block-code': cardDetails.blockCode,
            'available-customer-rewardpoint': cardDetails.availableCustomerRewardpoint,
            'card-eligibility': {
              cardEligibilityFlag: cardDetails.eligibleFlag,
              eligibilityOverrideFlag: cardDetails.overRideFlag
            },
            'is-mask-card-no': cardDetails.maskFlag ? 'Y' : 'N',
            cardtransactions: creditCardTransactionsCharge,
            'historical-txn-count': cardDetails.historicalTxnCount
          };
          creditCardTransactionsCharge = [];
        });
        requestType = pageData[0].reversalcharge;
        feeType = pageData[0].feeTypeID;
        reason = pageData[0].reasonSelected;
        frontlineNotes = pageData[0].notes;
        frontLineUserType = this.get('queries.userGroup');
        addnVerification = this.get('queries.selectedAddVerification')
          ? this.get('queries.selectedAddVerification').key
          : '';
        basicVerification = this.get('queries.selectedBasicVerification')
          ? this.get('queries.selectedBasicVerification').key
          : '';
      }
    }
    return {
      customerId: '',
      requestType: requestType,
      feeType: feeType,
      reason: reason,
      frontlineNotes: frontlineNotes,
      operationName: 'FEEWREQ',
      frtlnUserType: frontLineUserType,
      basicVerification: basicVerification,
      addnVerification: addnVerification,
      creditCardRequest: credicardRequest
    };
  }
});
