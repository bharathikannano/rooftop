import Service from '@ember/service';
export default Service.extend({
  //queryParams :['relId'],

  countryName: null,
  customerId: null,
  requestId: null,
  contentType: null,
  channel: null,
  sso: null,
  userId: null,
  cvUrlStatus: null,
  cvUrlType: null,
  cvUrlTime: null,
  sessionVaild: false,
  langId: null,
  ccProductType: null,

  cardMaskConfig() {
    let obj = {
      showFirst: 6,
      showLast: 4,
      spacingIndex: [4, 8, 12]
    };
    return obj;
  },
  loanMaskConfig() {
    let obj = {
      showFirst: 0,
      showLast: 4,
      spacingIndex: [0]
    };
    return obj;
  },
  cardMasking: function() {
    let noMask = ['SG', 'HK'];
    return noMask.indexOf(this.get('countryName')) === -1;
  },
  getCustomerInfo: function() {
    return this.getProperties('sso', 'countryName');
  },
  setSSO: function(ssoValue) {
    this.set('sso', ssoValue);
    window.ssoValue = ssoValue;
  },
  getSSO: function() {
    return window.ssoValue;
  },
  setuserId: function(userIdValue) {
    this.set('userId', userIdValue);
    window.userIdValue = userIdValue;
  },
  getuserId: function() {
    return window.userIdValue;
  },

  setcountryName: function(countryCodeValue) {
    this.set('countryName', countryCodeValue);
    window.countryCodeValue = countryCodeValue;
  },
  getcountryName: function() {
    return window.countryCodeValue;
  },

  setchannel: function(channelCodeValue) {
    this.set('channel', channelCodeValue);
    window.channelCodeValue = channelCodeValue;
  },
  getchannel: function() {
    return window.channelCodeValue;
  },

  setProductType: function(productType) {
    this.set('ccProductType', productType);
    this.ccProductType = productType;
  },

  getProductType: function() {
    return this.ccProductType;
  },

  validateKey: function() {
    let evt = window.event;
    let keys = window.event.key;
    let fieldExp = new RegExp('[^a-zA-Z0-9.,#\\n ]', 'g');
    if (fieldExp.test(keys)) {
      evt.preventDefault();
      evt.defaultPrevented = true;
    } else {
      return true;
    }
  }
});
