import Service from '@ember/service';
import CordovaPluginWrapper from 'rdc-ui-eng-service-requests/mixins/cordova-plugin-wrapper';

export default Service.extend(CordovaPluginWrapper, {
  pluginName: 'FirebaseAnalytics',

  logEvent(eventName, params) {
    this._exec('logEvent', [eventName, params]);
  }
});
